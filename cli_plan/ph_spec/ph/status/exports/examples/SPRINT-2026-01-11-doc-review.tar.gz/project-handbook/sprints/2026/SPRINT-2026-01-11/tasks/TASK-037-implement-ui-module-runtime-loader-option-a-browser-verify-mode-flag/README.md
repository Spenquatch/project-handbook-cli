---
title: Task TASK-037 - Implement: UI module runtime loader (Option A browser verify + mode flag)
type: task
date: 2026-01-11
task_id: TASK-037
feature: v2.1_ui-module-registry-discovery
session: task-execution
tags: [task, v2.1_ui-module-registry-discovery]
links: [../../../../features/v2.1_ui-module-registry-discovery/overview.md]
---

# Task TASK-037: Implement: UI module runtime loader (Option A browser verify + mode flag)

## Overview
- **Feature**: [v2.1_ui-module-registry-discovery](../../../../features/v2.1_ui-module-registry-discovery/overview.md)
- **Decision**: [FDR-v2_1_ui-module-registry-discovery-0002](../../../../features/v2.1_ui-module-registry-discovery/fdr/0002-nextjs-runtime-module-loading-strategy.md)
- **Story Points**: 3
- **Owner**: @spenser
- **Lane**: `module-registry/runtime`
- **Session**: `task-execution`

## Agent Navigation Rules
1. **Start work**: `pnpm -C project-handbook make -- task-status id=TASK-037 status=doing`
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: `pnpm -C project-handbook make -- task-status id=TASK-037 status=review`

## Context & Background
This task implements the accepted runtime loading posture:
- Option A (`browser-verify`): verify sha256 **before execute** in the browser and import via Blob URL ESM
- a mode flag exists from day 1 (`"browser-verify" | "server-verify"`) so the Option A → Option B transition is mechanical
- failures map to deterministic reason codes so the shell can render stable fallback UX and emit non-secret telemetry

Decision reference: [FDR-v2_1_ui-module-registry-discovery-0002](../../../../features/v2.1_ui-module-registry-discovery/fdr/0002-nextjs-runtime-module-loading-strategy.md).

## What You Are Building (contract summary)
- A single loader abstraction (`loadUiModule()`) under `v2/apps/tribuence-mini/src/lib/`
- `browser-verify` behavior:
  - fetch bytes from `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}` (same-origin, implemented by `TASK-030`)
  - compute sha256 and compare to `integritySha256`
  - on match: `Blob` → `URL.createObjectURL()` → dynamic `import()` (client-only)
- Export contract enforcement:
  - required: `default` (React component), `capabilityId` (string)
  - allowed additional exports: `panelTitle`, `panelVersion` (may be absent; loader must not fail if missing)
- Deterministic reason codes: `NOT_ALLOWLISTED`, `FETCH_404`, `FETCH_FAILED`, `HASH_MISMATCH`, `EVAL_ERROR`, `EXPORT_INVALID`

## Quick Start
```bash
# From repo root
pnpm -C project-handbook make -- task-status id=TASK-037 status=doing
cd project-handbook/sprints/current/tasks/TASK-037-implement-ui-module-runtime-loader-option-a-browser-verify-mode-flag/

# Follow implementation
cat steps.md              # Read implementation steps
cat commands.md           # Copy-paste commands
cat validation.md         # Validation approach
```

## Dependencies
Hard dependency (must be `done` before execution):
- `TASK-030` — provides `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}` (same-origin byte fetch route)

Operational/system dependencies (must exist for validation):
- `pnpm -C v2/apps/tribuence-mini test` works locally (Vitest runs in `environment: "node"`).

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.

## Evidence
All evidence for this task must be captured under `project-handbook/status/evidence/TASK-037/` (see `validation.md`).
