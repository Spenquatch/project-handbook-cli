---
title: DR-0007 — Module registry alignment with v3 roadmap
type: decision-register
date: 2026-01-12
tags: [decision-register, v2.1, module-registry, v3, alignment, entitlements, overlays, compliance]
links:
  - ../adr/0033-module-registry-alignment-with-v3-roadmap.md
  - ../features/v2.1_ui-module-registry-discovery/overview.md
  - ../features/v2.1_ui-module-registry-discovery/decision-register/DR-0001-ui-module-artifact-origin-and-publish-pipeline.md
  - ../features/v2.1_ui-module-registry-discovery/decision-register/DR-0002-nextjs-runtime-module-loading-strategy.md
  - ../features/v2_context-control-plane-schema/decision-register/DR-0001-context-control-plane-migration-and-consumption-contract.md
  - ../features/v3_capability-control-service-billing/overview.md
  - ../features/v3_provisioning-adapters-and-workflows/overview.md
  - ../features/v3_backstage-operator-surface/overview.md
  - ../features/v3_license-compliance-automation/overview.md
  - ../features/v3_client-customization-overlays/overview.md
  - ../status/evidence/TASK-028/index.md
---

# Decision Register Entry

### DR-0007 — Module registry alignment with v3 roadmap

**Decision owner(s):** v2/v3 platform (@spenser)  
**Date:** 2026-01-12  
**Status:** Accepted  
**Related docs:** `ADR-0033`, `TASK-028`, `DR-0001` (module origin), `DR-0002` (loader), `context DR-0001` (control-plane snapshot), v3 overviews

**Problem / Context**
- v2.1 is adding a UI module registry (artifact origin + publish pipeline + runtime loader) that is selected via Context control-plane manifests.
- The v3 roadmap introduces:
  - a capability control service (entitlements/billing) that drives enable/disable via Context,
  - provisioning workflows/adapters (status + audit),
  - an operator surface (Backstage),
  - license compliance automation,
  - client customization overlays.
- We need to choose a minimal alignment posture that avoids v2.1 dead ends while *not* designing or implementing v3 in this task.

**Evidence (repo inspection; no secrets)**
- v2.1 module origin + publish pipeline decision: `project-handbook/status/evidence/TASK-028/dr-0001.txt`
- v2.1 runtime loader decision: `project-handbook/status/evidence/TASK-028/dr-0002.txt`
- Context control-plane snapshot contract: `project-handbook/status/evidence/TASK-028/context-dr-0001.txt`
- v3 feature overviews reviewed: `project-handbook/status/evidence/TASK-028/v3-overviews.txt`
- Evidence index: `project-handbook/status/evidence/TASK-028/index.md`

**Option A — Keep v2.1 module delivery “dumb + content-addressed”; make v3 concerns additive in Context**
- **Pros:**
  - Aligns with existing accepted v2.1 decisions (content-addressed artifacts, same-origin fetch, integrity verification) without increasing surface area.
  - Keeps v3 entitlements/billing/provisioning as a *policy + desired-state* layer that writes to Context (no need to change module distribution mechanics).
  - Makes client overlays an additive composition concern (overlay descriptors + precedence rules) without baking tenant-specific mutations into module artifacts.
  - Leaves room for v3 compliance automation by requiring a place to attach metadata (provenance/license), without forcing enforcement in v2.1.
- **Cons:**
  - Provenance is weaker initially (sha256 integrity is strong, but “who produced this artifact” remains a separate concern).
  - Some future v3 gates (license posture, signer trust) may require a later migration if we only store minimal module manifests in Context.
- **Cascading implications:**
  - **Stable identifiers**: treat `moduleId` as stable and capability-aligned (the control-plane selects modules; modules should not invent their own “capability namespace”).
  - **Content-addressed artifacts remain the primitive**: module bytes are immutable and keyed by `{moduleId}/{version}/{integritySha256}` (no “latest”, no overwrite).
  - **Additive metadata only**: any v3 needs (entitlement reasons, overlay descriptors, license posture, provenance fields) must be introduced as additive fields in Context snapshot types and/or module manifests (no breaking changes to consumers).
  - **Policy stays out of the loader**: the runtime loader continues to enforce allowlist + integrity; entitlement decisions happen upstream in Context/control-service layers.
- **Risks:**
  - If v3 requires “trusted publisher” enforcement very early, retrofitting signature verification could increase lift (mitigate by reserving metadata fields now).
  - Overlay precedence ambiguity can cause nondeterministic UI if not formalized (mitigate by requiring explicit precedence rules in the control plane).
- **Unlocks:**
  - A clean layering model: v2.1 solves distribution + integrity; v3 solves entitlement + provisioning + overlays + compliance.
  - Minimizes rework: future v3 work can mostly add fields and services without invalidating v2.1 execution tasks.
- **Quick wins / low-hanging fruit:**
  - Document a “v3 compatibility checklist” as an execution gate for all v2.1 tasks (module ids, immutability, metadata extension points, overlay semantics).

**Option B — Introduce signed module releases + provenance/compliance gates in v2.1**
- **Pros:**
  - Strong supply-chain posture early: artifacts are not only integrity-checked, but also provenance-validated (trusted publisher/signature).
  - Provides a natural place to enforce license/compliance posture at publish time and/or serve time.
  - Reduces future v3 retrofit risk if v3 governance requires signatures/attestations as a baseline.
- **Cons:**
  - Adds key management, signing/verifying implementation, and operational complexity to v2.1 (higher scope than discovery/PoC intent).
  - Increases the number of moving parts in the runtime critical path (serve-time verification or client verification), potentially impacting performance and local dev ergonomics.
- **Cascading implications:**
  - Requires defining and storing a signed “module release descriptor” (e.g. `{moduleId, version, integritySha256, publisher, license, signature}`) and deciding where it lives (Context vs registry metadata).
  - Requires an explicit trust policy (“which publishers/signers are allowed”) and how that relates to module allowlists.
  - Requires deciding where enforcement occurs (CI gate, server route, client loader, or combinations).
- **Risks:**
  - Implementation complexity delays v2.1 delivery and could create churn if the signing scheme changes in v3.
  - Mistakes in trust policy or verification semantics can lead to false blocks or unsafe bypass.
- **Unlocks:**
  - A v3-ready governance baseline (trusted publishers + compliance metadata) with less future work.
- **Quick wins / low-hanging fruit:**
  - Start with CI-only signing of release descriptors and server-side verification before serving bytes, leaving client verification for later.

**Recommendation**
- **Recommended:** Option A — Keep v2.1 module delivery “dumb + content-addressed”; make v3 concerns additive in Context
- **Rationale:** v3 features are currently in “proposed” state, while v2.1 already has accepted decisions that minimize surface area and rely on content-addressed integrity. Option A keeps v2.1 execution small and makes v3 evolution additive (Context fields + new services), while still reserving explicit extension points for provenance/compliance/overlays so we don’t paint ourselves into a corner.

## v3 compatibility checklist (exhaustive; execution gate)

This checklist is the explicit “must remain true” contract that keeps v2.1 module registry work compatible with the v3 roadmap.

### A) Module artifacts and serving (registry/origin)
- [ ] **Immutability is real**: module artifacts are append-only and never overwritten.
- [ ] **Content-addressed URLs remain the primitive**: every module fetch URL includes `integritySha256` (no “latest” indirection).
- [ ] **Object key scheme stays stable**: `ui-modules/{moduleId}/{version}/{integritySha256}/index.mjs` (or a strictly additive extension that preserves existing keys).
- [ ] **Artifact format remains explicit and bounded**: v2.1 uses a single-file ESM `index.mjs`; any multi-file evolution must preserve content-addressing and allow immutable caching.
- [ ] **Browser never needs S3 access**: browsers fetch module bytes via a same-origin route (or a dedicated internal origin), not via S3 endpoints or signed S3 URLs.
- [ ] **Allowlist is enforced before any origin proxying**: unknown `moduleId` is rejected without enabling arbitrary key reads.
- [ ] **Input validation is strict**: `moduleId`, `version`, and `integritySha256` are validated (format + length) before any storage lookup.
- [ ] **Immutable caching is safe**: served module bytes set immutable cache headers because `integritySha256` makes the URL content-addressed.
- [ ] **Deterministic error semantics**: missing objects yield `404` (not `500`); error responses never include secrets.

### B) Runtime loader semantics (security + determinism)
- [ ] **Verify-before-execute posture is preserved**:
  - Preferred: client verifies sha256 before importing/executing (Option A in `DR-0002`).
  - If server verification is used later, the server must verify the requested hash before serving bytes.
- [ ] **Failure is panel-scoped and deterministic**: loader failures render a deterministic fallback state and never take down the whole shell.
- [ ] **Stable failure reason codes** exist and remain stable across v2.1 and v3 (`NOT_ALLOWLISTED`, `FETCH_404`, `FETCH_FAILED`, `HASH_MISMATCH`, `EVAL_ERROR`, `EXPORT_INVALID`).
- [ ] **Telemetry remains non-sensitive**: module load events include `{ moduleId, version, integritySha256, outcome, reasonCode, durationMs }` only (no credentials, no full URLs with secrets).
- [ ] **SSR boundary is explicit**: module execution is client-only; SSR must never evaluate remote module code.
- [ ] **CSP implications are explicit**: if `blob:` is required for verify-before-execute, CSP decisions must be recorded; if CSP disallows `blob:`, a verified server-serve mode must be used.

### C) Identity and versioning (capability alignment)
- [ ] **`moduleId` is stable and not tenant-specific**: overlays/customizations must not create per-tenant forks in IDs.
- [ ] **Module-to-capability alignment is explicit**: module exports include a `capabilityId` sanity check and UI wiring treats it as an invariant.
- [ ] **Versioning is explicit and pinned**: Context selects `{ moduleId, version, integritySha256 }`; “floating” versions are not used in runtime manifests.

### D) Context control-plane ownership (v3 services write policy; Context is source of truth)
- [ ] **Context remains the system-of-record** for workspace capability state and module manifests.
- [ ] **v3 control service drives desired state by writing to Context** (manifests) and observing Context status; it does not introduce a parallel gating surface.
- [ ] **Wrappers and UI gate off the same snapshot** (single canonical snapshot contract) and treat fetch failures as deterministic safe-gated behavior.
- [ ] **No provider secrets** are stored in or returned by Context snapshot surfaces; only references/IDs are permitted.

### E) Additive evolution is non-negotiable (schemas/contracts)
- [ ] **Context schema evolution stays additive**: new v3 fields (entitlements, overlays, compliance metadata) must be optional/empty-safe so older consumers keep working.
- [ ] **Snapshot remains empty-safe**: arrays default to empty; missing surfaces do not crash UI/wrappers.
- [ ] **Stable contract versioning**: contract files and types are versioned; breaking changes require an explicit ADR and a migration plan.

### F) v3 entitlements/billing compatibility
- [ ] **Entitlements are policy, not distribution**: billing/plan logic never changes how bytes are fetched; it only changes what manifests select and what state is shown.
- [ ] **Deterministic enable/disable events**: control actions are idempotent and produce deterministic audit records suitable for billing and operator surfaces.

### G) v3 provisioning/workflow compatibility
- [ ] **Provisioning status is reflected back into Context** so UI/wrappers can gate deterministically off a single snapshot.
- [ ] **Job history and runbook linkage are representable** (IDs/links), enabling Backstage/operator tooling without schema redesign.

### H) v3 overlays compatibility (client customization)
- [ ] **Overlays are declarative, versioned, and validated**; unsafe overlays are rejected.
- [ ] **Overlay application is deterministic**: precedence/layering rules are explicit and stable.
- [ ] **Overlays cannot bypass capability gating** and cannot introduce cross-tenant leakage.
- [ ] **Overlays do not require mutating module bytes**: customization is expressed as separate overlay state/artifacts, not per-tenant module rebuilds.

### I) v3 compliance compatibility (license governance)
- [ ] **License posture is representable**: module/capability metadata can carry license classification and governance pointers.
- [ ] **Compliance artefacts can be deterministic**: future “reactive source provision” and compliance reports can reference module/capability metadata without changing the module delivery contract.
- [ ] **Copyleft isolation posture is preserved**: platform code remains API-only with copyleft services; module registry does not introduce code linking across license boundaries.

### J) Auditability and operator experience
- [ ] **Everything is traceable**: for any workspace, operators can determine which `{ moduleId, version, integritySha256 }` was selected and served.
- [ ] **Evidence/runbook linkage is possible**: metadata surfaces can carry stable runbook/evidence links without exposing secrets.

**Follow-up tasks (explicit)**
- Update `project-handbook/features/v2.1_ui-module-registry-discovery/implementation/IMPLEMENTATION.md` with a v3 compatibility checklist (execution gate) that all v2.1 tasks must satisfy.
- Ensure upcoming v2.1 execution tasks treat these as invariants:
  - content-addressed/immutable module artifacts,
  - capability-aligned module IDs,
  - additive-only Context schema evolution for entitlements/overlays/compliance metadata,
  - policy in Context/control-service layers (not in the loader).
- Promote this DR to `ADR-0033` and create execution tasks to reserve/implement:
  - additive metadata fields for provenance and license posture in Context module manifests,
  - overlay descriptor + precedence semantics in Context snapshot types,
  - checklist enforcement points (contracts/tests) so future work can’t drift silently.
  - Created in this sprint:
    - `TASK-040` (contract: v3-ready UI module manifest metadata fields, v1)
    - `TASK-041` (contract: v3 overlay descriptors + precedence, v1)

**Operator/user approval**
- Approved: **Option A** (operator approval received 2026-01-12).
