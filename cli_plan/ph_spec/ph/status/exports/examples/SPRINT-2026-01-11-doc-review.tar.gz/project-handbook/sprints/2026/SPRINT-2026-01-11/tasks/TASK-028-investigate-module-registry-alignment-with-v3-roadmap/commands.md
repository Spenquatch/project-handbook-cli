---
title: Investigate: Module registry alignment with v3 roadmap - Commands
type: commands
date: 2026-01-11
task_id: TASK-028
tags: [commands]
links: []
---

# Commands: Investigate: Module registry alignment with v3 roadmap

## Task Status
```bash
pnpm -C project-handbook make -- task-status id=TASK-028 status=doing
pnpm -C project-handbook make -- task-status id=TASK-028 status=review
pnpm -C project-handbook make -- task-status id=TASK-028 status=done
```

## Evidence Directory (required)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-028"
mkdir -p "$EVID_DIR"
${EDITOR:-vi} "$EVID_DIR/index.md"
```

## Read Inputs (capture as evidence)
```bash
set -euo pipefail

sed -n '1,260p' project-handbook/features/v2.1_ui-module-registry-discovery/decision-register/DR-0001-ui-module-artifact-origin-and-publish-pipeline.md | tee "$EVID_DIR/dr-0001.txt"
sed -n '1,260p' project-handbook/features/v2.1_ui-module-registry-discovery/decision-register/DR-0002-nextjs-runtime-module-loading-strategy.md | tee "$EVID_DIR/dr-0002.txt"
sed -n '1,260p' project-handbook/features/v2_context-control-plane-schema/decision-register/DR-0001-context-control-plane-migration-and-consumption-contract.md | tee "$EVID_DIR/context-dr-0001.txt"

DR_PATH="project-handbook/decision-register/DR-0007-module-registry-alignment-with-v3-roadmap.md"
${EDITOR:-vi} "$DR_PATH"

for f in \
  project-handbook/features/v3_capability-control-service-billing/overview.md \
  project-handbook/features/v3_provisioning-adapters-and-workflows/overview.md \
  project-handbook/features/v3_backstage-operator-surface/overview.md \
  project-handbook/features/v3_license-compliance-automation/overview.md \
  project-handbook/features/v3_client-customization-overlays/overview.md; do
  echo "--- $f"
  sed -n '1,200p' "$f"
done | tee "$EVID_DIR/v3-overviews.txt"
```

## Handbook Validation
```bash
pnpm -C project-handbook make -- validate
```
