---
id: FDR-v2_workspace-signup-onboarding-0002
title: Playwright Onboarding E2E Cleanup Strategy (API-driven teardown)
type: fdr
status: accepted
date: 2026-01-09
tags: [v2, onboarding, playwright, e2e, cleanup, fdr]
links:
  - ../overview.md
  - ../decision-register/DR-0002-playwright-onboarding-e2e-cleanup-strategy.md
  - ../testing/PLAYWRIGHT_ONBOARDING_E2E.md
  - ../../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
  - ../../../adr/0026-v2-workspace-signup-onboarding.md
  - ../../../adr/0028-v2-launch.md
---

# Decision

Use **API-driven teardown** for the onboarding Playwright E2E:
- delete the **Keycloak user** created/provisioned for the test,
- delete the **Context workspace** created during onboarding,
using deterministic, test-owned identifiers (prefix-based and/or ID-based), so the onboarding E2E can become a reliable
launch gate (`ADR-0028`) without requiring reset-by-recreate between runs.

# Scope

In scope:
- Local/dev + CI test teardown strategy for onboarding E2E.
- Minimal new deletion surface required to support deterministic cleanup.
- Evidence + safety requirements for gate runner integration.

Out of scope:
- Provider-specific teardown beyond Context workspace deletion (AnythingLLM/Twenty artifacts can be handled later as the
  onboarding E2E expands in coverage).
- “Reset the world” workflows as the primary test strategy (kept as a local escape hatch only).

# Implementation Contract (Execution Work References This)

## Test-owned identifiers (hard requirements)
- Keycloak usernames created by automation must be prefixed with `e2e-`.
- Context workspace slugs created by automation must be prefixed with `e2e-`.
- Cleanup code must delete only resources that match these constraints (and ideally also match IDs captured by the test).

## Keycloak teardown
- Extend `v2/apps/tribuence-mini/e2e/helpers/keycloak.ts` with:
  - `deleteUserByUsername(username)` using the existing admin token mechanism already used for provisioning.
- Deletion must:
  - query the user by username in the configured realm (default `tribuence`),
  - delete by user id (not by username string),
  - refuse to delete if the username does not start with `e2e-`,
  - never log credentials or tokens.

## Context workspace teardown
- Add a minimal delete primitive to the Context subgraph:
  - schema: add `workspaceDelete(id: ID!): ContextWorkspace!`
  - implementation: `v2/services/context/index.js`
  - semantics:
    - deletes `context_workspaces` row for the current tenant id + workspace id,
    - relies on DB `ON DELETE CASCADE` where applicable,
    - returns the deleted workspace record (id/slug/name) for evidence.
- Safety:
  - the mutation must be gated (env + explicit operator intent) so it is not exposed in production by default.
  - the resolver must refuse to delete workspaces whose slug does not start with `e2e-` (defense in depth).

## Playwright teardown hook
- Add a helper that:
  - reads the `tribuence-workspace-id` cookie after onboarding succeeds,
  - calls `workspaceDelete` with that id (preferred),
  - falls back to `workspaces` query + slug match when needed.

## Gate runner evidence
- When integrated into the v2 launch gate runner, the onboarding E2E gate must:
  - write Playwright artifacts under `$EVIDENCE_DIR/playwright/`,
  - write a stable text summary to `$EVIDENCE_DIR/playwright-onboarding.txt` (pass/fail + runtime),
  - avoid secrets in traces/logs (redaction posture is a prerequisite).

# Status

Accepted (operator approved Option A in DR-0002 on 2026-01-09).
