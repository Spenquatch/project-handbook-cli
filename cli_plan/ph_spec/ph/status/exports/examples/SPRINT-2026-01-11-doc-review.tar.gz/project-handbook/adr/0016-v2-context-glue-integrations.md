---
id: ADR-0016
title: v2 Context Glue Plane (Workspace Integrations)
type: adr
status: accepted
date: 2026-01-06
tags: [tribuence-mini, v2, context, integrations, twenty, anythingllm]
links:
  - ../features/v2_context-glue-integrations/overview.md
  - ../features/v2_capability-manifests-and-toggles/overview.md
  - ../features/v2_capability-detection-surface/overview.md
  - ../contracts/tribuence-mini-v2/vault-secrets.md
  - ../contracts/tribuence-mini-v2/twenty-ui-create-operations.md
---

# Context

Tribuence v2 is a modular platform that connects OSS capabilities (Twenty, AnythingLLM, and future tools) to a single
workspace concept. The Context service is the system-of-record for Tribuence workspaces and must also be the “glue plane”
that:
- provisions external capability workspaces per Context workspace,
- stores durable mappings,
- exposes a stable GraphQL surface for the UI and other services, and
- scales to many providers without changing the core workflow.

# Decision

## 1) Context owns the integration mapping layer

Context persists per-workspace mappings:
- `contextWorkspaceId -> providerType + providerWorkspaceId/slug + providerApiKeyId (if applicable)`

Mappings are authoritative and are exposed via the Context subgraph.

## 2) Provisioning is automatic, idempotent, and asynchronous

When a Context workspace is created, Context enqueues provisioning jobs for required providers (initially: Twenty and
AnythingLLM). Provisioning jobs are:
- idempotent (safe to re-run),
- retriable (bounded retries with backoff),
- never executed from the browser.

## 3) Twenty integration is provisioned via Twenty GraphQL using an automation user

For each Context workspace, Context:
1) authenticates as a Twenty automation user (credentials stored in Vault),
2) creates a dedicated Twenty workspace,
3) activates the workspace with the Context workspace name,
4) creates a dedicated Twenty API key record in that workspace,
5) stores `twentyWorkspaceId` + `twentyApiKeyId` in Context.

Runtime Twenty tokens are generated server-side per workspace (short-lived) using Twenty’s GraphQL `generateApiKeyToken`
mutation and cached until expiry. Context stores only ids, not long-lived tokens.

## 4) AnythingLLM integration is provisioned via AnythingLLM API using the instance API key

For each Context workspace, Context ensures an AnythingLLM workspace exists (slug derived deterministically from the
Context workspace slug) and stores the resolved slug/id. AnythingLLM uses the instance API key from Vault.

## 5) The UI reads integration state from Context (not from env guessing)

The UI gates features based on Context-provided capability state and integration status. The UI does not inspect Vault
env keys directly to decide whether a provider is configured per workspace.

# Consequences

## Positive
- Scales to many providers with a consistent lifecycle.
- Keeps all per-workspace mappings in one authoritative place.
- Avoids per-workspace Vault writes and vault-agent restarts for dynamic credentials.

## Tradeoffs
- Requires a small provisioning subsystem (jobs + retries + observability).
- Requires secure storage and handling of provider automation credentials.

# Rollout / Acceptance

- Creating a Context workspace triggers automatic provisioning for Twenty and AnythingLLM.
- Each Context workspace has a durable mapping record for Twenty and AnythingLLM.
- Twenty API key tokens are generated per workspace server-side and are short-lived; no long-lived workspace tokens are stored.
- The UI uses Context integration state to show/hide capability UX per selected workspace.
