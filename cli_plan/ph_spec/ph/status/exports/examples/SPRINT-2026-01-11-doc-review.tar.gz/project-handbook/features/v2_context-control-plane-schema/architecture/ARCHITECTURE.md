---
title: v2 Context Control Plane Schema Architecture
type: architecture
feature: v2_context-control-plane-schema
date: 2026-01-07
tags: [architecture]
links:
  - ../../adr/0027-v2-context-control-plane-schema.md
  - ../../adr/0016-v2-context-glue-integrations.md
  - ../../adr/0022-v2-capability-manifests-and-toggles.md
  - ../../adr/0018-v2-capability-detection-surface.md
  - ../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
  - ../../adr/0025-v2-1-ui-module-registry.md
  - ../../adr/0023-v2-context-knowledge-network.md
---

# Architecture: v2 Context Control Plane Schema

## Overview
Context is the system-of-record for workspace-scoped capability configuration and integration state. The control plane
schema defines:
- desired state (manifests),
- observed state (status),
- linkage (integration links),
- execution (provisioning jobs + runs),
- deterministic setup guidance identifiers,
- UI module selection manifests (v2.1).

## Canonical Snapshot Contract (accepted)
The architecture requires a single workspace-scoped snapshot query as the only supported gating input for the UI and
wrapper subgraphs (see `FDR-v2_context-control-plane-schema-0001`).

### Proposed query (GraphQL)
```graphql
type Query {
  # workspaceId is optional; falls back to `x-workspace-id` for parity with existing Context APIs
  contextControlPlaneSnapshot(workspaceId: ID): ContextControlPlaneSnapshot!
}
```

### Consumption contract (UI + wrappers)
- **Headers:** `x-tenant-id` required; `x-workspace-id` required unless using `workspaceId` argument.
- **UI transport:** UI queries via Apollo Router.
- **Wrapper transport:** wrapper subgraphs call Context directly (service-to-service) and forward relevant headers
  (wrappers must not call the Router to avoid recursion).
- **Timeout/fallback:** strict timeouts; deterministic fallback to “stub / gated” behavior on failure.

## Components
- **Context DB**: durable store for manifests, links, jobs, runs, and setup guidance.
- **Context GraphQL**: exposes the control-plane API to UI and wrappers.
- **Provisioning worker**: executes integration jobs and writes run status/results.
- **Wrappers/UI shell**: consume control-plane state for gating and actions.

## Data Flow
1) Workspace is created in Context.
2) Capability manifests are applied for the workspace.
3) Context enqueues provisioning jobs for enabled capabilities.
4) Worker executes provider provisioning and records job runs and link state.
5) UI queries Context for capability state and renders deterministic panels/gating.
6) Wrapper subgraphs consult Context for stub/enabled mode and for workspace-scoped auth resolution.

## Dependencies
- Context glue integrations (ADR-0016).
- Capability manifests and toggles (ADR-0022).
- UI gating surface (ADR-0018).
- Landing harness boundaries (ADR-0024) and future module registry (ADR-0025).
