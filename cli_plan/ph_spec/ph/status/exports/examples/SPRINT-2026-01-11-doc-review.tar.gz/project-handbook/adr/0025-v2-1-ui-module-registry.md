---
id: ADR-0025
title: v2.1 UI Module Registry (Context-Selected, Integrity-Checked Runtime Loading)
type: adr
status: accepted
date: 2026-01-07
tags: [tribuence-mini, v2.1, ui, modules, registry, context, security]
links:
  - ../features/v2.1_ui-module-registry-execution/overview.md
  - ../features/v2.1_ui-module-registry-discovery/overview.md
  - ../features/v2_ui-dev-harness-and-module-boundaries/overview.md
  - ../features/v2_capability-detection-surface/overview.md
  - ../features/v2_capability-manifests-and-toggles/overview.md
  - ../features/v2_registry-cosmo-minio-required/overview.md
---

# Context

Tribuence must support selecting and rendering different UI implementations per workspace based on enabled capabilities
and provider state, without shipping every OSS UI directly in the v2 UI shell. The system must remain secure: runtime
module loading must not become an untrusted plugin ecosystem.

# Decision

## 1) Context owns the workspace-scoped UI module manifest

Context stores and serves a per-workspace `uiModuleManifest` that maps:
`capabilityId` → `{ moduleId, version, integritySha256 }`.

The UI shell consumes this manifest to decide which modules to load. The UI never selects modules by inspecting env
variables or guessing based on upstream reachability.

## 2) UI modules are loaded at runtime from an internal artifact origin

UI module artifacts are built in CI and published to an internal-only artifact origin backed by MinIO.
Artifacts are immutable and versioned; there is no floating “latest”.

## 3) Runtime loading is allowlisted and integrity-checked

The UI shell enforces:
- module id allowlist,
- version pinning,
- sha256 integrity verification before executing module code.

If a module fails to load or fails integrity, the UI renders a deterministic fallback panel state and continues running.

## 4) v2 panel boundaries prevent retrofit

The v2 landing page remains the dev harness and v2 capability panels follow the module-ready boundary (ADR-0024).
v2.1 module loading is a packaging/loading change that reuses the same panel interface contract.

# Consequences

## Positive
- Dynamic per-workspace UI selection without shipping all UIs in the shell.
- Clear security posture: internal-only, allowlisted, integrity-checked modules.
- Avoids v2 retrofits due to enforced module-ready boundaries.

## Tradeoffs
- Additional infrastructure and CI steps to build/publish/version UI module artifacts.

# Rollout / Acceptance

- Context exposes a per-workspace `uiModuleManifest` used by the UI shell.
- UI loads only allowlisted modules and verifies sha256 integrity for pinned versions.
- Module load failures render deterministic fallback UI without breaking the shell.
- Playwright E2E validates module selection + load + fallback behavior via the landing harness.
