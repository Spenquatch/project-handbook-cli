---
id: ADR-0015
title: Tribuence Mini v2 Cosmo + MinIO + Schema Publishing (Required Baseline)
type: adr
status: superseded
date: 2026-01-05
tags: [tribuence-mini, v2, graphql, cosmo, minio, registry]
links:
  - ../../v2/ARCHITECTURE.md
  - ../features/tribuence-mini-v2/overview.md
  - ../contracts/tribuence-mini-v2/federation-composition.md
  - ../features/tribuence-mini-v2/architecture/COSMO_MINIO_PLAN.md
  - ../features/v2_registry-cosmo-minio-required/overview.md
  - ../features/v2_schema-publishing-and-composition/overview.md
  - ./0030-v2-cosmo-artifact-store-minio-baseline-then-seaweedfs.md
---

# Context

This ADR is **superseded by ADR-0030** (SeaweedFS S3 gateway replaces MinIO as the default artifact store after the MinIO baseline).

The v2 stack must scale from a few subgraphs to many OSS-wrapped capabilities while staying deterministic and debuggable.

To achieve this, v2 requires:
- a **schema registry** that is the source of truth for all composed schemas,
- a **durable artifact store** for schemas and publish metadata, and
- a **single publish pipeline** that gates composition.

# Decision

## 1) Cosmo + MinIO are required in the default v2 stack

- Cosmo (registry/controlplane) and MinIO (artifact storage) run in the default `make v2-up` loop.
- All required Cosmo dependencies are included (ClickHouse, Redis, NATS, Cosmo Keycloak, and Cosmo services).
- Secrets are Vault-seeded and rendered via the v2 Vault Agent into `/secrets/*.env`.

## 2) Internal-only exposure posture (least exposure)

- Cosmo + MinIO are **not exposed via Traefik**.
- If operator access is needed (Studio/controlplane), ports are bound to `127.0.0.1` only.

## 3) Cosmo is the schema source of truth; schema publishing is a required gate

- All subgraph schemas are published to Cosmo.
- Composition checks run against Cosmo-published schemas and block publish when incompatible.
- Apollo Router uses the Cosmo-produced supergraph for runtime composition.

## 4) MinIO is the required artifact store for schema lifecycle

- MinIO stores Cosmo artifacts (schema versions, publish metadata, and related outputs).
- MinIO bucket initialization is automated and idempotent.

# Consequences

## Positive
- One canonical schema registry and composition gate across all subgraphs.
- Deterministic audit trail for schema evolution (publish history + artifacts).
- A stable foundation for expanding to additional OSS capabilities.

## Tradeoffs
- More always-on infra in local/dev (increased baseline complexity).
- Requires strong bootstrap automation and smoke probes to avoid drift.

# Rollout / Acceptance

- `make v2-up` brings up Cosmo + MinIO + dependencies successfully in the default stack.
- `v2/scripts/vault/bootstrap-v2.sh` seeds and renders all Cosmo/MinIO secrets without printing them.
- MinIO bucket initialization runs automatically and is idempotent.
- A schema publish command publishes Context + Twenty + AnythingLLM schemas to Cosmo.
- Composition checks run and fail fast on incompatible publishes.
- Apollo Router serves a supergraph produced from Cosmo-published schemas.
- No Cosmo/MinIO services are reachable via Traefik hostnames; any operator ports bind to `127.0.0.1`.

# Threat Model (required posture)

## Assets
- MinIO credentials and bucket contents (Cosmo artifacts).
- Cosmo API tokens (publisher/harvester).
- Cosmo DB credentials and data (Postgres/ClickHouse).

## Mitigations
- No Traefik exposure; operator ports bind to `127.0.0.1` only when present.
- Secrets live in Vault KV; never committed; never printed in logs.
- Smoke probes enforce baseline health and prevent silent drift.
