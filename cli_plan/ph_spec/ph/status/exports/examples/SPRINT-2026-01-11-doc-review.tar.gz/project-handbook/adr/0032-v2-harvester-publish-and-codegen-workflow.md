---
id: ADR-0032
title: v2 Harvester Publish Workflow + Codegen Wiring (Option A)
type: adr
status: accepted
date: 2026-01-10
tags: [v2, cosmo, schema, harvester, codegen, ci, federation]
links:
  - ../decision-register/DR-0006-harvester-publish-and-codegen-workflow.md
  - ./0021-v2-schema-harvester-service.md
  - ./0019-v2-codegen-from-registry.md
  - ./0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
  - ../features/v2_schema-harvester-service/implementation/IMPLEMENTATION.md
  - ../features/v2_codegen-from-registry/implementation/IMPLEMENTATION.md
---

# Context

v2 requires a single canonical schema publishing workflow that:
- publishes subgraph schemas to Cosmo (authoritative),
- enforces composition checks as a hard gate before downstream work,
- updates in-repo SDL mirrors deterministically for diff/debug only (not as a source of truth),
- unblocks registry-backed codegen and a CI ordering that fails fast: publish/check → codegen → typecheck,
- never leaks secrets (Vault-rendered auth only; sanitized logs and artefacts).

Legacy reference code exists under `modular-oss-saas/services/schema-harvester/` and already implements an “Option A with fallback” shape (introspect `_service.sdl`, fallback to contract SDL, local composition preflight, publish to Cosmo). For v2, legacy is reference-only: we may reuse patterns or code, but must meet the v2 hardening requirements in this ADR and in the feature implementation docs.

# Decision

Adopt **Option A** as the canonical workflow:

1) **Harvester SDL source of truth**
- Default: introspect each running subgraph via federation `_service.sdl` from its v2-network `routing_url`.
- Fallback (per-subgraph): read contract SDL from the committed mirror file only when introspection is intentionally disabled or unavailable.

2) **Publish/check gate**
- Harvester must publish to Cosmo and enforce composition checks as a hard gate before mirrors are updated and before codegen runs.

3) **Mirror updates**
- Mirrors under `v2/infra/compose/graphql/subgraphs/*/schema.graphql` are updated only after successful publish/check, using atomic writes (temp file → rename) and never deleting last-known-good on failures.
- Mirrors are for diff/debug only; Cosmo remains authoritative.

4) **Codegen wiring**
- Codegen fetches schema inputs from Cosmo (not local mirrors) and runs after publish/check.
- CI enforces: publish/check → codegen → typecheck (and fails on drift).

5) **Hardening (non-negotiable)**
- No secrets in logs, reports, or evidence.
- Deterministic publish report contract (stable JSON shape, stable ordering) with aggressive sanitization and bounded error strings.
- Minimal secret blast radius: Cosmo auth env is Vault-rendered and mounted only into harvester/codegen fetcher components, not Router.
- Clear, deterministic failure modes for: unreachable subgraph, composition failure, Cosmo auth failure, partial file writes (mitigated by atomic updates).

# Consequences

## Positive
- Aligns publish + codegen with the same authoritative source (Cosmo) and prevents drift.
- Makes the pipeline deterministic and testable (explicit gates + atomic artifacts).
- Compatible with (and improves upon) the legacy harvester approach.

## Tradeoffs
- Requires subgraphs + Cosmo to be up for publish/codegen workflows (local and CI).
- Introduces more explicit operational concerns (timeouts/retries/warmup, report sanitization) that must be implemented.

# Rollout / Acceptance

- Create explicit execution tasks referencing this ADR for:
  - harvester implementation (publish/check + mirrors + report hardening),
  - codegen wiring (Cosmo-backed schema fetch + codegen + CI ordering/drift enforcement).
