---
title: Validate: v2 smoke probe for control-plane snapshot query - Validation Guide
type: validation
date: 2026-01-11
task_id: TASK-036
tags: [validation]
links: []
---

# Validation Guide: Validate: v2 smoke probe for control-plane snapshot query

## Automated Validation
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Manual Validation (Task-Specific, No Ambiguity)

### Step 1 — Run v2 smoke harness and capture output
```bash
set -euo pipefail
EVID_DIR="project-handbook/status/evidence/TASK-036"
mkdir -p "$EVID_DIR"

V2_SMOKE_MODE=router \
V2_SMOKE_REQUIRE_GRAPHS=TRIBUENCE_CONTEXT \
V2_SMOKE_ROUTER_URL="http://router.local/" \
make -C v2 v2-smoke 2>&1 | tee "$EVID_DIR/v2-smoke.txt"
```

### Pass criteria
- The smoke run exits `0`.
- The output includes **PASS** lines for the new `contextControlPlaneSnapshot` probes:
  - happy-path shape assertions (workspace id, empty-safe arrays, `generatedAt`)
  - missing-scope error assertion (`BAD_USER_INPUT` when neither `workspaceId` nor `x-workspace-id` is provided)

### Evidence (required)
- `project-handbook/status/evidence/TASK-036/index.md` (what changed + what was run)
- `project-handbook/status/evidence/TASK-036/v2-smoke.txt` (full smoke output)

## Sign-off
- [ ] All validation steps completed
- [ ] Evidence documented above
- [ ] Ready to mark task as "done"
