---
title: DR-0005 — Apollo Router Supergraph Consumption from Cosmo (Auth + Refresh Model)
type: decision-register
date: 2026-01-09
tags: [decision-register, apollo-router, cosmo, federation]
links:
  - ../releases/current/plan.md
  - ../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
  - ../features/v2_schema-publishing-and-composition/overview.md
---

# Decision Register Entry

### DR-0005 — Apollo Router Supergraph Consumption from Cosmo (Auth + Refresh Model)

**Decision owner(s):** @spenser  
**Date:** 2026-01-09  
**Status:** Accepted  
**Related docs:** `ADR-0015`, `v2_schema-publishing-and-composition`, `TASK-003`

**Problem / Context**
- This DR ID was reserved during sprint planning to enable a `session=research-discovery` task; it must be completed in `TASK-003` and requires operator/user approval before being marked `Accepted`.
- ADR-0015 requires Router to serve a Cosmo-produced supergraph (not a local-only composition). We need a concrete Router config + auth/refresh model that works in local/dev and has deterministic failure modes and smoke probes.
- Key unknowns that can change scope/effort: whether Router pulls directly from Cosmo vs consumes an on-disk artifact produced by a harvester, and how credentials are handled safely.

**Evidence (repo inspection + docs; no secrets)**
- Current v2 Router supergraph wiring + Vault env template: `project-handbook/status/evidence/TASK-003/router-supergraph-wiring.txt`
- Current committed supergraph snapshot size/hash only: `project-handbook/status/evidence/TASK-003/supergraph-local-stats.txt`
- Apollo Router CLI capabilities (supergraph sources + hot reload + Uplink polling): `project-handbook/status/evidence/TASK-003/apollo-router-help.txt`
- Cosmo CLI authentication env vars (`COSMO_API_KEY`, `COSMO_API_URL`): `project-handbook/status/evidence/TASK-003/cosmo-cli-auth-snippets.txt`
- Cosmo CLI can fetch federated-graph artifacts from the control plane; note that `federated-graph fetch-schema` returns the composed API schema, while Apollo Router requires a federation supergraph (generated via `federated-graph fetch --apollo-compatibility` + `rover supergraph compose`).

**Option A — Router pulls the supergraph directly from Cosmo (startup + periodic refresh)**
- **Pros:**
  - No extra “supergraph fetcher” container needed if we can use a Router-native remote/polling mechanism.
  - Keeps the artifact path contract simple (no shared writable volume between services).
- **Cons:**
  - Apollo Router’s `--hot-reload` explicitly only applies to *local* config/supergraph files; it does not imply polling arbitrary supergraph URLs (evidence: `project-handbook/status/evidence/TASK-003/apollo-router-help.txt`).
  - Apollo Router’s *polling* mode is tied to Apollo Uplink endpoints; we do not yet have evidence that Cosmo exposes an Apollo-Uplink-compatible endpoint for Apollo Router to poll (gap remains).
  - Requires placing Cosmo credentials inside the Router container (larger blast radius vs keeping Router as “file-only”).
- **Cascading implications:**
  - v2 would need to define and implement a “Router→Cosmo” auth contract (token type, rotation, storage in Vault, and how it is rendered into `/secrets/router.env`).
  - Smoke probes need to cover: “Router can fetch supergraph from Cosmo at startup” and “Router refreshes without restart (or has a deterministic restart trigger)”.
  - If Apollo Uplink is used, we must define:
    - which Uplink endpoints are used,
    - poll interval/timeout,
    - and the required `APOLLO_*` env contract for managed schema fetch.
- **Risks:**
  - High integration uncertainty: if Cosmo does not provide an Apollo-Uplink-compatible endpoint, periodic refresh likely requires a custom polling wrapper anyway (collapsing into Option B shape).
  - Operational ambiguity in local/dev: unclear how to debug “is Router serving the latest Cosmo supergraph?” if it is fetched via opaque remote calls.
- **Unlocks:**
  - If feasible, eliminates an extra moving part (no shared volume, no polling sidecar).
- **Quick wins / low-hanging fruit:**
  - Spike in implementation task (bounded) to confirm whether Apollo Router can poll supergraph from a Cosmo endpoint without custom code:
    - establish a known-good Cosmo endpoint that returns Apollo Router-compatible supergraph SDL,
    - validate Router startup fetch + refresh behavior,
    - document exact env vars + rotation model.

**Option B — Harvester pulls supergraph from Cosmo; Router consumes a local file artifact**
- **Pros:**
  - Deterministic + debuggable: the “current supergraph” is an on-disk file that can be hashed, diffed, and referenced by smoke probes.
  - Router can reload updated *local* supergraph files via `--hot-reload` (evidence: `project-handbook/status/evidence/TASK-003/apollo-router-help.txt`).
  - Keeps Cosmo credentials out of the Router container: only the fetcher/harvester needs the Cosmo API key; Router reads a file.
  - Aligns with Cosmo CLI support for fetching federated-graph artifacts and producing an Apollo Router-compatible supergraph SDL (via `npx wgc federated-graph fetch --apollo-compatibility ...` + `rover supergraph compose`) which can be written to a file.
- **Cons:**
  - Adds one more moving part: a harvester-owned “supergraph sync” step (either integrated into Harvester or a dedicated helper container) that writes to a shared volume.
  - Requires a clear artifact contract (path, atomic update, initial bootstrap behavior) to avoid Router starting without a supergraph file.
- **Cascading implications:**
  - v2 needs a *shared supergraph artifact contract*:
    - **format:** Apollo Router supergraph SDL text
    - **path in Router container:** `/dist/graphql-runtime/supergraph.graphql`
    - **update:** write-to-temp + atomic rename; only replace file when content hash changes
    - **ownership:** Harvester lane produces the file; Router consumes read-only
  - v2 compose changes (exact files):
    - `v2/infra/compose/docker-compose.v2.yml`: replace the current bind-mount of `supergraph-local.graphql` with a named volume shared between Router (read-only) and the fetcher (read-write); add the fetcher service/job.
    - `v2/infra/compose/graphql/router.v2.yaml`: no required changes (still runtime behavior), but ensure any Router config changes remain compatible with file hot reload.
    - `v2/infra/vault/templates/router.env.tpl`: update `APOLLO_ROUTER_SUPERGRAPH_PATH` default/seeded value to the new shared path.
    - `v2/scripts/vault/bootstrap-v2.sh`: update the default `APOLLO_ROUTER_SUPERGRAPH_PATH` to match the chosen shared path.
    - `v2/infra/vault/templates/cosmo-cli.env.tpl` and `v2/infra/vault/templates/agent.hcl`: render a Cosmo CLI auth env file for the fetcher without leaking into Router.
  - Secrets contract additions (high-level; align with `DR-0004`):
    - Add a Cosmo CLI auth KV entry under `kv/data/tribuence/v2/cosmo-cli` and render it to `/secrets/cosmo-cli.env`, mounted only into the fetcher/harvester container(s) (never into `apollo-router`):
      - `COSMO_API_KEY` (secret)
      - `COSMO_API_URL` (non-secret; internal control plane URL)
      - `COSMO_FEDERATED_GRAPH_NAME` (non-secret; e.g. `tribuence`)
      - `COSMO_FEDERATED_GRAPH_NAMESPACE` (non-secret; e.g. `dev`)
  - Smoke probes:
    - validate the supergraph file exists and is non-empty before Router is considered healthy,
    - validate fetcher can retrieve schema from Cosmo (no secret printing),
    - validate Router health stays green after a supergraph update event (hot reload).
- **Risks:**
  - If the shared file is updated non-atomically, Router may see a partial write (mitigate with temp file + atomic rename).
  - If Cosmo is unreachable at startup, Router may have no supergraph; mitigate by:
    - persisting the supergraph volume across restarts, and
    - making the fetcher “best effort” (never deleting last-known-good file).
- **Unlocks:**
  - Enables a stable “Router serving Cosmo-produced supergraph” gate even before more sophisticated registry/webhook automation exists.
  - Creates a single place (the fetcher/harvester) to evolve refresh strategy later (polling → webhook → event-driven) without changing Router.
- **Quick wins / low-hanging fruit:**
  - Implement a minimal `supergraph-sync` helper (Harvester lane) that runs `wgc federated-graph fetch --apollo-compatibility ...` + `rover supergraph compose` on an interval and writes to the shared supergraph file using atomic updates.

**Recommendation**
- **Recommended:** Option B — Harvester pulls supergraph from Cosmo; Router consumes a local file artifact
- **Rationale:** It is the most deterministic and least-surprising local/dev posture: Apollo Router has first-class hot reload for local files (so refresh is straightforward), and Cosmo already exposes a supported “fetch latest SDL” mechanism via the CLI. Option A has an unresolved compatibility gap around periodic refresh (unless Cosmo can act as Apollo Uplink), and it increases secret blast radius by putting Cosmo credentials inside the Router container.

**Guidance: when to revisit this decision (migration / hardening triggers)**
- **Migrate to Option A (Router-native remote refresh) when:**
  - We can prove a *supported* Router-native remote schema mechanism with safe refresh semantics (e.g., an Apollo-Uplink-compatible endpoint or an equivalent first-class Cosmo integration) and we want to remove the supergraph-sync component.
  - The operational model prefers “Router pulls schema directly” and the org is willing to accept the dependency that typically comes with that model (often Apollo GraphOS / hosted Uplink, unless we self-host an Uplink-compatible service).
- **Keep Option B but harden it when:**
  - **Downtime budget tightens:** we need guaranteed schema continuity across restarts; harden by persisting the supergraph volume, never deleting last-known-good, and making startup depend on an existing supergraph file.
  - **Polling is too blunt:** we need faster convergence than polling (or want to reduce control-plane load); harden by moving refresh triggers to events (Cosmo webhook → deploy rollout, or a controller that triggers the sync job only on publish events).
  - **Compliance/security posture tightens:** we need tighter secret scoping + audit; harden by using short-lived tokens, strict RBAC for the sync identity, and ensuring Router never mounts Cosmo credentials.
  - **Scale/multi-tenancy increases:** multiple graphs/environments/tenants need different supergraphs; harden by naming/versioning the runtime artifact, adding per-environment graph refs, and enforcing atomic updates + validation gates per graph.
- **Escalate to a new “production distribution” solution when:**
  - We need signed/verified supergraph delivery with explicit provenance (e.g., a CI-produced artifact + signature verification gate before Router loads it).
  - We want to stop using the CLI fetch pattern entirely and instead integrate directly with Cosmo APIs or an operator/controller with stronger guarantees (and we have evidence + bandwidth to design that contract).

**Follow-up tasks (explicit)**
- `TASK-003` (research-discovery): complete this DR and update the execution-ready Router consumption plan.
- Create execution tasks to implement Option B:
  - `TASK-006` / a new Router-lane task: add a `supergraph-sync` helper + shared volume, and switch Router to consume the synced file with `--hot-reload`.
  - Add smoke probes validating: (1) supergraph sync succeeds without leaking secrets, and (2) Router remains healthy and serves the updated supergraph after a refresh.
  - Update any existing “local snapshot” contracts/tests (`project-handbook/contracts/tribuence-mini-v2/*`, `v2/scripts/v2-smoke.sh`) to distinguish:
    - committed snapshot for graph detection (debugging), vs
    - runtime supergraph artifact from Cosmo (source of truth).

**Operator/user approval request**
- Approved: **Option B** — Harvester pulls supergraph from Cosmo; Router consumes a local file artifact.
- Approved by: @spenser (2026-01-10)
