---
title: v2 UI Dev Harness + Module-Ready Boundaries Architecture
type: architecture
feature: v2_ui-dev-harness-and-module-boundaries
date: 2026-01-07
tags: [architecture]
links:
  - ../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
  - ../../adr/0018-v2-capability-detection-surface.md
  - ../../adr/0022-v2-capability-manifests-and-toggles.md
---

# Architecture: v2 UI Dev Harness + Module-Ready Boundaries

## Overview
The v2 landing page is the required dev harness for exercising workspace-scoped capabilities through a single UI.
Capability UI is implemented as isolated panels with strict boundaries so the future v2.1 ModuleRegistry can load the
same panels without requiring a retrofit.

## Components
- **Landing harness page**: the single, auth-gated entrypoint used by developers and Playwright tests.
- **Capability panels**: isolated UI units (Twenty panel, AnythingLLM panel, References panel, future panels).
- **Context capability surface**: a single GraphQL query that drives all gating and setup guidance.
- **Context capability manifests**: durable enable/disable state per workspace.

## Data Flow
1) User logs in and selects a Context workspace.
2) Landing harness queries Context for capabilities for that workspace.
3) Harness renders capability panels:
   - enabled and ready panels show interactive UI,
   - disabled/unready panels show deterministic gating UI and setup guidance.
4) Panel actions call server-side operations only; the browser never sees provider credentials.

## Dependencies
- Capability detection surface (ADR-0018).
- Capability manifests and toggles (ADR-0022).
