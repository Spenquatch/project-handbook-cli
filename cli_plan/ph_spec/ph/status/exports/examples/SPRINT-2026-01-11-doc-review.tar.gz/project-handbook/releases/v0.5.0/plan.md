---
title: Release v0.5.0 Plan
type: release-plan
version: v0.5.0
start_sprint: SPRINT-2026-01-09
end_sprint: SPRINT-2026-01-23
planned_sprints: 3
sprint_ids: [SPRINT-2026-01-09, SPRINT-2026-01-16, SPRINT-2026-01-23]
status: delivered
delivered_date: 2026-01-11
delivered_sprint: SPRINT-2026-01-11
date: 2026-01-09
tags: [release, planning]
links:
  - ../../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
  - ../../adr/0021-v2-schema-harvester-service.md
  - ../../adr/0019-v2-codegen-from-registry.md
  - ../../features/v2_registry-cosmo-minio-required/overview.md
  - ../../features/v2_schema-publishing-and-composition/overview.md
  - ../../features/v2_schema-harvester-service/overview.md
  - ../../features/v2_codegen-from-registry/overview.md
---

# Release v0.5.0

> Release status: **delivered** (marked delivered in `SPRINT-2026-01-11`, on 2026-01-11).

## Release Summary
Make Cosmo + MinIO a required part of the v2 default stack, and introduce a single, canonical schema publishing +
composition gate (with a harvester + registry-backed codegen) so the supergraph remains deterministic as v2 expands to
many OSS-backed capabilities.

## Release Goals
1. **Primary Goal**: Required registry baseline (Cosmo + MinIO) with internal-only posture and smoke probes.
2. **Secondary Goal**: Canonical publish + composition gate; Apollo Router serves a Cosmo-produced supergraph.
3. **Stretch Goal**: Harvester + registry-backed codegen becomes the default dev/CI path (no manual schema mirrors).

## Release Type & Scope
- **Type**: standard (3 sprints)
- **In scope (must-have)**:
  - `v2_registry-cosmo-minio-required`: default-stack wiring (compose + Vault templates + bucket init), internal-only
    exposure posture, and health/smoke probes.
  - `v2_schema-publishing-and-composition`: one canonical publish entrypoint + composition gate; Router consumes a
    Cosmo-produced supergraph.
  - `v2_schema-harvester-service`: a single harvester command/service that runs the publish path and updates in-repo SDL
    mirrors after successful publishes (never prints secrets).
  - `v2_codegen-from-registry`: a canonical codegen entrypoint that consumes registry-backed SDL mirrors and runs in CI.
- **Out of scope (explicitly not in this release)**:
  - Context control plane schema expansion (ADR-0027) beyond what is strictly required to publish/compose existing v2
    subgraphs.
  - Capability enable/disable + per-workspace toggles (ADR-0022) and UI gating surface (ADR-0018).
  - v2.1 UI module registry discovery/execution (ADR-0025).
  - New capability wrappers beyond the current v2 baseline (Twenty + AnythingLLM + Context).
- **Scope flexibility**:
  - Locked:
    - Cosmo + MinIO included in default `make v2-up` loop (not optional).
    - No Traefik exposure for Cosmo/MinIO; operator ports bind to `127.0.0.1` only.
    - No secret leakage via logs, evidence artefacts, or publish output.
    - Composition checks are required gates (no “manual publish” workflows).
  - Flexible:
    - Harvester packaging (CLI first, service later) as long as the canonical publish path is enforced.
    - Exact layout of in-repo schema mirrors as long as the consumer surface stays stable and is documented.

## Sprint Timeline
- **SPRINT-2026-01-09** (Sprint 1 of 3): Baseline registry wiring + isolation posture
  - Cosmo + MinIO compose wiring in default v2 stack (Vault + templates + bucket init).
  - Establish smoke probes + minimum operational runbook for local/dev.
- **SPRINT-2026-01-16** (Sprint 2 of 3): Publish + composition gate + Router consumption
  - Canonical publish entrypoint and composition checks enforced as a gate.
  - Router serves a Cosmo-produced supergraph; failure modes are deterministic and documented.
- **SPRINT-2026-01-23** (Sprint 3 of 3): Harvester + codegen + hardening
  - Harvester automates publish + mirror updates; sanitizes all output.
  - Registry-backed codegen wired as the default for v2 UI and subgraphs; CI gate in place.


## Feature Assignments
Assigned in `releases/v0.5.0/features.yaml`:
- `v2_registry-cosmo-minio-required` (critical path)
- `v2_schema-publishing-and-composition` (critical path)
- `v2_schema-harvester-service` (critical path)
- `v2_codegen-from-registry`

## Scope Control
- **Scope lock date**: 2026-01-15 (end of Sprint 1)
- **Change control**:
  - Default: new requests go to the next release
  - Exceptions: owner-approved only (@spenser), and must be recorded by updating this plan + the release feature list

## Communication Plan
### Internal
- Announcement: add a short note to `project-handbook/status/current_summary.md` when Sprint 1 starts
- Progress cadence: weekly via `make release-status` (end of each sprint)
- Escalation path: owner @spenser (critical-path regressions block Sprint 2/3 planning)

### Stakeholders
- Update cadence: end-of-sprint written update (same cadence as internal)
- Demo date(s): end of Sprint 3 (registry publish + composition gate + codegen loop)
- Release notes owner: @spenser

## Success Criteria
- [ ] Cosmo + MinIO start successfully as part of the default `make v2-up` loop
- [ ] Cosmo/MinIO are not exposed via Traefik; any operator ports bind to `127.0.0.1` only
- [ ] Vault seeding/rendering for Cosmo/MinIO never prints secrets; publish/harvester output is sanitized
- [ ] MinIO bucket initialization is automated and idempotent
- [ ] Canonical publish entrypoint publishes all v2 subgraphs to Cosmo and runs composition checks as a hard gate
- [ ] Apollo Router serves a Cosmo-produced supergraph (no “local-only” composition)
- [ ] Harvester updates in-repo schema mirrors after successful publish
- [ ] Registry-backed codegen runs from schema mirrors and is enforced in CI
- [ ] Operator/dev runbook updates are complete and validated via handbook evidence

## Risk Management
- Critical path:
  - `v2_registry-cosmo-minio-required` → blocks all downstream registry workflows
  - `v2_schema-publishing-and-composition` → blocks Router consumption + deterministic supergraph
  - `v2_schema-harvester-service` → blocks canonical publish + mirror/codegen workflow
- Dependencies:
  - Cosmo stack dependencies (ClickHouse/Redis/NATS/Cosmo Keycloak) and local resource constraints
  - Vault seeding + secret templates must remain deterministic and non-leaky
- Capacity:
  - Treat Sprint 1 as “foundation-only” with strict scope lock; reserve buffer in Sprint 2/3 for integration hardening

## Release Notes Draft
*Auto-generated from completed tasks and features*
