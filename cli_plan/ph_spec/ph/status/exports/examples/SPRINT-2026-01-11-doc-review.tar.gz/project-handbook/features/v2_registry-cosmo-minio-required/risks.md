---
title: v2 Registry Baseline (Cosmo + MinIO) Risks
type: risks
feature: v2_registry-cosmo-minio-required
date: 2026-01-06
tags: [risks]
links:
  - ../../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
---

# Risk Register: v2 Registry Baseline (Cosmo + MinIO)

## High Priority Risks
- **Baseline stack instability (more services)**  
  - Impact: High  
  - Probability: Medium  
  - Mitigation: idempotent Vault bootstrap, deterministic MinIO init, and required smoke probes.
- **Secret leakage via logs/config**  
  - Impact: High  
  - Probability: Low  
  - Mitigation: never print secrets, avoid env dumps, sanitize errors, and validate logs during smoke.

## Medium Priority Risks
- **Accidental exposure via Traefik or host ports**  
  - Impact: Medium  
  - Probability: Medium  
  - Mitigation: no Traefik routers; bind operator ports to `127.0.0.1` only; validate via isolation checks.
- **SeaweedFS S3 parity differences vs MinIO (cutover risk)**  
  - Impact: Medium  
  - Probability: Medium  
  - Mitigation: keep integration store-agnostic, gate cutover on a deterministic artifact write/read probe, and retain a rollback path until probes are green.

## Risk Mitigation Strategies
Maintain “least exposure” posture and treat Cosmo/MinIO health as required gates in the v2 smoke workflow.
- Gate `make v2-up` and `make v2-smoke` on Cosmo/MinIO dependency health with explicit, actionable failures.
- Bind operator ports to `127.0.0.1` and verify exposure constraints in smoke validation.
