---
title: Contract: v3 overlay descriptors + precedence in Context snapshot (v1) - Implementation Steps
type: implementation
date: 2026-01-12
task_id: TASK-041
tags: [implementation]
links: []
---

# Implementation Steps: Contract: v3 overlay descriptors + precedence in Context snapshot (v1)

## Overview
Extend the Context control-plane **v1 snapshot contract** to include an **overlays** surface that is:
- tenant/workspace-scoped,
- additive and empty-safe,
- explicitly deterministic (precedence/layering rules are part of the contract),
- aligned with `ADR-0033` and the v3 overlays feature posture (validated overlays that cannot bypass capability gating).

## Prerequisites
- `TASK-032` is `done` (v1 snapshot GraphQL contract exists).
- `TASK-033` is `done` (v1 DB schema contract exists).
- `ADR-0033` is accepted (alignment posture is locked).

## Step 0 — Verify prerequisites are actually present (stop if not)
1. Confirm `TASK-032` and `TASK-033` are `done` via `pnpm -C project-handbook make -- task-show id=TASK-032` and `...TASK-033`.
2. Confirm the v1 surfaces exist in the contract docs (anchors must exist; do not invent new “v1” sections here):
   - `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md` contains `ContextControlPlaneSnapshot`.
   - `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` contains the v1 DB schema sections from `TASK-033`.

## Step 1 — Capture evidence index
1. Create `project-handbook/status/evidence/TASK-041/index.md`.
2. Capture the relevant excerpts from the current v1 snapshot contract types you are extending.

## Step 2 — Update the GraphQL contract (additive overlays surface)
Update `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md` to add overlay support **additively**:

1. Add an overlay surface to the v1 snapshot:
   - Add `overlays: [ContextOverlayDescriptor!]!` to `ContextControlPlaneSnapshot`.
   - Contract invariant: the field is **empty-safe** (empty list when none; never `null`).
   - Contract invariant: the list is returned in **precedence order** (already sorted).
2. Define `ContextOverlayDescriptor` (minimum contract; extend additively later):
   - `overlayId: String!` (stable overlay identifier; not tenant-specific)
   - `version: String!` (explicit/pinned; no “latest”)
   - `integritySha256: String!` (64-char lowercase hex digest)
   - `scope: ContextOverlayScope!` (`TENANT` | `WORKSPACE` | `CAPABILITY`)
   - `capabilityId: String` (nullable; only present when `scope=CAPABILITY`)
   - `priority: Int!` (lower value applies first)
3. Document explicit precedence rules in the contract:
   - overlays are applied in ascending `priority`,
   - ties are resolved deterministically (`overlayId` ascending),
   - overlays cannot bypass capability gating; they only affect UI/resources/configuration.
4. Document the intended mapping to v1 storage (so downstream migration tasks are unambiguous):
   - `overlayId` ↔ `overlay_bindings.overlay_id`
   - `version` ↔ `overlay_bindings.version`
   - `integritySha256` ↔ `overlay_bindings.integrity_sha256`
   - `priority` ↔ `overlay_bindings.priority`
   - `scope=TENANT` ↔ `overlay_bindings.workspace_id IS NULL` and `overlay_bindings.capability_id IS NULL`
   - `scope=WORKSPACE` ↔ `overlay_bindings.workspace_id IS NOT NULL` and `overlay_bindings.capability_id IS NULL`
   - `scope=CAPABILITY` ↔ `overlay_bindings.workspace_id IS NOT NULL` and `overlay_bindings.capability_id IS NOT NULL`

## Step 3 — Update the DB schema contract (minimal deterministic storage)
Update `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` v1 to include a minimal overlay binding/storage
contract that preserves determinism and tenant/workspace scoping.

Minimum requirements:
- Tenant-scoped on every row (`tenant_id`).
- `workspace_id` and `capability_id` are nullable to represent `WORKSPACE` and `CAPABILITY` overlays.
- Deterministic precedence:
  - store `priority` as an integer,
  - define a deterministic tie-breaker (e.g. `overlay_id`).
- No secrets stored (no credentials, no signed URLs).

Do **not** rename existing v1 tables/columns from `TASK-033`.

Contract requirements (make them explicit in the DB contract):
- Add a new v1 table contract: `overlay_bindings` (table name is part of the contract).
- Required columns:
  - `id` (`text`, PK)
  - `tenant_id` (`text`, not null)
  - `workspace_id` (`text`, nullable, FK → `context_workspaces.id`)
  - `capability_id` (`text`, nullable)
  - `overlay_id` (`text`, not null)
  - `version` (`text`, not null)
  - `integrity_sha256` (`text`, not null)
  - `priority` (`int`, not null)
  - `created_at` (`timestamptz`, not null)
  - `updated_at` (`timestamptz`, not null)
- Required uniqueness / determinism guarantees (acceptable to express as partial unique indexes in “Suggested SQL DDL”):
  - Tenant overlays (workspace_id null, capability_id null): unique `(tenant_id, overlay_id)`
  - Workspace overlays (workspace_id not null, capability_id null): unique `(tenant_id, workspace_id, overlay_id)`
  - Capability overlays (workspace_id not null, capability_id not null): unique `(tenant_id, workspace_id, capability_id, overlay_id)`
- Required ordering contract: when selecting overlays, sort by `(priority asc, overlay_id asc)`.

## Step 4 — Capture “after” excerpts + diff (required)
1. Capture “after” excerpts for both contract docs you touched.
2. Capture `git diff` outputs for review (see `commands.md`).

## Step 5 — Submit for review
1. Update `validation.md` to match the finalized contract changes (no placeholders).
2. Run `pnpm -C project-handbook make -- validate`.
1. Set status to `review` via `pnpm -C project-handbook make -- task-status id=TASK-041 status=review`.
