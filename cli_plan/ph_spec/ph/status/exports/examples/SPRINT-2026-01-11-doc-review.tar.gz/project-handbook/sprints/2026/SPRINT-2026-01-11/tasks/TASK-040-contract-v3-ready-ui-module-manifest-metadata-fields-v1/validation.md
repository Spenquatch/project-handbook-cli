---
title: Contract: v3-ready UI module manifest metadata fields (v1) - Validation Guide
type: validation
date: 2026-01-12
task_id: TASK-040
tags: [validation]
links: []
---

# Validation Guide: Contract: v3-ready UI module manifest metadata fields (v1)

## Automated Validation
```bash
EVID_DIR="project-handbook/status/evidence/TASK-040"
mkdir -p "$EVID_DIR"

pnpm -C project-handbook make -- validate | tee "$EVID_DIR/validate.txt"
pnpm -C project-handbook make -- sprint-status | tee "$EVID_DIR/sprint-status.txt"
```

## Manual Validation (Pass/Fail; no ambiguity)
- `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md` includes, additively:
  - `ContextUiModuleManifest.provenance: ContextArtifactProvenance`
  - `ContextUiModuleManifest.license: ContextLicensePosture`
  - `ContextArtifactProvenance` fields: `publisher`, `sourceRepo`, `sourceCommit`, `buildId`, `builtAt` (all nullable)
  - `ContextLicensePosture` fields: `spdxId`, `classification`, `requiresSourceProvision` (all nullable)
  - Explicit note: no secrets stored/returned in these fields
- `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` v1 includes nullable storage fields on `ui_module_manifests` for the same metadata (no table renames; tenant/workspace scoped; no secrets).
- Evidence captures show “before” and “after” excerpts and diffs for both contract files.

## Evidence (required)
- `project-handbook/status/evidence/TASK-040/index.md`
- `project-handbook/status/evidence/TASK-040/adr-0033.txt`
- `project-handbook/status/evidence/TASK-040/context-subgraph-before.txt`
- `project-handbook/status/evidence/TASK-040/context-subgraph-after.txt`
- `project-handbook/status/evidence/TASK-040/context-subgraph.diff`
- `project-handbook/status/evidence/TASK-040/context-db-before.txt`
- `project-handbook/status/evidence/TASK-040/context-db-after.txt`
- `project-handbook/status/evidence/TASK-040/context-db.diff`
- `project-handbook/status/evidence/TASK-040/validate.txt`
- `project-handbook/status/evidence/TASK-040/sprint-status.txt`

## Sign-off
- [ ] All validation steps completed
- [ ] Evidence documented above
- [ ] Ready to mark task as "done"
