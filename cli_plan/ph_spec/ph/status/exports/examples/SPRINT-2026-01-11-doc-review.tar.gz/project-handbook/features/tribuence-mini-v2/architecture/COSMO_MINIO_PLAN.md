---
title: Tribuence Mini v2 Cosmo + MinIO Plan (Discovery Output)
type: architecture
feature: tribuence-mini-v2
date: 2026-01-05
tags: [architecture, cosmo, minio, discovery]
links:
  - ../overview.md
  - ../status.md
  - ../../../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
  - ../../../contracts/tribuence-mini-v2/traefik-routing.md
  - ../../../contracts/tribuence-mini-v2/vault-secrets.md
  - ../../../../v2/ARCHITECTURE.md
---

# Cosmo + MinIO Plan (v2)

## Goal
Make **Cosmo** (schema registry + composition gate) and **MinIO** (artifact storage) a **required** part of the v2 stack:
- v2 composition is governed by Cosmo (source of truth).
- MinIO stores all registry/publish artifacts.
- The stack remains least-exposure by default (no Traefik exposure).

## Integration boundaries (default stance)
- **Internal-only** on the Docker network; no Traefik routers for Cosmo or MinIO.
- If operator access is needed (Studio/controlplane), bind ports to **`127.0.0.1` only**.
- The “default stack” includes Cosmo + MinIO.

## Required components (from reference)
Cosmo is not “just one container”. The reference compose stack requires:
- **Postgres** (Cosmo controlplane DB + Cosmo Keycloak DB)
- **ClickHouse** (OTEL traces/migrations)
- **Redis** (Cosmo runtime state)
- **NATS** (Cosmo event bus)
- **Keycloak** (Cosmo Studio auth)
- **MinIO** (S3 storage for artifacts)
- Cosmo services: `cosmo-controlplane`, `cosmo-cdn`, `cosmo-studio`, and a one-shot `cosmo-seed`.

## Proposed v2 wiring (execution-ready)

### Compose structure
- Cosmo/MinIO services are wired into the default v2 compose stack (no extra operator compose files required).

### Services + ports (internal-first)
Recommended internal ports (match reference images) and suggested host bindings if needed:
- `minio`: `9000` (S3), `9001` (console) — bind to `127.0.0.1` only if needed.
- `cosmo-clickhouse`: `8123` (HTTP), `9000` (native) — internal only.
- `cosmo-nats`: `4222` — internal only.
- `cosmo-redis`: `6379` — internal only (do not reuse Twenty Redis unless we are willing to accept shared-key-space risk).
- `cosmo-keycloak`: `8080` — internal only.
- `cosmo-controlplane`: `3001` — bind to `127.0.0.1:3001` only if needed for operator tooling.
- `cosmo-cdn`: `11000` — internal only.
- `cosmo-studio`: container `3000`; bind to `127.0.0.1:3003` only if needed.
- `cosmo-postgres-bootstrap`: one-shot job (creates DBs/roles in the shared Postgres).
- `cosmo-seed`: one-shot job (creates org/user + initial API key); keep behind a separate profile (example: `cosmo-seed`).

### Volumes (state)
- `minio-data-v2` → `/data`
- `cosmo-clickhouse-data-v2` → `/var/lib/clickhouse`
- Cosmo uses the existing v2 `postgres-data-v2` volume (shared Postgres); it should not introduce a new Postgres container.

## Vault secrets plan (no committed secrets)

### KV paths
Keep Cosmo/MinIO isolated under v2 namespaces:
- `kv/data/tribuence/v2/minio`
- `kv/data/tribuence/v2/cosmo`

### Rendered env files
Extend the existing v2 Vault Agent to render:
- `/secrets/minio.env` (MinIO container)
- `/secrets/cosmo.env` (Cosmo containers)

### Key inventory (minimum viable)
`kv/data/tribuence/v2/minio`:
- `MINIO_ACCESS_KEY`
- `MINIO_SECRET_KEY`

`kv/data/tribuence/v2/cosmo`:
- Postgres: `COSMO_POSTGRES_USER`, `COSMO_POSTGRES_PASSWORD`, `COSMO_POSTGRES_DB`
- ClickHouse: `COSMO_CLICKHOUSE_USER`, `COSMO_CLICKHOUSE_PASSWORD`, `COSMO_CLICKHOUSE_DB`
- Redis: `COSMO_REDIS_PASSWORD` (only if we run a dedicated `cosmo-redis`)
- Auth: `COSMO_AUTH_JWT_SECRET`, `COSMO_AUTH_ADMISSION_SECRET`
- Cosmo Keycloak: `COSMO_KEYCLOAK_ADMIN`, `COSMO_KEYCLOAK_ADMIN_PASSWORD`
- Seeding: `COSMO_SEED_USER_EMAIL`, `COSMO_SEED_USER_PASSWORD`, `COSMO_SEED_ORG`, `COSMO_SEED_API_KEY`
- Registry client usage (later, harvester): `COSMO_API_URL`, `COSMO_API_TOKEN`, `COSMO_GRAPH_REF`
- Storage: `COSMO_S3_BUCKET`

Notes:
- Prefer generating random values for secrets (JWT/admission/passwords) in `v2/scripts/vault/bootstrap-v2.sh`.
- Avoid logging values that contain credentials (especially `S3_STORAGE_URL` if Cosmo requires it).

## Bootstrap steps (next sprint execution)
1. Extend Vault bootstrap + templates to seed/render the keys above into `/secrets/minio.env` and `/secrets/cosmo.env`.
2. Add MinIO service and a one-shot bucket initializer (recommended: `minio/mc`) that ensures `COSMO_S3_BUCKET` exists.
3. Add Cosmo dependencies (ClickHouse, NATS, Redis, Cosmo Keycloak) + Cosmo services (controlplane + cdn).
4. Add `cosmo-postgres-bootstrap` to create:
   - Cosmo DB (`COSMO_POSTGRES_DB`) and role (`COSMO_POSTGRES_USER`), and
   - a dedicated `keycloak` DB for Cosmo Keycloak (do not reuse the v2 end-user auth DB).
5. Add `cosmo-seed` profile to provision org/user/API key once and store the resulting token in Vault (must not print).

## Smoke probes (minimum)
- MinIO live: `GET /minio/health/live` (container-local)
- Cosmo controlplane: `GET /health`
- ClickHouse: `SELECT 1` via `clickhouse-client`
- Keycloak: readiness probe on `:8080`
- `cosmo-seed` completes successfully (idempotent; re-runs safely)

## Recommendation
Proceed by making Cosmo+MinIO a **required baseline** in v2, gated by:
- Vault-seeded secrets + bucket init automation, and
- a smoke probe set that fails fast on drift.
