---
title: v2 Registry Baseline (Cosmo + MinIO) Testing
type: testing
feature: v2_registry-cosmo-minio-required
date: 2026-01-06
tags: [testing]
links:
  - ../../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
---

# Testing: v2 Registry Baseline (Cosmo + MinIO)

## Test Strategy
- **Bring-up smoke**: `make v2-up` + bootstrap + probes must pass.
- **Isolation**: Cosmo/MinIO are not reachable via Traefik hostnames.
- **Secrets hygiene**: bootstrap and logs never print secret values.

## Test Cases
1. `make v2-up` results in healthy Cosmo + MinIO + dependencies on the v2 network.
2. MinIO bucket initializer is idempotent and leaves required buckets present.
3. Smoke probes fail fast when Cosmo/MinIO deps are unhealthy (infra mode includes a store-agnostic S3 write/read probe).

## Acceptance Criteria
- [ ] Cosmo + MinIO are present in the default v2 stack (no extra compose file required).
- [ ] Vault seeds and renders `/secrets/minio.env` and `/secrets/cosmo.env` without printing secrets.
- [ ] MinIO bucket init runs automatically and is idempotent.
- [ ] Smoke probes exist and pass in a clean local bring-up.
- [ ] Cosmo and MinIO are not exposed via Traefik hostnames.
