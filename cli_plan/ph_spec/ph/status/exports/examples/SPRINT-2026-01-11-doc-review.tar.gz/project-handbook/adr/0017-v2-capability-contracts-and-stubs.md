---
id: ADR-0017
title: v2 Capability Contracts + Stub Subgraphs (Always-Composable)
type: adr
status: accepted
date: 2026-01-06
tags: [tribuence-mini, v2, graphql, federation, capabilities, contracts]
links:
  - ../features/v2_capability-contracts-and-stubs/overview.md
  - ../features/v2_capability-detection-surface/overview.md
  - ../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
---

# Context

Tribuence v2 composes many capability subgraphs behind Apollo Router. Composition must remain stable as capabilities are
enabled/disabled per workspace, and the UI must degrade gracefully without schema churn.

# Decision

## 1) Every capability publishes a minimal, stable contract SDL

Each capability defines a contract-first SDL that is:
- stable across enable/disable,
- published to Cosmo as the schema source of truth,
- used for codegen and UI wiring.

## 2) Capability subgraphs are always present in composition (stub mode supported)

Each capability subgraph supports two runtime modes:
- **enabled**: forwards to the upstream OSS integration for the current workspace,
- **stub**: returns a deterministic `CAPABILITY_MISSING` error for capability-root fields while preserving the schema.

## 3) Error contract is standardized

In stub mode, capability operations return:
- a single GraphQL error with a stable code: `CAPABILITY_MISSING`,
- a stable message that includes provider type and required setup path (Context integration link id),
- no secrets, no upstream URLs, no bearer tokens.

# Consequences

## Positive
- Router composition is stable even when capabilities vary by workspace.
- UI can gate/hide features deterministically without schema drift.
- Enables progressive rollout of new OSS wrappers without destabilizing existing clients.

## Tradeoffs
- Requires stub-mode implementation in every wrapper subgraph.
- Requires a capability catalog and integration state source (Context).

# Rollout / Acceptance

- Disabling a capability does not change the composed schema.
- In stub mode, capability operations return `CAPABILITY_MISSING` consistently and do not leak secrets.
- Codegen consumes Cosmo-published schemas and remains stable regardless of capability enablement.
