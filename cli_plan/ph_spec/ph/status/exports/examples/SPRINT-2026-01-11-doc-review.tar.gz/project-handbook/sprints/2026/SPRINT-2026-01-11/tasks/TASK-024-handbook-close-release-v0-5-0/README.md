---
title: Task TASK-024 - Handbook: Close release v0.5.0
type: task
date: 2026-01-11
task_id: TASK-024
feature: handbook-hygiene
session: task-execution
tags: [task, handbook-hygiene]
links: [../../../../../features/handbook-hygiene/overview.md]
---

# Task TASK-024: Handbook: Close release v0.5.0

## Overview
- **Feature**: [handbook-hygiene](../../../../../features/handbook-hygiene/overview.md)
- **Decision**: [ADR-0012](../../../../../adr/0012-handbook-reporting-and-continuity-artifacts.md)
- **Story Points**: 1
- **Owner**: @spenser
- **Lane**: `handbook/release`
- **Session**: `task-execution`

## Goal
Close the current release (`v0.5.0`) in the Project Handbook so reporting and continuity surfaces reflect reality and the next release can be planned cleanly.

## Outputs (what must exist when done)
- `pnpm -C project-handbook make -- release-close version=v0.5.0` has been run successfully.
- `project-handbook/releases/v0.5.0/plan.md` updated by automation to reflect close-out.
- `project-handbook/status/current_summary.md` updated (via `make status`) and references `SPRINT-2026-01-11` with the current sprint task list.
- Evidence captured under `project-handbook/status/evidence/TASK-024/` (release-status before/after + release-close output).

## Non-goals
- Do not change product code under `v2/`.

## Agent Navigation Rules
1. **Start work**: Update `task.yaml` status to "doing"
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: Set to "review" when ready for review

## Context & Background
This task implements the [ADR-0012](../../../../../adr/0012-handbook-reporting-and-continuity-artifacts.md) decision for the [handbook-hygiene] feature.

## Quick Start
```bash
pnpm -C project-handbook make -- task-status id=TASK-024 status=doing
cd project-handbook/sprints/current/tasks/TASK-024-*/
cat steps.md
cat commands.md
cat validation.md
```

## Dependencies
- This is the sprint’s `FIRST_TASK`.

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.
