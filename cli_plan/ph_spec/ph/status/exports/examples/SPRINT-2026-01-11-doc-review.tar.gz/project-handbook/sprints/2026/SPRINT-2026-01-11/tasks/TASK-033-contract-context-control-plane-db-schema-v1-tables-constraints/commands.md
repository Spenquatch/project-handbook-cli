---
title: Contract: Context control-plane DB schema (v1 tables + constraints) - Commands
type: commands
date: 2026-01-11
task_id: TASK-033
tags: [commands]
links: []
---

# Commands: Contract: Context control-plane DB schema (v1 tables + constraints)

## Task Status
```bash
pnpm -C project-handbook make -- task-status id=TASK-033 status=doing
pnpm -C project-handbook make -- task-status id=TASK-033 status=review
pnpm -C project-handbook make -- task-status id=TASK-033 status=done
```

## Evidence Directory
```bash
EVID_DIR="project-handbook/status/evidence/TASK-033"
mkdir -p "$EVID_DIR"
${EDITOR:-vi} "$EVID_DIR/index.md"
```

## Capture "Before" Contract Excerpts (recommended)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-033"
mkdir -p "$EVID_DIR"

rg -n "Contract: Context DB Schema|Tables|Suggested SQL DDL" \
  project-handbook/contracts/tribuence-mini-v2/context-db-schema.md \
  | tee "$EVID_DIR/context-db-schema-before.txt"
```

## Edit Contract
```bash
${EDITOR:-vi} project-handbook/contracts/tribuence-mini-v2/context-db-schema.md
```

## Capture "After" Excerpts + Diff (required)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-033"
mkdir -p "$EVID_DIR"

rg -n "capability_manifests|integration_links|ui_module_manifests|Suggested SQL DDL" \
  project-handbook/contracts/tribuence-mini-v2/context-db-schema.md \
  | tee "$EVID_DIR/context-db-schema-after.txt"

git diff -- project-handbook/contracts/tribuence-mini-v2/context-db-schema.md \
  | tee "$EVID_DIR/context-db-schema.diff"
```

## Validation
```bash
EVID_DIR="project-handbook/status/evidence/TASK-033"
mkdir -p "$EVID_DIR"

pnpm -C project-handbook make -- validate | tee "$EVID_DIR/validate.txt"
pnpm -C project-handbook make -- sprint-status | tee "$EVID_DIR/sprint-status.txt"
```

## Quick Copy-Paste
```bash
pnpm -C project-handbook make -- task-show id=TASK-033
rg -n "capability_manifests|integration_links|ui_module_manifests" project-handbook/contracts/tribuence-mini-v2/context-db-schema.md
```
