---
title: v2.1 UI Module Registry (Discovery) Status
type: status
feature: v2.1_ui-module-registry-discovery
date: 2026-01-07
tags: [status]
links:
  - ../../adr/0025-v2-1-ui-module-registry.md
  - ../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
---

# Status: v2.1 UI Module Registry (Discovery)

Stage: approved

## Now
- Sprint `SPRINT-2026-01-11`: discovery tasks grounding execution-ready contracts:
  - `TASK-026` → `DR-0001` accepted (artifact origin + publish pipeline contract)
  - `TASK-027` → `DR-0002` accepted (Next.js runtime loader contract)
  - `TASK-028` → `DR-0007` accepted → `ADR-0033` (v3 alignment constraints + checklist)
- Sprint `SPRINT-2026-01-11`: execution tasks added for the accepted origin/publish contract (Option A):
  - [TASK-030](../../sprints/current/tasks/TASK-030-implement-ui-module-origin-proxy-route-option-a/README.md) — same-origin proxy route (allowlist + immutable caching)
  - [TASK-031](../../sprints/current/tasks/TASK-031-implement-ui-module-publish-pipeline-s3-upload-smoke-check/README.md) — publish + smoke scripts (S3 + proxy route)
  - [TASK-037](../../sprints/current/tasks/TASK-037-implement-ui-module-runtime-loader-option-a-browser-verify-mode-flag/README.md) — runtime loader (Option A browser verify + mode flag)
  - [TASK-038](../../sprints/current/tasks/TASK-038-implement-ui-module-panel-integration-deterministic-fallback-states/README.md) — landing harness panel integration + deterministic fallback UX
  - [TASK-039](../../sprints/current/tasks/TASK-039-validate-playwright-e2e-for-module-load-failure-modes/README.md) — Playwright E2E gate: module load + deterministic failure modes
  - [TASK-040](../../sprints/current/tasks/TASK-040-contract-v3-ready-ui-module-manifest-metadata-fields-v1/README.md) — contract: v3-ready module manifest metadata extension points
  - [TASK-041](../../sprints/current/tasks/TASK-041-contract-v3-overlay-descriptors-precedence-in-context-snapshot-v1/README.md) — contract: v3 overlay descriptors + precedence semantics (additive)

## Cross-Task Dependencies (SPRINT-2026-01-11)
- `TASK-037` depends on `TASK-030` providing the same-origin byte fetch route (`/api/ui-modules/{moduleId}/{version}/{integritySha256}`) so the loader never reaches across origins.
- `TASK-028` depends on concrete outputs from:
  - `TASK-026` (origin/publish contract DR)
  - `TASK-027` (runtime loader contract DR)
  - `TASK-029` (Context snapshot + wrapper consumption contract DR; feature `v2_context-control-plane-schema`)

## Next
- Execute `TASK-030` first (origin route), then proceed in parallel:
  - `TASK-031` (publish + smoke scripts)
  - `TASK-037` (browser-verify runtime loader + mode flag)
- After loader + Context snapshot are ready, finish the runtime lane:
  - `TASK-038` (panel integration + deterministic fallback states)
  - `TASK-039` (Playwright E2E: success + failure modes)
- If v3 governance requires it, create follow-up execution tasks to reserve/implement provenance/compliance metadata and overlay semantics as additive Context fields.

## Risks
- Runtime remote code execution risk (mitigated by allowlist + integrity checks + internal-only origin).
- Module drift from the panel contract (mitigated by a strict interface and CI validation).
- v3 governance requirements (provenance, overlays, compliance) add scope pressure; mitigate by enforcing the v3 compatibility checklist and keeping Context evolution additive.

## Recent
- Feature created

## Active Work (auto-generated)
*Last updated: 2026-01-12*

### Current Sprint (SPRINT-2026-01-11)
- ✅ TASK-026: Investigate: UI module artifact origin + publish pipeline (S3 + integrity) (3pts, @spenser)
- ✅ TASK-027: Investigate: Next.js runtime module loading (allowlist + sha256) (3pts, @spenser)
- ✅ TASK-028: Investigate: Module registry alignment with v3 roadmap (2pts, @spenser)
- ⭕ TASK-030: Implement: UI module origin proxy route (Option A) (3pts, @spenser)
- ⭕ TASK-031: Implement: UI module publish pipeline (S3 upload + smoke check) (3pts, @spenser)
- ⭕ TASK-037: Implement: UI module runtime loader (Option A browser verify + mode flag) (3pts, @spenser)

### Metrics
- **Total Story Points**: 17 (planned)
- **Completed Points**: 8 (47%)
- **Remaining Points**: 9
- **Estimated Completion**: SPRINT-2026-W03
- **Average Velocity**: 21 points/sprint
