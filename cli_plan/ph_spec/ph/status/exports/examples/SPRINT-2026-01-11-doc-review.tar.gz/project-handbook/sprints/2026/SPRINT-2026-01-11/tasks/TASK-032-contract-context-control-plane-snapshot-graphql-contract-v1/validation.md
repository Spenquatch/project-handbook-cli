---
title: Contract: Context control-plane snapshot GraphQL contract (v1) - Validation Guide
type: validation
date: 2026-01-11
task_id: TASK-032
tags: [validation]
links: []
---

# Validation Guide: Contract: Context control-plane snapshot GraphQL contract (v1)

## Automated Validation
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Manual Validation (Task-Specific, No Ambiguity)
Create `project-handbook/status/evidence/TASK-032/` and capture:

### 1) Contract contains the v1 snapshot query + input semantics
Pass criteria:
- `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md` contains:
  - `contextControlPlaneSnapshot(workspaceId: ID): ContextControlPlaneSnapshot!`
  - explicit semantics: `workspaceId` may be omitted, fallback to `x-workspace-id`, and error `BAD_USER_INPUT` if neither provided

### 2) Contract contains the required v1 snapshot fields and minimal types
Pass criteria:
- `ContextControlPlaneSnapshot` includes (all non-null):
  - `workspace: ContextWorkspace!`
  - `manifests: [ContextCapabilityManifest!]!`
  - `statuses: [ContextCapabilityStatus!]!`
  - `integrationLinks: [ContextIntegrationLinkSummary!]!`
  - `jobs: [ContextIntegrationJobSummary!]!`
  - `setupGuidance: [ContextSetupGuidance!]!`
  - `uiModuleManifests: [ContextUiModuleManifest!]!`
  - `generatedAt: DateTime!`
- The contract defines minimal v1 types for the arrays (additive-only extension later; no placeholders).

### 3) Consumer contract is explicitly documented (UI + wrappers)
Pass criteria:
- The contract states:
  - headers and requirements (`x-tenant-id`, `x-workspace-id` unless `workspaceId` provided),
  - strict timeout + deterministic fallback guidance,
  - wrappers must not call Apollo Router for gating (call Context directly; forward headers).

## Evidence (required)
- `project-handbook/status/evidence/TASK-032/index.md`
- `project-handbook/status/evidence/TASK-032/context-subgraph-before.txt`
- `project-handbook/status/evidence/TASK-032/context-subgraph-after.txt`
- `project-handbook/status/evidence/TASK-032/context-subgraph.diff`
- `project-handbook/status/evidence/TASK-032/validate.txt`
- `project-handbook/status/evidence/TASK-032/sprint-status.txt`

## Sign-off
- [ ] All validation steps completed
- [ ] Evidence documented above
- [ ] Ready to mark task as "done"
