---
id: ADR-0011
title: Tribuence Mini v2 Router Introspection in Local/Dev
type: adr
status: draft
date: 2026-01-02
tags: [tribuence-mini, v2, apollo-router, introspection, local-dev, smoke]
links:
  - ../../v2/ARCHITECTURE.md
  - ../contracts/tribuence-mini-v2/supergraph-router.md
  - ../contracts/tribuence-mini-v2/v2-smoke-spec.md
  - ../contracts/tribuence-mini-v2/apollo-router-config.md
---

# Context

The v2 smoke spec (`contracts/tribuence-mini-v2/v2-smoke-spec.md`) needs to detect which subgraphs are federated by inspecting `enum join__Graph`.

In Apollo Router, the `join__*` types are execution-only and are not exposed via normal GraphQL introspection. v2 therefore treats the committed supergraph snapshot as the source of truth for graph detection:
- `v2/infra/compose/graphql/supergraph-local.graphql`

In production, teams often disable GraphQL introspection for security reasons. For v2 local/dev, we need a clear posture so the smoke harness and planning assumptions remain stable.

# Decision

In **local/dev v2**:
- Apollo Router may keep GraphQL introspection disabled (default posture).
- The smoke harness detects federated graphs by reading `v2/infra/compose/graphql/supergraph-local.graphql` and inspecting `enum join__Graph`.

This decision is limited to local/dev; production hardening (if/when relevant) can introduce a separate ADR that defines:
- whether introspection is disabled,
- whether `_service.sdl` is restricted,
- and what alternative “graph presence” signal the smoke harness should use.

# Consequences

## Positive
- Smoke harness can detect federated graphs deterministically (no brittle schema-specific probes).
- Incremental bring-up remains simple: it’s obvious which subgraphs are present based on `join__Graph`.

## Tradeoffs / Risks
- Router exposes supergraph SDL in local/dev, which would be undesirable in a public environment.
- If future environments require disabling `_service.sdl`, smoke harness must gain an alternative detection mechanism (tracked separately).

# Rollout

1. Ensure Router config + composition produce a supergraph that includes `join__Graph` (see `federation-composition.md`).
2. Ensure Router is reachable via Traefik at `router.local` and responds to GraphQL POSTs.
3. Confirm smoke can read `supergraph-local.graphql` and parse `join__Graph`.

# Acceptance Criteria

- The supergraph snapshot exists and includes `enum join__Graph { ... }` with expected values when corresponding subgraphs are composed:
  - `rg -n '^enum join__Graph\\b' v2/infra/compose/graphql/supergraph-local.graphql`
- Router remains reachable via Traefik at `router.local` for GraphQL probes.
