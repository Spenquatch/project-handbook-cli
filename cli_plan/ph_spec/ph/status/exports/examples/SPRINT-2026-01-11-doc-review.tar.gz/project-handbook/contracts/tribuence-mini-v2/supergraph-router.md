---
title: Tribuence Mini v2 Supergraph + Router Contract
type: api
date: 2025-12-30
tags: [contracts, graphql, federation, apollo-router, tribuence-mini-v2]
links:
  - ../../features/tribuence-mini-v2/overview.md
  - ../../adr/0007-tribuence-mini-v2-supergraph-context.md
  - ../../adr/0008-tribuence-mini-v2-anythingllm-subgraph-wrapper.md
  - ./vault-secrets.md
  - ./twenty-subgraph.md
  - ./context-subgraph.md
  - ./anythingllm-subgraph.md
  - ../../../v2/ARCHITECTURE.md
---

# Contract: Supergraph + Apollo Router (v2)

## Purpose
Define the stable, implementation-facing expectations for:
- **what is exposed publicly via Traefik**, and
- **how the Apollo Router behaves** (paths, headers, subgraph wiring).

This contract is the source of truth for:
- `TASK-007` (Traefik exposure),
- `TASK-011` (Router service + `router.local` liveness),
- `TASK-012` (federation asset layout + supergraph snapshot),
- and downstream UI work (GraphQL client configuration).

Related: the deterministic supergraph composition workflow is specified in:
- `federation-composition.md`
Related: Router config expectations (local/dev):
- `apollo-router-config.md`
Related: Traefik routing + isolation (local/dev):
- `traefik-routing.md`

## Public Surfaces (Traefik)

### Allowed hosts
- `app.local` — v2 UI (Next.js)
- `router.local` — Apollo Router (GraphQL entrypoint)
- `keycloak.local` — Keycloak (optional; enable only when auth flows require it)

### Forbidden hosts
No Traefik routes should expose upstream/internal services such as:
- Twenty (REST/GraphQL), AnythingLLM, Vault, Postgres, etc.

Expected behavior: any non-allowed host returns Traefik default `404`.

## Apollo Router HTTP Contract

### Router endpoint
- Host: `router.local`
- GraphQL path: `/` (Apollo Router `supergraph.path`)
- Content type: `application/json`

Example minimal probe:
```bash
curl -sS --resolve "router.local:80:127.0.0.1" \
  -H 'content-type: application/json' \
  --data '{"query":"{ __typename }"}' \
  "http://router.local/"
```

### Health check
Router health runs on a separate internal port (pattern from `modular-oss-saas`):
- Internal health URL (container-local): `http://127.0.0.1:8088/health`
- Not required to be Traefik-exposed.

### Local/dev graph detection posture
The v2 smoke harness detects federated graphs by reading the committed supergraph snapshot and inspecting `enum join__Graph`:
- `v2/infra/compose/graphql/supergraph-local.graphql`

Rationale: Apollo Router does not expose the `join__*` execution schema types via normal introspection.

Local/dev posture is defined in:
- `project-handbook/adr/0011-tribuence-mini-v2-router-introspection-local-dev.md`

## Request Header Propagation

The Router must propagate the following headers to **all** subgraphs:
- `authorization`
- `x-tenant-id`
- `x-workspace-id`

Semantics:
- `authorization`: End-user auth context (when enabled). Router treats this as opaque and forwards it.
- `x-tenant-id`: A coarse “tenant namespace”. For local/dev v2, default to `tribuence` unless/until multi-tenant behavior is introduced.
- `x-workspace-id`: Active workspace selection for v2 flows. Context subgraph uses this as the default scope when an operation omits `workspaceId`.

## Federation Artifacts & Layout

These paths are **required** for execution work so that federation wiring is discoverable and repeatable:

- Router config: `v2/infra/compose/graphql/router.v2.yaml`
- Subgraph assets root: `v2/infra/compose/graphql/subgraphs/`
- Local supergraph snapshot: `v2/infra/compose/graphql/supergraph-local.graphql`
- Router runtime supergraph (Cosmo-synced, in-container): `/dist/graphql-runtime/supergraph.graphql`

Composition workflow (how to generate `supergraph-local.graphql`):
- `project-handbook/contracts/tribuence-mini-v2/federation-composition.md`

### Subgraph graph names (required)
Router configuration must use stable graph names so smoke tests can detect which subgraphs are present via the composed supergraph SDL (`join__Graph` enum values).

Required graph names (Router config):
- `twenty`
- `tribuence_context`
- `anythingllm`

Expected `join__Graph` enum values in the composed supergraph SDL:
- `TWENTY`
- `TRIBUENCE_CONTEXT`
- `ANYTHINGLLM`

Subgraph directories:
- `v2/infra/compose/graphql/subgraphs/twenty/`
- `v2/infra/compose/graphql/subgraphs/tribuence-context/`
- `v2/infra/compose/graphql/subgraphs/anythingllm/`

Each subgraph directory must contain a committed SDL snapshot (e.g. `schema.graphql`) that represents the schema used to compose `supergraph-local.graphql`.

## Subgraphs (Required at Bring-up)

### Twenty subgraph
- Must federate the upstream Twenty GraphQL surface.
- The routing URL must be reachable from inside the Router container.
- Contract defined in `twenty-subgraph.md`.

### Tribuence Context subgraph
- New GraphQL subgraph implemented by the Context service.
- Contract defined in `context-subgraph.md`.

### AnythingLLM subgraph
AnythingLLM does not provide a native GraphQL API; v2 therefore assumes a **GraphQL wrapper subgraph**:
- UI calls Router → Router calls `anythingllm` GraphQL wrapper → wrapper calls AnythingLLM REST internally.

If a future upstream adds GraphQL, this contract can be revised; until then, “AnythingLLM subgraph” means the wrapper.

Implementation decision record: `ADR-0008` (draft).
Contract defined in `anythingllm-subgraph.md`.
