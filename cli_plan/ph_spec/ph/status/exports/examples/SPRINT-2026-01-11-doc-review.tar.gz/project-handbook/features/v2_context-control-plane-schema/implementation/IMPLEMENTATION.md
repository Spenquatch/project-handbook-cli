---
title: v2 Context Control Plane Schema Implementation
type: implementation
feature: v2_context-control-plane-schema
date: 2026-01-07
tags: [implementation]
links:
  - ../../adr/0027-v2-context-control-plane-schema.md
---

# Implementation: v2 Context Control Plane Schema

## Build Steps (required)
1. Implement the control-plane persistence model in Context:
   - `capability_manifests` (desired enablement state per workspace),
   - `capability_status` (observed state per workspace/capability),
   - `integration_links` (workspace mapping to provider workspace + provider credential ids),
   - `integration_jobs` and `integration_job_runs` (durable execution + audit),
   - `setup_guidance` (deterministic identifiers used by UI; no secrets),
   - `ui_module_manifests` (v2.1: per workspace capability → module id + version + sha256).
2. Implement a single Context GraphQL query that returns the full workspace control-plane snapshot:
   - manifests + status + guidance identifiers + link status summary.
3. Implement GraphQL mutations for:
   - enable/disable capabilities (manifest updates),
   - ensure integration link (idempotent),
   - run provisioning/sync jobs (idempotent).
4. Enforce invariants:
   - every record is tenant/workspace scoped,
   - idempotency keys prevent duplicate upstream resources,
   - no provider secrets stored or returned.

## Required Posture
- The control-plane snapshot query is the only supported gating input for UI and wrappers.
- Context is provider-agnostic; provider-specific logic is encapsulated behind adapters/jobs.

## Implementation Notes
- The existing `ContextWorkspace` + `ContextReference` model remains valid; this feature adds the control-plane surfaces
  required for provisioning, capability gating, and module selection.

## Execution-ready plan (accepted)
This section reflects `FDR-v2_context-control-plane-schema-0001` (Option A, accepted).

### Migration sequencing (additive)
1. **Schema first:** add idempotent SQL migrations under `v2/services/context/db/migrations/` for the control-plane
   tables and indices (do not remove or rewrite v0 tables).
2. **Read surface next:** add the snapshot query (it can safely return empty arrays until write paths land).
3. **Write paths:** introduce mutations + worker/job wiring incrementally (manifests → links → jobs/runs → status).
4. **Backwards compatibility:** keep existing workspace/reference APIs stable and tenant/workspace scoped.

### Canonical snapshot query contract
- Proposed name: `contextControlPlaneSnapshot(workspaceId: ID): ContextControlPlaneSnapshot!`
- `workspaceId` is optional and must fall back to `x-workspace-id` to match existing Context conventions.
- The snapshot must remain additive-only; consumers must tolerate new fields, but existing fields must not change meaning.

### Contract updates required during execution
- Update `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` (v1) with the new control-plane tables.
- Update `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md` (v1) to include the snapshot query + types.
