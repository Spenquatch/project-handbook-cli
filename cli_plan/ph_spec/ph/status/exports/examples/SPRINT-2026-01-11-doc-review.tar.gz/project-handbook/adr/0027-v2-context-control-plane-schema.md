---
id: ADR-0027
title: v2 Context Control Plane Schema (Manifests, Links, Jobs, Status, Guidance)
type: adr
status: accepted
date: 2026-01-07
tags: [tribuence-mini, v2, context, control-plane, capabilities, integrations, schema]
links:
  - ../features/v2_context-control-plane-schema/overview.md
  - ../features/v2_context-glue-integrations/overview.md
  - ../features/v2_capability-manifests-and-toggles/overview.md
  - ../features/v2_capability-detection-surface/overview.md
  - ../features/v2_ui-dev-harness-and-module-boundaries/overview.md
  - ../features/v2.1_ui-module-registry-discovery/overview.md
  - ../features/v2.1_ui-module-registry-execution/overview.md
  - ../features/v2_context-knowledge-network/overview.md
---

# Context

v2 requires Context to act as the system-of-record for workspace-scoped capability configuration and integration state.
Multiple v2 features depend on the same underlying control-plane surfaces: enable/disable manifests, provisioning jobs,
integration link mappings, deterministic status used for UI/wrapper gating, and setup guidance identifiers.

# Decision

## 1) Context exposes a workspace control-plane snapshot query

Context provides a single GraphQL query that returns the control-plane snapshot for the selected workspace:
- capability desired state (manifests),
- capability observed state (status),
- integration link summaries (not secrets),
- provisioning job status/runs summary,
- setup guidance identifiers.

This snapshot query is the only supported gating input for the UI and wrapper subgraphs.

## 2) Context stores durable manifests, links, jobs, and runs

Context persists these workspace-scoped records:
- capability manifests (desired enablement per capability),
- capability status (observed state per capability with explicit states),
- integration links (workspace mapping to provider workspace and provider credential ids),
- integration jobs and job runs (durable execution + audit with idempotency keys),
- setup guidance (deterministic identifiers used by UI; no secrets).

For v2.1, Context also stores a workspace-scoped UI module manifest:
`capabilityId` → `{ moduleId, version, integritySha256 }`.

## 3) Invariants are strict and enforced everywhere

The control plane enforces:
- tenant/workspace scoping on every record and resolver,
- idempotency keys to prevent duplicate upstream resources,
- no provider secrets stored and no provider secrets returned via GraphQL.

# Consequences

## Positive
- One authoritative state surface for capability gating across UI and wrappers.
- Deterministic provisioning behavior with explicit auditability.
- Provider-agnostic modeling supports expansion to many OSS systems.

## Tradeoffs
- Context becomes a foundational service whose schema must remain stable and evolve additively.

# Rollout / Acceptance

- Context exposes the workspace control-plane snapshot query used by UI and wrappers.
- Context supports manifests, status, links, jobs/runs, and setup guidance identifiers.
- Isolation and idempotency invariants are enforced and validated.
- Control-plane APIs do not store or return provider secrets.
