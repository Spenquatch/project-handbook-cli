---
title: Implement: Context snapshot query + types (empty-safe) - Commands
type: commands
date: 2026-01-11
task_id: TASK-035
tags: [commands]
links: []
---

# Commands: Implement: Context snapshot query + types (empty-safe)

## Task Status
```bash
pnpm -C project-handbook make -- task-status id=TASK-035 status=doing
pnpm -C project-handbook make -- task-status id=TASK-035 status=review
pnpm -C project-handbook make -- task-status id=TASK-035 status=done
```

## Preflight (dependency + contract presence)
```bash
pnpm -C project-handbook make -- task-show id=TASK-032
pnpm -C project-handbook make -- task-show id=TASK-034

rg -n "contextControlPlaneSnapshot|ContextControlPlaneSnapshot" \
  project-handbook/contracts/tribuence-mini-v2/context-subgraph.md
```

## Evidence Directory
```bash
EVID_DIR="project-handbook/status/evidence/TASK-035"
mkdir -p "$EVID_DIR"
${EDITOR:-vi} "$EVID_DIR/index.md"
```

## Implement (v2 repo)
```bash
${EDITOR:-vi} v2/services/context/index.js
${EDITOR:-vi} v2/infra/compose/graphql/subgraphs/tribuence-context/schema.graphql
```

## Prove committed SDL snapshot updated
```bash
rg -n "contextControlPlaneSnapshot" v2/infra/compose/graphql/subgraphs/tribuence-context/schema.graphql \
  | tee "$EVID_DIR/schema-grep.txt"
```

## Bring up v2 (required for Router + Context)
```bash
KEYCLOAK_ADMIN=admin KEYCLOAK_ADMIN_PASSWORD=dev-not-admin make -C v2 v2-up
V2_VAULT_MINT_ANYLLM_API_KEY=true bash v2/scripts/vault/bootstrap-v2.sh
```

## Manual GraphQL validation via Router
Requires `jq` (see `v2/docs/README.md` prerequisites).
```bash
EVID_DIR="project-handbook/status/evidence/TASK-035"
mkdir -p "$EVID_DIR"

ROUTER_URL="${ROUTER_URL:-http://router.local/}"
TENANT_ID="${TENANT_ID:-tribuence}"

WORKSPACE_SLUG="e2e-cp-$(date +%s)"
WORKSPACE_NAME="e2e control plane"

WORKSPACE_CREATE_MUTATION='mutation($input: WorkspaceCreateInput!){ workspaceCreate(input:$input){ id slug name } }'
curl -sS "$ROUTER_URL" \
  -H "content-type: application/json" \
  -H "x-tenant-id: $TENANT_ID" \
  -d "{\"query\":\"$WORKSPACE_CREATE_MUTATION\",\"variables\":{\"input\":{\"slug\":\"$WORKSPACE_SLUG\",\"name\":\"$WORKSPACE_NAME\"}}}" \
  | tee "$EVID_DIR/workspace-create.json"

WORKSPACE_ID="$(jq -r '.data.workspaceCreate.id' "$EVID_DIR/workspace-create.json")"
test -n "$WORKSPACE_ID" && test "$WORKSPACE_ID" != "null"

SNAPSHOT_QUERY='query($workspaceId: ID){ contextControlPlaneSnapshot(workspaceId:$workspaceId){ workspace { id slug } generatedAt manifests statuses integrationLinks jobs setupGuidance uiModuleManifests } }'
curl -sS "$ROUTER_URL" \
  -H "content-type: application/json" \
  -H "x-tenant-id: $TENANT_ID" \
  -d "{\"query\":\"$SNAPSHOT_QUERY\",\"variables\":{\"workspaceId\":\"$WORKSPACE_ID\"}}" \
  | tee "$EVID_DIR/snapshot-by-arg.json"

# Header fallback: omit workspaceId argument, supply x-workspace-id header
curl -sS "$ROUTER_URL" \
  -H "content-type: application/json" \
  -H "x-tenant-id: $TENANT_ID" \
  -H "x-workspace-id: $WORKSPACE_ID" \
  -d "{\"query\":\"{ contextControlPlaneSnapshot { workspace { id } generatedAt manifests statuses integrationLinks jobs setupGuidance uiModuleManifests } }\"}" \
  | tee "$EVID_DIR/snapshot-by-header.json"

# Missing both workspaceId and x-workspace-id must fail with BAD_USER_INPUT
curl -sS "$ROUTER_URL" \
  -H "content-type: application/json" \
  -H "x-tenant-id: $TENANT_ID" \
  -d "{\"query\":\"{ contextControlPlaneSnapshot { generatedAt } }\"}" \
  | tee "$EVID_DIR/snapshot-missing-workspace.json"

# Tenant mismatch must not leak data (workspace should not be found)
curl -sS "$ROUTER_URL" \
  -H "content-type: application/json" \
  -H "x-tenant-id: other-tenant" \
  -H "x-workspace-id: $WORKSPACE_ID" \
  -d "{\"query\":\"{ contextControlPlaneSnapshot { workspace { id } } }\"}" \
  | tee "$EVID_DIR/snapshot-tenant-mismatch.json"
```

## Handbook validation
```bash
pnpm -C project-handbook make -- validate | tee "$EVID_DIR/handbook-validate.txt"
```
