---
id: ADR-0031
title: v2 Router Supergraph Delivery — Cosmo Sync Artifact (Option B)
type: adr
status: accepted
date: 2026-01-10
tags: [v2, registry, apollo-router, cosmo, supergraph]
links:
  - ./0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
  - ../decision-register/DR-0005-router-supergraph-consumption-from-cosmo.md
  - ../features/v2_schema-publishing-and-composition/overview.md
  - ../features/v2_schema-publishing-and-composition/implementation/IMPLEMENTATION.md
---

# Context

ADR-0015 requires Apollo Router to serve a **Cosmo-produced supergraph**. Today, v2 runs Router with a **committed local snapshot** (`v2/infra/compose/graphql/supergraph-local.graphql`) for local/dev.

We need a deterministic, self-hostable way for Router to consume the Cosmo-produced supergraph in local/dev now, with a credible path to production hardening later.

Discovery and options analysis are captured in:
- `DR-0005` (accepted): `project-handbook/decision-register/DR-0005-router-supergraph-consumption-from-cosmo.md`

# Decision

Adopt `DR-0005` **Option B** as the v2 baseline:

1) A Harvester-owned “supergraph sync” step fetches the latest valid federated-graph SDL from the Cosmo control plane and writes it to a shared on-disk artifact.

2) Apollo Router consumes that local artifact file and hot-reloads when it changes.

3) Cosmo credentials live in Vault and are mounted **only** into the sync job/container; Router never mounts Cosmo credentials.

# Consequences

## Positive
- Deterministic + debuggable: the runtime supergraph is a file that can be hashed, diffed, and validated by smoke probes.
- Keeps secret blast radius smaller: Router stays “file-only”; Cosmo API key stays outside the Router container.
- Self-hostable baseline: no reliance on Apollo GraphOS/Uplink assumptions.

## Tradeoffs
- Adds a moving part (sync job/service) that must be reliable and safe (atomic writes, last-known-good preservation).
- A polling loop is acceptable for local/dev but may be too blunt for production (hardening triggers below).

# Rollout / Acceptance

Implementation work must:
- Add a shared supergraph artifact contract (path + atomic update) and wire Router to use it with hot reload.
- Provide deterministic smoke probes proving:
  - the sync job can fetch and write a non-empty supergraph without leaking secrets,
  - Router stays healthy and serves requests across a supergraph update.

Hardening/migration triggers are explicitly documented in `DR-0005`:
- `project-handbook/decision-register/DR-0005-router-supergraph-consumption-from-cosmo.md`
