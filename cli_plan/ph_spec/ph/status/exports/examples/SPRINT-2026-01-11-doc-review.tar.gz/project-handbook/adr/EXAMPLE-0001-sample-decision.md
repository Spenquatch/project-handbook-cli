---
id: ADR-0001
title: Sample Global Decision
type: adr
status: accepted
date: 2025-09-12
supersedes: null
superseded_by: null
tags: [sample]
links: []
---

Context
- Briefly explain the problem and constraints.

Decision
- Describe the chosen direction and scope.

Consequences
- Positive and negative outcomes.

Rollout & Reversibility
- Phases, flags, and rollback plan.

