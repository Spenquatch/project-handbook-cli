---
title: Implement: Context snapshot query + types (empty-safe) - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-035
tags: [implementation]
links: []
---

# Implementation Steps: Implement: Context snapshot query + types (empty-safe)

## Overview
Add the canonical control-plane snapshot query to the existing v2 Context subgraph, with empty-safe placeholder arrays for
surfaces not yet implemented.

## Prerequisites
- [ ] `TASK-032` is `done` (GraphQL contract is defined).
- [ ] `TASK-034` is `done` (DB migrations for v1 tables are present).

Preflight checks (stop if they fail):
- The contract includes the snapshot query + types:
  - `rg -n "contextControlPlaneSnapshot|ContextControlPlaneSnapshot" project-handbook/contracts/tribuence-mini-v2/context-subgraph.md`
- The committed SDL snapshot exists and will be updated:
  - `ls -la v2/infra/compose/graphql/subgraphs/tribuence-context/schema.graphql`

## Step 1 — Capture evidence index
1. Create `project-handbook/status/evidence/TASK-035/index.md`.
2. Record which schema/resolver files were changed and why.

## Step 2 — Implement GraphQL schema + resolvers (v2 repo)
1. Update `v2/services/context/index.js` GraphQL SDL:
   - Add the query:
     - `contextControlPlaneSnapshot(workspaceId: ID): ContextControlPlaneSnapshot!`
   - Add the minimal v1 types per `TASK-032` (additive-only):
     - `ContextControlPlaneSnapshot` and its child types (`ContextCapabilityManifest`, `ContextCapabilityStatus`, etc.)
2. Update `v2/services/context/index.js` resolvers:
   - Determine `workspaceId` as: `args.workspaceId ?? ctx.workspaceId`
   - If missing, throw a `GraphQLError` with `extensions.code="BAD_USER_INPUT"`.
   - Load `workspace` for the current tenant + workspace id; error if not found.
   - Return **empty arrays** for all new surfaces until write paths exist:
     - `manifests`, `statuses`, `integrationLinks`, `jobs`, `setupGuidance`, `uiModuleManifests`
   - Set `generatedAt` to a DateTime string (`new Date().toISOString()`).
3. Update the committed SDL snapshot (must match the SDL exposed by the Context subgraph):
   - `v2/infra/compose/graphql/subgraphs/tribuence-context/schema.graphql`

## Step 3 — Local verification
1. Bring up v2 and render secrets:
   - `KEYCLOAK_ADMIN=admin KEYCLOAK_ADMIN_PASSWORD=dev-not-admin make -C v2 v2-up`
   - `V2_VAULT_MINT_ANYLLM_API_KEY=true bash v2/scripts/vault/bootstrap-v2.sh`
2. Create a workspace (needed so snapshot can return a non-null `workspace` field).
3. Query Router and assert:
   - non-null snapshot response
   - `generatedAt` present
   - all list fields present and array-typed (empty-safe)
4. Negative tests (required):
   - Missing both `workspaceId` arg and `x-workspace-id` header yields `BAD_USER_INPUT`
   - Tenant mismatch does not allow reading another tenant’s workspace (workspace not found)

## Step 4 — Submit for review
1. Update `validation.md` with the exact verification commands used.
2. Set status to `review` via `pnpm -C project-handbook make -- task-status id=TASK-035 status=review`.
