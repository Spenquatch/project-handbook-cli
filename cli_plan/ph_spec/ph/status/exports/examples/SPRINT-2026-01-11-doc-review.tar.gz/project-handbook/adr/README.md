---
title: ADRs (Global Decisions)
type: process
date: 2025-09-12
tags: [adr, decisions]
links: []
---

# Architectural Decision Records (Global)

Use ADRs for cross-cutting, multi-feature decisions. Feature-specific decisions belong in each feature's `fdr/` folder.

Naming & Status
- File: `0001-<slug>.md` with id `ADR-0001` in front matter
- Status: `draft | accepted | superseded | rejected`
- Supersede rules: add both `supersedes` and `superseded_by` links when applicable

## Key System ADRs

### Capacity Management
- **ADR-0002**: 80/20 Sprint Capacity Allocation Model (planned work vs reactive)
- **ADR-0003**: P0-P4 Issue Severity Classification System

### Process & Workflow
- **ADR-0004**: Parking Lot Quarterly Review Cycle
- **ADR-0005**: AI-Powered P0 Issue Triage System

*Note: Create these ADRs as your team formalizes these decisions*

