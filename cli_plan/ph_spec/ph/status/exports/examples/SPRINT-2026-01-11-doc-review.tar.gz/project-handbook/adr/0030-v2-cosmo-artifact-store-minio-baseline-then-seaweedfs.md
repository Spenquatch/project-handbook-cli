---
id: ADR-0030
title: v2 Cosmo Artifact Store — MinIO Baseline then SeaweedFS Cutover
type: adr
status: accepted
date: 2026-01-10
tags: [v2, registry, cosmo, minio, seaweedfs, s3]
links:
  - ./0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
  - ../decision-register/DR-0003-cosmo-minio-baseline-topology.md
  - ../features/v2_registry-cosmo-minio-required/overview.md
  - ../features/v2_registry-cosmo-minio-required/fdr/0001-vault-secrets-contract-cosmo-minio.md
---

# Context

ADR-0015 requires Cosmo + MinIO in the default v2 stack. During discovery (`DR-0003`), operator input introduced concern about MinIO’s long-term support posture. SeaweedFS was evaluated as a migration target because it provides an S3 gateway (`weed server -s3`) and stable release tags.

# Decision

1) **Implement the baseline with MinIO first**, using the legacy, known-good wiring as the reference shape (`modular-oss-saas/infra/compose/*` and `modular-oss-saas/scripts/infra/*`) adapted to v2 conventions.

2) **Follow the accepted Vault contract** for Cosmo/MinIO secrets seeding + rendering:
   - `FDR-v2_registry-cosmo-minio-required-0001` (no secrets printed posture).

3) **Immediately follow with a SeaweedFS cutover series** once the baseline is green:
   - bring up SeaweedFS S3 gateway on the internal v2 network (no Traefik exposure),
   - validate Cosmo artifact write/read behavior against SeaweedFS,
   - remove MinIO from the default v2 compose once cutover succeeds.

4) **Minimize migration cost from day one** by keeping the artifact-store integration store-agnostic:
   - use a generic S3 client for bucket initialization (prefer `aws-cli` over `minio/mc`),
   - centralize endpoint/creds/bucket configuration so swapping the backend is a bounded change,
   - add a reusable “Cosmo artifact write/read” smoke probe used for both baseline and cutover.

# Consequences

## Positive
- Unblocks the registry pipeline quickly using proven MinIO wiring.
- Avoids accumulating “silent” MinIO debt by explicitly scheduling the SeaweedFS cutover as the next bounded slice.
- Keeps the artifact-store integration measurable (via probe) and easier to swap.

## Tradeoffs
- Requires implementing and maintaining two artifact-store backends during the transition window.
- SeaweedFS may have S3 parity differences vs MinIO; cutover is gated by explicit probes and should not proceed without passing them.

# Rollout / Acceptance

- Baseline: `make v2-up` brings up Cosmo + MinIO + dependencies successfully, with internal-only posture and bucket init.
- Cutover: SeaweedFS S3 gateway passes the “Cosmo artifact write/read” probe and becomes the artifact store; MinIO is removed from the default stack.
