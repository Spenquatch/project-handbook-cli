---
title: Validate: Playwright E2E for module load + failure modes - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-039
tags: [implementation]
links: []
---

# Implementation Steps: Validate: Playwright E2E for module load + failure modes

## Overview
Add Playwright E2E coverage that validates the runtime module loader contract:
- happy path module load + render,
- deterministic fallback states for key failure modes,
- no secrets printed while seeding artifacts or running tests.

## Prerequisites
- [ ] `TASK-031` is `done` (publish pipeline exists for seeding module artifacts)
- [ ] `TASK-038` is `done` (module-backed panel + fallback states exist in the UI)
- [ ] Playwright can run locally for `v2/apps/tribuence-mini`:
  - `pnpm -C v2/apps/tribuence-mini exec playwright test`

## Step 1 — Seed test artifacts into internal S3 (explicit module set)
Create and seed these module artifacts (one file each: `index.mjs`) using the publish pipeline from `TASK-031`:

Allowlisted module IDs (must be on the loader allowlist from `TASK-037`):
- `example` (happy path)
- `example-missing` (missing artifact → `FETCH_404`), intentionally **not uploaded**
- `example-hash-mismatch` (bytes mismatch → `HASH_MISMATCH`)
- `example-eval-error` (throws at eval → `EVAL_ERROR`)
- `example-export-invalid` (missing required exports → `EXPORT_INVALID`)

Non-allowlisted module ID (must not be on the allowlist):
- `not-allowlisted` → `NOT_ALLOWLISTED` (no upload required)

Seeding rules:
- All module versions are `0.0.0` (this is E2E-only; keep it stable).
- For `HASH_MISMATCH`, you must upload **tampered bytes** under the key that includes the *expected* sha256 (documented fallback).

## Step 2 — Write Playwright tests
Add a spec under `v2/apps/tribuence-mini/e2e/` that:
1. Logs in via Keycloak (reuse `e2e/helpers/keycloak.ts`).
2. Ensures a workspace exists and is selected (reuse the onboarding flow patterns).
3. Asserts the “UI Modules” registry harness section shows:
   - `ui-module-demo-happy` → `data-state="loaded"`
   - `ui-module-demo-not-allowlisted` → `data-state="fallback"` + `data-reason-code="NOT_ALLOWLISTED"`
   - `ui-module-demo-missing` → `data-state="fallback"` + `data-reason-code="FETCH_404"`
   - `ui-module-demo-hash-mismatch` → `data-state="fallback"` + `data-reason-code="HASH_MISMATCH"`
   - `ui-module-demo-eval-error` → `data-state="fallback"` + `data-reason-code="EVAL_ERROR"`
   - `ui-module-demo-export-invalid` → `data-state="fallback"` + `data-reason-code="EXPORT_INVALID"`

Hard requirement:
- Assertions must use stable selectors (`data-testid="ui-module-panel"` + `data-capability-id`) rather than fragile text-only matching.

## Step 3 — Evidence capture
Capture evidence under `project-handbook/status/evidence/TASK-039/`:
- publish output(s) showing `{moduleId, version, integritySha256}`,
- Playwright output + (if present) screenshots/videos/traces,
- a short note listing the exact failure cases covered and the expected reason codes.

## Notes
- Avoid printing secrets:
  - do not `cat /secrets/*.env`, do not dump `env`, do not `vault kv get`.
