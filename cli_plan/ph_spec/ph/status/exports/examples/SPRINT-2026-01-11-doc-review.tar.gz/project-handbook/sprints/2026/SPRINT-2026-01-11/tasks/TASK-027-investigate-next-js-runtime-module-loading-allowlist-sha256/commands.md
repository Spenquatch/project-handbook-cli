---
title: Investigate: Next.js runtime module loading (allowlist + sha256) - Commands
type: commands
date: 2026-01-11
task_id: TASK-027
tags: [commands]
links: []
---

# Commands: Investigate: Next.js runtime module loading (allowlist + sha256)

## Task Status
```bash
pnpm -C project-handbook make -- task-status id=TASK-027 status=doing
pnpm -C project-handbook make -- task-status id=TASK-027 status=review
pnpm -C project-handbook make -- task-status id=TASK-027 status=done
```

## Evidence Directory (required)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-027"
mkdir -p "$EVID_DIR"
${EDITOR:-vi} "$EVID_DIR/index.md"
```

## Read Context (capture as evidence)
```bash
set -euo pipefail

sed -n '1,240p' project-handbook/adr/0025-v2-1-ui-module-registry.md | tee "$EVID_DIR/adr-0025.txt"
sed -n '1,240p' project-handbook/adr/0024-v2-ui-dev-harness-and-module-boundaries.md | tee "$EVID_DIR/adr-0024.txt"
DR_PATH="project-handbook/features/v2.1_ui-module-registry-discovery/decision-register/DR-0002-nextjs-runtime-module-loading-strategy.md"
${EDITOR:-vi} "$DR_PATH"
```

## Locate UI boundary references (repo inspection only)
```bash
rg -n "panel|boundary|capability panel|module" project-handbook/features/v2_ui-dev-harness-and-module-boundaries -S | tee "$EVID_DIR/ui-boundary-notes.txt" || true
```

## Handbook Validation
```bash
pnpm -C project-handbook make -- validate
```
