---
id: ADR-0014
title: Tribuence Mini v2 Auth-Gated UI + BFF Endpoints + Security Posture (Phase 1)
type: adr
status: draft
date: 2026-01-05
tags: [tribuence-mini, v2, auth, security, nextjs, keycloak, nextauth, traefik]
links:
  - ../../v2/ARCHITECTURE.md
  - ../features/tribuence-mini-v2/overview.md
  - ../contracts/tribuence-mini-v2/traefik-routing.md
  - ../contracts/tribuence-mini-v2/supergraph-router.md
  - ./0010-tribuence-mini-v2-local-dev-auth-and-headers.md
---

# Context

`v0.3.0` established a **GraphQL-only** v2 UI talking to Apollo Router (`router.local`) and validated by `make v2-smoke`.

The next “big chunk” of work needs to make the v2 UI:
- **Auth gated** (end-user login required),
- **Secure** (no token leakage, least exposure via Traefik, safe logging),
- **Reliable** (health endpoints and actionable diagnostics), and
- **Extendable** (a stable server-side integration surface for future growth).

This ADR intentionally focuses on local/dev posture first; production-grade hardening remains a follow-up.

# Decision

## 1) Auth-gate the v2 UI with Keycloak + NextAuth

- The v2 UI (`app.local`) requires login when `NEXT_PUBLIC_REQUIRE_AUTH=true`.
- Authentication uses **Keycloak** (OIDC) and **NextAuth** in the v2 UI app.
- The UI gets a minimal `/login` surface and redirects to the main app after successful auth.

## 2) Add minimal “BFF” Next.js endpoints (server-only integration surface)

The v2 UI will include a small set of **server-only** endpoints under `/api/*`:
- `/api/auth/*` (required for NextAuth)
- `/api/healthz` (UI aggregate health)
- Optional “BFF” endpoints for operations that should not be executed directly by the browser:
  - large document upload (multipart),
  - Twenty mutations (service-token gated) while UI-level Twenty codegen is evolving.

Client-side code must not call upstream services directly (no direct Twenty/AnythingLLM URLs, no embedding of service tokens).

## 3) Traefik continues to expose only an allowlist of public hosts

Public hosts (Traefik):
- `app.local` → v2 UI
- `router.local` → Apollo Router
- `keycloak.local` → Keycloak (only when auth is enabled)

All other upstream services remain internal-only (no Traefik routers for Twenty, AnythingLLM, Vault, Postgres, etc).

## 4) No sensitive token leakage in logs or client env

- Service tokens remain in Vault and are only available to server-side processes (containers) and operator tooling.
- Error responses returned to the browser must be sanitized (strip bearer tokens, API keys, JWTs).
- Logging must avoid printing headers like `authorization` or Vault-rendered secret values.

# Consequences

## Positive
- End-user auth gating becomes a first-class v2 concept (not an afterthought).
- A stable “BFF” surface enables incremental improvements (upload strategy, Twenty ops) without breaking the UI.
- Keeps Traefik exposure tight while still supporting login flows.

## Tradeoffs
- Adds complexity (Keycloak + NextAuth + UI routing + BFF endpoints).
- “Auth gated UI” does not automatically imply “end-user auth across subgraphs”; early phases may still rely on service tokens for subgraph access.

# Rollout / Acceptance

- `keycloak.local` routes and NextAuth OIDC flow work end-to-end in local/dev.
- `app.local` is inaccessible when auth is required and the user is not logged in.
- `make v2-smoke` remains green; new `/api/healthz` is additive and does not replace smoke as the release gate.
- No browser-exposed environment variables include service tokens (Twenty, AnythingLLM, Vault).

