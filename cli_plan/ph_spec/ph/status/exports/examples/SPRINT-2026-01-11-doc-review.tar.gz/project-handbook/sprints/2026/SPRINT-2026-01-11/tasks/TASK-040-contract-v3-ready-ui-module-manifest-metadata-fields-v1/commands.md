---
title: Contract: v3-ready UI module manifest metadata fields (v1) - Commands
type: commands
date: 2026-01-12
task_id: TASK-040
tags: [commands]
links: []
---

# Commands: Contract: v3-ready UI module manifest metadata fields (v1)

## Task Status
```bash
pnpm -C project-handbook make -- task-status id=TASK-040 status=doing
pnpm -C project-handbook make -- task-status id=TASK-040 status=review
pnpm -C project-handbook make -- task-status id=TASK-040 status=done
```

## Confirm Dependencies (must be `done`)
```bash
pnpm -C project-handbook make -- task-show id=TASK-032
pnpm -C project-handbook make -- task-show id=TASK-033
```

## Evidence Directory
```bash
EVID_DIR="project-handbook/status/evidence/TASK-040"
mkdir -p "$EVID_DIR"
${EDITOR:-vi} "$EVID_DIR/index.md"
```

## Capture Inputs (evidence)
```bash
set -euo pipefail
EVID_DIR="project-handbook/status/evidence/TASK-040"

sed -n '1,260p' project-handbook/adr/0033-module-registry-alignment-with-v3-roadmap.md \
  | tee "$EVID_DIR/adr-0033.txt"

rg -n "ContextUiModuleManifest|ContextArtifactProvenance|ContextLicensePosture|uiModuleManifests" \
  project-handbook/contracts/tribuence-mini-v2/context-subgraph.md \
  | tee "$EVID_DIR/context-subgraph-before.txt"

rg -n "ui_module_manifests|provenance_|license_" \
  project-handbook/contracts/tribuence-mini-v2/context-db-schema.md \
  | tee "$EVID_DIR/context-db-before.txt"
```

## Edit Contracts
```bash
${EDITOR:-vi} project-handbook/contracts/tribuence-mini-v2/context-subgraph.md
${EDITOR:-vi} project-handbook/contracts/tribuence-mini-v2/context-db-schema.md
```

## Capture “After” Excerpts + Diffs (required)
```bash
set -euo pipefail
EVID_DIR="project-handbook/status/evidence/TASK-040"
mkdir -p "$EVID_DIR"

rg -n "ContextUiModuleManifest|ContextArtifactProvenance|ContextLicensePosture|provenance:|license:" \
  project-handbook/contracts/tribuence-mini-v2/context-subgraph.md \
  | tee "$EVID_DIR/context-subgraph-after.txt"

rg -n "ui_module_manifests|provenance_|license_" \
  project-handbook/contracts/tribuence-mini-v2/context-db-schema.md \
  | tee "$EVID_DIR/context-db-after.txt"

git diff -- project-handbook/contracts/tribuence-mini-v2/context-subgraph.md \
  | tee "$EVID_DIR/context-subgraph.diff"

git diff -- project-handbook/contracts/tribuence-mini-v2/context-db-schema.md \
  | tee "$EVID_DIR/context-db.diff"
```

## Validation
```bash
set -euo pipefail
EVID_DIR="project-handbook/status/evidence/TASK-040"
mkdir -p "$EVID_DIR"

pnpm -C project-handbook make -- validate | tee "$EVID_DIR/validate.txt"
pnpm -C project-handbook make -- sprint-status | tee "$EVID_DIR/sprint-status.txt"
```

## Quick Copy-Paste
```bash
pnpm -C project-handbook make -- task-show id=TASK-040
rg -n "ContextUiModuleManifest|ContextArtifactProvenance|ContextLicensePosture" project-handbook/contracts/tribuence-mini-v2/context-subgraph.md
rg -n "ui_module_manifests|provenance_|license_" project-handbook/contracts/tribuence-mini-v2/context-db-schema.md
```
