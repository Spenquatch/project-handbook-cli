---
title: Validate: v2 smoke probe for control-plane snapshot query - Commands
type: commands
date: 2026-01-11
task_id: TASK-036
tags: [commands]
links: []
---

# Commands: Validate: v2 smoke probe for control-plane snapshot query

## Task Status
```bash
pnpm -C project-handbook make -- task-status id=TASK-036 status=doing
pnpm -C project-handbook make -- task-status id=TASK-036 status=review
pnpm -C project-handbook make -- task-status id=TASK-036 status=done
```

## Evidence Directory
```bash
EVID_DIR="project-handbook/status/evidence/TASK-036"
mkdir -p "$EVID_DIR"
${EDITOR:-vi} "$EVID_DIR/index.md"
```

## Implement (v2 repo)
```bash
${EDITOR:-vi} v2/scripts/v2-smoke.sh
```

## Start/Verify v2 Stack (local)
This task requires the v2 stack to be reachable at `http://router.local/` (default for the smoke harness).

`make -C v2 v2-up` requires non-default Keycloak admin bootstrap env vars:
- `KEYCLOAK_ADMIN`
- `KEYCLOAK_ADMIN_PASSWORD` (must not be `admin`)

```bash
# From repo root
KEYCLOAK_ADMIN="admin" KEYCLOAK_ADMIN_PASSWORD="dev-not-admin" make -C v2 v2-up
```

## Run Smoke Harness (capture evidence)
```bash
set -euo pipefail
EVID_DIR="project-handbook/status/evidence/TASK-036"
mkdir -p "$EVID_DIR"

# Router-mode smoke run that MUST include the new snapshot probe
V2_SMOKE_MODE=router \
V2_SMOKE_REQUIRE_GRAPHS=TRIBUENCE_CONTEXT \
V2_SMOKE_ROUTER_URL="http://router.local/" \
make -C v2 v2-smoke 2>&1 | tee "$EVID_DIR/v2-smoke.txt"
```

## Validate Handbook (docs)
```bash
# From repo root
pnpm -C project-handbook make -- validate
```
