---
title: Implement: Context DB migrations for control-plane tables (v1) - Commands
type: commands
date: 2026-01-11
task_id: TASK-034
tags: [commands]
links: []
---

# Commands: Implement: Context DB migrations for control-plane tables (v1)

## Task Status
```bash
pnpm -C project-handbook make -- task-status id=TASK-034 status=doing
pnpm -C project-handbook make -- task-status id=TASK-034 status=review
pnpm -C project-handbook make -- task-status id=TASK-034 status=done
```

## Preflight (dependency + contract presence)
```bash
pnpm -C project-handbook make -- task-show id=TASK-033

# Must contain the v1 control-plane table contract before you implement migrations.
rg -n "control-?plane|v1|capability_manifests|integration_links|ui_module_manifests" \
  project-handbook/contracts/tribuence-mini-v2/context-db-schema.md
```

## Evidence Directory
```bash
EVID_DIR="project-handbook/status/evidence/TASK-034"
mkdir -p "$EVID_DIR"
${EDITOR:-vi} "$EVID_DIR/index.md"
```

## Choose migration filename(s)
Context applies migrations in **lexicographic sort order**, every boot.
```bash
ls -1 v2/services/context/db/migrations/*.sql | tee "$EVID_DIR/migrations-ls.txt"
```

## Implement migrations (v2 repo)
```bash
${EDITOR:-vi} v2/services/context/db/migrations/002_control_plane_v1.sql
```

## Bring up v2 (required for DB + Context startup)
`make -C v2 v2-up` refuses default `admin/admin` Keycloak credentials.
```bash
KEYCLOAK_ADMIN=admin KEYCLOAK_ADMIN_PASSWORD=dev-not-admin make -C v2 v2-up

# Render /secrets/*.env (Context reads DATABASE_URL from /secrets/context.env)
V2_VAULT_MINT_ANYLLM_API_KEY=true bash v2/scripts/vault/bootstrap-v2.sh
```

## Verify Context boot (migrations apply with no errors)
```bash
docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml logs --tail=200 context \
  | tee "$EVID_DIR/context-startup-logs.txt"

# Idempotency check: restart Context (migrations run again)
docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml restart context
docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml logs --tail=200 context \
  | tee -a "$EVID_DIR/context-startup-logs.txt"
```

## Verify tables + indexes exist in Postgres (and v0 tables preserved)
```bash
{
  echo "== tables ==";
  docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml exec -T postgres \
    psql -U postgres -d tribuence_v2 -c "\\dt" ;
  echo "";
  echo "== indexes (context schema) ==";
  docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml exec -T postgres \
    psql -U postgres -d tribuence_v2 -c "select tablename, indexname from pg_indexes where schemaname='public' and tablename like 'context_%' order by tablename, indexname;" ;
} | tee "$EVID_DIR/psql-schema.txt"
```

## Handbook validation
```bash
pnpm -C project-handbook make -- validate | tee "$EVID_DIR/handbook-validate.txt"
```
