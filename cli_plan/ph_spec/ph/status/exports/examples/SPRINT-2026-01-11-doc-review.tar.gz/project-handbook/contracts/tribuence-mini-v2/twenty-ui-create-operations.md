---
title: Tribuence Mini v2 Twenty Create Operations (MVP)
type: api
date: 2026-01-05
tags: [contracts, twenty, graphql, tribuence-mini-v2]
links:
  - ../../features/tribuence-mini-v2/overview.md
  - ./twenty-subgraph.md
  - ./supergraph-router.md
  - ./vault-secrets.md
  - ./ui-graphql-operations.md
  - ../../../v2/infra/compose/graphql/subgraphs/twenty/schema.graphql
---

# Contract: Twenty Create Operations (v2, MVP)

## Purpose
Define the **minimum Twenty GraphQL operation(s)** needed for the v2 “simple create tool” (v0.4.0) so implementation work does not guess.

This contract is based on the committed Twenty SDL snapshot:
- `v2/infra/compose/graphql/subgraphs/twenty/schema.graphql`

Evidence:
- `project-handbook/status/evidence/TASK-008/twenty-schema-snippet.txt`

## Router Endpoint + Headers
All operations are executed via Apollo Router:
- URL: `V2_GRAPHQL_URL` (local/dev: `http://router.local/`)
- Method: `POST`
- Path: `/`

Required headers:
- `content-type: application/json`
- `x-tenant-id: tribuence`
- `x-workspace-id: <workspaceId>` when a workspace is selected

## Auth Posture (Important)
Twenty requires a **service token** (local/dev default: `TWENTY_API_KEY` from Vault).

For Twenty operations, do **not** forward the end-user Keycloak token as `authorization` to Twenty. Instead:
- Execute server-side (Next.js server action / route handler), and
- Set `authorization: Bearer <TWENTY_API_KEY>` for the Router request used to reach Twenty.

Vault reference:
- `project-handbook/contracts/tribuence-mini-v2/vault-secrets.md`
- `project-handbook/contracts/tribuence-mini-v2/twenty-subgraph.md`

## MVP Operation: Create Person

### Schema signature
```graphql
createPerson(data: PersonCreateInput!, upsert: Boolean): Person
```

### Operation (recommended)
```graphql
mutation TwentyPersonCreate($data: PersonCreateInput!, $upsert: Boolean) {
  createPerson(data: $data, upsert: $upsert) {
    id
    createdAt
    name { firstName lastName }
    emails { primaryEmail }
    company { id name }
  }
}
```

### Variables (minimum recommended)
Notes:
- The SDL snapshot does not mark any `PersonCreateInput` fields as required, but the upstream service may still enforce expectations at runtime.
- Prefer always supplying at least a `name` and/or `emails.primaryEmail` for predictable UI feedback.

Example:
```json
{
  "data": {
    "name": { "firstName": "Ada", "lastName": "Lovelace" },
    "emails": { "primaryEmail": "ada@example.com" }
  },
  "upsert": false
}
```

### Minimal UI feedback fields
The response selection set above is the recommended minimum:
- `id` for linkability and dedupe
- `createdAt` for ordering
- `name` + `emails.primaryEmail` for immediate confirmation
- `company` is optional and may be `null`

## Alternate Operation (Optional): Create Company
Only use if the UI is intentionally creating companies first.

### Schema signature
```graphql
createCompany(data: CompanyCreateInput!, upsert: Boolean): Company
```

### Operation
```graphql
mutation TwentyCompanyCreate($data: CompanyCreateInput!, $upsert: Boolean) {
  createCompany(data: $data, upsert: $upsert) {
    id
    createdAt
    name
    domainName { primaryLinkUrl primaryLinkLabel }
  }
}
```

Example variables:
```json
{
  "data": { "name": "Example Co" },
  "upsert": false
}
```

## Error Handling Expectations (Server → UI)
Server-side code should treat GraphQL `errors[]` as failures and return a stable, compact error to the UI:
- Include a single human-readable message (avoid leaking upstream details).
- Prefer returning `400` for obvious input validation issues and `502` for upstream/service errors.

## Drift Risks
- Twenty’s schema is large and may change; treat the committed SDL snapshot as the source of truth for v0.4.0.
- `PersonCreateInput` is “all optional” in SDL; upstream may still require meaningful values (name/email) at runtime.
- When auth gating is enabled, user `authorization` headers will exist; Twenty operations must override with the service token.
