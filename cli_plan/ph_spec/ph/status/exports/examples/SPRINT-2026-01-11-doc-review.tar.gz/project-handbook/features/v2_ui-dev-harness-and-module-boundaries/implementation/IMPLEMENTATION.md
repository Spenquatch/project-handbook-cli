---
title: v2 UI Dev Harness + Module-Ready Boundaries Implementation
type: implementation
feature: v2_ui-dev-harness-and-module-boundaries
date: 2026-01-07
tags: [implementation]
links:
  - ../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
  - ../../adr/0018-v2-capability-detection-surface.md
---

# Implementation: v2 UI Dev Harness + Module-Ready Boundaries

## Build Steps (required)
1. Standardize a “capability panel” interface in the v2 UI codebase:
   - deterministic `capabilityId` and title,
   - accepts only workspace id + capability state (no env reads),
   - renders either interactive UI or gating UI based on capability state.
2. Make the landing page the single supported dev harness:
   - auth required,
   - workspace selection required,
   - capability panels rendered for all capabilities in the platform.
3. Enforce module-ready boundaries:
   - each panel fetches data via GraphQL hooks/server actions only,
   - panels never read `process.env` directly and never inspect querystring banners for readiness,
   - panels never import provider-specific secrets or tokens.
4. Add Playwright coverage that treats the landing harness as the canonical E2E entrypoint for capability tests.

## Required Posture
- UI capability gating is driven exclusively by Context capability state.
- UI panels are isolated and can be moved behind a v2.1 ModuleRegistry without contract changes.

## Implementation Notes
- This feature is a planning and boundary-enforcement layer; it does not introduce a module registry runtime.
