---
id: ADR-0023
title: v2 Context Knowledge Network (Workspace-Scoped Context Graph for AI)
type: adr
status: accepted
date: 2026-01-06
tags: [tribuence-mini, v2, context, integrations, ai, knowledge, graph]
links:
  - ../features/v2_context-knowledge-network/overview.md
  - ../features/v2_context-glue-integrations/overview.md
  - ../features/v2_capability-manifests-and-toggles/overview.md
  - ../features/v2_capability-detection-surface/overview.md
---

# Context

Tribuence requires a single workspace-scoped interface that AI workflows can use to retrieve curated, relevant, linkable
context across all integrated OSS systems (Twenty, AnythingLLM, and future providers). The existing v2 Context service
already models workspaces and generic references; this ADR extends it into a durable knowledge network.

# Decision

## 1) Context is the system-of-record for the workspace knowledge network

Context stores a workspace-scoped context graph with:
- entities (system + entityType + entityId + label + metadata),
- edges (typed relationships between entities),
- curated annotations (notes/tags attached to entities),
- ingestion runs (auditability and deterministic status).

All records are tenant/workspace scoped and never store provider secrets or raw auth headers.

## 2) Ingestion is driven by Context capability enablement and integration links

Context ingestion runs when a capability is enabled for a workspace and uses Context integration link state to resolve
provider workspace identity. Ingestion is idempotent and safe to retry.

Twenty and AnythingLLM ingestion is required baseline coverage for this feature.

## 3) AI retrieval uses a single Context GraphQL surface

Context exposes a deterministic retrieval API that returns a workspace-scoped “context pack” suitable for AI usage:
- entities + edges + annotations,
- provenance fields that link back to upstream systems using identifiers only.

Retrieval uses keyword search + graph traversal only.
Semantic embedding indexing is explicitly out of scope for this feature.

# Consequences

## Positive
- One cohesive, workspace-scoped context surface for AI and automation.
- Deterministic provenance across many OSS integrations.
- Strong isolation guarantees (tenant/workspace) enforced by one service.

## Tradeoffs
- Context becomes a higher-leverage core service that requires strict invariants and robust validation.

# Rollout / Acceptance

- Context persists entities, edges, annotations, and ingestion runs per workspace.
- Context ingests metadata from Twenty and AnythingLLM into the context graph model.
- Context exposes a workspace-scoped context-pack retrieval query that returns entities + edges + annotations.
- Isolation is enforced and verified: no cross-workspace reads/writes and no provider secret leakage.
