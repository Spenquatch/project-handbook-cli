---
title: Task TASK-028 - Investigate: Module registry alignment with v3 roadmap
type: task
date: 2026-01-11
task_id: TASK-028
feature: v2.1_ui-module-registry-discovery
session: research-discovery
tags: [task, v2.1_ui-module-registry-discovery]
links: [../../../../../features/v2.1_ui-module-registry-discovery/overview.md]
---

# Task TASK-028: Investigate: Module registry alignment with v3 roadmap

## Overview
- **Feature**: [v2.1_ui-module-registry-discovery](../../../../../features/v2.1_ui-module-registry-discovery/overview.md)
- **Decision**: `DR-0007` (create during this task; cross-cutting)
- **Story Points**: 2
- **Owner**: @spenser
- **Lane**: `integration/v3-alignment`
- **Session**: `research-discovery`

## Goal
Produce an operator-approvable cross-cutting DR (`DR-0007`) that captures minimal v3-compatible constraints for v2.1 module registry and Context control-plane evolution, and embed the resulting checklist into the v2.1 module registry discovery plan.

## Outputs (what must exist when done)
- Create and complete `project-handbook/decision-register/DR-0007-module-registry-alignment-with-v3-roadmap.md` (two viable options + evidence + explicit approval request; keep DR as `Proposed`).
- `project-handbook/features/v2.1_ui-module-registry-discovery/implementation/IMPLEMENTATION.md` includes a concrete v3 compatibility checklist (invariants + constraints; no placeholders).
- Evidence captured under `project-handbook/status/evidence/TASK-028/` and referenced from DR-0007.

## After operator approval (same research session)
- Promote the accepted decision to an ADR under `project-handbook/adr/` and create execution tasks that reference the ADR (not the DR).

## Non-goals
- Do not redesign v3 features; this task only constrains v2.1 decisions to avoid known dead ends.
- Do not create or change product code under `v2/`.

## Agent Navigation Rules
1. **Start work**: Update `task.yaml` status to "doing"
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: Set to "review" when ready for review

## Context & Background
This task creates a cross-cutting DR (`DR-0007`) that constrains the module registry and Context evolution without committing to execution until operator approval.

## Quick Start
```bash
pnpm -C project-handbook make -- task-status id=TASK-028 status=doing
cd project-handbook/sprints/current/tasks/TASK-028-*/
cat steps.md
cat commands.md
cat validation.md
```

## Dependencies
Review `task.yaml` for any `depends_on` tasks that must be completed first.

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.
