---
title: Implement: UI module panel integration + deterministic fallback states - Commands
type: commands
date: 2026-01-11
task_id: TASK-038
tags: [commands]
links: []
---

# Commands: Implement: UI module panel integration + deterministic fallback states

## Task Status Updates
```bash
pnpm -C project-handbook make -- task-status id=TASK-038 status=doing
pnpm -C project-handbook make -- task-status id=TASK-038 status=review
pnpm -C project-handbook make -- task-status id=TASK-038 status=done
```

## Required Environment (for manual validation)
- v2 stack is reachable at `http://app.local/` and `http://router.local/` (Traefik network aliases).
- A workspace exists and is selectable in the landing harness.
- Context snapshot query exists (from `TASK-035`) and returns `uiModuleManifests`.
- Postgres is running (service `postgres` in `v2/infra/compose/docker-compose.v2.yml`) if you seed `ui_module_manifests`.

## Validation Commands
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Implementation Commands
```bash
$EDITOR v2/apps/tribuence-mini/src/app/page.tsx
# Loader entrypoint is created in TASK-037 (path may differ; follow TASK-037 docs)
$EDITOR v2/apps/tribuence-mini/src/lib/ui-module-loader.ts

pnpm -C v2/apps/tribuence-mini lint
pnpm -C v2/apps/tribuence-mini typecheck
pnpm -C v2/apps/tribuence-mini test
```

## Manual Validation Helpers (copy/paste)

### 1) Create evidence folder
```bash
EVID_DIR="project-handbook/status/evidence/TASK-038"
mkdir -p "$EVID_DIR"
```

### 2) Seed one allowlisted module artifact into internal S3 (records `INTEGRITY_SHA256`)
This creates a minimal ESM module that satisfies the `TASK-037` export contract (`default` + `capabilityId`) and uploads
it to internal S3 at the exact key used by the origin route (`TASK-030`).

```bash
MODULE_ID="example"
VERSION="0.0.0"

cat >"$EVID_DIR/index.mjs" <<'EOF'
export const capabilityId = 'ui-module-demo-happy';
export default function ExamplePanel() {
  return 'Example module rendered.';
}
EOF

INTEGRITY_SHA256="$(python3 - <<'PY'
import hashlib
path = "project-handbook/status/evidence/TASK-038/index.mjs"
with open(path, "rb") as f:
  print(hashlib.sha256(f.read()).hexdigest())
PY
)"
printf '%s\n' "$INTEGRITY_SHA256" | tee "$EVID_DIR/index.mjs.sha256.txt"

docker compose -f v2/infra/compose/docker-compose.v2.yml run --rm \
  -e MODULE_ID="$MODULE_ID" \
  -e VERSION="$VERSION" \
  -e INTEGRITY_SHA256="$INTEGRITY_SHA256" \
  -v "$(pwd)/$EVID_DIR:/evid:ro" \
  --entrypoint /opt/healthcheck/with-env-file.sh \
  cosmo-artifact-probe \
  /secrets/artifacts.env sh -lc '
    KEY="ui-modules/${MODULE_ID}/${VERSION}/${INTEGRITY_SHA256}/index.mjs"
    aws --no-cli-pager --endpoint-url "$S3_ENDPOINT_URL" s3api put-object \
      --bucket "$COSMO_S3_BUCKET" \
      --key "$KEY" \
      --body /evid/index.mjs \
      --content-type "text/javascript; charset=utf-8" \
      >/dev/null
    printf "%s\n" "uploaded key=${KEY}"
  ' | tee "$EVID_DIR/upload.txt"
```

### 3) Seed a module manifest row (Context DB) for the selected workspace
This assumes Context stores module selection in `ui_module_manifests` (contracted in `TASK-033`) and that the snapshot
query reads from this table (still empty-safe when no rows exist).

```bash
# Pick the workspace you want to validate against (one row is enough for TASK-038).
# You can discover a workspace id by querying Router:
# curl -sS --resolve "router.local:80:127.0.0.1" -H 'content-type: application/json' -H 'x-tenant-id: tribuence' \
#   --data '{"query":"query { workspaces { id slug } }"}' "http://router.local/" | jq

WORKSPACE_ID="PUT-WORKSPACE-ID-HERE"
TENANT_ID="tribuence"
CAPABILITY_ID="ui-module-demo-happy"

MODULE_ID="example"
VERSION="0.0.0"
INTEGRITY_SHA256="$(cat "$EVID_DIR/index.mjs.sha256.txt")"

docker compose -f v2/infra/compose/docker-compose.v2.yml exec -T postgres \
  psql -v ON_ERROR_STOP=1 -U "${POSTGRES_USER:-postgres}" -d "${POSTGRES_DB:-tribuence_v2}" <<SQL
insert into ui_module_manifests (
  id, tenant_id, workspace_id, capability_id,
  module_id, version, integrity_sha256,
  created_at, updated_at
) values (
  'seed-' || md5(random()::text || clock_timestamp()::text),
  '${TENANT_ID}', '${WORKSPACE_ID}', '${CAPABILITY_ID}',
  '${MODULE_ID}', '${VERSION}', '${INTEGRITY_SHA256}',
  now(), now()
)
on conflict (tenant_id, workspace_id, capability_id)
do update set
  module_id = excluded.module_id,
  version = excluded.version,
  integrity_sha256 = excluded.integrity_sha256,
  updated_at = now();
SQL
```

## Git Integration
```bash
git -C project-handbook status
git -C v2 status
```

## Quick Copy-Paste
```bash
pnpm -C project-handbook make -- validate
pnpm -C v2/apps/tribuence-mini test
```
