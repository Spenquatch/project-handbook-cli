---
title: Contract: Context control-plane snapshot GraphQL contract (v1) - Commands
type: commands
date: 2026-01-11
task_id: TASK-032
tags: [commands]
links: []
---

# Commands: Contract: Context control-plane snapshot GraphQL contract (v1)

## Task Status
```bash
pnpm -C project-handbook make -- task-status id=TASK-032 status=doing
pnpm -C project-handbook make -- task-status id=TASK-032 status=review
pnpm -C project-handbook make -- task-status id=TASK-032 status=done
```

## Evidence Directory
```bash
EVID_DIR="project-handbook/status/evidence/TASK-032"
mkdir -p "$EVID_DIR"
${EDITOR:-vi} "$EVID_DIR/index.md"
```

## Capture "Before" Contract Excerpts (required)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-032"
mkdir -p "$EVID_DIR"

rg -n "GraphQL Schema|contextControlPlaneSnapshot|ContextControlPlaneSnapshot" \
  project-handbook/contracts/tribuence-mini-v2/context-subgraph.md \
  | tee "$EVID_DIR/context-subgraph-before.txt"
```

## Edit Contract
```bash
${EDITOR:-vi} project-handbook/contracts/tribuence-mini-v2/context-subgraph.md
```

## Capture "After" Excerpts + Diff (required)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-032"
mkdir -p "$EVID_DIR"

rg -n "contextControlPlaneSnapshot|ContextControlPlaneSnapshot|ContextUiModuleManifest" \
  project-handbook/contracts/tribuence-mini-v2/context-subgraph.md \
  | tee "$EVID_DIR/context-subgraph-after.txt"

git diff -- project-handbook/contracts/tribuence-mini-v2/context-subgraph.md \
  | tee "$EVID_DIR/context-subgraph.diff"
```

## Validation
```bash
EVID_DIR="project-handbook/status/evidence/TASK-032"
mkdir -p "$EVID_DIR"

pnpm -C project-handbook make -- validate | tee "$EVID_DIR/validate.txt"
pnpm -C project-handbook make -- sprint-status | tee "$EVID_DIR/sprint-status.txt"
```

## Quick Copy-Paste
```bash
pnpm -C project-handbook make -- task-show id=TASK-032
rg -n "contextControlPlaneSnapshot|ContextControlPlaneSnapshot" project-handbook/contracts/tribuence-mini-v2/context-subgraph.md
```
