---
title: Investigate: UI module artifact origin + publish pipeline (S3 + integrity) - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-026
tags: [implementation]
links: []
---

# Implementation Steps: Investigate: UI module artifact origin + publish pipeline (S3 + integrity)

## Overview
This is a `session=research-discovery` task. The deliverable is a completed feature-local DR (`DR-0001`) plus execution-ready feature documentation. No product code changes.

## Prerequisites
- `TASK-025` is `done` (release planning completed and current surfaces are coherent).

## Step 1 — Ground truth constraints (ADR + feature docs)
1. Read:
   - `project-handbook/adr/0025-v2-1-ui-module-registry.md`
   - `project-handbook/features/v2.1_ui-module-registry-discovery/architecture/ARCHITECTURE.md`
   - `project-handbook/features/v2.1_ui-module-registry-discovery/implementation/IMPLEMENTATION.md`
2. Create an evidence index at `project-handbook/status/evidence/TASK-026/index.md`.
3. Create the DR file for this task:
   - `project-handbook/features/v2.1_ui-module-registry-discovery/decision-register/DR-0001-ui-module-artifact-origin-and-publish-pipeline.md`

## Step 2 — Inventory existing artifact + secrets patterns (repo inspection)
Goal: understand the current v2 patterns for artifact storage and Vault-rendered env, and how to keep browsers off any internal artifact store.
1. Inspect:
   - `v2/infra/compose/docker-compose.v2.yml` (artifact store services + networks + exposure posture)
   - `v2/infra/vault/templates/*.tpl` and `v2/infra/vault/templates/agent.hcl` (how `/secrets/*.env` are rendered)
   - `project-handbook/features/v2_registry-cosmo-minio-required/fdr/0001-vault-secrets-contract-cosmo-minio.md` (no-leakage posture patterns)

Evidence to capture:
- `project-handbook/status/evidence/TASK-026/v2-artifact-store-inventory.txt`
- `project-handbook/status/evidence/TASK-026/v2-vault-template-inventory.txt`

## Step 3 — Define two viable origin models (A/B)
Update DR-0001 with exactly two viable options:
- **Option A**: reuse an internal S3-compatible artifact store and serve module bytes via the UI shell (proxy route).
- **Option B**: a dedicated module origin exposed via Traefik (localhost-only or internal-only), backed by S3.

Each option must specify:
- bucket name and object key scheme,
- immutability rules (no floating tags; version+hash pinned),
- how the UI resolves `{moduleId, version, integritySha256}` into an origin request,
- publish credentials posture and minimal CI outline,
- smoke validation steps (including integrity mismatch behavior).

## Step 4 — Complete DR-0001 (with evidence + recommendation)
1. Fill in `DR-0001` (replace placeholders, add evidence references).
2. End with an explicit operator approval request and keep status `Proposed` until approval.

## Step 5 — Update feature docs to be execution-ready (pending approval)
Update:
- `project-handbook/features/v2.1_ui-module-registry-discovery/architecture/ARCHITECTURE.md`
- `project-handbook/features/v2.1_ui-module-registry-discovery/implementation/IMPLEMENTATION.md`

Include:
- selected origin model and data flow,
- exact v2 wiring points that would change (as a plan only),
- exact smoke validation steps and what evidence to capture.

## Step 6 — Validate handbook + wrap for review
1. Run `pnpm -C project-handbook make -- validate`.
2. Update `validation.md` and `checklist.md` with the evidence file list.
3. Set task status to `review`.
