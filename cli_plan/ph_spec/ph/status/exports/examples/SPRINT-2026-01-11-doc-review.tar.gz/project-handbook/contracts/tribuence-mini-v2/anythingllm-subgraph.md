---
title: Tribuence Mini v2 AnythingLLM Subgraph Contract
type: api
date: 2025-12-31
tags: [contracts, anythingllm, graphql, federation, tribuence-mini-v2]
links:
  - ../../features/tribuence-mini-v2/overview.md
  - ../../adr/0007-tribuence-mini-v2-supergraph-context.md
  - ../../adr/0008-tribuence-mini-v2-anythingllm-subgraph-wrapper.md
  - ./supergraph-router.md
  - ./vault-secrets.md
  - ../../../v2/ARCHITECTURE.md
---

# Contract: AnythingLLM Subgraph (v2)

## Purpose
AnythingLLM is REST-first. v2 therefore treats “AnythingLLM subgraph” as a **GraphQL wrapper service** that:
- exposes a federation-ready GraphQL schema, and
- calls AnythingLLM REST internally using a Vault-provisioned API key.

This contract defines the **minimum** wrapper surface needed for v2 smoke tests and early UI migration, based on the existing Tribuence Mini POC integration code (`modular-oss-saas/apps/tribuence-mini/src/lib/llm.ts`).

## Service Contract (HTTP)
- Internal-only service (no Traefik route required).
- GraphQL endpoint path: `/graphql`
- Health endpoint path: `/health`

## Wrapper → AnythingLLM REST Contract

### Base URL & auth
- `ANYLLM_BASE_URL` must end with `/` (example: `http://anythingllm:3001/`)
- Requests must include `Authorization: Bearer <ANYLLM_API_KEY>`

These values are provisioned via Vault (see `vault-secrets.md`).

## Wrapper Error Behavior (Required)

### Input validation errors
The wrapper must validate required inputs and return GraphQL errors with:
- `extensions.code = BAD_USER_INPUT`
- a clear `message` (single line)

Examples:
- `anythingDocumentUpload.input.contentBase64` is not valid base64
- required fields are missing/empty

### Upstream AnythingLLM errors
When AnythingLLM REST returns a non-2xx response, the wrapper must:
- not leak `ANYLLM_API_KEY` in logs or errors
- return a GraphQL error with:
  - `extensions.code`:
    - `UNAUTHENTICATED` for upstream `401`
    - `FORBIDDEN` for upstream `403`
    - `BAD_GATEWAY` for other non-2xx (including `5xx`)
  - `extensions.upstream.status` (number)
  - `extensions.upstream.path` (string; example: `api/v1/workspaces`)

Note: the wrapper may still choose to return partial `data` when safe, but smoke probes and UI flows should treat any `errors[]` as actionable.

## API Key Minting (Local/Dev)
For local/dev, the repo already contains a reference way to mint an AnythingLLM API key by executing inside the container:
- `modular-oss-saas/scripts/vault/bootstrap-mini.sh` (`generate_anythingllm_api_key`)

For v2, prefer copying/adapting that logic into `v2/scripts/vault/bootstrap-v2.sh` (see `vault-bootstrap.md`) so the wrapper can call AnythingLLM REST without manual key setup.

### Minimum REST endpoints (v0)
The wrapper must be able to call:
- `GET api/v1/workspaces`
- `POST api/v1/workspace/new` with JSON body `{ "name": string }`
- `GET api/v1/documents`
- `POST api/v1/document/upload` as multipart form-data:
  - `file` (uploaded file)
  - `addToWorkspaces` (workspace slug)
  - `metadata` (optional JSON string)
- `POST api/v1/workspace/{slug}/chat` with JSON body:
  - `message` (string)
  - `mode` (`query|chat`)
  - `sessionId` (string|null)
  - `attachments` (array, optional)
  - `reset` (boolean, optional)

## GraphQL → REST Mapping (v0, Required)

### `Query.anythingWorkspaces`
- Calls: `GET api/v1/workspaces`
- Maps each upstream workspace object to:
  - `AnythingWorkspace.slug`: required (must be stable)
  - `AnythingWorkspace.name`: required
  - `AnythingWorkspace.id`: optional (pass through if present)

### `Mutation.anythingWorkspaceEnsure`
Goal: ensure a workspace exists and return the **canonical upstream slug** to use for subsequent operations.

- Input:
  - `input.slug`: desired workspace slug (local/dev can use deterministic values like `demo`)
  - `input.name`: optional; used for creation if provided, else fallback to `input.slug`
- Behavior:
  1. Call `GET api/v1/workspaces` and return an existing workspace whose `slug == input.slug` when present.
  2. If not found, call `POST api/v1/workspace/new` with `{ "name": input.name ?? input.slug }`.
  3. Re-fetch `GET api/v1/workspaces` and return the newly created workspace.
- Output requirement:
  - Always return the upstream `slug` actually present after creation, even if it differs from the requested `input.slug`.

Rationale: AnythingLLM may derive the slug from the created name; v2 smoke and UI should use the returned slug as the source of truth.

### `Query.anythingDocuments`
- Calls: `GET api/v1/documents`
- Mapping expectations:
  - `AnythingDocument.id`:
    - prefer upstream `id` when present
    - otherwise fall back to a stable unique field such as `location` (if present)
  - `AnythingDocument.title` is required; derive from upstream fields if needed (e.g. `title || name`)
  - other fields are best-effort pass-through

### `Mutation.anythingDocumentUpload`
- Input:
  - `workspaceSlug`: must be a canonical slug returned by `anythingWorkspaceEnsure` (or selected from `anythingWorkspaces`)
  - `contentBase64`: decoded to bytes
- Calls: `POST api/v1/document/upload` multipart form-data:
  - `file`: bytes with provided `filename` and `mimeType`
  - `addToWorkspaces`: `workspaceSlug`
  - `metadata`: optional JSON string, if provided
- Output:
  - `ok=true` only when upstream upload returns success (2xx)
  - `raw` may include an upstream response payload (debug-only; not relied on by smoke)

### `Mutation.anythingChat`
- Calls: `POST api/v1/workspace/{slug}/chat` with:
  - `message`, `mode`, `sessionId`, `reset`
- Output:
  - Map upstream response into `AnythingChatResponse` best-effort
  - `error` must be set when upstream responds with a successful HTTP status but indicates an application-level failure in its payload

## GraphQL Schema (Minimum v0)

```graphql
extend schema
  @link(url: "https://specs.apollo.dev/federation/v2.6", import: ["@key"])

scalar JSON

type AnythingWorkspace @key(fields: "slug") {
  slug: String!
  name: String!
  id: ID
}

type AnythingDocument @key(fields: "id") {
  id: ID!
  title: String!
  name: String
  url: String
  location: String
  published: String
  wordCount: Int
  tokenCountEstimate: Int
  metadata: JSON
}

type AnythingChatResponse {
  id: String
  type: String
  textResponse: String
  sources: [JSON!]!
  close: Boolean
  error: String
}

type AnythingDocumentUploadResult {
  ok: Boolean!
  raw: JSON
}

input AnythingWorkspaceEnsureInput {
  slug: String!
  name: String
}

input AnythingDocumentUploadInput {
  workspaceSlug: String!
  filename: String!
  mimeType: String!
  contentBase64: String!
  metadata: JSON
}

input AnythingChatInput {
  workspaceSlug: String!
  message: String!
  mode: String
  sessionId: String
  reset: Boolean
}

type Query {
  anythingWorkspaces: [AnythingWorkspace!]!
  anythingDocuments: [AnythingDocument!]!
}

type Mutation {
  anythingWorkspaceEnsure(input: AnythingWorkspaceEnsureInput!): AnythingWorkspace!
  anythingDocumentUpload(input: AnythingDocumentUploadInput!): AnythingDocumentUploadResult!
  anythingChat(input: AnythingChatInput!): AnythingChatResponse!
}
```

Notes:
- `AnythingDocumentUploadInput` uses base64 instead of `Upload` so Apollo Router + curl-based smoke tests can operate without multipart GraphQL upload wiring initially. Execution can later add `Upload` if desired.
- The GraphQL naming intentionally namespaces fields (`anything*`) to avoid collisions in the supergraph until we formalize shared domain types.
- The wrapper-defined `AnythingDocumentUploadResult.ok` is the stable success signal for smoke tests; `raw` may contain any upstream response payload for debugging.
