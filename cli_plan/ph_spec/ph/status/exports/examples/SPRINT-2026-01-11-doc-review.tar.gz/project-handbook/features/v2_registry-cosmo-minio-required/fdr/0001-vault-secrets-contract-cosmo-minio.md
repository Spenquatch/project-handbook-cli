---
id: FDR-v2_registry-cosmo-minio-required-0001
title: Vault Secrets Contract for Cosmo/MinIO (No Leakage)
type: fdr
status: accepted
date: 2026-01-10
tags: [v2, registry, vault, cosmo, minio, security, fdr]
links:
  - ../overview.md
  - ../implementation/IMPLEMENTATION.md
  - ../../../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
  - ../../../adr/0030-v2-cosmo-artifact-store-minio-baseline-then-seaweedfs.md
  - ../../../decision-register/DR-0004-vault-secrets-contract-cosmo-minio.md
  - ../../../status/evidence/TASK-002/index.md
---

# Decision

Adopt the **Option A** secrets contract from `DR-0004`: a small number of KV paths and rendered env files, consistent with existing v2 Vault patterns, with strict “no secrets printed” posture.

# Scope

In scope:
- Vault KV v2 paths + required field names for Cosmo + MinIO baseline (names only; no values).
- Vault Agent template outputs under `/secrets/*.env`.
- Bootstrap behavior expectations for `v2/scripts/vault/bootstrap-v2.sh` (idempotent, never prints secret values).

Out of scope:
- Production secret rotation/PKI strategy.
- Non-Cosmo/MinIO secret contracts (covered by existing v2 KV entries: `next`, `router`, `context`, `anythingllm`).

# Implementation Contract (Execution Work References This)

## Vault KV v2 layout (paths + key names only)

### `kv/data/tribuence/v2/minio`
- `MINIO_ACCESS_KEY`
- `MINIO_SECRET_KEY`
- `COSMO_S3_BUCKET`

### `kv/data/tribuence/v2/cosmo`
- Postgres:
  - `COSMO_POSTGRES_USER`
  - `COSMO_POSTGRES_PASSWORD`
  - `COSMO_POSTGRES_DB`
- ClickHouse:
  - `COSMO_CLICKHOUSE_DB`
  - `COSMO_CLICKHOUSE_USER`
  - `COSMO_CLICKHOUSE_PASSWORD`
- Auth:
  - `COSMO_AUTH_JWT_SECRET`
  - `COSMO_AUTH_ADMISSION_SECRET`
- Cosmo Keycloak:
  - `COSMO_KEYCLOAK_ADMIN`
  - `COSMO_KEYCLOAK_ADMIN_PASSWORD`
- Cosmo seed (one-shot bootstrap job):
  - `COSMO_SEED_API_KEY`
  - `COSMO_SEED_USER_EMAIL`
  - `COSMO_SEED_USER_PASSWORD`
  - `COSMO_SEED_ORG`
- Optional centralized config:
  - `S3_REGION` (default `auto`)
  - `S3_FORCE_PATH_STYLE` (default `true`)
  - `COSMO_CONTROLPLANE_ALLOWED_ORIGINS`
  - `COSMO_WEB_BASE_URL`

## Rendered env contract (`/secrets/*.env`)

### `/secrets/minio.env` (consumer: `minio`)
- `MINIO_ROOT_USER` (from `MINIO_ACCESS_KEY`)
- `MINIO_ROOT_PASSWORD` (from `MINIO_SECRET_KEY`)

### `/secrets/cosmo.env` (consumers: `cosmo-controlplane`, `cosmo-cdn`, `cosmo-seed`)
- Derived values (do not duplicate in Vault):
  - `DB_URL` (from `COSMO_POSTGRES_*`)
  - `CLICKHOUSE_DSN`, `CLICKHOUSE_MIGRATION_DSN` (from `COSMO_CLICKHOUSE_*`)
  - `S3_STORAGE_URL` (from MinIO creds + `COSMO_S3_BUCKET`)
- Required Cosmo env vars (names only; see evidence for legacy naming):
  - `COSMO_AUTH_JWT_SECRET`, `COSMO_AUTH_ADMISSION_JWT_SECRET`
  - `S3_REGION`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY`, `S3_FORCE_PATH_STYLE`
  - `COSMO_SEED_API_KEY`, `COSMO_SEED_USER_EMAIL`, `COSMO_SEED_USER_PASSWORD`, `COSMO_SEED_ORG`

## v2 files expected to change (when implementing)
- Vault Agent:
  - `v2/infra/vault/templates/agent.hcl` (render `/secrets/minio.env` + `/secrets/cosmo.env`)
  - Add templates:
    - `v2/infra/vault/templates/minio.env.tpl`
    - `v2/infra/vault/templates/cosmo.env.tpl`
- Vault bootstrap:
  - `v2/scripts/vault/bootstrap-v2.sh` (seed `kv/data/tribuence/v2/minio` and `kv/data/tribuence/v2/cosmo`)

## “No secrets printed” posture (hard requirements)
- Do not print secret values in bootstrap logs or evidence:
  - Use “value not printed” messaging patterns (already present in v2 bootstrap evidence).
  - Do not emit `vault kv get` outputs; do not `cat /secrets/*.env`; do not dump `env`.
- Treat placeholders as unset and refuse to persist placeholder secrets.
- Avoid `set -x` (or disable it) in any secret-handling portion of scripts.

# When to transition to Option B (split contract) — explicit triggers

Transition from this FDR’s “Option A” contract to the “Option B” split model (per-service KV paths + per-service env templates) when one or more of these signals appear:
- **Least privilege becomes non-negotiable:** controlplane/cdn must not see seed user passwords or other one-shot bootstrap secrets.
- **New jobs need narrow access:** harvester/router/publisher need a Cosmo token or S3 creds but not DB/keycloak/seed secrets.
- **Different rotation cadence:** you need to rotate one secret independently (e.g., publish token weekly) without touching unrelated secrets (e.g., DB password quarterly).
- **Operator error/drift:** frequent accidental overwrites in a large `kv/data/tribuence/v2/cosmo` payload.
- **Exposure posture hardens:** any increase in external exposure (even localhost-bound operator overlays) raises the value of tighter secret scoping.

Migration notes (when splitting):
- Keep key names consistent; only change **where** they live (KV path + which `/secrets/*.env` consumes them).
- Prefer a mechanical migration:
  - add new KV paths/templates alongside the old,
  - update compose mounts to consume the new per-service env files,
  - then deprecate/remove the old keys once stable.

# Status

Accepted (based on operator/user approval of Option A in `DR-0004` on 2026-01-10).
