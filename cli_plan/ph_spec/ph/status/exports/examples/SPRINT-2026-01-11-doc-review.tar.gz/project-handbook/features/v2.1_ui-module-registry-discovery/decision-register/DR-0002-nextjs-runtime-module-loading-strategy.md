---
title: DR-0002 — Next.js runtime module loading strategy (allowlist + sha256)
type: decision-register
date: 2026-01-11
tags: [decision-register, nextjs, ui, modules, registry, integrity, allowlist]
links:
  - ../../../adr/0025-v2-1-ui-module-registry.md
  - ../../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
  - ../../../status/evidence/TASK-027/index.md
  - ./DR-0001-ui-module-artifact-origin-and-publish-pipeline.md
  - ../fdr/0002-nextjs-runtime-module-loading-strategy.md
---

# Decision Register Entry

### DR-0002 — Next.js runtime module loading strategy (allowlist + sha256)

**Decision owner(s):** @spenser  
**Date:** 2026-01-11  
**Status:** Accepted  
**Related docs:** `ADR-0025`, `ADR-0024`, `DR-0001`, `FDR-v2_1_ui-module-registry-discovery-0002`, `TASK-027`

**Problem / Context**
- `ADR-0025` requires runtime loading of allowlisted UI modules with pinned versions and sha256 integrity verification *before executing module code*.
- `DR-0001` selects the byte origin model: browser fetches module bytes from a same-origin UI route (Next.js proxy to internal S3-compatible storage).
- This decision defines *how* the Next.js UI shell loads and executes module code at runtime while preserving:
  - verify-before-execute integrity posture,
  - deterministic fallback UI for failures,
  - a module format contract that does not require a v2 panel retrofit (`ADR-0024`).

**Evidence (repo inspection)**
- `project-handbook/status/evidence/TASK-027/index.md`

**Posture: design for an A → B switch (low lift)**
- Regardless of Option A vs Option B, keep these contracts stable:
  - **Manifest fields**: `{ moduleId, version, integritySha256 }` (Context-owned per `ADR-0025`).
  - **Fetch URL**: `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}` (same-origin, per `DR-0001`).
  - **Artifact format**: single-file ESM `index.mjs`.
  - **Module contract**: required exports + deterministic failure reason codes + telemetry event shape.
- Implement the loader as one abstraction (example name: `loadUiModule()`), with a single config/flag:
  - `moduleLoaderMode = "browser-verify" | "server-verify"`
  - Switching A → B should be: “flip the flag + redeploy” (no refactor of panels, manifests, or publish pipeline).

**Option A — Browser verifies sha256 and imports via Blob URL ESM**
- **How it works (verify-before-execute)**
  - Client fetches bytes from: `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}` (same origin, `DR-0001`).
  - Client computes sha256 over response bytes and compares to `{integritySha256}`.
  - Only after a hash match, client creates a `Blob` (`type: "text/javascript"`) + `URL.createObjectURL()` and then `import(/* webpackIgnore: true */ blobUrl)`.
  - On success, the imported module’s exports are validated against the module contract (see “Module format contract” below).
- **Allowlist enforcement location**
  - Server route enforces allowlist + size/content-type hardening.
  - Client loader also enforces allowlist (fail fast before fetch).
- **Module format contract (execution-ready)**
  - Artifact: single-file ESM `index.mjs`.
  - Required exports:
    - `default` — a React component that renders a capability panel.
    - `capabilityId` — string used for sanity check vs Context manifest capability (prevents mis-wiring).
  - Optional exports:
    - `panelTitle` — display label for the harness.
    - `panelVersion` — module’s internal version string for telemetry/debugging.
- **Caching strategy**
  - HTTP caching: route returns `Cache-Control: public, max-age=31536000, immutable` because the URL includes `{integritySha256}`.
  - Client caching: cache the parsed module instance (or blob URLs) in-memory keyed by `{moduleId, version, integritySha256}` to avoid repeated hashing/import during a session.
  - Invalidation: none (new module version/hash is a new URL).
- **Deterministic fallback UI semantics**
  - On failure, the panel renders a “module unavailable” gated state with a stable reason code:
    - `NOT_ALLOWLISTED`, `FETCH_404`, `FETCH_FAILED`, `HASH_MISMATCH`, `EVAL_ERROR`, `EXPORT_INVALID`.
  - The shell continues rendering other panels; the failure does not break the app.
- **Telemetry hooks (no secrets)**
  - Emit an event like `ui_module_load_result` with:
    - `{ moduleId, version, integritySha256, outcome, reasonCode, durationMs }`
    - optional `correlationId` if the proxy route returns one on errors.
- **Pros:** Strongest “verify-before-execute” posture in the browser; loader can validate exports before rendering.
- **Cons:** Requires blob URL execution (impacts future CSP hardening); more client-side work (hashing + import).
- **Cascading implications:** If CSP is introduced, `script-src` must explicitly allow `blob:` for this path (or Option A becomes non-viable).
- **Risks:** Browser/runtime edge cases around importing from Blob URLs; must ensure loader is client-only (no SSR execution).
- **Unlocks:** Meets ADR-0025’s security posture without trusting any intermediate cache.
- **Quick wins / low-hanging fruit:** Reuses the `DR-0001` origin contract without needing a separate module host.

**Option B — Server verifies sha256 and client imports by URL (normal caching semantics)**
- **How it works (verify-before-execute via server)**
  - Server route fetches bytes from internal S3 storage and computes sha256.
  - Server compares computed hash to `{integritySha256}` in the request path:
    - mismatch ⇒ return `500` (or `404`) and *do not* return bytes.
    - match ⇒ return bytes with `Cache-Control: public, max-age=31536000, immutable` and `Content-Type: text/javascript`.
  - Client loads module code via a runtime `import(/* webpackIgnore: true */ url)` from the same-origin route.
- **Allowlist enforcement location**
  - Server route enforces allowlist (primary).
  - Client allowlist optional (defense-in-depth and better UX for deterministic failure codes).
- **Module format contract (execution-ready)**
  - Same as Option A (single-file ESM `index.mjs` with required exports).
- **Caching strategy**
  - Leverages standard browser module caching semantics for `import(url)` plus immutable HTTP caching.
  - Invalidation: none (new module version/hash is a new URL).
- **Deterministic fallback UI semantics**
  - If import fails (network/404/500 or module evaluation error), render the same deterministic “module unavailable” gated state and continue.
- **Telemetry hooks (no secrets)**
  - Emit `ui_module_load_result` with the same fields as Option A, but note the UI cannot validate pre-execution integrity independently (server is source of truth).
- **Pros:** No blob URL requirement; simplest client code; aligns with “serve verified assets” model and normal caching semantics.
- **Cons:** The browser executes code after it has already fetched it; the “verify-before-execute” guarantee relies on server correctness and route hardening.
- **Cascading implications:** Requires stronger server-side hardening (strict allowlist, size limits, content-type, error semantics) because the browser trusts the response.
- **Risks:** Next.js bundler/runtime constraints for runtime `import(url)` (must ensure it is treated as a true runtime import in the client bundle).
- **Unlocks:** Easiest path if CSP hardening disallows `blob:` or if Blob import proves unreliable in the target browsers.
- **Quick wins / low-hanging fruit:** Start with a minimal runtime `import(url)` loader and iterate on server hardening and deterministic error mapping.

**Recommendation**
- **Recommended:** Option A — Browser verifies sha256 and imports via Blob URL ESM
- **Rationale:** It matches the security intent of `ADR-0025` most directly (“verify bytes before execute” in the same runtime that executes them). If CSP hardening or runtime constraints make `blob:` untenable, Option B remains a viable fallback with stricter server hardening.

**Guidance: signals to transition Option A → Option B (what it looks like)**
- **CSP hardening blocks `blob:`**: security review requires a CSP that does not allow `script-src blob:` (or an equivalent posture), making Blob URL execution unacceptable.
- **Client CPU becomes measurable**: module hashing/import on typical client devices shows materially higher p95/p99 page-interactive times (especially on low-end devices).
- **Operational simplicity**: you prefer the browser do less work and want module execution to follow standard `import(url)` caching semantics for predictability.
- **Browser compatibility issues**: Blob URL ESM import has edge-case failures in your supported browsers that are hard to mitigate cleanly.
- **Prefetch + caching strategy favors URL imports**: you want to rely on standard module caching keyed by URL and/or a CDN cache, and keep the client loader minimal.

**Transition plan: Option A → Option B (expected lift)**
- **Low-ish lift if the “stable contracts” posture above is followed**.
- Concrete steps:
  - Extend the server route to enforce “verify-before-serve” (Option B):
    - allowlist + strict param validation,
    - return bytes only when verified for the requested `{integritySha256}`,
    - keep immutable cache headers.
  - Update the loader implementation:
    - keep the same `loadUiModule()` API,
    - set `moduleLoaderMode = "server-verify"` and use `import(/* webpackIgnore: true */ url)`,
    - keep the same deterministic failure mapping + telemetry event schema.
  - Re-run the same Playwright E2E suite:
    - happy path module load,
    - each failure mode renders the same deterministic fallback states.

**Follow-up tasks (explicit)**
- Pending operator approval of Option A:
  - Define the module contract in code (types + runtime validation):
    - required exports (`default`, `capabilityId`) and optional metadata fields.
  - Implement a client-only loader helper:
    - allowlist check,
    - fetch bytes from `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}`,
    - sha256 verify, blob URL import, export validation,
    - deterministic failure mapping + telemetry event emission.
  - Implement the loader behind a single abstraction + mode flag:
    - `moduleLoaderMode = "browser-verify" | "server-verify"`,
    - keep failure reason codes + telemetry stable across modes.
  - Ensure the origin route is hardened (even though chosen in `DR-0001`):
    - strict moduleId allowlist, version format validation, sha256 format validation,
    - max module size, safe content-type, immutable cache headers.
  - Define deterministic fallback UI for module load failures:
    - stable reason codes and operator-friendly UX copy (no secrets).
  - Add Playwright E2E coverage in the landing harness:
    - happy path module load,
    - each failure mode (404, allowlist reject, hash mismatch, eval error) renders deterministic fallback.
  - If/when CSP is introduced:
    - add an explicit decision/checklist item that confirms whether `script-src` allows `blob:` for Option A.

**Operator/user approval**
- Approved: **Option A** (operator approval received 2026-01-12).  
- Promoted to: `FDR-v2_1_ui-module-registry-discovery-0002` (`features/v2.1_ui-module-registry-discovery/fdr/0002-nextjs-runtime-module-loading-strategy.md`).
