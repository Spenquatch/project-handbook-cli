---
id: ADR-0020
title: v2 REST OSS Wrapping Patterns (Facade Subgraphs + Context Integration Ops)
type: adr
status: accepted
date: 2026-01-06
tags: [tribuence-mini, v2, rest, graphql, wrappers, capabilities]
links:
  - ../features/v2_rest-wrapper-facade-subgraphs/overview.md
  - ../features/v2_rest-wrapper-context-integration-ops/overview.md
  - ../adr/0016-v2-context-glue-integrations.md
---

# Context

Many OSS systems expose REST APIs only. Tribuence’s platform surface remains GraphQL-first, so REST capabilities must be
wrapped into GraphQL in a consistent way while still allowing narrow operational endpoints when a full subgraph is not
yet warranted.

# Decision

## 1) Facade subgraphs are the default for REST capabilities

For REST-based OSS that provides resource CRUD or broad domain functionality, we build a dedicated wrapper subgraph that:
- translates GraphQL operations into REST calls,
- enforces tenant/workspace scoping via Context integration mapping,
- standardizes pagination, filtering, and error handling,
- supports stub mode (`CAPABILITY_MISSING`) per ADR-0017.

## 2) Context integration ops exist for narrow workflows

For narrow workflows (setup, health probes, one-shot syncs, webhook provisioning), we expose “integration operations”
through Context GraphQL that:
- run server-side only,
- are workspace-scoped,
- return deterministic status/results for UI gating and automation,
- do not attempt to model full upstream resources.

## 3) Both patterns are required platform primitives

The platform must support both patterns:
- facade subgraphs for durable capability schemas,
- Context integration ops for targeted workflows and lifecycle management.

# Consequences

## Positive
- Enables rapid onboarding of REST OSS without abandoning GraphQL-first UX.
- Keeps the Router schema stable through contract/stub patterns.
- Prevents the UI from calling upstream REST directly.

## Tradeoffs
- Requires disciplined boundaries to avoid duplicating business logic between subgraphs and Context.

# Rollout / Acceptance

- At least one REST-only OSS capability is integrated via a facade subgraph.
- At least one setup/sync workflow for that capability is exposed via Context integration ops.
- No browser code calls upstream REST directly; all calls go through GraphQL (Router) and/or Context server-side ops.
