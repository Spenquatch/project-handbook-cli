---
title: V2_Registry Cosmo Minio Required Changelog
type: changelog
feature: v2_registry-cosmo-minio-required
date: 2026-01-06
tags: [changelog]
links: []
---

# Changelog: V2_Registry Cosmo Minio Required

## Unreleased
- Initial feature creation

## [Future Versions]
- To be determined based on implementation progress
