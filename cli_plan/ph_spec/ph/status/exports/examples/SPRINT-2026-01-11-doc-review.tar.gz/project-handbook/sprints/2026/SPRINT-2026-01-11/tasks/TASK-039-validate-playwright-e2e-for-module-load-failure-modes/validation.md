---
title: Validate: Playwright E2E for module load + failure modes - Validation Guide
type: validation
date: 2026-01-11
task_id: TASK-039
tags: [validation]
links: []
---

# Validation Guide: Validate: Playwright E2E for module load + failure modes

## Automated Validation
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Manual Validation (Must Be Task-Specific)
Run Playwright and capture results + publish/seed outputs (no secrets). Use the copy/paste blocks in `commands.md` so the
artifacts are deterministic and reviewable.

```bash
set -euo pipefail
EVID_DIR="project-handbook/status/evidence/TASK-039"
mkdir -p "$EVID_DIR"

pnpm -C v2/apps/tribuence-mini exec playwright test 2>&1 | tee "$EVID_DIR/playwright.txt"
```

**Pass criteria**
- Playwright passes.
- Covered cases:
  - happy path: module-backed panel renders
  - allowlist reject: deterministic fallback state rendered
  - missing artifact (404): deterministic fallback state rendered
  - hash mismatch: deterministic fallback state rendered
  - eval error: deterministic fallback state rendered
  - export invalid: deterministic fallback state rendered
- Evidence contains at least one captured publish output that records `{moduleId, version, integritySha256}` (no secrets).

## Evidence (required)
- `project-handbook/status/evidence/TASK-039/playwright.txt`
- `project-handbook/status/evidence/TASK-039/publish-example.txt`
- `project-handbook/status/evidence/TASK-039/publish-example-eval-error.txt`
- `project-handbook/status/evidence/TASK-039/publish-example-export-invalid.txt`
- `project-handbook/status/evidence/TASK-039/publish-example-hash-mismatch.txt`
- `project-handbook/status/evidence/TASK-039/example.sha256.txt`
- `project-handbook/status/evidence/TASK-039/example-eval-error.sha256.txt`
- `project-handbook/status/evidence/TASK-039/example-export-invalid.sha256.txt`
- `project-handbook/status/evidence/TASK-039/example-hash-mismatch.expected.sha256.txt`
- `project-handbook/status/evidence/TASK-039/notes.md` (brief list of cases + expected reason codes)

## Sign-off
- [ ] All validation steps completed
- [ ] Evidence documented above
- [ ] Ready to mark task as "done"
