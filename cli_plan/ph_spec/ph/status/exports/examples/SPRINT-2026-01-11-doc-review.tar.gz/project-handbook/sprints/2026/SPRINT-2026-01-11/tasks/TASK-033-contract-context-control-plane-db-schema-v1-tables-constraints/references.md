---
title: Contract: Context control-plane DB schema (v1 tables + constraints) - References
type: references
date: 2026-01-11
task_id: TASK-033
tags: [references]
links: []
---

# References: Contract: Context control-plane DB schema (v1 tables + constraints)

## Internal References

### Decision Context
- **Decision**: [FDR-v2_context-control-plane-schema-0001](../../../../../features/v2_context-control-plane-schema/fdr/0001-context-control-plane-snapshot-contract.md)
- **Decision register (background)**: [DR-0001](../../../../../features/v2_context-control-plane-schema/decision-register/DR-0001-context-control-plane-migration-and-consumption-contract.md)
- **Feature**: [Feature overview](../../../../../features/v2_context-control-plane-schema/overview.md)
- **Feature architecture**: [ARCHITECTURE.md](../../../../../features/v2_context-control-plane-schema/architecture/ARCHITECTURE.md)
- **Feature implementation plan**: [IMPLEMENTATION.md](../../../../../features/v2_context-control-plane-schema/implementation/IMPLEMENTATION.md)

### Canonical Contracts
- **Target contract (edit in this task)**: [context-db-schema.md](../../../../../contracts/tribuence-mini-v2/context-db-schema.md)
- **Related contract (GraphQL)**: [context-subgraph.md](../../../../../contracts/tribuence-mini-v2/context-subgraph.md)

### Related ADRs (invariants + posture)
- [ADR-0027](../../../../../adr/0027-v2-context-control-plane-schema.md) — control-plane snapshot + invariants
- [ADR-0016](../../../../../adr/0016-v2-context-glue-integrations.md) — integration mapping + provisioning posture
- [ADR-0022](../../../../../adr/0022-v2-capability-manifests-and-toggles.md) — enable/disable manifests
- [ADR-0018](../../../../../adr/0018-v2-capability-detection-surface.md) — UI gating based on Context

### Sprint Context
- **Sprint Plan**: [Current sprint](../../plan.md)
- **Sprint Tasks**: [All sprint tasks](../)
- **Daily Progress**: [Daily status](../../../../../status/daily/)

## Notes
Add concrete links here only when you discover resources during the task (no placeholders).
