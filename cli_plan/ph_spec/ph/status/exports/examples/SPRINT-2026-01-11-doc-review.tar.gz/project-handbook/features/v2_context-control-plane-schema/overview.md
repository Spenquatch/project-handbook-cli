---
title: v2 Context Control Plane Schema
type: overview
feature: v2_context-control-plane-schema
date: 2026-01-07
tags: [feature]
links: [./architecture/ARCHITECTURE.md, ./implementation/IMPLEMENTATION.md, ./testing/TESTING.md]
dependencies: ["ADR-0027", "ADR-0016", "ADR-0022", "ADR-0018", "ADR-0024", "ADR-0025", "ADR-0023"]
backlog_items:
  - WORK-P2-20260107-133109
  - WORK-P2-20260107-133116
parking_lot_origin: null  # Original parking lot ID if promoted
capacity_impact: planned  # planned (80%) or reactive (20%)
epic: false
---

# v2 Context Control Plane Schema

## Purpose
Define the Context “control plane” data model and GraphQL surface that all v2 capabilities depend on: capability manifests,
capability status, integration links, provisioning jobs, setup guidance, and (v2.1) UI module manifests.

## Outcomes
- Context exposes a workspace-scoped, deterministic capability control-plane API.
- Integration provisioning is modeled as durable jobs with explicit status and idempotency guarantees.
- UI gating, wrapper stub gating, and future module loading all consume the same Context control-plane state.
- The Context schema is provider-agnostic (Twenty/AnythingLLM first; extensible to any OSS).

## State
- Stage: approved
- Owner: @spenser

## Scope
- Formalizes the v2 control-plane schema that powers:
  - `v2_context-glue-integrations`,
  - `v2_capability-manifests-and-toggles`,
  - `v2_capability-detection-surface`,
  - `v2_ui-dev-harness-and-module-boundaries`,
  - `v2.1_ui-module-registry-execution`,
  - `v2_context-knowledge-network`.
- This feature defines the schema and acceptance constraints; implementation tasks follow after discovery work-items complete.

## Backlog Integration
- Related Issues: ["WORK-P2-20260107-133109", "WORK-P2-20260107-133116"]
- Capacity Type: planned  # Uses 80% allocation
- Parking Lot Origin: null  # Set if promoted from parking lot

## Key Links
- [Architecture](./architecture/ARCHITECTURE.md)
- [Implementation](./implementation/IMPLEMENTATION.md)
- [Testing](./testing/TESTING.md)
- [Status](./status.md)
- [Changelog](./changelog.md)
