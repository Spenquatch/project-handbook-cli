---
title: Handbook: Plan v0.5.1 release + assign initial features - Completion Checklist
type: checklist
date: 2026-01-11
task_id: TASK-025
tags: [checklist]
links: []
---

# Completion Checklist: Handbook: Plan v0.5.1 release + assign initial features

## Pre-Work
- [ ] Confirm `TASK-024` is `done`
- [ ] Confirm `project-handbook/releases/current` exists and points to a release directory

## During Execution
- [ ] Create `project-handbook/status/evidence/TASK-025/`
- [ ] Run `release-plan` (next, bump=patch) and confirm `v0.5.1` exists
- [ ] Add initial features to `v0.5.1`
- [ ] Capture `release-status` output

## Before Review
- [ ] Run `pnpm -C project-handbook make -- validate`
- [ ] Ensure evidence list in `validation.md` is complete
- [ ] Confirm evidence files exist:
  - `project-handbook/status/evidence/TASK-025/index.md`
  - `project-handbook/status/evidence/TASK-025/release-plan.txt`
  - `project-handbook/status/evidence/TASK-025/release-status.txt`
- [ ] Set status to `review` via `pnpm -C project-handbook make -- task-status ...`

## After Completion
- [ ] Set status to `done`
