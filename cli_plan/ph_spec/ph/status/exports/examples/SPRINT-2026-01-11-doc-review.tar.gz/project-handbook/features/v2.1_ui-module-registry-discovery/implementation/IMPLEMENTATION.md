---
title: v2.1 UI Module Registry (Discovery) Implementation
type: implementation
feature: v2.1_ui-module-registry-discovery
date: 2026-01-07
tags: [implementation]
links:
  - ../../adr/0025-v2-1-ui-module-registry.md
  - ../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
---

# Implementation: v2.1 UI Module Registry (Discovery)

## DR-0001 — Artifact Origin + Publish Pipeline (approved)
This feature’s artifact origin decision is captured in:
- `project-handbook/features/v2.1_ui-module-registry-discovery/decision-register/DR-0001-ui-module-artifact-origin-and-publish-pipeline.md`

Approved: **Option A — proxy module bytes via the UI shell**.

### Contract (execution-ready)
- **Storage backend**: internal S3-compatible artifact store (`seaweedfs`) accessed server-side using Vault-rendered `/secrets/artifacts.env`.
- **Bucket**: `COSMO_S3_BUCKET` (existing v2 artifacts bucket).
- **Object key scheme**: `ui-modules/{moduleId}/{version}/{integritySha256}/index.mjs`
- **Immutability posture**: append-only (keys include `integritySha256`; no overwrites; no “latest”).
- **Browser fetch URL**: `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}`
- **Integrity behavior**:
  - UI verifies sha256 before executing module code.
  - Missing key returns `404`; integrity mismatch renders deterministic fallback UI (per `ADR-0025`).

### Minimal CI outline (publish)
- Build module bundle as a single-file ESM `index.mjs` for v2.1.
- Compute sha256 over the file bytes; set `integritySha256` in the module manifest.
- Upload the bundle to the object key scheme above using least-privilege S3 credentials scoped to the `ui-modules/` prefix.

### Smoke validation (publish + serve)
- Put one known module artifact object at the expected key.
- Fetch via the UI route and verify the response hashes to `integritySha256`.
  - Fetch with an unknown `moduleId` and confirm the route rejects it without proxying arbitrary S3 keys.

### Triggers for migrating to Option B
Use the explicit “signals to transition Option A → Option B” list in `DR-0001` when proxying via the UI shell starts to
look like a bottleneck (latency/CPU), when artifact formats become multi-file, or when operational/security separation
becomes valuable.

## DR-0002 — Next.js runtime loader (approved)
This feature’s runtime loader decision is captured in:
- `project-handbook/features/v2.1_ui-module-registry-discovery/decision-register/DR-0002-nextjs-runtime-module-loading-strategy.md`

Approved: **Option A — browser verifies sha256 and imports via Blob URL ESM**.

### Contract (execution-ready)
- **Artifact format**
  - Single-file ESM `index.mjs` uploaded at:
    - `ui-modules/{moduleId}/{version}/{integritySha256}/index.mjs`
- **Required exports**
  - `default`: a React component that renders the capability panel UI.
  - `capabilityId`: string (sanity check against Context capability/panel wiring).
- **Optional exports**
  - `panelTitle`, `panelVersion` for harness display + telemetry/debug.
- **Fetch URL (same-origin)**
  - `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}`
- **Caching**
  - Route returns immutable cache headers because `{integritySha256}` makes content-addressed URLs.
  - Client caches loaded modules in-memory (keyed by `{moduleId, version, integritySha256}`) to avoid repeated hashing/import.

### Loader behavior (Option A, plan)
- **Client-only execution**
  - The loader runs in the browser only (no SSR execution); panels are rendered using a client component boundary.
- **Integrity flow**
  - Fetch bytes from the proxy route.
  - Compute sha256 in the browser (Web Crypto) and compare to `integritySha256`.
  - Only after match: create Blob URL and `import()` the module.
  - Validate exports; render the panel.
- **Deterministic fallback**
  - For each failure mode, render a deterministic gated panel state that includes:
    - stable reason code (see `ARCHITECTURE.md`),
    - non-secret setup guidance identifier (if applicable),
    - optional correlation id surfaced from server errors.
- **Telemetry**
  - Emit `ui_module_load_result` with `{ moduleId, version, integritySha256, outcome, reasonCode, durationMs }` (no secrets).

## Build Steps (required)
1. Complete the runtime loading PoC (`WORK-P2-20260107-104645`) and write down:
   - the exact module format and loader integration points,
   - the allowlist + integrity enforcement mechanism,
   - the deterministic fallback behavior.
2. Complete the artifact origin + publish pipeline PoC (`WORK-P2-20260107-104653`) and verify it matches `DR-0001`:
   - object key scheme and immutability posture,
   - how artifacts are served internally (proxy route),
   - publish credentials posture and CI outline,
   - smoke validation (hash match + allowlist enforcement).
3. Produce the execution plan for `v2.1_ui-module-registry-execution` including:
   - required Context schema changes (`uiModuleManifest`),
   - required UI shell changes (loader + caching),
   - required CI publish steps,
   - required E2E coverage and failure semantics.
4. Enforce the v3 compatibility checklist (execution gate) below and keep it in sync with:
   - `project-handbook/decision-register/DR-0007-module-registry-alignment-with-v3-roadmap.md`

## ADR-0033 — v3 alignment (accepted)
This feature’s v3 alignment posture is captured in:
- `project-handbook/adr/0033-module-registry-alignment-with-v3-roadmap.md`
- (decision record) `project-handbook/decision-register/DR-0007-module-registry-alignment-with-v3-roadmap.md`

### v3 compatibility checklist (execution gate)
This is the exhaustive execution gate copied from `DR-0007` and must be kept in sync with it.

#### A) Module artifacts and serving (registry/origin)
- [ ] **Immutability is real**: module artifacts are append-only and never overwritten.
- [ ] **Content-addressed URLs remain the primitive**: every module fetch URL includes `integritySha256` (no “latest” indirection).
- [ ] **Object key scheme stays stable**: `ui-modules/{moduleId}/{version}/{integritySha256}/index.mjs` (or a strictly additive extension that preserves existing keys).
- [ ] **Artifact format remains explicit and bounded**: v2.1 uses a single-file ESM `index.mjs`; any multi-file evolution must preserve content-addressing and allow immutable caching.
- [ ] **Browser never needs S3 access**: browsers fetch module bytes via a same-origin route (or a dedicated internal origin), not via S3 endpoints or signed S3 URLs.
- [ ] **Allowlist is enforced before any origin proxying**: unknown `moduleId` is rejected without enabling arbitrary key reads.
- [ ] **Input validation is strict**: `moduleId`, `version`, and `integritySha256` are validated (format + length) before any storage lookup.
- [ ] **Immutable caching is safe**: served module bytes set immutable cache headers because `integritySha256` makes the URL content-addressed.
- [ ] **Deterministic error semantics**: missing objects yield `404` (not `500`); error responses never include secrets.

#### B) Runtime loader semantics (security + determinism)
- [ ] **Verify-before-execute posture is preserved**:
  - Preferred: client verifies sha256 before importing/executing (Option A in `DR-0002`).
  - If server verification is used later, the server must verify the requested hash before serving bytes.
- [ ] **Failure is panel-scoped and deterministic**: loader failures render a deterministic fallback state and never take down the whole shell.
- [ ] **Stable failure reason codes** exist and remain stable across v2.1 and v3 (`NOT_ALLOWLISTED`, `FETCH_404`, `FETCH_FAILED`, `HASH_MISMATCH`, `EVAL_ERROR`, `EXPORT_INVALID`).
- [ ] **Telemetry remains non-sensitive**: module load events include `{ moduleId, version, integritySha256, outcome, reasonCode, durationMs }` only (no credentials, no full URLs with secrets).
- [ ] **SSR boundary is explicit**: module execution is client-only; SSR must never evaluate remote module code.
- [ ] **CSP implications are explicit**: if `blob:` is required for verify-before-execute, CSP decisions must be recorded; if CSP disallows `blob:`, a verified server-serve mode must be used.

#### C) Identity and versioning (capability alignment)
- [ ] **`moduleId` is stable and not tenant-specific**: overlays/customizations must not create per-tenant forks in IDs.
- [ ] **Module-to-capability alignment is explicit**: module exports include a `capabilityId` sanity check and UI wiring treats it as an invariant.
- [ ] **Versioning is explicit and pinned**: Context selects `{ moduleId, version, integritySha256 }`; “floating” versions are not used in runtime manifests.

#### D) Context control-plane ownership (v3 services write policy; Context is source of truth)
- [ ] **Context remains the system-of-record** for workspace capability state and module manifests.
- [ ] **v3 control service drives desired state by writing to Context** (manifests) and observing Context status; it does not introduce a parallel gating surface.
- [ ] **Wrappers and UI gate off the same snapshot** (single canonical snapshot contract) and treat fetch failures as deterministic safe-gated behavior.
- [ ] **No provider secrets** are stored in or returned by Context snapshot surfaces; only references/IDs are permitted.

#### E) Additive evolution is non-negotiable (schemas/contracts)
- [ ] **Context schema evolution stays additive**: new v3 fields (entitlements, overlays, compliance metadata) must be optional/empty-safe so older consumers keep working.
- [ ] **Snapshot remains empty-safe**: arrays default to empty; missing surfaces do not crash UI/wrappers.
- [ ] **Stable contract versioning**: contract files and types are versioned; breaking changes require an explicit ADR and a migration plan.

#### F) v3 entitlements/billing compatibility
- [ ] **Entitlements are policy, not distribution**: billing/plan logic never changes how bytes are fetched; it only changes what manifests select and what state is shown.
- [ ] **Deterministic enable/disable events**: control actions are idempotent and produce deterministic audit records suitable for billing and operator surfaces.

#### G) v3 provisioning/workflow compatibility
- [ ] **Provisioning status is reflected back into Context** so UI/wrappers can gate deterministically off a single snapshot.
- [ ] **Job history and runbook linkage are representable** (IDs/links), enabling Backstage/operator tooling without schema redesign.

#### H) v3 overlays compatibility (client customization)
- [ ] **Overlays are declarative, versioned, and validated**; unsafe overlays are rejected.
- [ ] **Overlay application is deterministic**: precedence/layering rules are explicit and stable.
- [ ] **Overlays cannot bypass capability gating** and cannot introduce cross-tenant leakage.
- [ ] **Overlays do not require mutating module bytes**: customization is expressed as separate overlay state/artifacts, not per-tenant module rebuilds.

#### I) v3 compliance compatibility (license governance)
- [ ] **License posture is representable**: module/capability metadata can carry license classification and governance pointers.
- [ ] **Compliance artefacts can be deterministic**: future “reactive source provision” and compliance reports can reference module/capability metadata without changing the module delivery contract.
- [ ] **Copyleft isolation posture is preserved**: platform code remains API-only with copyleft services; module registry does not introduce code linking across license boundaries.

#### J) Auditability and operator experience
- [ ] **Everything is traceable**: for any workspace, operators can determine which `{ moduleId, version, integritySha256 }` was selected and served.
- [ ] **Evidence/runbook linkage is possible**: metadata surfaces can carry stable runbook/evidence links without exposing secrets.

## Required Posture
- Discovery outputs must be concrete enough to implement without re-discovery.
- No secrets are embedded in PoCs or artifacts; all creds remain server-side.

## Implementation Notes
- This feature depends on ADR-0024: panels in v2 already follow the module-ready boundary, so v2.1 module loading is
  a packaging/loading change rather than a rewrite.
