---
title: DR-0001 — UI module artifact origin + publish pipeline (S3 + integrity)
type: decision-register
date: 2026-01-11
tags: [decision-register, ui, modules, registry, artifacts, s3, integrity]
links:
  - ../../../adr/0025-v2-1-ui-module-registry.md
  - ../../../status/evidence/TASK-026/index.md
  - ../../v2_registry-cosmo-minio-required/fdr/0001-vault-secrets-contract-cosmo-minio.md
---

# Decision Register Entry

### DR-0001 — UI module artifact origin + publish pipeline (S3 + integrity)

**Decision owner(s):** @spenser  
**Date:** 2026-01-11  
**Status:** Accepted  
**Related docs:** `ADR-0025`, `v2_registry-cosmo-minio-required`, `FDR-v2_registry-cosmo-minio-required-0001`, `TASK-026`

**Problem / Context**
- v2.1 requires runtime loading of allowlisted UI modules with pinned versions and sha256 integrity checks (`ADR-0025`).
- v2 already has an internal S3-compatible artifact store (`seaweedfs`) and Vault-rendered env for server-side access, but browsers must not access S3 endpoints directly.
- This decision defines:
  - the artifact origin model used by the browser (`proxy via UI shell` vs `dedicated origin service`),
  - the bucket + object key scheme,
  - the immutability posture,
  - and the minimal CI publish outline + smoke validation steps.

**Evidence (repo inspection)**
- `project-handbook/status/evidence/TASK-026/index.md`

**Option A — UI shell proxies module bytes (Next.js route fetches from S3)**
- **Bucket + object key scheme**
  - Bucket: `COSMO_S3_BUCKET` (existing v2 artifacts bucket) with a dedicated prefix.
  - Prefix: `ui-modules/`
  - Object key: `ui-modules/{moduleId}/{version}/{integritySha256}/index.mjs`
- **Immutability rules**
  - Publish is append-only: new `{version, integritySha256}` publishes create a new key; no overwrites.
  - Deleting objects is a manual operator action (no automated “cleanup latest”).
- **How the UI resolves `{moduleId, version, integritySha256}`**
  - Context returns `{ moduleId, version, integritySha256 }`.
  - Browser fetches: `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}`
  - Next.js server maps this to `s3://COSMO_S3_BUCKET/ui-modules/.../index.mjs` and streams bytes back.
- **Publish credentials posture + minimal CI outline**
  - CI builds the module bundle (single-file ESM for v2.1), computes `integritySha256`, and uploads `index.mjs` to the key above.
  - CI uses a least-privilege S3 identity (write-only) scoped to `COSMO_S3_BUCKET` + prefix `ui-modules/` (no list/delete outside prefix).
  - No S3 credentials are ever exposed to the browser; only the Next.js server talks to S3.
- **Smoke validation steps**
  - Upload a known module bundle to the expected key (CI or local via `aws --endpoint-url "$S3_ENDPOINT_URL" s3api put-object ...`).
  - Verify `GET /api/ui-modules/...` returns `200` and the response bytes hash to the expected `integritySha256`.
  - Verify a wrong `integritySha256` path returns `404` (no key).
- **Pros:**
  - Smallest surface area: no new externally reachable origin service beyond the existing UI shell.
  - Browser never talks to S3; server-only S3 access aligns with v2 Vault patterns.
  - Easy to enforce “same-origin only” module fetches (no CORS).
- **Cons:**
  - UI shell becomes the hot path for module bytes (needs caching headers and potential in-process caching).
  - If modules evolve into multi-file bundles, proxying many assets through Next.js may be inefficient.
- **Cascading implications:**
  - Requires adding a Next.js API route and server-side S3 fetch logic (plus hardening: allowlist + size limits).
  - Requires deciding how to set caching headers for immutable module bytes.
- **Risks:**
  - Misconfiguration could allow arbitrary key proxying; must strictly validate and allowlist `moduleId`.
  - Large module bundles could impact UI server latency without caching.
- **Unlocks:**
  - A safe baseline origin model using only existing infra building blocks (Vault + internal S3 endpoint).
- **Quick wins / low-hanging fruit:**  
  - Reuse the existing v2 artifact bucket + `artifacts.env` wiring and keep the contract to a single `index.mjs` file per module version.

**Option B — Dedicated module origin service behind Traefik (origin fetches from S3)**
- **Bucket + object key scheme**
  - Bucket: `COSMO_S3_BUCKET`
  - Prefix: `ui-modules/`
  - Object key: `ui-modules/{moduleId}/{version}/{integritySha256}/index.mjs`
- **Immutability rules**
  - Same append-only posture as Option A (keys include `integritySha256`; no overwrites).
- **How the UI resolves `{moduleId, version, integritySha256}`**
  - Browser fetches module bytes directly from a dedicated origin route:
    - `GET /ui-modules/{moduleId}/{version}/{integritySha256}/index.mjs` (Traefik routes to `module-origin`)
  - The origin service fetches from S3 and returns bytes with immutable cache headers.
- **Publish credentials posture + minimal CI outline**
  - Same as Option A for CI publishing.
  - The origin service consumes Vault-rendered `/secrets/artifacts.env` for S3 credentials (server-side only).
- **Smoke validation steps**
  - Upload the expected object.
  - Verify `GET /ui-modules/.../index.mjs` returns `200` and bytes hash correctly.
  - Verify allowlist enforcement: unknown `moduleId` returns `404`/`403` without touching S3.
- **Pros:**
  - Keeps the UI shell out of the byte-serving hot path; easier to scale and cache independently.
  - Gives a clean place to implement caching, range requests, and strict content-type headers.
- **Cons:**
  - Adds a new service + Traefik routing and increases system surface area to secure/monitor.
  - Still requires server-side S3 access and careful allowlist validation (same core security concerns).
- **Cascading implications:**
  - Adds Compose service wiring + Traefik config for the new origin.
  - Requires a decision on local-only vs internal-only exposure posture for the origin route.
- **Risks:**
  - More moving parts increases drift risk and complicates local dev bring-up.
  - Incorrect Traefik routing could unintentionally expose the origin beyond intended boundaries.
- **Unlocks:**
  - A dedicated foundation for module distribution that can evolve without entangling Next.js runtime.
- **Quick wins / low-hanging fruit:**  
  - Implement as a tiny HTTP service that only supports `GET` and streams from S3; keep module artifact format single-file for v2.1.

**Recommendation**
- **Recommended:** Option A — UI shell proxies module bytes (Next.js route fetches from S3)
- **Rationale:** It minimizes new surface area while aligning with the existing v2 posture: internal S3 access remains server-side via Vault-rendered env, and the browser fetches only from the UI shell. If throughput/caching needs or multi-file bundles emerge, Option B can be revisited with evidence from the runtime loader PoC.

**Guidance: signals to transition Option A → Option B (what it looks like)**
- **Proxy route becomes a measurable bottleneck:** module loads regularly show elevated latency (e.g. `p95` for `GET /api/ui-modules/*` materially higher than other API routes), UI server CPU spikes during module loads, or you see frequent timeouts/aborts under parallel panel loads.
  - Example: “cold” loads are fine, but concurrent loading 3–5 panels causes `GET /api/ui-modules/*` to slow to seconds and the UI shell becomes the limiting factor.
- **Caching needs outgrow Next.js route semantics:** you need stronger cache control (immutable caching, shared cache across UI instances, conditional requests) and it’s awkward to implement/observe via the UI shell.
  - Example: you want a dedicated cache layer in front of module bytes (or you want cache hit/miss metrics) without coupling it to application routes.
- **Artifact format evolves beyond single-file `index.mjs`:** modules become multi-file bundles (chunks, WASM, assets, source maps), and proxying all those assets through the UI shell is inefficient or complicates routing.
  - Example: a module introduces `*.wasm` or multiple chunk files and the number of requests per panel grows substantially.
- **Security hardening requires stricter separation:** you want the tightest possible “serve bytes” surface that is isolated from the UI app logic (smaller attack surface, simpler allowlist validation, tighter rate/size limits).
  - Example: security review asks for an origin that can be locked down to `GET` only with minimal headers and no application session coupling.
- **Multiple non-UI consumers need the same artifacts:** other services (gate runner, E2E harness, tooling) need to fetch module bytes without going through the UI shell’s app routes.
  - Example: CI smoke checks want to verify module bytes directly from an origin endpoint without needing the UI app running.
- **Operational clarity demands separate ownership:** on-call/debug workflows benefit from a distinct service with its own logs/metrics/restarts so module serving issues don’t look like “the UI is down”.
  - Example: a module publish/serve outage should page “module-origin” without conflating it with Next.js app health.

**Follow-up tasks (explicit)**
- After operator approval of Option A:
  - Update feature docs (if not already) to reflect the accepted origin model and contract details.
  - Add Next.js route `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}`:
    - allowlist `moduleId`,
    - map to `COSMO_S3_BUCKET` + key scheme above,
    - return immutable cache headers and safe content type.
  - Add publish tooling (CI):
    - build `index.mjs`,
    - compute sha256,
    - upload to the key above with least-privilege credentials.
  - Add smoke validation gate:
    - “put/get/hash match” for one module artifact,
    - “unknown moduleId rejected” behavior.

**Operator/user approval**
- Approved: **Option A** (operator approval received 2026-01-11).
