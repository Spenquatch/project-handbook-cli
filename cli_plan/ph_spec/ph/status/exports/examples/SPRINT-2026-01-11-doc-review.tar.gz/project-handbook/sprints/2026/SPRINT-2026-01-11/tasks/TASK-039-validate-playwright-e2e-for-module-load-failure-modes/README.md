---
title: Task TASK-039 - Validate: Playwright E2E for module load + failure modes
type: task
date: 2026-01-11
task_id: TASK-039
feature: v2.1_ui-module-registry-discovery
session: task-execution
tags: [task, v2.1_ui-module-registry-discovery]
links: [../../../features/v2.1_ui-module-registry-discovery/overview.md]
---

# Task TASK-039: Validate: Playwright E2E for module load + failure modes

## Overview
**Feature**: [v2.1_ui-module-registry-discovery](../../../features/v2.1_ui-module-registry-discovery/overview.md)
**Decision**: [FDR-v2_1_ui-module-registry-discovery-0002](../../../../../features/v2.1_ui-module-registry-discovery/fdr/0002-nextjs-runtime-module-loading-strategy.md)
**Story Points**: 2
**Owner**: @spenser
**Lane**: module-registry/runtime
**Session**: `task-execution`

## Goal (what you’re validating)
Lock the runtime module loader behavior with Playwright E2E coverage:
- happy path module load + render,
- deterministic fallback states with stable reason codes for key failure modes,
- evidence capture (no secrets) suitable for review and future refactors.

## Agent Navigation Rules
1. **Start work**: Update `task.yaml` status to "doing"
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: Set to "review" when ready for review

## Context & Background
This task implements the [FDR-v2_1_ui-module-registry-discovery-0002](../../../../../features/v2.1_ui-module-registry-discovery/fdr/0002-nextjs-runtime-module-loading-strategy.md) decision for the [v2.1_ui-module-registry-discovery] feature.

## Quick Start
```bash
# Update status when starting
cd sprints/current/tasks/TASK-039-validate-playwright-e2e-for-module-load-failure-modes/
# Edit task.yaml: status: doing

# Follow implementation
cat steps.md              # Read implementation steps
cat commands.md           # Copy-paste commands
cat validation.md         # Validation approach
```

## Dependencies (explicit)
Must be `done` first (per `task.yaml`):
- `TASK-031` — publish pipeline script exists for seeding module artifacts.
- `TASK-038` — landing harness has module panel slots + deterministic fallback UI selectors.

Required system dependencies for E2E:
- v2 stack up (`make -C v2 v2-up`) and reachable at `http://app.local/`
- Keycloak reachable at `http://keycloak.local` (or `E2E_KEYCLOAK_BASE_URL`), with admin creds available for E2E user provisioning/teardown
- Internal S3 reachable from the helper container used by the publish pipeline (`cosmo-artifact-probe`)

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.
