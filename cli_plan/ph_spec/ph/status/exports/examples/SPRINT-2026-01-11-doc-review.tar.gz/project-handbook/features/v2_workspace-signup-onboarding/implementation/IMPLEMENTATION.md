---
title: v2 Workspace Signup Onboarding Implementation
type: implementation
feature: v2_workspace-signup-onboarding
date: 2026-01-07
tags: [implementation]
links:
  - ../../adr/0026-v2-workspace-signup-onboarding.md
  - ../../adr/0016-v2-context-glue-integrations.md
  - ../../contracts/tribuence-mini-v2/context-subgraph.md
  - ./KEYCLOAK_SELF_REGISTRATION.md
---

# Implementation: v2 Workspace Signup Onboarding

## Build Steps (required)
1. Enable Keycloak self-registration in the v2 realm and keep v2 UI auth gating enabled.
2. Add a required post-auth onboarding route in the v2 UI:
   - triggers when no workspace is selected for the session,
   - collects `workspace slug` + `workspace name`,
   - calls Context `workspaceCreate`,
   - selects the created workspace and redirects to the landing harness.
3. Ensure workspace creation triggers Context capability provisioning:
   - manifests are created/updated for the workspace,
   - provisioning jobs enqueue for enabled capabilities,
   - capability detection surface reflects provisioning status.
4. Ensure onboarding never requires provider secrets from the user.

## Required Posture
- Auth is always required; there is no unauthenticated workspace creation.
- Workspace creation is tenant-scoped (via `x-tenant-id`) and workspace-scoped for all downstream provisioning.
- The landing harness remains the canonical dev/testing surface after onboarding completes.

## Implementation Notes
- Use the existing Context mutation `workspaceCreate` and the same server-side patterns used by the landing harness.
- E2E strategy and harness guidance: `../testing/PLAYWRIGHT_ONBOARDING_E2E.md`.
