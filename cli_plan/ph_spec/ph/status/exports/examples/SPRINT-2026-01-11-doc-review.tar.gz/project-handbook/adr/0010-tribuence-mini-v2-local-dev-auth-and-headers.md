---
id: ADR-0010
title: Tribuence Mini v2 Local/Dev Auth + Header Strategy (Phase 0)
type: adr
status: draft
date: 2026-01-02
tags: [tribuence-mini, v2, auth, headers, apollo-router, local-dev]
links:
  - ../../v2/ARCHITECTURE.md
  - ../features/tribuence-mini-v2/overview.md
  - ../contracts/tribuence-mini-v2/supergraph-router.md
  - ../contracts/tribuence-mini-v2/twenty-subgraph.md
  - ../contracts/tribuence-mini-v2/vault-secrets.md
---

# Context

Tribuence Mini v2 aims to expose a single GraphQL entrypoint (`router.local`) that federates multiple subgraphs. In local/dev, we need a bring-up posture that:
- keeps Traefik exposure minimal (public: UI + Router only),
- supports deterministic smoke probes,
- avoids leaking service tokens into client-side code,
- and keeps the header contract stable as “real auth” is introduced later.

Reality of upstream services:
- **Twenty** commonly requires an auth token for GraphQL access (and introspection).
- **AnythingLLM** is REST-first and will be integrated via a wrapper; the wrapper uses its own REST API key.
- **Context** is internal and can start without end-user auth for v0, relying on tenant/workspace headers.

# Decision (Phase 0: local/dev bring-up)

1. **Apollo Router propagates headers** to all subgraphs:
   - `authorization`
   - `x-tenant-id`
   - `x-workspace-id`
   (Contract: `contracts/tribuence-mini-v2/supergraph-router.md`.)

2. **Service tokens live in Vault** and are consumed by server-side components and smoke probes:
   - `TWENTY_API_KEY` is stored under v2 Router KV (`vault-secrets.md`) and used for:
     - Twenty SDL introspection (snapshot generation),
     - smoke probes that must reach Twenty through the Router.

3. **No client-side service token leakage**:
   - The v2 UI must not embed `TWENTY_API_KEY` in browser-exposed env.
   - Early bring-up may rely on smoke probes and operator tooling (curl) to validate Twenty federation.

4. **Subgraph auth expectations for v0**:
   - Twenty: expects `authorization: Bearer <TWENTY_API_KEY>` in local/dev.
   - Context: does not require `authorization` for v0; it relies on `x-tenant-id` and `x-workspace-id` semantics.
   - AnythingLLM wrapper: uses `ANYLLM_API_KEY` internally; GraphQL-level `authorization` is not required for v0.

# Consequences

## Positive
- Establishes a stable header contract early (Router propagation) without blocking on end-user auth flows.
- Keeps service tokens server-side (Vault + internal containers) and avoids leaking them into the browser.
- Allows incremental federation: Twenty first, then Context, then AnythingLLM wrapper.

## Tradeoffs / Risks
- v0 UI testing may not include real authenticated Twenty flows; smoke probes carry more responsibility.
- Introducing end-user auth later may require additional decisions:
  - whether Twenty can validate end-user tokens directly,
  - whether a token-exchange/BFF layer is needed.

# Rollout

1. Ensure Router header propagation matches the contract (`supergraph-router.md`).
2. Generate and commit Twenty SDL snapshot using `TWENTY_API_KEY` (`twenty-subgraph.md`).
3. Validate v2 smoke harness can:
   - hit Router liveness,
   - detect `TWENTY` via `join__Graph`,
   - run required probes without exposing internal services.
4. Add Context federation and validate Context CRUD probes (later sprint).

# Acceptance Criteria

- `TWENTY_API_KEY` is provisioned via Vault (not hard-coded) and is usable for introspection/probes.
- Router forwards `x-tenant-id` and `x-workspace-id` to subgraphs (Context depends on this).
- No browser-exposed env includes service tokens intended for internal auth.

