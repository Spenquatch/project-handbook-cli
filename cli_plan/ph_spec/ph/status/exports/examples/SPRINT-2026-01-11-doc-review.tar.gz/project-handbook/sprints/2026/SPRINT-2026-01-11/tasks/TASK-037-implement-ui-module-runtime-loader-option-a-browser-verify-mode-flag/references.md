---
title: Implement: UI module runtime loader (Option A browser verify + mode flag) - References
type: references
date: 2026-01-11
task_id: TASK-037
tags: [references]
links: []
---

# References: Implement: UI module runtime loader (Option A browser verify + mode flag)

## Internal References

### Decision Context
- **Decision**: [FDR-v2_1_ui-module-registry-discovery-0002](../../../../features/v2.1_ui-module-registry-discovery/fdr/0002-nextjs-runtime-module-loading-strategy.md)
- **Origin contract**: [FDR-v2_1_ui-module-registry-discovery-0001](../../../../features/v2.1_ui-module-registry-discovery/fdr/0001-ui-module-artifact-origin-and-publish-pipeline.md)
- **Feature**: [Feature overview](../../../../features/v2.1_ui-module-registry-discovery/overview.md)
- **Architecture**: [Feature architecture](../../../../features/v2.1_ui-module-registry-discovery/architecture/ARCHITECTURE.md)

### Related Tasks
- `TASK-030` (dependency): [Implement: UI module origin proxy route (Option A)](../TASK-030-implement-ui-module-origin-proxy-route-option-a/README.md)
- `TASK-039` (follow-up validation): Playwright E2E for module load failure modes

### Code References (repo root)
- `v2/apps/tribuence-mini/src/lib/` (loader location)
- `v2/apps/tribuence-mini/vitest.config.ts` (test environment is Node)

### Sprint Context
- **Sprint Plan**: [Current sprint](../../plan.md)
- **Sprint Tasks**: [All sprint tasks](../)
- **Daily Progress**: [Daily status](../../daily/)

## Notes
- The loader must be client-only; do not SSR-execute remote module code.
- Keep the Option A → Option B transition mechanical by keeping the stable contracts from the FDR unchanged.
