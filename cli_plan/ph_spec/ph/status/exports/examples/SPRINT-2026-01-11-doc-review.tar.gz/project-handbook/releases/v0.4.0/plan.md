---
title: Release v0.4.0 Plan
type: release-plan
version: v0.4.0
start_sprint: SPRINT-2026-01-04-19
end_sprint: SPRINT-2026-01-04-19
planned_sprints: 1
sprint_ids: [SPRINT-2026-01-04-19]
status: planned
date: 2026-01-04
tags: [release, planning]
links: []
---

# Release v0.4.0

## Release Summary
Add a secure, auth-gated v2 UI posture (Keycloak + NextAuth), a minimal “workspace landing” flow, and operational reliability improvements (health endpoints + evidence-driven validation) without expanding Traefik public exposure beyond an allowlist.

## Release Goals
1. **Primary Goal**: Auth-gated v2 UI that supports a minimal landing workflow (workspace select → AnythingLLM chat/upload → Twenty create action) with no secret leakage.
2. **Secondary Goal**: Reliability improvements (UI `/api/healthz`, normalized service health endpoints/healthchecks) and recorded validation evidence.
3. **Stretch Goal**: Cosmo + MinIO integration plan (discovery) ready for next sprint execution.

## Release Type & Scope
- **Type**: minor (1 bounded sprint)
- **In scope (must-have)**:
  - Keycloak + NextAuth auth gating for the v2 UI (toggleable via `NEXT_PUBLIC_REQUIRE_AUTH`).
  - Traefik allowlist exposure preserved (public: `app.local`, `router.local`, optional `keycloak.local` when auth is enabled).
  - Server-only secret handling via Vault Agent templates (no browser token leakage).
  - UI aggregate health endpoint (`GET /api/healthz`) and improved service health diagnostics.
  - Validation evidence captured for the end-to-end auth-gated flow and smoke gate.
- **Out of scope (explicitly not in this release)**:
  - Production deployment, CI/CD, and multi-environment promotion.
  - Fine-grained authorization/RBAC and per-user token exchange across subgraphs.
  - Exposing Twenty/AnythingLLM/Vault/Postgres via Traefik.
- **Scope flexibility**:
  - Locked:
    - Auth-gated UI posture + Traefik allowlist invariants.
    - No secret leakage (Vault-only, server-side consumption).
  - Flexible:
    - Depth of “Twenty create” surface (start minimal; expand later with codegen).
    - Upload strategy (GraphQL base64 vs server-side multipart) as long as it stays server-side and secure.

## Sprint Timeline
- **SPRINT-2026-01-04-19** (Sprint 1 of 1): Sprint theme/focus
  - Theme: Security posture + auth gating + minimal landing workflow + health diagnostics.


## Feature Assignments
*Use `make release-add-feature` to assign features to this release*

## Scope Control
- **Scope lock date**: TBD
- **Change control**:
  - Default: new requests go to the next release
  - Exceptions: TBD (who decides, criteria, and how to document)

## Communication Plan
### Internal
- Announcement: TBD
- Progress cadence: weekly release health check
- Escalation path: TBD

### Stakeholders
- Update cadence: TBD
- Demo date(s): TBD
- Release notes owner: TBD

## Success Criteria
- [ ] All assigned features complete
- [x] Integration gate executed with evidence (`TASK-013`)
- [x] Quality gates passed (`make v2-smoke V2_SMOKE_MODE=router`; auth redirect validated)
- [x] `GET /api/healthz` returns expected JSON shape (no secret values)
- [x] Release plan updated with validated commands + known issues

## Risk Management
- Critical path: (Identify critical features)
- Dependencies: (External dependencies)
- Capacity: (Team availability considerations)

## Release Notes Draft
*Auto-generated from completed tasks and features*

### How to run (validated)
Validated via: `project-handbook/status/evidence/TASK-013/` (integration gate).

```bash
# From repo root
make v2-down || true
make v2-up

# Required: seed Vault KV + render /secrets/*.env (Router/UI/subgraphs depend on this)
NEXT_PUBLIC_REQUIRE_AUTH=true \
  V2_VAULT_FETCH_KEYCLOAK_CLIENT_SECRET=true \
  V2_VAULT_MINT_ANYLLM_API_KEY=true \
  bash v2/scripts/vault/bootstrap-v2.sh

make v2-smoke V2_SMOKE_MODE=router

# Health endpoint (no secrets)
curl -sS --resolve "app.local:80:127.0.0.1" "http://app.local/api/healthz" | jq
```

### Known issues (as of 2026-01-05)
- `TWENTY_API_KEY` is not seeded by default; smoke skips the Twenty auth probe and `/api/healthz` marks Twenty as `skipped`.

### Evidence
- `project-handbook/status/evidence/TASK-013/`

### Validated on
- OS: macOS 15.6.1 (Darwin 24.6.0), CPU arch: arm64
- Docker: 28.0.4, Compose: v2.34.0-desktop.1
