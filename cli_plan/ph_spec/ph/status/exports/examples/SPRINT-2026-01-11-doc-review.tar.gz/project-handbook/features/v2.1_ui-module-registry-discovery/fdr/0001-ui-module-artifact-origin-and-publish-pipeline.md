---
id: FDR-v2_1_ui-module-registry-discovery-0001
title: UI module artifact origin + publish pipeline (Option A proxy via UI shell)
type: fdr
status: accepted
date: 2026-01-11
tags: [v2.1, ui, modules, registry, artifacts, s3, integrity, fdr]
links:
  - ../overview.md
  - ../decision-register/DR-0001-ui-module-artifact-origin-and-publish-pipeline.md
  - ../../../adr/0025-v2-1-ui-module-registry.md
  - ../../../status/evidence/TASK-026/index.md
---

# Decision

Adopt **Option A** from `DR-0001`: the **UI shell proxies module bytes** (Next.js route fetches from internal S3) so the
browser never talks to S3 endpoints directly.

# Scope

In scope:
- v2.1 module artifact bucket/key contract.
- Immutability + integrity posture for published artifacts.
- Browser-visible origin URL contract (same-origin proxy route).
- Explicit triggers for when to migrate to a dedicated origin service (Option B).

Out of scope:
- Implementing the runtime loader, allowlist enforcement, or Context schema changes (separate execution tasks).
- Introducing an externally reachable S3 endpoint or public module origin.

# Implementation Contract (Execution Work References This)

## Storage contract
- **Backend**: internal S3-compatible endpoint (v2 uses `seaweedfs`).
- **Bucket**: `COSMO_S3_BUCKET`.
- **Prefix**: `ui-modules/`.
- **Object key scheme**: `ui-modules/{moduleId}/{version}/{integritySha256}/index.mjs`.

## Immutability posture
- Publish is **append-only**: keys include `integritySha256`; do not overwrite existing objects.
- No floating tags (`latest`) and no server-side “resolve newest”.

## Browser-facing origin contract (Option A)
- Browser fetch URL:
  - `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}`
- Server behavior:
  - validate `moduleId` against an allowlist (do not proxy arbitrary keys),
  - map to the exact S3 key above and stream bytes,
  - set immutable caching headers appropriate for content-addressed artifacts.

## Minimal CI publish outline
- Build a v2.1 module bundle as **single-file ESM** `index.mjs`.
- Compute sha256 over file bytes; store as `integritySha256` in the module manifest.
- Upload to the key above using least-privilege S3 credentials scoped to `COSMO_S3_BUCKET` + `ui-modules/` prefix.

## Smoke validation (publish + serve)
- Put one known module artifact at the expected key.
- Fetch via `GET /api/ui-modules/...` and verify response bytes hash to `integritySha256`.
- Confirm unknown `moduleId` is rejected without proxying arbitrary S3 keys.

# When to migrate to Option B (dedicated origin) — explicit triggers

Transition to a dedicated module origin service (behind Traefik) when one or more of these become true:
- **Proxy route becomes a measurable bottleneck** (latency/CPU/timeouts under parallel panel loads).
  - Example: `p95` for `GET /api/ui-modules/*` is consistently high compared to other UI routes and dominates panel render time.
- **Caching/observability needs require separation** (shared caching, cache hit/miss metrics, independent scaling/restarts).
  - Example: you want to roll module-serving changes without redeploying/restarting the UI shell.
- **Artifacts become multi-file** (chunks/WASM/assets/source maps) and proxying through Next.js becomes noisy/inefficient.
  - Example: module load turns into dozens of requests and the UI shell’s routing/logging becomes the bottleneck.
- **Security hardening calls for a minimal “serve bytes only” surface**.
  - Example: you need stricter rate limits/size limits/headers isolation than you want to embed in app routes.
- **Non-UI consumers need artifacts** without bringing up the UI shell.
  - Example: gate runner or CI smoke checks should fetch module bytes from the origin directly.
- **Operational ownership wants clear separation** so module serving incidents are isolated from “UI app down”.

# Status

Accepted (operator approved Option A in `DR-0001` on 2026-01-11).
