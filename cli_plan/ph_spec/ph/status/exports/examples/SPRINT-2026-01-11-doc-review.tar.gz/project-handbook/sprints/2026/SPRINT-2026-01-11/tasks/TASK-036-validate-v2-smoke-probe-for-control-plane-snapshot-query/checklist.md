---
title: Validate: v2 smoke probe for control-plane snapshot query - Completion Checklist
type: checklist
date: 2026-01-11
task_id: TASK-036
tags: [checklist]
links: []
---

# Completion Checklist: Validate: v2 smoke probe for control-plane snapshot query

## Pre-Work (hard gates)
- [ ] `TASK-035` is `done`
- [ ] Decision is accepted and stable: `FDR-v2_context-control-plane-schema-0001`
- [ ] v2 smoke harness can run locally (router reachable, `curl` + `jq` present)

## Implementation (must be true)
- [ ] `v2/scripts/v2-smoke.sh` checks that the runtime supergraph snapshot contains `contextControlPlaneSnapshot`
- [ ] `v2/scripts/v2-smoke.sh` includes a happy-path probe that asserts:
  - [ ] `.data.contextControlPlaneSnapshot.workspace.id` is a string
  - [ ] `.data.contextControlPlaneSnapshot.{manifests,statuses,integrationLinks,jobs,setupGuidance,uiModuleManifests}` are arrays
  - [ ] `.data.contextControlPlaneSnapshot.generatedAt` is a string
- [ ] `v2/scripts/v2-smoke.sh` includes a failure-mode probe that asserts:
  - [ ] calling `contextControlPlaneSnapshot` without `workspaceId` and without `x-workspace-id` yields `extensions.code == "BAD_USER_INPUT"`

## Validation + Evidence (must be true)
- [ ] `V2_SMOKE_REQUIRE_GRAPHS=TRIBUENCE_CONTEXT make -C v2 v2-smoke` exits `0`
- [ ] `project-handbook/status/evidence/TASK-036/index.md` exists and documents what changed + how it was validated
- [ ] `project-handbook/status/evidence/TASK-036/v2-smoke.txt` exists and shows the probe(s) passing
- [ ] `validation.md` references the evidence files above (explicit paths)
- [ ] `pnpm -C project-handbook make -- validate` is clean

## Status Updates (required)
- [ ] `pnpm -C project-handbook make -- task-status id=TASK-036 status=review`
- [ ] `pnpm -C project-handbook make -- task-status id=TASK-036 status=done`
