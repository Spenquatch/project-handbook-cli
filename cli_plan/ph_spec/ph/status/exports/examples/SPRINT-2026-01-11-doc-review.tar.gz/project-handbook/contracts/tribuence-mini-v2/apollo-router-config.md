---
title: Tribuence Mini v2 Apollo Router Config (Local/Dev)
type: process
date: 2026-01-02
tags: [contracts, apollo-router, graphql, federation, tribuence-mini-v2]
links:
  - ./supergraph-router.md
  - ./federation-composition.md
  - ./service-topology.md
  - ./vault-secrets.md
  - ./v2-smoke-spec.md
  - ../../adr/0011-tribuence-mini-v2-router-introspection-local-dev.md
  - ../../../v2/ARCHITECTURE.md
---

# Contract: Apollo Router Config (v2, local/dev)

## Purpose
Define the **minimum Router configuration behavior** v2 requires so:
- Traefik can route `router.local` correctly,
- the Router forwards required headers to subgraphs,
- and the smoke harness can detect federated subgraphs via the committed supergraph snapshot (`supergraph-local.graphql`).

This contract supports:
- `TASK-011` (Router service + `router.local` liveness),
- `TASK-012` (federation assets + supergraph snapshot),
- and `contracts/tribuence-mini-v2/v2-smoke-spec.md`.

## Required File Location
Router config must live at:
- `v2/infra/compose/graphql/router.v2.yaml`

## Required Behavior (Config-Level)

### 1) Listen + GraphQL path
- Router listens on `0.0.0.0:4000`
- Router GraphQL path is `/`

Contract reference:
- `supergraph-router.md`

### 2) Health endpoint
- Router health listens on `0.0.0.0:8088`
- Health path is `/health`

Used for container health checks; not required to be Traefik-exposed.

### 3) Header propagation
Router must propagate these headers to **all** subgraphs:
- `authorization`
- `x-tenant-id`
- `x-workspace-id`

Contract reference:
- `supergraph-router.md`

### 4) Supergraph input (runtime)
Apollo Router must load the **runtime supergraph file** (Cosmo-synced):
- `APOLLO_ROUTER_SUPERGRAPH_PATH=/dist/graphql-runtime/supergraph.graphql`

Related files (debugging / detection):
- Committed supergraph snapshot (used by smoke/UI graph detection): `v2/infra/compose/graphql/supergraph-local.graphql`
- Composition workflow for the committed snapshot: `federation-composition.md`

### 5) Local/dev subgraph errors are visible
For v2 local/dev, Router should include subgraph error details so smoke/UI can rely on stable error codes (e.g. `extensions.code = BAD_USER_INPUT` from Context validation errors).

Config:
```yaml
include_subgraph_errors:
  all: true
```

## Required Behavior (Runtime / Smoke)

### Graph detection must be deterministic in local/dev
The v2 smoke spec detects graphs by inspecting `enum join__Graph` in the committed supergraph snapshot:
- `v2/infra/compose/graphql/supergraph-local.graphql`

Decision reference:
- `ADR-0011` (local/dev router introspection posture)

## Minimal Example (Reference)
The prior system’s Router config is a good baseline for v2 (read-only reference):
- `modular-oss-saas/infra/compose/apollo-router/configs/router.yaml`

It demonstrates:
- supergraph listen + path
- health check listen
- header propagation
