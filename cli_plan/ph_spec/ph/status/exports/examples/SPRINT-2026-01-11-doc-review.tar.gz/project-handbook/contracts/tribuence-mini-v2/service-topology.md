---
title: Tribuence Mini v2 Service Topology (Local/Dev)
type: architecture
date: 2026-01-02
tags: [contracts, topology, compose, ports, tribuence-mini-v2]
links:
  - ./supergraph-router.md
  - ./federation-composition.md
  - ./vault-secrets.md
  - ./twenty-subgraph.md
  - ./context-subgraph.md
  - ./anythingllm-subgraph.md
  - ./v2-smoke-spec.md
  - ../../../v2/ARCHITECTURE.md
---

# Contract: Service Topology (v2, local/dev)

## Purpose
Provide a single place to find the **internal service names**, **ports**, and **HTTP paths** that v2 compose and Router configuration are expected to use.

If any item below changes during execution, update:
- Router/subgraph URLs in `vault-secrets.md`
- Router graph naming in `supergraph-router.md`
- Composition config in `federation-composition.md`
- Smoke probes in `v2-smoke-spec.md`

## Public (Traefik-exposed) Hosts
These are the only hosts intended to be publicly reachable via Traefik:
- `app.local` → v2 UI (Next.js)
- `router.local` → Apollo Router (GraphQL)
- `keycloak.local` → Keycloak (optional; only when auth flows are enabled)

All other upstream/internal services (Twenty, AnythingLLM, Vault, Postgres) must not be exposed via Traefik (see `supergraph-router.md`).

## Internal Services (Compose Network)

| Component | Compose service name | Primary port | HTTP paths | Notes |
|---|---|---:|---|---|
| Apollo Router | `apollo-router` | 4000 | GraphQL: `/` | Supergraph entrypoint; Traefik routes `router.local` → this service. |
| Apollo Router health | `apollo-router` | 8088 | Health: `/health` | Used for container health checks; not required to be Traefik-exposed. |
| Twenty server | `twenty-server` | 3150 | GraphQL: `/graphql`; Health: `/healthz` | See `twenty-subgraph.md`. |
| Context service | `context` | 4010 | GraphQL: `/graphql`; Health: `/health` | Implements `context-subgraph.md` + `context-db-schema.md`. |
| AnythingLLM wrapper subgraph | `anythingllm-subgraph` | 4020 | GraphQL: `/graphql`; Health: `/health` | Implements `anythingllm-subgraph.md`. |
| AnythingLLM (upstream) | `anythingllm` | 3001 | REST base: `/api/v1/*`; Health: `/api/health` | Wrapper calls this internally with `ANYLLM_API_KEY`. |
| Vault (dev) | `vault` | 8200 | API: `/v1/*` | Dev-mode Vault; agent renders env files (see `vault-secrets.md`). |
| Postgres | `postgres` | 5432 | n/a | Shared DB surface for local/dev; exact DBs/users are implementation-defined. |
| Keycloak | `keycloak` | 8080 | UI + OIDC endpoints | Optional; only when `NEXT_PUBLIC_REQUIRE_AUTH=true` (see `vault-secrets.md`). |

Notes:
- Port numbers are the v2 *convention* used by current contracts; they’re not externally visible except via Traefik on `app.local/router.local/keycloak.local`.
- Subgraph routing URLs in Router config should use these internal names/ports.

## Health Endpoints (Local/Dev)

Compose should rely on health checks that match the endpoints below (no “false healthy”).

| Component | Health probe (from inside container) | Notes |
|---|---|---|
| Traefik | `http://127.0.0.1:80/ping` | Traefik ping is enabled and bound to `web`. |
| v2 UI | `http://127.0.0.1:3000/` | Uses the Next.js dev server root response. |
| Apollo Router | `http://127.0.0.1:8088/health` | Router health endpoint (internal port; not Traefik-exposed). |
| Context service | `http://127.0.0.1:4010/health` | Returns `503` when database connectivity is broken. |
| AnythingLLM wrapper subgraph | `http://127.0.0.1:4020/health` | Returns `503` when AnythingLLM upstream is not reachable/healthy. |
| AnythingLLM (upstream) | `http://127.0.0.1:3001/api/health` | Upstream health endpoint (no Traefik exposure). |
| Vault (dev) | `vault status -address http://127.0.0.1:8200` | CLI probe in container. |
| Keycloak | `http://127.0.0.1:9000/health/ready` | Uses management port with `KC_HEALTH_ENABLED=true`. |
| Twenty server | `http://127.0.0.1:3150/healthz` | Upstream endpoint; compose uses a Node-based probe (image may not ship curl/wget). |
