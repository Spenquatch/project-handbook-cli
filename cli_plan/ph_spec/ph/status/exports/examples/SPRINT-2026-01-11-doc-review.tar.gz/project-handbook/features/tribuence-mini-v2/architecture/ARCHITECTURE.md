---
title: Tribuence Mini V2 Architecture
type: architecture
feature: tribuence-mini-v2
date: 2025-12-22
tags: [architecture]
links: []
---

# Architecture: Tribuence Mini V2

## Overview
`v2/ARCHITECTURE.md` is the canonical system architecture. This document is a short, execution-oriented summary for sprint planning.

The v2 system promotes Twenty CRM and AnythingLLM into core services, and exposes them through a federated GraphQL supergraph (Apollo Router). A new Context service provides workspaces, reference IDs, and document/chat metadata and participates as its own subgraph.

## Components
- **Traefik**: routes `app.local` (Next UI), `router.local` (supergraph), and infra surfaces as needed.
- **Apollo Router**: federates subgraphs (Twenty, Context, AnythingLLM).
- **Twenty CRM**: upstream GraphQL + workers, backed by Postgres.
- **AnythingLLM**: upstream service, backed by Postgres/pgvector.
- **Tribuence Context Service**: owns workspaces, reference IDs, document/chat metadata, and Context subgraph resolvers.
- **Vault dev + agent**: renders env for Router, Context service, Next UI, AnythingLLM.
- **Postgres + Keycloak**: baseline stateful services.

## Data Flow
```mermaid
flowchart LR
  U[User] --> N[v2 UI (Next.js)]
  N -->|GraphQL| R[Apollo Router]
  R --> T[Twenty subgraph]
  R --> C[Context subgraph]
  R --> A[AnythingLLM subgraph]
  V[Vault dev + agent] --> R
  V --> C
  V --> N
  V --> A
  T --> DB[(Postgres)]
  C --> DB
  A --> DB
```

1. UI calls GraphQL only (queries/mutations for Twenty entities, Context workspace/reference, AnythingLLM ingestion/chat).
2. Router composes the supergraph and routes requests to subgraphs.
3. Context service links cross-system operations via reference IDs (e.g., document upload → metadata → ingestion → chat session).

## Dependencies
- Upstream Twenty GraphQL (image/config; no fork edits).
- AnythingLLM image/config and storage expectations (pgvector).
- Vault templates and bootstrap scripts for consistent env.

## Contracts (Source of Truth for Interfaces)
- Supergraph + Router: `../../contracts/tribuence-mini-v2/supergraph-router.md`
- Federation composition workflow: `../../contracts/tribuence-mini-v2/federation-composition.md`
- Apollo Router config (local/dev): `../../contracts/tribuence-mini-v2/apollo-router-config.md`
- Service topology: `../../contracts/tribuence-mini-v2/service-topology.md`
- v2 compose conventions: `../../contracts/tribuence-mini-v2/v2-compose-conventions.md`
- Traefik routing + isolation: `../../contracts/tribuence-mini-v2/traefik-routing.md`
- Twenty subgraph: `../../contracts/tribuence-mini-v2/twenty-subgraph.md`
- AnythingLLM subgraph: `../../contracts/tribuence-mini-v2/anythingllm-subgraph.md`
- Context subgraph: `../../contracts/tribuence-mini-v2/context-subgraph.md`
- Context DB schema (v0): `../../contracts/tribuence-mini-v2/context-db-schema.md`
- UI GraphQL operations (MVP): `../../contracts/tribuence-mini-v2/ui-graphql-operations.md`
- Vault secrets layout: `../../contracts/tribuence-mini-v2/vault-secrets.md`
- Vault bootstrap workflow: `../../contracts/tribuence-mini-v2/vault-bootstrap.md`

## Reference Inventory (Reuse to Move Fast)

These directories contain a large amount of existing infra and patterns that we should **copy/copy-edit** into `v2/` rather than rebuilding from scratch.

### `modular-oss-saas/` (Reference-only)
- Baseline compose stack:
  - `modular-oss-saas/infra/compose/docker-compose.yml`
  - `modular-oss-saas/infra/compose/docker-compose.override.yml`
  - `modular-oss-saas/infra/compose/docker-compose.observability.yml`
- Vault agent templates + Next env rendering:
  - `modular-oss-saas/infra/vault/templates/agent.hcl`
  - `modular-oss-saas/infra/vault/templates/next.env.tpl`
- Vault bootstrap script pattern:
  - `modular-oss-saas/scripts/vault/bootstrap-mini.sh`

### `oss-forks/` (Reference-only, no edits)
- Twenty CRM fork checkout and config references:
  - `oss-forks/twenty-crm/`

### Copy policy
- Treat both trees as **read-only**. Copy the needed files into `v2/` and adapt there.
