---
title: Tribuence Mini V2 - Security Checklist
type: checklist
feature: tribuence-mini-v2
date: 2026-01-05
tags: [security, checklist]
links:
  - ../overview.md
  - ../status.md
  - ../../../adr/0014-tribuence-mini-v2-auth-gated-ui-bff-and-security-posture.md
  - ../../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-001-v0-4-0-security-audit-threat-model/README.md
---

# Tribuence Mini V2 — Security Checklist

This is the sprint-level security checklist for `tribuence-mini-v2` (v0.4.0 scope). It is created/owned by `TASK-001` and must be referenced by downstream auth/BFF tasks.

## Scope
- v2 local/dev stack: Traefik + Router + subgraphs + Vault Agent + Next.js UI
- Auth-gated UI flow: Keycloak → NextAuth → UI → Router

## Threat Model (v0.4.0 “Phase 1”)

### Assets (must protect)
- Vault KV secrets (NextAuth secret, JWT secrets, Keycloak client secret, service tokens like `TWENTY_API_KEY` / `ANYLLM_API_KEY`, upstream provider keys like `OPENAI_API_KEY`).
- End-user session artifacts (NextAuth cookies/session state, any future bearer/JWT headers).
- Tenant/workspace identifiers and any stored user content (Context DB, AnythingLLM storage, Twenty data).

### Trust boundaries / data flows
- **Browser → Traefik (`app.local`) → v2 UI (Next.js)**: UI must not leak service tokens; errors returned to browser must be sanitized.
- **Browser → Traefik (`keycloak.local`, optional) → Keycloak**: admin console must not run with default credentials when exposed.
- **Browser ↔ `/api/auth/*` (NextAuth) ↔ Keycloak (OIDC)**: callbacks are public; session material should be cookie-based and never logged/echoed back to the client.
- **v2 UI (server) → Traefik (`router.local`) → Apollo Router → subgraphs**: Router/subgraphs are internal; any auth header forwarding must avoid logging/echoing secrets.
- **Vault → Vault Agent → `/secrets/*.env`**: secrets are rendered into containers; values must not be printed in bootstrap/template logs.
- **Subgraphs → upstream services** (Twenty, AnythingLLM) and **subgraphs → databases**: treat upstream tokens as server-only; never surface in client env or UI errors.

### Browser-exposed env inventory (current)
- No `NEXT_PUBLIC_*` variables are referenced in v2 UI code today.
- Server-side env vars referenced by v2 UI:
  - `V2_GRAPHQL_URL` (rendered in the UI connection panel via `v2/apps/tribuence-mini/src/app/page.tsx`; must remain non-sensitive)
  - `V2_SUPERGRAPH_SNAPSHOT_PATH` (server-only; used for local snapshot detection)

## Guardrails (must hold)
### Public surfaces (Traefik)
- [ ] Only allowlisted hosts are routed publicly (`app.local`, `router.local`, optional `keycloak.local`).
- [ ] Internal services remain non-routable through Traefik (404 on attempted hosts).
- [ ] No “temporary debug” hostnames or wildcard routing.

### Secrets & env boundaries
- [ ] No service tokens or credentials are present in `NEXT_PUBLIC_*`.
- [ ] Vault-rendered env files are mounted server-side only (not exposed to the browser).
- [ ] Vault/bootstrap scripts do not print secret values to stdout/stderr.

### Logging & error redaction
- [ ] Do not log `authorization` headers, bearer tokens, JWTs, or Vault-rendered values.
- [ ] Errors returned to the browser are sanitized (no token substrings, no upstream payload dumps).
- [ ] Evidence artifacts stored under `project-handbook/status/evidence/TASK-*/` are redacted.

### Auth/session boundaries
- [ ] `/api/auth/*` remains public and functional (NextAuth callback must work).
- [ ] `/api/healthz` exposure stance is documented and enforced (default: safe-public, sanitized).
- [ ] When `NEXT_PUBLIC_REQUIRE_AUTH=true`, UI pages are gated; when `false`, UI remains usable.

## Evidence (link to sprint artifacts)
- `project-handbook/status/evidence/TASK-001/` (security audit evidence)
- `project-handbook/status/evidence/TASK-00{2,3,4,5,13}/` (auth surface and flow evidence)

## Findings (TASK-001)
- **P1** Fastify default request logging may include `authorization`/cookies once auth lands → `BUG-P1-20260105-0837`
- **P1** Keycloak admin defaults to `admin/admin` in compose → `BUG-P1-20260105-083807`
- **P1** v2 UI renders upstream errors directly; requires redaction + no raw payload echoes → `BUG-P1-20260105-083811`
