---
title: v2 Workspace Signup Onboarding
type: overview
feature: v2_workspace-signup-onboarding
date: 2026-01-07
tags: [feature]
links: [./architecture/ARCHITECTURE.md, ./implementation/IMPLEMENTATION.md, ./testing/TESTING.md]
dependencies: ["ADR-0026", "ADR-0016", "ADR-0022", "ADR-0024", "v2_ui-dev-harness-and-module-boundaries", "v2_context-glue-integrations"]
backlog_items:
  - BUG-P1-20260105-083807
  - WORK-P2-20260107-110638
  - WORK-P2-20260107-110646
parking_lot_origin: null  # Original parking lot ID if promoted
capacity_impact: planned  # planned (80%) or reactive (20%)
epic: false
---

# v2 Workspace Signup Onboarding

## Purpose
Provide a deterministic “signup → first login → create workspace” onboarding flow that results in a valid, workspace-scoped
Tribuence environment with Context-owned capability provisioning.

## Outcomes
- A new user can self-register (via Keycloak) and log into the v2 UI.
- On first login (no workspace selected), the UI routes to a required onboarding form to create a Context workspace.
- Workspace creation triggers Context provisioning (Twenty + AnythingLLM links) based on capability manifests.
- The user lands in the existing landing harness with the workspace selected and capability panels rendered.

## State
- Stage: approved
- Owner: @spenser

## Scope
- v2 signup uses Keycloak self-registration; Tribuence does not build a separate credentials store.
- v2 onboarding is an in-app form rendered only after authentication and before any capability UI is usable.
- This flow provisions only workspace-scoped resources; tenant-level provisioning is out of scope.

## Backlog Integration
- Related Issues: ["BUG-P1-20260105-083807", "WORK-P2-20260107-110638", "WORK-P2-20260107-110646"]
- Capacity Type: planned  # Uses 80% allocation
- Parking Lot Origin: null  # Set if promoted from parking lot

## Key Links
- [Architecture](./architecture/ARCHITECTURE.md)
- [Implementation](./implementation/IMPLEMENTATION.md)
- [Testing](./testing/TESTING.md)
- [Status](./status.md)
- [Changelog](./changelog.md)
