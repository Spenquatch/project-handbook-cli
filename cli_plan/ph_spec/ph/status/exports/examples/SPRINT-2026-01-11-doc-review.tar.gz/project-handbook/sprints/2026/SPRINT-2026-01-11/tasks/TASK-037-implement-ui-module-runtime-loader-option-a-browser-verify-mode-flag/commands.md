---
title: Implement: UI module runtime loader (Option A browser verify + mode flag) - Commands
type: commands
date: 2026-01-11
task_id: TASK-037
tags: [commands]
links: []
---

# Commands: Implement: UI module runtime loader (Option A browser verify + mode flag)

## Task Status Updates
```bash
pnpm -C project-handbook make -- task-status id=TASK-037 status=doing
pnpm -C project-handbook make -- task-status id=TASK-037 status=review
pnpm -C project-handbook make -- task-status id=TASK-037 status=done
```

## Evidence Directory
```bash
EVID_DIR="project-handbook/status/evidence/TASK-037"
mkdir -p "$EVID_DIR"
${EDITOR:-vi} "$EVID_DIR/index.md"
```

## Validation Commands
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Implementation Commands
```bash
# Implementation (v2 repo)
$EDITOR v2/apps/tribuence-mini/src/lib/ui-module-loader.ts
$EDITOR v2/apps/tribuence-mini/src/lib/ui-modules.ts

# Unit tests
pnpm -C v2/apps/tribuence-mini lint
pnpm -C v2/apps/tribuence-mini typecheck
pnpm -C v2/apps/tribuence-mini test
```

## Capture Evidence (recommended)
```bash
set -euo pipefail
EVID_DIR="project-handbook/status/evidence/TASK-037"
mkdir -p "$EVID_DIR"

pnpm -C v2/apps/tribuence-mini lint 2>&1 | tee "$EVID_DIR/lint.txt"
pnpm -C v2/apps/tribuence-mini typecheck 2>&1 | tee "$EVID_DIR/typecheck.txt"
pnpm -C v2/apps/tribuence-mini test 2>&1 | tee "$EVID_DIR/test.txt"
```

## Git Integration
```bash
git -C project-handbook status
git -C v2 status
```

## Quick Copy-Paste
```bash
pnpm -C project-handbook make -- validate
pnpm -C v2/apps/tribuence-mini test
```
