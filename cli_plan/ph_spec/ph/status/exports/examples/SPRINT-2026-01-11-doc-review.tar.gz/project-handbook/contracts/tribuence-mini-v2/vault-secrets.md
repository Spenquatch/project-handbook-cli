---
title: Tribuence Mini v2 Vault Secrets Contract
type: process
date: 2025-12-31
tags: [contracts, vault, secrets, tribuence-mini-v2]
links:
  - ../../features/tribuence-mini-v2/overview.md
  - ../../adr/0007-tribuence-mini-v2-supergraph-context.md
  - ./vault-bootstrap.md
  - ./supergraph-router.md
  - ./twenty-subgraph.md
  - ./anythingllm-subgraph.md
  - ./context-subgraph.md
  - ../../../v2/ARCHITECTURE.md
---

# Contract: Vault Secrets (v2)

## Purpose
Define the v2 secret layout and env-rendering expectations so:
- `TASK-009` (Vault agent + env templates) and
- `TASK-010` (bootstrap-v2 KV seeds)
can implement Vault templates + `bootstrap-v2.sh` without guessing:
- where secrets live in Vault KV v2,
- which keys must exist,
- which env files are rendered for which services.

## Vault Assumptions (Local/Dev)
- Vault runs in dev mode.
- KV v2 is mounted at `kv/` (mount: `/kv`).
- v2 bootstrap script runs against `VAULT_ADDR` with `VAULT_TOKEN` (defaults are acceptable in local/dev).

## Required Rendered Env Files
The v2 Vault Agent must render **one env file per v2 runtime surface** under a shared secrets volume (example path `/secrets`):

- `next.env` → consumed by `v2/apps/tribuence-mini` container
- `router.env` → consumed by `apollo-router` container
- `context.env` → consumed by `context` container
- `anythingllm.env` → consumed by `anythingllm` (and/or `anythingllm-subgraph`) container(s)

The exact mount point is implementation-defined, but the file names above are part of this contract so compose wiring is consistent.

## KV Paths (v2)
Store secrets under a v2-specific namespace:

- Next UI: `kv/data/tribuence/v2/next`
- Apollo Router: `kv/data/tribuence/v2/router`
- Context service: `kv/data/tribuence/v2/context`
- AnythingLLM: `kv/data/tribuence/v2/anythingllm`

## Required Keys (Minimum Set)

### `kv/data/tribuence/v2/next` (renders `next.env`)
Always required:
- `NEXTAUTH_URL`
- `NEXTAUTH_SECRET`
- `JWT_SECRET`
- `NEXT_PUBLIC_APP_URL`
- `NEXT_PUBLIC_REQUIRE_AUTH` (`true|false`)
- `V2_GRAPHQL_URL` (expected: `http://router.local/`)

Required when `NEXT_PUBLIC_REQUIRE_AUTH=true`:
- `KEYCLOAK_ISSUER`
- `KEYCLOAK_PUBLIC_ISSUER`
- `KEYCLOAK_CLIENT_ID`
- `KEYCLOAK_CLIENT_SECRET`

## Auth Toggle (Local/Dev)

Auth gating is controlled by `NEXT_PUBLIC_REQUIRE_AUTH` in `kv/data/tribuence/v2/next`:
- `false` → UI runs without auth gating (Keycloak values may be absent; `next.env` will not render `KEYCLOAK_*`).
- `true` → UI requires login and **must** have the Keycloak keys listed above.

Recommended operator flow (no secret printing):
```bash
# Bring up the stack (Keycloak must be running to fetch its generated client secret)
make v2-up

# Enable auth and fetch the Keycloak client secret into Vault (writes kv/data/tribuence/v2/next)
NEXT_PUBLIC_REQUIRE_AUTH=true V2_VAULT_FETCH_KEYCLOAK_CLIENT_SECRET=true bash v2/scripts/vault/bootstrap-v2.sh

# Restart Vault Agent (re-renders /secrets/*.env) and restart the UI (reloads env vars)
docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml restart vault-agent v2-ui

# Disable auth (keeps seeded values; UI will ignore KEYCLOAK_* when require_auth=false)
NEXT_PUBLIC_REQUIRE_AUTH=false bash v2/scripts/vault/bootstrap-v2.sh

# Restart Vault Agent + UI again to apply the toggle
docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml restart vault-agent v2-ui
```

### `kv/data/tribuence/v2/router` (renders `router.env`)
- `APOLLO_ROUTER_SUPERGRAPH_PATH` (expected: `/dist/graphql-runtime/supergraph.graphql`)
- `APOLLO_ROUTER_LISTEN` (expected: `0.0.0.0:4000`)
- `APOLLO_ROUTER_HEALTH_LISTEN` (expected: `0.0.0.0:8088`)
- `SUBGRAPH_TWENTY_URL` (see `twenty-subgraph.md`)
- `SUBGRAPH_CONTEXT_URL` (expected internal URL, e.g. `http://context:4010/graphql`)
- `SUBGRAPH_ANYTHINGLLM_URL` (expected internal URL, e.g. `http://anythingllm-subgraph:4020/graphql`)
- `TWENTY_API_KEY` (service token for local/dev; used if Router injects auth to Twenty)

If Router config uses static YAML only (no env interpolation), execution may omit these and encode values directly; but the presence of a dedicated `router.env` remains recommended to avoid drift.

### `kv/data/tribuence/v2/context` (renders `context.env`)
- `DATABASE_URL` (Context DB URL)
- `CONTEXT_JWT_SECRET` (or equivalent signing secret)
- `TENANT_DEFAULT` (expected: `tribuence`)

### `kv/data/tribuence/v2/anythingllm` (renders `anythingllm.env`)
- `ANYLLM_BASE_URL` (expected internal URL: `http://anythingllm:3001/`)
- `ANYLLM_API_KEY` (Bearer token for AnythingLLM REST)
- `OPENAI_API_KEY` (or provider key used by AnythingLLM)
- `OPEN_MODEL_PREF`
- `LLM_PROVIDER`

## Notes
- The above key names intentionally mirror the repo’s existing mini template keys where possible, to maximize reuse from `modular-oss-saas/infra/vault/templates/next.env.tpl` and `modular-oss-saas/scripts/vault/bootstrap-mini.sh`.
- If key names change during execution, update this contract and the consuming feature docs before implementation continues.

## Bootstrap Responsibilities (Phase 0)
`v2/scripts/vault/bootstrap-v2.sh` is expected to seed **all required KV keys** needed to bring up the v2 stack without manual Vault edits.

Workflow reference:
- `vault-bootstrap.md`

Guidance:
- **Generate secrets** when safe:
  - `NEXTAUTH_SECRET`, `JWT_SECRET`, `CONTEXT_JWT_SECRET` should be generated (random) by the bootstrap script.
- **Set deterministic local/dev defaults** where appropriate:
  - `NEXT_PUBLIC_APP_URL` defaults to `http://app.local`
  - `V2_GRAPHQL_URL` defaults to `http://router.local/`
  - `TENANT_DEFAULT` defaults to `tribuence`
- **Handle upstream tokens explicitly**:
  - `TWENTY_API_KEY` may need to be minted/seeded using patterns from `modular-oss-saas/scripts/vault/bootstrap-mini.sh` (the Twenty contract expects `authorization: Bearer <TWENTY_API_KEY>` for local/dev).
  - `ANYLLM_API_KEY` is minted/managed by AnythingLLM; for local/dev, the recommended pattern is to mint it by executing inside the container (see `modular-oss-saas/scripts/vault/bootstrap-mini.sh`, function `generate_anythingllm_api_key`).
    - If the container is not running, bootstrap should accept an operator-provided `ANYLLM_API_KEY` (env/arg) or fail fast with instructions.
    - Preferred v2 UX: `V2_VAULT_MINT_ANYLLM_API_KEY=true bash v2/scripts/vault/bootstrap-v2.sh` (must not print the key).

If bootstrap cannot seed a required key, it must fail fast with a clear message listing:
- the KV path,
- the missing key name,
- and what value/source is expected.
