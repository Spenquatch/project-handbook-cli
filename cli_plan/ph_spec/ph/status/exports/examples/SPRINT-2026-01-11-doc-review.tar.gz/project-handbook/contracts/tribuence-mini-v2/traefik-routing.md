---
title: Tribuence Mini v2 Traefik Routing + Isolation Contract
type: architecture
date: 2026-01-02
tags: [contracts, traefik, routing, isolation, tribuence-mini-v2]
links:
  - ./supergraph-router.md
  - ./service-topology.md
  - ./v2-compose-conventions.md
  - ./v2-smoke-spec.md
  - ../../../v2/ARCHITECTURE.md
---

# Contract: Traefik Routing + Isolation (v2, local/dev)

## Purpose
Define the **only** public hostnames that v2 is allowed to expose and the expected behavior for:
- allowed hosts (`app.local`, `router.local`, optional `keycloak.local`)
- all other hosts (must be blocked by default)

This contract supports `TASK-007` and informs the smoke/isolation probes.

## Required Dynamic Config Location
Traefik must load a file-provider dynamic config under:
- `v2/infra/compose/traefik/configs/traefik.v2.yml`

## Allowed Hosts (Public)

### `app.local` (v2 UI)
- Host: `app.local`
- Route exists in Traefik config.
- Backend behavior:
  - Before UI service exists: `502` is acceptable (placeholder backend).
  - After UI service exists: `200` (or `302` if auth enabled).

### `router.local` (Apollo Router)
- Host: `router.local`
- Route exists in Traefik config.
- Backend behavior:
  - Before Router service exists: `502` is acceptable (placeholder backend).
  - After Router service exists: GraphQL POSTs return `200`.

### `keycloak.local` (optional)
- Host: `keycloak.local`
- Only configure if auth flows require it (see `vault-secrets.md` keys under `NEXT_PUBLIC_REQUIRE_AUTH=true`).

## Forbidden Hosts (Must Not Exist)
No Traefik routes should expose upstream/internal services such as:
- Twenty, AnythingLLM, Vault, Postgres, etc.

Examples of forbidden hosts (non-exhaustive):
- `twenty.local`
- `anythingllm.local`
- `vault.local`
- `postgres.local`

Expected behavior: forbidden (and unknown) hosts return Traefik default `404` (no router match).

## Hostname Resolution (Local Dev)
Traefik routes are based on the HTTP `Host` header. In local/dev, you can satisfy hostname resolution via either:
- `/etc/hosts` entries for `app.local`, `router.local`, `keycloak.local` → `127.0.0.1`, or
- `curl --resolve` for smoke probes (recommended for deterministic scripts).

Example:
```bash
curl -sS --resolve "router.local:80:127.0.0.1" http://router.local/
```

## Placeholder Routing (Pre-Router / Pre-UI)
During early bring-up, it is acceptable for `traefik.v2.yml` to point allowed hosts at an unused local port (e.g. `127.0.0.1:65535`) to force:
- allowed hosts → `502` (route exists but backend missing)
- forbidden/unknown hosts → `404` (no route)

This enables isolation validation before Router/UI services land.

