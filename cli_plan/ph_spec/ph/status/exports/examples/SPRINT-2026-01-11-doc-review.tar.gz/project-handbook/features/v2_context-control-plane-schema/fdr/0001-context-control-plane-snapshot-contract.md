---
id: FDR-v2_context-control-plane-schema-0001
title: Context control-plane snapshot contract + additive migration plan (Option A)
type: fdr
status: accepted
date: 2026-01-12
tags: [v2, context, control-plane, schema, migration, wrappers, contract, fdr]
links:
  - ../overview.md
  - ../architecture/ARCHITECTURE.md
  - ../implementation/IMPLEMENTATION.md
  - ../decision-register/DR-0001-context-control-plane-migration-and-consumption-contract.md
  - ../../../adr/0027-v2-context-control-plane-schema.md
  - ../../../adr/0018-v2-capability-detection-surface.md
  - ../../../contracts/tribuence-mini-v2/context-subgraph.md
  - ../../../contracts/tribuence-mini-v2/context-db-schema.md
  - ../../../status/evidence/TASK-029/index.md
---

# Decision

Adopt **Option A** from `DR-0001`: evolve the existing v2 Context service additively to become the control plane system
of record, and expose a single canonical **workspace control-plane snapshot query** used for all UI and wrapper gating.

# Scope

In scope:
- A single canonical snapshot query contract (name, input semantics, high-level response shape).
- Consumer contract for UI + wrapper gating (headers, timeout/fallback, “no Router recursion” for wrappers).
- Additive migration sequencing for the existing Context v0 schema (workspaces + references).

Out of scope:
- Exact provider-specific provisioning semantics (handled by capability-specific adapters/jobs).
- Full job run log surfaces (only summaries belong in the snapshot).
- Any browser-visible provider credentials; secrets must never be stored or returned.

# Implementation Contract (Execution Work References This)

## Canonical snapshot query
- Query name: `contextControlPlaneSnapshot`
- Input semantics:
  - `workspaceId` argument is optional.
  - If omitted, Context must use `x-workspace-id` (parity with existing Context v0 reference APIs).
  - If both are missing, the query must fail with a `BAD_USER_INPUT` error.

Minimal contract (types will expand additively):
```graphql
type Query {
  contextControlPlaneSnapshot(workspaceId: ID): ContextControlPlaneSnapshot!
}

type ContextControlPlaneSnapshot {
  workspace: ContextWorkspace!
  manifests: [ContextCapabilityManifest!]!
  statuses: [ContextCapabilityStatus!]!
  integrationLinks: [ContextIntegrationLinkSummary!]!
  jobs: [ContextIntegrationJobSummary!]!
  setupGuidance: [ContextSetupGuidance!]!
  uiModuleManifests: [ContextUiModuleManifest!]!
  generatedAt: DateTime!
}
```

## Consumer contract (UI + wrappers)
- **Headers:** `x-tenant-id` required; `x-workspace-id` required unless `workspaceId` is provided.
- **UI transport:** UI calls snapshot via Apollo Router (same as existing v2 UI GraphQL requests).
- **Wrapper transport:** wrapper subgraphs call Context directly (service-to-service) and forward:
  - `x-tenant-id`
  - `x-workspace-id`
  - `authorization` (if present)
  Wrappers must not call Apollo Router for gating (avoid recursion and composition ambiguity).
- **Timeout + fallback:** strict timeout (suggested default 1500ms). On error/timeout, wrappers default to stub mode and UI
  renders deterministic gating UX.
- **Caching posture:** `no-store` by default. If caching is added, it must not allow stale “enabled” state to persist after
  disable.

## Invariants (non-negotiable)
- Tenant/workspace scoping on every record and resolver.
- Idempotency keys for provisioning/link/job operations.
- No provider secrets stored; no provider secrets returned.

## Migration sequencing (additive)
1. Add new control-plane tables and indices via idempotent SQL migrations (keep v0 tables intact).
2. Add the snapshot query early (empty-safe arrays) so callers can integrate before write paths are complete.
3. Land write paths incrementally (manifests → links → jobs/runs → status → guidance → module manifests).
4. Add smoke probes that assert snapshot shape stability and invariants.

# When to revisit Option B (separate read service/subgraph) — explicit triggers

Split to a dedicated control-plane read surface when one or more become true:
- Snapshot reads are a measurable bottleneck and need independent scaling/observability.
- Ownership boundaries require isolating a stable read contract from write-heavy Context surfaces.
- You need a read-model with different durability/latency guarantees (and can tolerate eventual consistency).

# Status

Accepted (operator approved Option A in `DR-0001` on 2026-01-12).
