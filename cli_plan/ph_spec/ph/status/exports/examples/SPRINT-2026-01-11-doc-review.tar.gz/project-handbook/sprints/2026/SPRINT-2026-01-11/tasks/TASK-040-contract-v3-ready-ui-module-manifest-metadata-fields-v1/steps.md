---
title: Contract: v3-ready UI module manifest metadata fields (v1) - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-040
tags: [implementation]
links: []
---

# Implementation Steps: Contract: v3-ready UI module manifest metadata fields (v1)

## Overview
Extend the Context control-plane **v1 contract surfaces** so v3 governance can attach provenance and license posture
metadata to UI module manifests **additively** (no breaking changes to existing consumers).

## Prerequisites
- `TASK-032` is `done` (v1 snapshot GraphQL contract exists).
- `TASK-033` is `done` (v1 DB schema contract exists).
- `ADR-0033` is accepted (alignment posture is locked).

## Step 0 — Verify prerequisites are actually present (stop if not)
1. Confirm `TASK-032` and `TASK-033` are `done` via `pnpm -C project-handbook make -- task-show id=TASK-032` and `...TASK-033`.
2. Confirm the v1 surfaces exist in the contract docs (anchors must exist; do not invent new “v1” sections here):
   - `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md` contains `ContextControlPlaneSnapshot` and `ContextUiModuleManifest`.
   - `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` contains the v1 `ui_module_manifests` table contract.

## Step 1 — Capture evidence index
1. Create `project-handbook/status/evidence/TASK-040/index.md`.
2. Capture the relevant excerpts from the current v1 contract surfaces (snapshot types + DB table names for UI module
   manifests) that you are extending.

## Step 2 — Update the GraphQL contract (additive fields)
Update `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md` to extend the v1 snapshot types:
1. Extend `ContextUiModuleManifest` with additive nullable fields:
   - `provenance: ContextArtifactProvenance`
   - `license: ContextLicensePosture`
2. Define the new types with explicit (nullable) fields (minimum contract):
   - `ContextArtifactProvenance`:
     - `publisher: String`
     - `sourceRepo: String`
     - `sourceCommit: String`
     - `buildId: String`
     - `builtAt: DateTime`
   - `ContextLicensePosture`:
     - `spdxId: String`
     - `classification: String`
     - `requiresSourceProvision: Boolean`
3. Document invariants:
   - all fields are nullable/empty-safe,
   - no secrets (no credentials, no private keys, no signed URLs),
   - tenant/workspace scoping remains mandatory.
4. Document the intended mapping to v1 storage (so downstream migration tasks are unambiguous):
   - `provenance.publisher` ↔ `ui_module_manifests.provenance_publisher`
   - `provenance.sourceRepo` ↔ `ui_module_manifests.provenance_source_repo`
   - `provenance.sourceCommit` ↔ `ui_module_manifests.provenance_source_commit`
   - `provenance.buildId` ↔ `ui_module_manifests.provenance_build_id`
   - `provenance.builtAt` ↔ `ui_module_manifests.provenance_built_at`
   - `license.spdxId` ↔ `ui_module_manifests.license_spdx_id`
   - `license.classification` ↔ `ui_module_manifests.license_classification`
   - `license.requiresSourceProvision` ↔ `ui_module_manifests.license_requires_source_provision`

## Step 3 — Update the DB schema contract (nullable storage fields)
Update `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` v1 to include nullable storage for the same
metadata on the v1 UI module manifest storage.

Rules:
- Do **not** rename existing v1 tables/columns from `TASK-033`.
- Add the following columns to `ui_module_manifests` (as defined in `TASK-033`):
  - `provenance_publisher` (`text`, nullable)
  - `provenance_source_repo` (`text`, nullable)
  - `provenance_source_commit` (`text`, nullable)
  - `provenance_build_id` (`text`, nullable)
  - `provenance_built_at` (`timestamptz`, nullable)
  - `license_spdx_id` (`text`, nullable)
  - `license_classification` (`text`, nullable)
  - `license_requires_source_provision` (`boolean`, nullable)
- The DB contract must keep the v1 invariants:
  - tenant/workspace scoping,
  - no provider secrets stored,
  - deterministic behavior (no “latest” pointers for module artifacts).

## Step 4 — Capture “after” excerpts + diff (required)
1. Capture “after” excerpts for both contract docs you touched.
2. Capture `git diff` outputs for review (see `commands.md`).

## Step 5 — Submit for review
1. Update `validation.md` to match the finalized contract changes (no placeholders).
2. Run `pnpm -C project-handbook make -- validate`.
1. Set status to `review` via `pnpm -C project-handbook make -- task-status id=TASK-040 status=review`.
