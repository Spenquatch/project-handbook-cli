---
title: Tribuence Mini v2 Contracts
type: process
date: 2025-12-30
tags: [contracts, tribuence-mini-v2]
links:
  - ./supergraph-router.md
  - ./federation-composition.md
  - ./apollo-router-config.md
  - ./service-topology.md
  - ./v2-compose-conventions.md
  - ./traefik-routing.md
  - ./twenty-subgraph.md
  - ./anythingllm-subgraph.md
  - ./vault-secrets.md
  - ./vault-bootstrap.md
  - ./context-subgraph.md
  - ./context-db-schema.md
  - ./ui-graphql-operations.md
  - ./v2-smoke-spec.md
---

# Tribuence Mini v2 Contracts

These documents define the **explicit contracts** that v2 implementation work should follow so that execution tasks under `v2/` don’t need to guess.

## Contracts

- **Supergraph / Router contract**: `supergraph-router.md`
- **Federation composition workflow**: `federation-composition.md`
- **Apollo Router config**: `apollo-router-config.md`
- **Service topology (ports/paths)**: `service-topology.md`
- **v2 compose conventions**: `v2-compose-conventions.md`
- **Traefik routing + isolation**: `traefik-routing.md`
- **Twenty subgraph contract**: `twenty-subgraph.md`
- **Twenty create ops (MVP)**: `twenty-ui-create-operations.md`
- **AnythingLLM subgraph contract**: `anythingllm-subgraph.md`
- **Vault secrets contract**: `vault-secrets.md`
- **Vault bootstrap workflow**: `vault-bootstrap.md`
- **Context subgraph contract**: `context-subgraph.md`
- **Context DB schema contract**: `context-db-schema.md`
- **UI GraphQL operations (MVP)**: `ui-graphql-operations.md`
- **Smoke test spec**: `v2-smoke-spec.md`
