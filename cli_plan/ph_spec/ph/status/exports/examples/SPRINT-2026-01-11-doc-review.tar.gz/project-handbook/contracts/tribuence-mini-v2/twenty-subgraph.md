---
title: Tribuence Mini v2 Twenty Subgraph Contract
type: api
date: 2025-12-31
tags: [contracts, twenty, graphql, tribuence-mini-v2]
links:
  - ../../features/tribuence-mini-v2/overview.md
  - ../../adr/0007-tribuence-mini-v2-supergraph-context.md
  - ./supergraph-router.md
  - ./vault-secrets.md
  - ../../../v2/ARCHITECTURE.md
---

# Contract: Twenty Subgraph (v2)

## Purpose
Define stable expectations for how v2 reaches Twenty CRM from inside the compose network:
- the internal URL (host/port/path),
- how authentication is provided in local/dev,
- the minimum health/probe surface.

This contract unblocks:
- `TASK-013` (Twenty subgraph: endpoint/auth + schema snapshot),
- and informs `TASK-011`/`TASK-012` (Router wiring + federation assets).

## Service Topology (Internal-Only)
- Compose service name: `twenty-server`
- Health endpoint: `GET /healthz`
- GraphQL endpoint: `POST /graphql`
- (Optional) metadata GraphQL: `POST /metadata` (not required for v2 federation baseline)

**Traefik exposure**: forbidden. Twenty must not be reachable via a public host like `twenty.local`.

## Routing URL (from Apollo Router)
Router-to-Twenty routing URL:
- `http://twenty-server:${TWENTY_SERVER_PORT:-3150}/graphql`

Notes:
- `TWENTY_SERVER_PORT` defaults to `3150` in the repo’s mini compose overlay patterns.
- The Router container and Twenty container must share an internal network.

## Authentication (Local/Dev Default)

### Default: API key token in `authorization` header
For local/dev bring-up, v2 uses a Twenty API key token minted against the Twenty database and injected via Vault.

- Vault key: `TWENTY_API_KEY` (see `vault-secrets.md`)
- HTTP header: `authorization: Bearer <TWENTY_API_KEY>`

This is intentionally aligned with the existing mini bootstrap logic in `modular-oss-saas/scripts/vault/bootstrap-mini.sh` (copy/copy-edit into `v2/scripts/vault/bootstrap-v2.sh`).

Vault location (v2):
- KV path: `kv/data/tribuence/v2/router`
- Key: `TWENTY_API_KEY`

## Token Minting (Local/Dev)
The repo already has a working reference implementation for minting a Twenty API key token in local/dev:
- `modular-oss-saas/scripts/vault/bootstrap-mini.sh` (`generate_twenty_api_key`)

High-level approach used there:
- Resolve `TWENTY_APP_SECRET` and DB credentials from the running stack.
- Query Twenty DB for:
  - a known `workspace_id`
  - a known `api_key_id`
- Derive a long-lived JWT-like token from those inputs.

For v2, prefer copying/adapting that logic into `v2/scripts/vault/bootstrap-v2.sh` (see `vault-bootstrap.md`) so:
- Twenty SDL introspection can run deterministically, and
- smoke probes can authenticate without leaking the token to the browser.

### Header propagation expectation
If the v2 UI supplies `authorization`, the Router must propagate it to Twenty (see `supergraph-router.md`). If the v2 UI does not supply auth yet, the execution plan must choose one of:
- configure the Router to inject a static `authorization` header for the Twenty subgraph, or
- have the UI send the service token as `authorization` during early bring-up.

## Minimal Probes

### Health probe (container-to-container)
Example (from inside the Router container or any internal container):
```bash
curl -sf "http://twenty-server:${TWENTY_SERVER_PORT:-3150}/healthz"
```

### GraphQL probe (expects auth in most stacks)
```bash
curl -sS \
  -H 'content-type: application/json' \
  -H "authorization: Bearer ${TWENTY_API_KEY}" \
  --data '{"query":"{ __typename }"}' \
  "http://twenty-server:${TWENTY_SERVER_PORT:-3150}/graphql"
```

## Known Constraints (Important for Federation Planning)
- Twenty’s workspace schema may be workspace-scoped and/or auth-scoped. When building SDL snapshots for federation, execution work should prefer a committed schema snapshot under `v2/infra/compose/graphql/subgraphs/twenty/schema.graphql` (rather than relying on unauthenticated introspection).

## SDL Snapshot Strategy (v0)
Goal: produce a committed SDL snapshot for federation that is repeatable in local/dev.

1. Ensure Twenty is reachable internally and auth is available (`TWENTY_API_KEY`).
2. Prefer Apollo Rover introspection to generate SDL:
   - `rover subgraph introspect "http://twenty-server:${TWENTY_SERVER_PORT:-3150}/graphql" --header "authorization: Bearer ${TWENTY_API_KEY}" > v2/infra/compose/graphql/subgraphs/twenty/schema.graphql`
3. If `rover` is not available in the execution environment, fall back to:
   - emitting introspection JSON via `curl` (same URL + header), and
   - converting to SDL using a repo-local script/tooling added during execution (the conversion mechanism is implementation-defined, but the committed output path is not).

Smoke tests may validate federation presence without assuming specific Twenty field/type names by parsing the Router’s composed supergraph SDL (see `contracts/tribuence-mini-v2/v2-smoke-spec.md`).
