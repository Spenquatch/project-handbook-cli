---
title: Implement: Context DB migrations for control-plane tables (v1) - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-034
tags: [implementation]
links: []
---

# Implementation Steps: Implement: Context DB migrations for control-plane tables (v1)

## Overview
Implement the Context control-plane DB schema (v1) as additive SQL migrations in the v2 Context service.

This is **schema-only** work:
- Add new `.sql` migration file(s) under `v2/services/context/db/migrations/`.
- Do not remove/rename existing v0 tables (`context_workspaces`, `context_references`).

Why idempotency is mandatory:
- `v2/services/context/index.js` applies **all migrations on every boot** (no migration state table). A single
  non-idempotent statement can brick startup.

## Prerequisites
- [ ] `TASK-033` is `done` (v1 DB contract is ready).
- [ ] You can identify the required v1 control-plane tables/indices in:
  - `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md`

## Step 1 — Preflight (no ambiguity)
1. Confirm the dependency is complete:
   - `pnpm -C project-handbook make -- task-show id=TASK-033`
2. Confirm the DB contract contains the v1 control-plane schema section you are about to implement (if it doesn’t, stop):
   - `rg -n "control-?plane|v1|capability_manifests|integration_links" project-handbook/contracts/tribuence-mini-v2/context-db-schema.md`

## Step 2 — Capture evidence index
1. Create `project-handbook/status/evidence/TASK-034/index.md`.
2. Record:
   - the contract section(s) implemented,
   - the migration filename(s) added,
   - any deviations (must be justified and linked to a contract note).

## Step 3 — Add migrations (additive + idempotent)
1. Pick the next migration number by listing current migrations (lexicographic sort order matters):
   - `ls -1 v2/services/context/db/migrations/*.sql`
2. Add new `.sql` migration(s) under `v2/services/context/db/migrations/` (do not edit `001_init.sql` in place).
   - Recommended filename pattern:
     - `002_control_plane_v1.sql` (single-file) OR
     - `002_control_plane_v1_tables.sql` + `003_control_plane_v1_indexes.sql` (split if it improves readability)
3. Implement the v1 control-plane tables and indices from `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md`.
4. Hard requirements:
   - Every new table is tenant/workspace scoped per contract (`tenant_id`, `workspace_id` patterns).
   - All statements are safe to re-run:
     - `CREATE TABLE IF NOT EXISTS ...`
     - `CREATE INDEX IF NOT EXISTS ...`
     - `ALTER TABLE ... ADD COLUMN IF NOT EXISTS ...` (only if the contract requires expanding an existing table)
   - Avoid `DROP`, `TRUNCATE`, or non-idempotent `ALTER TABLE ... ADD CONSTRAINT ...` without a duplicate-safe guard.

Idempotent uniqueness/constraint guidance:
- Prefer defining constraints inside `CREATE TABLE IF NOT EXISTS ...` for brand new tables.
- If you must add a constraint to an existing table, use an explicit, duplicate-safe guard (Postgres doesn’t support
  `ADD CONSTRAINT IF NOT EXISTS`).

## Step 4 — Local verification (prove idempotency + schema presence)
1. Bring up v2 and render secrets (Context reads `DATABASE_URL` from `/secrets/context.env`):
   - `KEYCLOAK_ADMIN=admin KEYCLOAK_ADMIN_PASSWORD=dev-not-admin make -C v2 v2-up`
   - `V2_VAULT_MINT_ANYLLM_API_KEY=true bash v2/scripts/vault/bootstrap-v2.sh`
2. Capture Context startup logs to evidence and confirm there are **no migration errors**.
3. Verify the new tables exist in Postgres and the v0 tables are still present:
   - `docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml exec -T postgres psql -U postgres -d tribuence_v2 -c "\\dt"`
4. Prove idempotency by restarting Context at least twice and re-checking logs:
   - `docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml restart context`
   - `docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml logs --tail=200 context`

## Step 5 — Submit for review
1. Update `validation.md` with the exact verification commands used.
2. Ensure evidence file list in `validation.md` matches what you captured.
3. Set status to `review` via `pnpm -C project-handbook make -- task-status id=TASK-034 status=review`.
