---
title: Handbook: Plan v0.5.1 release + assign initial features - Validation Guide
type: validation
date: 2026-01-11
task_id: TASK-025
tags: [validation]
links: []
---

# Validation Guide: Handbook: Plan v0.5.1 release + assign initial features

## Automated Validation
```bash
pnpm -C project-handbook make -- release-list
pnpm -C project-handbook make -- release-status
pnpm -C project-handbook make -- validate
```

## Pass/Fail Criteria
- `project-handbook/releases/v0.5.1/plan.md` exists and `project-handbook/releases/current` points to `v0.5.1`.
- `pnpm -C project-handbook make -- release-status` lists the initial assigned features for `v0.5.1`.

## Evidence (required)
- `project-handbook/status/evidence/TASK-025/index.md`
- `project-handbook/status/evidence/TASK-025/release-plan.txt`
- `project-handbook/status/evidence/TASK-025/release-status.txt`

## Sign-off
- [ ] All validation steps completed
- [ ] Evidence documented above
- [ ] Ready to mark task as "done"
