---
title: Task TASK-027 - Investigate: Next.js runtime module loading (allowlist + sha256)
type: task
date: 2026-01-11
task_id: TASK-027
feature: v2.1_ui-module-registry-discovery
session: research-discovery
tags: [task, v2.1_ui-module-registry-discovery]
links: [../../../../../features/v2.1_ui-module-registry-discovery/overview.md]
---

# Task TASK-027: Investigate: Next.js runtime module loading (allowlist + sha256)

## Overview
- **Feature**: [v2.1_ui-module-registry-discovery](../../../../../features/v2.1_ui-module-registry-discovery/overview.md)
- **Decision**: `DR-0002` (create during this task)
- **Story Points**: 3
- **Owner**: @spenser
- **Lane**: `module-registry/runtime`
- **Session**: `research-discovery`

## Goal
Produce an operator-approvable DR (`DR-0002`) that defines the Next.js runtime module loader contract (allowlist, version pinning, sha256 verification before execute, deterministic fallback) and the execution-ready integration plan.

## Outputs (what must exist when done)
- Create and complete `project-handbook/features/v2.1_ui-module-registry-discovery/decision-register/DR-0002-nextjs-runtime-module-loading-strategy.md` (two viable options + evidence + explicit approval request; keep DR as `Proposed`).
- `project-handbook/features/v2.1_ui-module-registry-discovery/architecture/ARCHITECTURE.md` updated with the loader data flow and failure modes.
- `project-handbook/features/v2.1_ui-module-registry-discovery/implementation/IMPLEMENTATION.md` updated with an execution-ready plan (module format, caching, fallback UI, telemetry).
- Evidence captured under `project-handbook/status/evidence/TASK-027/` and referenced from DR-0002.

## After operator approval (same research session)
- Promote the accepted decision to an FDR under `project-handbook/features/v2.1_ui-module-registry-discovery/fdr/` and create execution tasks that reference the FDR (not the DR).

## Non-goals
- Do not implement the runtime loader in `v2/` during this task.
- Do not create a “plugin ecosystem”; the loader must remain allowlisted and integrity checked.

## Agent Navigation Rules
1. **Start work**: Update `task.yaml` status to "doing"
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: Set to "review" when ready for review

## Context & Background
This task completes the feature-local `DR-0002` for the [v2.1_ui-module-registry-discovery] feature.

## Quick Start
```bash
pnpm -C project-handbook make -- task-status id=TASK-027 status=doing
cd project-handbook/sprints/current/tasks/TASK-027-*/
cat steps.md
cat commands.md
cat validation.md
```

## Dependencies
Review `task.yaml` for any `depends_on` tasks that must be completed first.

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.
