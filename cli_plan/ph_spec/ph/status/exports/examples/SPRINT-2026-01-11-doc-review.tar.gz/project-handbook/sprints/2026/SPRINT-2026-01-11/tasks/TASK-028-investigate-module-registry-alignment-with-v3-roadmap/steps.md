---
title: Investigate: Module registry alignment with v3 roadmap - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-028
tags: [implementation]
links: []
---

# Implementation Steps: Investigate: Module registry alignment with v3 roadmap

## Overview
This is a `session=research-discovery` task. The deliverable is a completed cross-cutting DR (`DR-0007`) plus a v3 compatibility checklist embedded in the v2.1 module registry discovery plan. No product code changes.

## Prerequisites
- `TASK-026`, `TASK-027`, and `TASK-029` are `done` (alignment is grounded in concrete DR outputs).

## Step 1 — Gather concrete inputs (from earlier DRs)
Read:
- `project-handbook/features/v2.1_ui-module-registry-discovery/decision-register/DR-0001-ui-module-artifact-origin-and-publish-pipeline.md`
- `project-handbook/features/v2.1_ui-module-registry-discovery/decision-register/DR-0002-nextjs-runtime-module-loading-strategy.md`
- `project-handbook/features/v2_context-control-plane-schema/decision-register/DR-0001-context-control-plane-migration-and-consumption-contract.md`

Create evidence index at `project-handbook/status/evidence/TASK-028/index.md`.

## Step 2 — Identify v3 constraints (minimal invariants)
Goal: define constraints that keep v2.1 choices compatible with v3 without designing v3 systems.
1. Review v3 feature overviews:
   - `project-handbook/features/v3_capability-control-service-billing/overview.md`
   - `project-handbook/features/v3_provisioning-adapters-and-workflows/overview.md`
   - `project-handbook/features/v3_backstage-operator-surface/overview.md`
   - `project-handbook/features/v3_license-compliance-automation/overview.md`
   - `project-handbook/features/v3_client-customization-overlays/overview.md`
2. Extract “must remain true” invariants (examples: provenance identity, entitlement gates, overlay layering, compliance checks) and write them into evidence + DR-0007.

## Step 3 — Complete DR-0007 (options + recommendation)
1. Create and fill in `project-handbook/decision-register/DR-0007-module-registry-alignment-with-v3-roadmap.md`.
2. Include two viable options and a recommendation.
3. End with an explicit operator approval request and keep status `Proposed` until approval.

## Step 4 — Embed the v3 compatibility checklist in v2.1 discovery docs
Update `project-handbook/features/v2.1_ui-module-registry-discovery/implementation/IMPLEMENTATION.md` to include:
- a checklist that future execution work must satisfy,
- explicit constraints on module ids/versions/integrity/provenance,
- explicit evolution notes for Context manifests (how v3 entitlements/overlays can be added additively).

## Step 5 — Validate handbook + wrap for review
1. Run `pnpm -C project-handbook make -- validate`.
2. Update `validation.md` and `checklist.md` with the evidence file list.
3. Set task status to `review`.
