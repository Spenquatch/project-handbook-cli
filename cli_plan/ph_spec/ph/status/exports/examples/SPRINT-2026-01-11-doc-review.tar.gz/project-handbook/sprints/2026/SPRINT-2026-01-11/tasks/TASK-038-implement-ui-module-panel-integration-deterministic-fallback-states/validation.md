---
title: Implement: UI module panel integration + deterministic fallback states - Validation Guide
type: validation
date: 2026-01-11
task_id: TASK-038
tags: [validation]
links: []
---

# Validation Guide: Implement: UI module panel integration + deterministic fallback states

## Automated Validation
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Manual Validation (Must Be Task-Specific)
Run v2 checks and capture at least one “module rendered” and one “fallback rendered” artifact from the landing harness.

```bash
set -euo pipefail
EVID_DIR="project-handbook/status/evidence/TASK-038"
mkdir -p "$EVID_DIR"

pnpm -C v2/apps/tribuence-mini lint 2>&1 | tee "$EVID_DIR/lint.txt"
pnpm -C v2/apps/tribuence-mini typecheck 2>&1 | tee "$EVID_DIR/typecheck.txt"
pnpm -C v2/apps/tribuence-mini test 2>&1 | tee "$EVID_DIR/test.txt"
```

Manual UI validation (explicit):
1. Ensure a workspace exists and is selected in the landing harness (`http://app.local/`).
2. Ensure Context snapshot returns at least one `uiModuleManifests` row for a rendered `capabilityId` slot (seed via SQL if needed).
3. Ensure the corresponding artifact exists in internal S3 and is reachable via the proxy route:
   - `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}`
4. Capture screenshots:
   - one panel in `data-state="loaded"`
   - one panel in `data-state="fallback"` with a visible `data-reason-code` / reason code text

Minimum required fallback proof for this task:
- `NOT_ALLOWLISTED` or `FETCH_404` rendered deterministically (panel-scoped).

**Pass criteria**
- At least one module-backed panel renders in the landing harness when the artifact exists and the hash matches.
- When the module cannot be loaded, the panel renders a deterministic fallback state with a stable reason code and the shell continues running.

## Evidence (required)
- `project-handbook/status/evidence/TASK-038/lint.txt`
- `project-handbook/status/evidence/TASK-038/typecheck.txt`
- `project-handbook/status/evidence/TASK-038/test.txt`
- `project-handbook/status/evidence/TASK-038/screenshot-module-rendered.png` (or a Playwright artifact link captured under evidence)
- `project-handbook/status/evidence/TASK-038/screenshot-fallback-rendered.png` (or a Playwright artifact link captured under evidence)

## Sign-off
- [ ] All validation steps completed
- [ ] Evidence documented above
- [ ] Ready to mark task as "done"
