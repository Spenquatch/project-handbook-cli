---
title: v2 Workspace Signup Onboarding Architecture
type: architecture
feature: v2_workspace-signup-onboarding
date: 2026-01-07
tags: [architecture]
links:
  - ../../adr/0026-v2-workspace-signup-onboarding.md
  - ../../adr/0016-v2-context-glue-integrations.md
  - ../../adr/0022-v2-capability-manifests-and-toggles.md
  - ../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
---

# Architecture: v2 Workspace Signup Onboarding

## Overview
Signup onboarding is a deterministic post-auth flow:
1) user self-registers in Keycloak,
2) user authenticates into the v2 UI,
3) UI forces workspace onboarding if no workspace is selected,
4) Context workspace creation triggers capability provisioning,
5) user lands in the existing landing harness.

## Components
- **Keycloak**: identity provider (self-registration + login).
- **v2 UI onboarding route**: renders the required workspace creation form for first login.
- **Context subgraph**: system-of-record for workspaces; creates workspace and drives provisioning jobs.
- **Capability manifests + integration links**: Context-owned desired state and link state for integrations.
- **Landing harness**: canonical UI for manual validation and Playwright E2E (ADR-0024).

## Data Flow
1) User registers and logs in via Keycloak.
2) UI middleware enforces auth and detects “no workspace selected”.
3) UI renders onboarding form to create a workspace (name + slug).
4) UI calls Context `workspaceCreate`.
5) Context creates the workspace, persists manifests, and enqueues provisioning jobs per enabled capabilities.
6) UI stores workspace selection and redirects to the landing harness.

## Dependencies
- Context glue plane provisioning patterns (ADR-0016).
- Capability enablement manifests (ADR-0022).
- Landing harness posture (ADR-0024).
