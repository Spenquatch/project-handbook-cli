---
title: v2.1 UI Module Registry (Discovery) Testing
type: testing
feature: v2.1_ui-module-registry-discovery
date: 2026-01-07
tags: [testing]
links:
  - ../../adr/0025-v2-1-ui-module-registry.md
  - ../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
---

# Testing: v2.1 UI Module Registry (Discovery)

## Test Strategy
- **Unit**: integrity validation and allowlist behavior for module loading.
- **Integration**: Context returns module manifests and UI consumes them deterministically.
- **E2E**: Playwright validates module load + fallback behavior in the landing harness.

## Test Cases
1) Workspace has an enabled capability with a valid module manifest; module loads and renders the panel.
2) Workspace has a module manifest with a bad integrity hash; UI refuses to load and renders fallback.
3) Workspace has a module id not on the allowlist; UI refuses to load and renders fallback.
4) Capability is disabled; UI does not load the module and renders gated UI based on Context state.

## Acceptance Criteria
- [ ] `WORK-P2-20260107-104645` produces a validated runtime loading approach and failure semantics.
- [ ] `WORK-P2-20260107-104653` produces a validated artifact origin + publish pipeline posture.
- [ ] The execution plan for `v2.1_ui-module-registry-execution` is complete and unambiguous.
