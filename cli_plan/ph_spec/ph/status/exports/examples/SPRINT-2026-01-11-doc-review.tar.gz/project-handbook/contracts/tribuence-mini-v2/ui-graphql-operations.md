---
title: Tribuence Mini v2 UI GraphQL Operations (MVP)
type: api
date: 2026-01-02
tags: [contracts, ui, graphql, tribuence-mini-v2]
links:
  - ../../features/tribuence-mini-v2/overview.md
  - ./supergraph-router.md
  - ./context-subgraph.md
  - ./anythingllm-subgraph.md
  - ./v2-smoke-spec.md
  - ../../../v2/ARCHITECTURE.md
---

# Contract: UI GraphQL Operations (v2, MVP)

## Purpose
Define the **minimum set of GraphQL operations** the v2 UI should implement so that:
- the first runnable UI slice can ship without guessing, and
- UI behavior stays aligned with the smoke harness and subgraph contracts.

This document intentionally avoids Twenty-specific domain operations (Twenty’s schema is large and will be handled via schema snapshots + codegen). It focuses on:
- Context (workspaces + references), and
- AnythingLLM wrapper entrypoints (workspaces/docs/chat) once the subgraph is present.

Twenty “create” operations are specified separately:
- `project-handbook/contracts/tribuence-mini-v2/twenty-ui-create-operations.md`

## Router Endpoint
All UI operations target the Apollo Router:
- URL: `V2_GRAPHQL_URL` (expected local/dev: `http://router.local/`)
- Method: `POST`
- Path: `/` (the Router GraphQL path)

Contract reference:
- `supergraph-router.md`

## Required Request Headers (UI → Router)
The UI must send:
- `content-type: application/json`
- `x-tenant-id: tribuence` (local/dev default; may become user/tenant-derived later)

Workspace scoping:
- When the user has an active workspace, also send `x-workspace-id: <workspaceId>`.
- When no workspace is selected, omit `x-workspace-id`.

Notes:
- Router must propagate these headers to subgraphs (see `supergraph-router.md`).
- `authorization` is treated as opaque; when present, forward it as-is.

## Context Operations (Required for MVP)

### 1) List workspaces
```graphql
query ContextWorkspaces {
  workspaces { id slug name }
}
```

### 2) Create workspace
```graphql
mutation ContextWorkspaceCreate($input: WorkspaceCreateInput!) {
  workspaceCreate(input: $input) { id slug name }
}
```
Variables example:
```json
{ "input": { "slug": "demo", "name": "Demo" } }
```

### 3) List references (workspace-scoped)
Preferred: rely on `x-workspace-id` header and omit `workspaceId` unless the UI is explicitly switching scope.
```graphql
query ContextReferences {
  references { id workspaceId system entityType entityId label metadata }
}
```

### 4) Create reference (workspace-scoped)
Preferred: rely on `x-workspace-id` header and omit `workspaceId`.
```graphql
mutation ContextReferenceCreate($input: ReferenceCreateInput!) {
  referenceCreate(input: $input) { id workspaceId system entityType entityId label metadata }
}
```
Variables example:
```json
{ "input": { "system": "TWENTY", "entityType": "Person", "entityId": "example", "label": "Example Person" } }
```

Contract reference:
- `context-subgraph.md` (schema + scoping semantics + error behavior)

## AnythingLLM Wrapper Operations (Conditional)
Only implement/enable these UI flows once the Router supergraph includes `ANYTHINGLLM` (see `supergraph-router.md` and the `join__Graph` detection pattern in `v2-smoke-spec.md`).

### 1) Ensure workspace
```graphql
mutation AnythingWorkspaceEnsure($input: AnythingWorkspaceEnsureInput!) {
  anythingWorkspaceEnsure(input: $input) { slug name }
}
```
UI rule:
- Treat the returned `slug` as canonical (AnythingLLM may derive the slug from the created name); use the returned slug for subsequent document/chat calls.

### 2) List documents
```graphql
query AnythingDocuments {
  anythingDocuments { id title name metadata }
}
```

### 3) Upload document (base64)
```graphql
mutation AnythingDocumentUpload($input: AnythingDocumentUploadInput!) {
  anythingDocumentUpload(input: $input) { ok }
}
```

### 4) Chat
```graphql
mutation AnythingChat($input: AnythingChatInput!) {
  anythingChat(input: $input) { textResponse sources error }
}
```

Contract reference:
- `anythingllm-subgraph.md`

## UI State Rules (MVP)
To keep header semantics stable and debuggable:
- Persist `workspaceId` client-side (cookie or localStorage) and reflect it in `x-workspace-id`.
- When workspace changes, clear any per-workspace cached data (references, AnythingLLM workspace slug mapping).
 - Persist the AnythingLLM workspace slug returned by `anythingWorkspaceEnsure` (per Context workspace) and use it as the source of truth for AnythingLLM operations.

## Error Handling (UI Expectations)
The UI should treat any GraphQL `errors[]` as actionable and display a compact message. For Context validation, errors should use stable codes:
- `extensions.code = BAD_USER_INPUT` for validation errors (see `context-subgraph.md`).
