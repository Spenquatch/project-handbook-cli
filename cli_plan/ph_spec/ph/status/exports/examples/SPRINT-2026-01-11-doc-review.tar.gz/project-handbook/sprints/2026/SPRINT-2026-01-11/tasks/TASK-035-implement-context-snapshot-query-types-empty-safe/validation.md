---
title: Implement: Context snapshot query + types (empty-safe) - Validation Guide
type: validation
date: 2026-01-11
task_id: TASK-035
tags: [validation]
links: []
---

# Validation Guide: Implement: Context snapshot query + types (empty-safe)

## Automated Validation
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Manual Validation (Must Be Task-Specific)
Create `project-handbook/status/evidence/TASK-035/` and capture:

### 1) SDL snapshot updated (committed file)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-035"
mkdir -p "$EVID_DIR"

rg -n "contextControlPlaneSnapshot" v2/infra/compose/graphql/subgraphs/tribuence-context/schema.graphql \
  | tee "$EVID_DIR/schema-grep.txt"
```

**Pass criteria**
- `schema.graphql` contains `contextControlPlaneSnapshot` and the v1 snapshot types (additive; no breaking removals).

### 2) Router query returns an empty-safe snapshot (arg + header fallback)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-035"
mkdir -p "$EVID_DIR"

KEYCLOAK_ADMIN=admin KEYCLOAK_ADMIN_PASSWORD=dev-not-admin make -C v2 v2-up
V2_VAULT_MINT_ANYLLM_API_KEY=true bash v2/scripts/vault/bootstrap-v2.sh

ROUTER_URL="${ROUTER_URL:-http://router.local/}"
TENANT_ID="${TENANT_ID:-tribuence}"

WORKSPACE_SLUG="e2e-cp-$(date +%s)"
WORKSPACE_NAME="e2e control plane"

WORKSPACE_CREATE_MUTATION='mutation($input: WorkspaceCreateInput!){ workspaceCreate(input:$input){ id slug name } }'
curl -sS "$ROUTER_URL" \
  -H "content-type: application/json" \
  -H "x-tenant-id: $TENANT_ID" \
  -d "{\"query\":\"$WORKSPACE_CREATE_MUTATION\",\"variables\":{\"input\":{\"slug\":\"$WORKSPACE_SLUG\",\"name\":\"$WORKSPACE_NAME\"}}}" \
  | tee "$EVID_DIR/workspace-create.json"

WORKSPACE_ID="$(jq -r '.data.workspaceCreate.id' "$EVID_DIR/workspace-create.json")"
test -n "$WORKSPACE_ID" && test "$WORKSPACE_ID" != "null"

SNAPSHOT_QUERY='query($workspaceId: ID){ contextControlPlaneSnapshot(workspaceId:$workspaceId){ workspace { id slug } generatedAt manifests statuses integrationLinks jobs setupGuidance uiModuleManifests } }'
curl -sS "$ROUTER_URL" \
  -H "content-type: application/json" \
  -H "x-tenant-id: $TENANT_ID" \
  -d "{\"query\":\"$SNAPSHOT_QUERY\",\"variables\":{\"workspaceId\":\"$WORKSPACE_ID\"}}" \
  | tee "$EVID_DIR/snapshot-by-arg.json"

curl -sS "$ROUTER_URL" \
  -H "content-type: application/json" \
  -H "x-tenant-id: $TENANT_ID" \
  -H "x-workspace-id: $WORKSPACE_ID" \
  -d "{\"query\":\"{ contextControlPlaneSnapshot { workspace { id } generatedAt manifests statuses integrationLinks jobs setupGuidance uiModuleManifests } }\"}" \
  | tee "$EVID_DIR/snapshot-by-header.json"
```

**Pass criteria**
- Response includes non-null `contextControlPlaneSnapshot.workspace`.
- Response includes `generatedAt` (ISO DateTime).
- `manifests`, `statuses`, `integrationLinks`, `jobs`, `setupGuidance`, `uiModuleManifests` are present and are arrays (empty-safe).

### 3) Negative tests (missing workspace + tenant mismatch)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-035"
ROUTER_URL="${ROUTER_URL:-http://router.local/}"
TENANT_ID="${TENANT_ID:-tribuence}"
WORKSPACE_ID="$(jq -r '.data.workspaceCreate.id' "$EVID_DIR/workspace-create.json")"
test -n "$WORKSPACE_ID" && test "$WORKSPACE_ID" != "null"

# Missing both workspaceId arg and x-workspace-id header must fail with BAD_USER_INPUT
curl -sS "$ROUTER_URL" \
  -H "content-type: application/json" \
  -H "x-tenant-id: $TENANT_ID" \
  -d "{\"query\":\"{ contextControlPlaneSnapshot { generatedAt } }\"}" \
  | tee "$EVID_DIR/snapshot-missing-workspace.json"

# Tenant mismatch must not leak data (workspace should not be found)
curl -sS "$ROUTER_URL" \
  -H "content-type: application/json" \
  -H "x-tenant-id: other-tenant" \
  -H "x-workspace-id: $WORKSPACE_ID" \
  -d "{\"query\":\"{ contextControlPlaneSnapshot { workspace { id } } }\"}" \
  | tee "$EVID_DIR/snapshot-tenant-mismatch.json"
```

**Pass criteria**
- Missing workspace returns a GraphQL error with `extensions.code="BAD_USER_INPUT"`.
- Tenant mismatch does not return the workspace data.

## Evidence (required)
- `project-handbook/status/evidence/TASK-035/index.md`
- `project-handbook/status/evidence/TASK-035/schema-grep.txt`
- `project-handbook/status/evidence/TASK-035/workspace-create.json`
- `project-handbook/status/evidence/TASK-035/snapshot-by-arg.json`
- `project-handbook/status/evidence/TASK-035/snapshot-by-header.json`
- `project-handbook/status/evidence/TASK-035/snapshot-missing-workspace.json`
- `project-handbook/status/evidence/TASK-035/snapshot-tenant-mismatch.json`
- `project-handbook/status/evidence/TASK-035/handbook-validate.txt`

## Sign-off
- [ ] All validation steps completed
- [ ] Evidence documented above
- [ ] Ready to mark task as "done"
