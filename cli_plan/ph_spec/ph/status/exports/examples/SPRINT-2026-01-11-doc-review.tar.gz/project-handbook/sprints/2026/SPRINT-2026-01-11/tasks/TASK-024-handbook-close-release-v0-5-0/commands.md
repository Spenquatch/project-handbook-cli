---
title: Handbook: Close release v0.5.0 - Commands
type: commands
date: 2026-01-11
task_id: TASK-024
tags: [commands]
links: []
---

# Commands: Handbook: Close release v0.5.0

## Task Status
```bash
pnpm -C project-handbook make -- task-status id=TASK-024 status=doing
pnpm -C project-handbook make -- task-status id=TASK-024 status=review
pnpm -C project-handbook make -- task-status id=TASK-024 status=done
```

## Evidence Directory (required)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-024"
mkdir -p "$EVID_DIR"
${EDITOR:-vi} "$EVID_DIR/index.md"
```

## Release Close + Status Updates
```bash
set -euo pipefail

pnpm -C project-handbook make -- release-status | tee "$EVID_DIR/release-status.before.txt"
pnpm -C project-handbook make -- release-close version=v0.5.0 | tee "$EVID_DIR/release-close.txt"
pnpm -C project-handbook make -- release-status | tee "$EVID_DIR/release-status.after.txt"

pnpm -C project-handbook make -- status | tee "$EVID_DIR/status.txt"
pnpm -C project-handbook make -- dashboard | tee "$EVID_DIR/dashboard.txt"
```

## Handbook Validation
```bash
pnpm -C project-handbook make -- validate
```
