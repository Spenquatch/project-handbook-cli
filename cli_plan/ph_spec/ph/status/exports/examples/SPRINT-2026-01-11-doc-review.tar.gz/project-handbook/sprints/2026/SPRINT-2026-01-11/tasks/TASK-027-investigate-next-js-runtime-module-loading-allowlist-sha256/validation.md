---
title: Investigate: Next.js runtime module loading (allowlist + sha256) - Validation Guide
type: validation
date: 2026-01-11
task_id: TASK-027
tags: [validation]
links: []
---

# Validation Guide: Investigate: Next.js runtime module loading (allowlist + sha256)

## Automated Validation
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Pass/Fail Criteria
- `project-handbook/features/v2.1_ui-module-registry-discovery/decision-register/DR-0002-nextjs-runtime-module-loading-strategy.md` exists and ends with an explicit operator approval request (status remains `Proposed`).
- Feature docs are updated to be execution-ready (architecture + implementation reflect the recommended option as “pending approval”).

## Evidence (required)
- `project-handbook/status/evidence/TASK-027/index.md`
- `project-handbook/status/evidence/TASK-027/adr-0025.txt`
- `project-handbook/status/evidence/TASK-027/adr-0024.txt`
- `project-handbook/status/evidence/TASK-027/ui-boundary-notes.txt`
- `project-handbook/status/evidence/TASK-027/v2-tribuence-mini-package-json.txt`
- `project-handbook/status/evidence/TASK-027/v2-tribuence-mini-middleware-ts.txt`
- `project-handbook/status/evidence/TASK-027/v2-tribuence-mini-homepage-snippet.txt`
- `project-handbook/status/evidence/TASK-027/v2-csp-search.txt`

## Sign-off
- [ ] All validation steps completed
- [ ] Evidence documented above
- [ ] Ready to mark task as "done"
