---
id: ADR-0033
title: Module registry alignment with v3 roadmap (Option A)
type: adr
status: accepted
date: 2026-01-12
tags: [v2.1, module-registry, v3, alignment, entitlements, overlays, compliance, context]
links:
  - ../decision-register/DR-0007-module-registry-alignment-with-v3-roadmap.md
  - ./0025-v2-1-ui-module-registry.md
  - ./0027-v2-context-control-plane-schema.md
  - ../features/v2.1_ui-module-registry-discovery/implementation/IMPLEMENTATION.md
  - ../features/v2.1_ui-module-registry-discovery/architecture/ARCHITECTURE.md
  - ../features/v3_capability-control-service-billing/overview.md
  - ../features/v3_client-customization-overlays/overview.md
  - ../features/v3_license-compliance-automation/overview.md
---

# Context

v2.1 introduces a UI module registry (artifact origin + publish pipeline + runtime loader) selected via Context control-plane
manifests. The v3 roadmap adds entitlements/billing, provisioning workflows, an operator surface, license compliance
automation, and client customization overlays.

This ADR records the accepted alignment posture so v2.1 execution work does not create v3 dead ends.

# Decision

Adopt **Option A**:

- Keep v2.1 module delivery **“dumb + content-addressed”** (immutable bytes keyed by `{moduleId}/{version}/{integritySha256}`).
- Keep v3 concerns (entitlements, overlays, compliance governance) **additive** and expressed via Context control-plane state
  and new v3 services.
- Keep policy out of the runtime loader: loader enforces allowlist + integrity; entitlement and overlay decisions happen
  upstream in the control-plane layers.

## v3 compatibility checklist (exhaustive; execution gate)

All v2.1 module registry and Context control-plane work must satisfy this checklist.

### A) Module artifacts and serving (registry/origin)
- [ ] **Immutability is real**: module artifacts are append-only and never overwritten.
- [ ] **Content-addressed URLs remain the primitive**: every module fetch URL includes `integritySha256` (no “latest” indirection).
- [ ] **Object key scheme stays stable**: `ui-modules/{moduleId}/{version}/{integritySha256}/index.mjs` (or a strictly additive extension that preserves existing keys).
- [ ] **Artifact format remains explicit and bounded**: v2.1 uses a single-file ESM `index.mjs`; any multi-file evolution must preserve content-addressing and allow immutable caching.
- [ ] **Browser never needs S3 access**: browsers fetch module bytes via a same-origin route (or a dedicated internal origin), not via S3 endpoints or signed S3 URLs.
- [ ] **Allowlist is enforced before any origin proxying**: unknown `moduleId` is rejected without enabling arbitrary key reads.
- [ ] **Input validation is strict**: `moduleId`, `version`, and `integritySha256` are validated (format + length) before any storage lookup.
- [ ] **Immutable caching is safe**: served module bytes set immutable cache headers because `integritySha256` makes the URL content-addressed.
- [ ] **Deterministic error semantics**: missing objects yield `404` (not `500`); error responses never include secrets.

### B) Runtime loader semantics (security + determinism)
- [ ] **Verify-before-execute posture is preserved**:
  - Preferred: client verifies sha256 before importing/executing.
  - If server verification is used later, the server must verify the requested hash before serving bytes.
- [ ] **Failure is panel-scoped and deterministic**: loader failures render a deterministic fallback state and never take down the whole shell.
- [ ] **Stable failure reason codes** exist and remain stable across v2.1 and v3 (`NOT_ALLOWLISTED`, `FETCH_404`, `FETCH_FAILED`, `HASH_MISMATCH`, `EVAL_ERROR`, `EXPORT_INVALID`).
- [ ] **Telemetry remains non-sensitive**: module load events include `{ moduleId, version, integritySha256, outcome, reasonCode, durationMs }` only (no credentials, no full URLs with secrets).
- [ ] **SSR boundary is explicit**: module execution is client-only; SSR must never evaluate remote module code.
- [ ] **CSP implications are explicit**: if `blob:` is required for verify-before-execute, CSP decisions must be recorded; if CSP disallows `blob:`, a verified server-serve mode must be used.

### C) Identity and versioning (capability alignment)
- [ ] **`moduleId` is stable and not tenant-specific**: overlays/customizations must not create per-tenant forks in IDs.
- [ ] **Module-to-capability alignment is explicit**: module exports include a `capabilityId` sanity check and UI wiring treats it as an invariant.
- [ ] **Versioning is explicit and pinned**: Context selects `{ moduleId, version, integritySha256 }`; “floating” versions are not used in runtime manifests.

### D) Context control-plane ownership (v3 services write policy; Context is source of truth)
- [ ] **Context remains the system-of-record** for workspace capability state and module manifests.
- [ ] **v3 control service drives desired state by writing to Context** (manifests) and observing Context status; it does not introduce a parallel gating surface.
- [ ] **Wrappers and UI gate off the same snapshot** (single canonical snapshot contract) and treat fetch failures as deterministic safe-gated behavior.
- [ ] **No provider secrets** are stored in or returned by Context snapshot surfaces; only references/IDs are permitted.

### E) Additive evolution is non-negotiable (schemas/contracts)
- [ ] **Context schema evolution stays additive**: new v3 fields (entitlements, overlays, compliance metadata) must be optional/empty-safe so older consumers keep working.
- [ ] **Snapshot remains empty-safe**: arrays default to empty; missing surfaces do not crash UI/wrappers.
- [ ] **Stable contract versioning**: contract files and types are versioned; breaking changes require an explicit ADR and a migration plan.

### F) v3 entitlements/billing compatibility
- [ ] **Entitlements are policy, not distribution**: billing/plan logic never changes how bytes are fetched; it only changes what manifests select and what state is shown.
- [ ] **Deterministic enable/disable events**: control actions are idempotent and produce deterministic audit records suitable for billing and operator surfaces.

### G) v3 provisioning/workflow compatibility
- [ ] **Provisioning status is reflected back into Context** so UI/wrappers can gate deterministically off a single snapshot.
- [ ] **Job history and runbook linkage are representable** (IDs/links), enabling Backstage/operator tooling without schema redesign.

### H) v3 overlays compatibility (client customization)
- [ ] **Overlays are declarative, versioned, and validated**; unsafe overlays are rejected.
- [ ] **Overlay application is deterministic**: precedence/layering rules are explicit and stable.
- [ ] **Overlays cannot bypass capability gating** and cannot introduce cross-tenant leakage.
- [ ] **Overlays do not require mutating module bytes**: customization is expressed as separate overlay state/artifacts, not per-tenant module rebuilds.

### I) v3 compliance compatibility (license governance)
- [ ] **License posture is representable**: module/capability metadata can carry license classification and governance pointers.
- [ ] **Compliance artefacts can be deterministic**: future “reactive source provision” and compliance reports can reference module/capability metadata without changing the module delivery contract.
- [ ] **Copyleft isolation posture is preserved**: platform code remains API-only with copyleft services; module registry does not introduce code linking across license boundaries.

### J) Auditability and operator experience
- [ ] **Everything is traceable**: for any workspace, operators can determine which `{ moduleId, version, integritySha256 }` was selected and served.
- [ ] **Evidence/runbook linkage is possible**: metadata surfaces can carry stable runbook/evidence links without exposing secrets.

# Consequences

## Positive
- Keeps v2.1 execution small and compatible with already-accepted origin/loader decisions.
- Makes v3 evolution additive (Context fields + new v3 services) instead of forcing rewrites in module delivery mechanics.

## Tradeoffs
- Strong publisher provenance/signature enforcement is deferred; if v3 governance requires it, it must be added later via additive metadata and explicit gates.

# Rollout / Acceptance

- Create explicit execution tasks referencing this ADR for:
  - reserving/prototyping additive metadata fields for provenance + license posture,
  - defining overlay descriptor + precedence semantics as additive control-plane state,
  - adding contract/test guardrails so the checklist can’t drift silently.

Created:
- `TASK-040` (contract: v3-ready UI module manifest metadata fields, v1)
- `TASK-041` (contract: v3 overlay descriptors + precedence, v1)
