---
title: Implement: Context DB migrations for control-plane tables (v1) - References
type: references
date: 2026-01-11
task_id: TASK-034
tags: [references]
links: []
---

# References: Implement: Context DB migrations for control-plane tables (v1)

## Internal References

### Decision Context
- **Decision**: [FDR-v2_context-control-plane-schema-0001](../../../../../features/v2_context-control-plane-schema/fdr/0001-context-control-plane-snapshot-contract.md)
- **Feature**: [Feature overview](../../../../../features/v2_context-control-plane-schema/overview.md)
- **Architecture**: [Feature architecture](../../../../../features/v2_context-control-plane-schema/architecture/ARCHITECTURE.md)
- **Implementation plan**: [Feature implementation](../../../../../features/v2_context-control-plane-schema/implementation/IMPLEMENTATION.md)

### Contracts (source of truth)
- **DB contract**: [Context DB schema](../../../../../contracts/tribuence-mini-v2/context-db-schema.md)

### Sprint Context
- **Sprint Plan**: [Current sprint](../../plan.md)
- **Sprint Tasks**: [All sprint tasks](../)
- **Daily Progress**: [Daily status](../../daily/)

### v2 implementation pointers (read-only references)
- **Migration runner**: [`v2/services/context/index.js`](../../../../../../v2/services/context/index.js)
- **Existing v0 migration**: [`v2/services/context/db/migrations/001_init.sql`](../../../../../../v2/services/context/db/migrations/001_init.sql)
- **v2 quickstart**: [`v2/docs/README.md`](../../../../../../v2/docs/README.md)
