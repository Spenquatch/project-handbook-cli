---
title: v2 Onboarding E2E (Playwright Strategy)
type: testing-note
feature: v2_workspace-signup-onboarding
date: 2026-01-07
tags: [playwright, onboarding, e2e, discovery]
links:
  - ../../status.md
  - ../../../adr/0026-v2-workspace-signup-onboarding.md
  - ../../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
---

# v2 Onboarding E2E (Playwright Strategy)

## Outcome
Define an execution-ready E2E strategy for validating:
signup → login → onboarding (workspace create) → landing harness,
with deterministic cleanup and low flake risk.

This document is the target output for `TASK-005`.

## Current State (Repo Reality)
- Playwright is already wired under `v2/apps/tribuence-mini/`:
  - config: `v2/apps/tribuence-mini/playwright.config.ts`
  - tests: `v2/apps/tribuence-mini/e2e/`
  - Keycloak login helper: `v2/apps/tribuence-mini/e2e/helpers/keycloak.ts`
- The landing harness is `/` (see `ADR-0024`) and already renders workspace list + capability panels.
- A dedicated “post-auth onboarding form” route does not exist yet in the UI; it must be added as part of the follow-up execution work to satisfy `ADR-0026` and make the E2E mirror the intended UX.

## Principles (from ADRs)
- The landing page is the canonical harness entrypoint (`ADR-0024`).
- Onboarding is post-auth only; no unauthenticated workspace creation (`ADR-0026`).
- No provider secrets are ever captured in UI or Playwright logs (`ADR-0014`).

## Test Flow (Happy Path)
### Target UX flow (matches ADR intent)
1. Start on `E2E_BASE_URL` (default `http://app.local`).
2. If not authenticated, middleware redirects to `/login`; click “Sign in” and complete Keycloak auth.
3. After auth, if no workspace is selected:
   - route to an onboarding page (recommended path: `/onboarding`),
   - create a Context workspace (`workspaceCreate`) with `slug` + `name`,
   - select it (set `tribuence-workspace-id` cookie),
   - redirect to `/` (landing harness).
4. Assert in landing harness:
   - “Active workspace” shows the created slug,
   - `Workspaces → Existing` contains the created workspace,
   - at least one capability panel renders deterministically (gated/un-gated) based only on Context state.

### Important constraint: “signup” coverage
For a low-flake launch gate, do not rely on Keycloak “self-registration UI” for user creation. Prefer:
- realm drift checks + bootstrap evidence (`TASK-009`/`TASK-010` lane), and
- provisioning an E2E user via Keycloak admin API (already implemented in `v2/apps/tribuence-mini/e2e/helpers/keycloak.ts`) for the E2E flow above.

## Determinism + Cleanup Strategy
Cleanup strategy is governed by `project-handbook/features/v2_workspace-signup-onboarding/decision-register/DR-0002-playwright-onboarding-e2e-cleanup-strategy.md`.

### Recommended (DR-0002 Option A): API-driven teardown
**Test-owned identifiers**
- Keycloak user:
  - Prefer fixed credentials via env (`E2E_KEYCLOAK_USERNAME` / `E2E_KEYCLOAK_PASSWORD`) in CI to avoid per-test user creation.
  - If provisioning is used, usernames are already generated with the `e2e-` prefix in `v2/apps/tribuence-mini/e2e/helpers/keycloak.ts`.
- Context workspace:
  - Workspace ID can be read from the cookie `tribuence-workspace-id` after the onboarding form submits successfully.
  - Workspace slug should be generated with an `e2e-` prefix (example: `e2e-onboarding-<timestamp>`).

**Required follow-up wiring**
- Keycloak: add `deleteUserByUsername(username)` to `v2/apps/tribuence-mini/e2e/helpers/keycloak.ts` (same admin token path already used for provisioning).
- Context: add `workspaceDelete(id: ID!)` to the Context subgraph (currently missing) and call it from a Playwright teardown helper:
  - Context service schema/resolvers: `v2/services/context/index.js`
  - Schema snapshots for composition: `v2/infra/compose/graphql/subgraphs/tribuence-context/schema.graphql` (+ any generated supergraph snapshot workflow)

### Fallback (DR-0002 Option B): reset-by-recreate
Keep as a local escape hatch only; do not make it a required gate unless it is measured and consistently under 5 minutes.

## Selector Strategy (Reduce Flake)
### Existing stable surface (already in repo)
- Keycloak login: use stable ids (`#username`, `#password`, `#kc-login`, `#kc-form-login`), as in `v2/apps/tribuence-mini/e2e/helpers/keycloak.ts`.
- Landing harness capability panels: use existing `data-testid` where present (see evidence: `project-handbook/status/evidence/TASK-005/data-testid-scan.txt`).

### Required additions for onboarding + workspace selection
Add `data-testid` for the pieces the onboarding E2E must interact with deterministically:
- Onboarding form:
  - `onboarding-workspace-form`
  - `onboarding-workspace-slug`
  - `onboarding-workspace-name`
  - `onboarding-submit`
- Landing harness workspace assertions:
  - `workspace-active-slug`
  - `workspace-existing-list`
  - `workspace-select-button` (on each list row) or `workspace-row-<slug>` (stable per slug)

Prefer `getByLabel(...)` for form fields wherever possible, but keep the test resilient to copy changes by anchoring on `data-testid` for container-level assertions and buttons.

## Evidence + Redaction
- Playwright traces/screenshots must not include tokens/secrets.
- Keep traces `on-first-retry` (current config) and ensure:
  - upstream errors are sanitized in UI (`BUG-P1-20260105-083811`),
  - server logs redact `Authorization`/`Cookie` (`BUG-P1-20260105-0837`),
  - no “raw upstream body” is rendered into the DOM.

## File Locations (must be selected in TASK-005)
### Canonical location (selected)
- Playwright tests: `v2/apps/tribuence-mini/e2e/`
- Helpers: `v2/apps/tribuence-mini/e2e/helpers/`

### Proposed spec name (follow-up execution task)
- `v2/apps/tribuence-mini/e2e/onboarding-workspace-create-harness.spec.ts`

## Smoke Gate Integration
Integrate the onboarding E2E into the launch gate runner (`ADR-0028`) as a required gate once it is stable.

**Runner contract reference**
- `project-handbook/features/v2_launch/implementation/GATES.md` defines the single entrypoint:
  - `EVIDENCE_DIR="../project-handbook/status/evidence/<TASK-ID>" make -C v2 v2-launch-gates`

**Proposed gate shape (follow-up execution task)**
- Gate command (run from v2):
  - `pnpm -C apps/tribuence-mini exec playwright test`
- Evidence:
  - write Playwright output (trace/video/screenshots) under `$EVIDENCE_DIR/playwright/` (configure via Playwright `--output` or config override)
  - write a stable gate summary (pass/fail + runtime) to `$EVIDENCE_DIR/playwright-onboarding.txt`
