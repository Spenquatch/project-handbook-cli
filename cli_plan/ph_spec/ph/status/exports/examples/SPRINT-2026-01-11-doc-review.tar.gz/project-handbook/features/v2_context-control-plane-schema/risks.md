---
title: v2 Context Control Plane Schema Risks
type: risks
feature: v2_context-control-plane-schema
date: 2026-01-07
tags: [risks]
links:
  - ../../adr/0027-v2-context-control-plane-schema.md
  - ../../adr/0016-v2-context-glue-integrations.md
---

# Risk Register: v2 Context Control Plane Schema

## High Priority Risks
- **Cross-workspace leakage in control-plane APIs**  
  - Impact: High  
  - Probability: Low  
  - Mitigation: enforce tenant/workspace scoping at the data-access layer and validate isolation tests.
- **Non-idempotent provisioning creates duplicate upstream resources**  
  - Impact: High  
  - Probability: Medium  
  - Mitigation: operation keys, serialized execution per workspace/provider, and durable job/run audit trail.

## Medium Priority Risks
- **Provider-specific requirements leak into core schema**  
  - Impact: Medium  
  - Probability: Medium  
  - Mitigation: provider-agnostic core types and provider adapters for integration-specific details.
- **Schema churn breaks UI/wrapper gating**  
  - Impact: Medium  
  - Probability: Medium  
  - Mitigation: maintain a single stable snapshot query and evolve it additively only.
- **Overlay precedence ambiguity causes nondeterministic UI**  
  - Impact: Medium  
  - Probability: Medium  
  - Mitigation: codify precedence semantics in the snapshot contract and DB schema (`TASK-041`) and require stable ordering guarantees.
- **Metadata fields become an accidental secret-leak vector**  
  - Impact: Medium  
  - Probability: Low  
  - Mitigation: explicitly prohibit credentials/signed URLs/private keys in provenance/license metadata (`TASK-040`) and validate evidence captures during review.
- **Non-idempotent DB migrations break Context boot**  
  - Impact: Medium  
  - Probability: Medium  
  - Mitigation: Context applies SQL migrations on every service boot; require `IF NOT EXISTS`/duplicate-safe DDL, restart-based validation, and evidence capture (`TASK-034`).

## Risk Mitigation Strategies
- Treat the control plane as a stable contract: additive-only schema changes and strict invariants.
- Validate isolation + idempotency in CI and gate releases on these checks.
