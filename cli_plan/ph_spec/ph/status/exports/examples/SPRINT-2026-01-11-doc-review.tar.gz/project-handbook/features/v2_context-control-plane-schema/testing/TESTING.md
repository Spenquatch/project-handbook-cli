---
title: v2 Context Control Plane Schema Testing
type: testing
feature: v2_context-control-plane-schema
date: 2026-01-07
tags: [testing]
links:
  - ../../adr/0027-v2-context-control-plane-schema.md
  - ../../adr/0018-v2-capability-detection-surface.md
---

# Testing: v2 Context Control Plane Schema

## Test Strategy
- **Unit**: invariant enforcement (tenant/workspace scoping; idempotency keys; redaction rules).
- **Integration**: control-plane snapshot query returns correct desired+observed state.
- **Integration**: enable/disable updates manifests and drives job enqueue behavior.
- **Integration**: ensure-link is idempotent and never duplicates link records.

## Test Cases
1) Two workspaces enable the same capability; confirm state is isolated and no records leak.
2) Enable a capability; confirm a provisioning job is enqueued and status reflects provisioning.
3) Run ensure-link twice; confirm only one link exists and only one active provisioning execution occurs.
4) Confirm no provider secrets appear in GraphQL responses or logs for control-plane APIs.

## Acceptance Criteria
- [ ] Context exposes a workspace control-plane snapshot query that drives UI/wrapper gating.
- [ ] Context supports manifests, status, links, jobs/runs, and setup guidance identifiers.
- [ ] Isolation and idempotency invariants are enforced and validated.
- [ ] No provider secrets are stored or returned by the control plane.
