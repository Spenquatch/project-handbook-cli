---
title: Investigate: Next.js runtime module loading (allowlist + sha256) - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-027
tags: [implementation]
links: []
---

# Implementation Steps: Investigate: Next.js runtime module loading (allowlist + sha256)

## Overview
This is a `session=research-discovery` task. The deliverable is a completed feature-local DR (`DR-0002`) plus execution-ready feature documentation. No product code changes.

## Prerequisites
- `TASK-025` is `done`.

## Step 1 — Ground truth constraints (ADR + boundaries)
1. Read:
   - `project-handbook/adr/0025-v2-1-ui-module-registry.md`
   - `project-handbook/adr/0024-v2-ui-dev-harness-and-module-boundaries.md`
2. Create an evidence index at `project-handbook/status/evidence/TASK-027/index.md`.
3. Create the DR file for this task:
   - `project-handbook/features/v2.1_ui-module-registry-discovery/decision-register/DR-0002-nextjs-runtime-module-loading-strategy.md`

## Step 2 — Inventory current UI boundaries (repo inspection)
Goal: ensure the loader strategy fits the existing v2 UI boundaries (module-ready panels) and does not require refactors.
1. Inspect the UI shell panel boundary (high level only; do not implement):
   - `project-handbook/features/v2_ui-dev-harness-and-module-boundaries/overview.md`
   - any existing UI panel interface contracts referenced there.

## Step 3 — Define two viable loader strategies (A/B)
Update DR-0002 with exactly two viable options:
- **Option A**: browser-side integrity verification + Blob URL ESM import (verify-before-execute in the browser).
- **Option B**: server-side verification + serve verified assets (normal caching semantics).

Each option must specify:
- module format contract (bundle type + entrypoint),
- allowlist enforcement location,
- caching strategy (what is cached, where, and invalidation rules),
- deterministic fallback UI states and failure semantics,
- telemetry hooks to record module load success/failure without leaking secrets.

## Step 4 — Complete DR-0002 (with evidence + recommendation)
1. Fill in DR-0002 (replace placeholders, add evidence references).
2. End with an explicit operator approval request and keep status `Proposed` until approval.

## Step 5 — Update feature docs to be execution-ready (pending approval)
Update:
- `project-handbook/features/v2.1_ui-module-registry-discovery/architecture/ARCHITECTURE.md`
- `project-handbook/features/v2.1_ui-module-registry-discovery/implementation/IMPLEMENTATION.md`

Include:
- selected loader strategy and data flow,
- exact v2 wiring points that would change (plan only),
- exact smoke/E2E validation steps and what evidence to capture.

## Step 6 — Validate handbook + wrap for review
1. Run `pnpm -C project-handbook make -- validate`.
2. Update `validation.md` and `checklist.md` with the evidence file list.
3. Set task status to `review`.
