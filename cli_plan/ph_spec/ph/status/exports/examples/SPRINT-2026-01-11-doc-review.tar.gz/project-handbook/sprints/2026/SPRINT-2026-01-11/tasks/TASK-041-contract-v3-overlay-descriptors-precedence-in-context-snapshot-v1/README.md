---
title: Task TASK-041 - Contract: v3 overlay descriptors + precedence in Context snapshot (v1)
type: task
date: 2026-01-11
task_id: TASK-041
feature: v2_context-control-plane-schema
session: task-execution
tags: [task, v2_context-control-plane-schema]
links: [../../../../features/v2_context-control-plane-schema/overview.md]
---

# Task TASK-041: Contract: v3 overlay descriptors + precedence in Context snapshot (v1)

## Overview
- **Feature**: [v2_context-control-plane-schema](../../../../features/v2_context-control-plane-schema/overview.md)
- **Decision**: [ADR-0033](../../../../adr/0033-module-registry-alignment-with-v3-roadmap.md)
- **Story Points**: 2
- **Owner**: @spenser
- **Lane**: `context/control-plane`
- **Session**: `task-execution`

## Agent Navigation Rules
1. **Start work**: Update `task.yaml` status to "doing"
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: Set to "review" when ready for review

## Context & Background
This task extends the v1 control-plane snapshot contract to reserve an **additive overlays surface** with explicit,
deterministic precedence rules required by [ADR-0033](../../../../adr/0033-module-registry-alignment-with-v3-roadmap.md).

This is an execution task for documentation/contracts only:
- In scope: `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md`, `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md`
- Out of scope: any `v2/` product code changes, overlay artifact schema/validator implementation

## Quick Start
```bash
pnpm -C project-handbook make -- task-status id=TASK-041 status=doing
cd project-handbook/sprints/current/tasks/TASK-041-contract-v3-overlay-descriptors-precedence-in-context-snapshot-v1/

# Follow implementation
cat steps.md              # Read implementation steps
cat commands.md           # Copy-paste commands
cat validation.md         # Validation approach
```

## Dependencies
Hard dependencies (must be `done` before execution):
- `TASK-032` — establishes the v1 snapshot types that this task extends.
- `TASK-033` — establishes the v1 DB schema contract that this task extends (additive overlay binding/storage).

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.

## Evidence
All evidence for this task must be captured under `project-handbook/status/evidence/TASK-041/` (see `validation.md`).
