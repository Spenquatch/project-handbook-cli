---
title: Contract: v3 overlay descriptors + precedence in Context snapshot (v1) - Commands
type: commands
date: 2026-01-12
task_id: TASK-041
tags: [commands]
links: []
---

# Commands: Contract: v3 overlay descriptors + precedence in Context snapshot (v1)

## Task Status
```bash
pnpm -C project-handbook make -- task-status id=TASK-041 status=doing
pnpm -C project-handbook make -- task-status id=TASK-041 status=review
pnpm -C project-handbook make -- task-status id=TASK-041 status=done
```

## Confirm Dependencies (must be `done`)
```bash
pnpm -C project-handbook make -- task-show id=TASK-032
pnpm -C project-handbook make -- task-show id=TASK-033
```

## Evidence Directory
```bash
EVID_DIR="project-handbook/status/evidence/TASK-041"
mkdir -p "$EVID_DIR"
${EDITOR:-vi} "$EVID_DIR/index.md"
```

## Capture Inputs (evidence)
```bash
set -euo pipefail
EVID_DIR="project-handbook/status/evidence/TASK-041"

sed -n '1,260p' project-handbook/adr/0033-module-registry-alignment-with-v3-roadmap.md \
  | tee "$EVID_DIR/adr-0033.txt"

sed -n '1,220p' project-handbook/features/v3_client-customization-overlays/overview.md \
  | tee "$EVID_DIR/v3-overlays-overview.txt"

sed -n '1,220p' project-handbook/features/v3_client-customization-overlays/architecture/ARCHITECTURE.md \
  | tee "$EVID_DIR/v3-overlays-arch.txt"

rg -n "ContextControlPlaneSnapshot|ContextOverlayDescriptor|ContextOverlayScope|overlays:" \
  project-handbook/contracts/tribuence-mini-v2/context-subgraph.md \
  | tee "$EVID_DIR/context-subgraph-before.txt"

rg -n "overlay_bindings|overlay_id|integrity_sha256|priority" \
  project-handbook/contracts/tribuence-mini-v2/context-db-schema.md \
  | tee "$EVID_DIR/context-db-before.txt"
```

## Edit Contracts
```bash
${EDITOR:-vi} project-handbook/contracts/tribuence-mini-v2/context-subgraph.md
${EDITOR:-vi} project-handbook/contracts/tribuence-mini-v2/context-db-schema.md
```

## Capture “After” Excerpts + Diffs (required)
```bash
set -euo pipefail
EVID_DIR="project-handbook/status/evidence/TASK-041"
mkdir -p "$EVID_DIR"

rg -n "ContextControlPlaneSnapshot|ContextOverlayDescriptor|ContextOverlayScope|overlays:" \
  project-handbook/contracts/tribuence-mini-v2/context-subgraph.md \
  | tee "$EVID_DIR/context-subgraph-after.txt"

rg -n "overlay_bindings|overlay_id|integrity_sha256|priority" \
  project-handbook/contracts/tribuence-mini-v2/context-db-schema.md \
  | tee "$EVID_DIR/context-db-after.txt"

git diff -- project-handbook/contracts/tribuence-mini-v2/context-subgraph.md \
  | tee "$EVID_DIR/context-subgraph.diff"

git diff -- project-handbook/contracts/tribuence-mini-v2/context-db-schema.md \
  | tee "$EVID_DIR/context-db.diff"
```

## Validation
```bash
set -euo pipefail
EVID_DIR="project-handbook/status/evidence/TASK-041"
mkdir -p "$EVID_DIR"

pnpm -C project-handbook make -- validate | tee "$EVID_DIR/validate.txt"
pnpm -C project-handbook make -- sprint-status | tee "$EVID_DIR/sprint-status.txt"
```

## Quick Copy-Paste
```bash
pnpm -C project-handbook make -- task-show id=TASK-041
rg -n "ContextOverlayDescriptor|ContextOverlayScope|overlays:" project-handbook/contracts/tribuence-mini-v2/context-subgraph.md
rg -n "overlay_bindings|overlay_id|integrity_sha256|priority" project-handbook/contracts/tribuence-mini-v2/context-db-schema.md
```
