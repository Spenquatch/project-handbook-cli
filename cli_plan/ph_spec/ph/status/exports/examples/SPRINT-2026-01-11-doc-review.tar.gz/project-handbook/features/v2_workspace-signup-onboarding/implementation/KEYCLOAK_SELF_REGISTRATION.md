---
title: v2 Keycloak Self-Registration (Realm Bootstrap Plan)
type: implementation-note
feature: v2_workspace-signup-onboarding
date: 2026-01-07
tags: [keycloak, onboarding, discovery]
links:
  - ../../status.md
  - ../../../adr/0026-v2-workspace-signup-onboarding.md
---

# v2 Keycloak Self-Registration (Realm Bootstrap Plan)

## Outcome
Produce a deterministic realm bootstrap (repeatable) that enables self-registration for the v2 realm, with a smoke check
that fails fast when settings drift.

This document is the target output for `TASK-004`.

## Current Wiring (Evidence)
- Realm import:
  - `v2/infra/compose/docker-compose.v2.yml` mounts `./keycloak/realm.json` to `/opt/keycloak/data/import/realm.json` and runs Keycloak with `--import-realm`.
  - Evidence: `project-handbook/status/evidence/TASK-004/compose-keycloak-snippet.txt`, `project-handbook/status/evidence/TASK-004/compose-keycloak-realm-mentions.txt`
- Realm JSON:
  - `v2/infra/compose/keycloak/realm.json` (realm `tribuence`, client `tribuence-mini-v2`).
- Operator notes:
  - `v2/infra/compose/keycloak/README.md` (how to re-import, redirect URIs, issuer, client secret handling).
- NextAuth wiring:
  - `v2/apps/tribuence-mini/src/app/api/auth/[...nextauth]/route.ts` configures `KeycloakProvider({ issuer, clientId, clientSecret })`.
  - `v2/apps/tribuence-mini/src/app/login/page.tsx` calls `signIn('keycloak', ...)`.
- Vault wiring:
  - `v2/infra/vault/templates/next.env.tpl` renders `KEYCLOAK_ISSUER`, `KEYCLOAK_PUBLIC_ISSUER`, `KEYCLOAK_CLIENT_ID`, `KEYCLOAK_CLIENT_SECRET`.
  - `v2/scripts/vault/bootstrap-v2.sh` sets defaults for issuer/clientId and can fetch the Keycloak client secret via `kcadm.sh` when admin creds are present (and refuses `admin/admin`).
  - Evidence: `project-handbook/status/evidence/TASK-004/v2-infra-keycloak-wiring.txt`

## Assumptions
- v2 auth uses Keycloak + NextAuth (see `ADR-0014`).
- v2 onboarding is post-auth only (see `ADR-0026`).
- `keycloak.local` is exposed only via the Traefik allowlist (see `project-handbook/contracts/tribuence-mini-v2/traefik-routing.md`).

## Questions To Answer (Exit Criteria for TASK-004) — Answered
### Canonical realm name
- Realm: `tribuence`
- Source-of-truth: `v2/infra/compose/keycloak/realm.json`
- Issuer default (Vault bootstrap): `http://keycloak.local/realms/tribuence` in `v2/scripts/vault/bootstrap-v2.sh`

### Bootstrap/import mechanism
- Mechanism: Keycloak `start-dev --import-realm` with a repo-mounted realm import file.
- Wiring:
  - `v2/infra/compose/docker-compose.v2.yml`:
    - command includes `--import-realm`
    - volume mount `./keycloak/realm.json:/opt/keycloak/data/import/realm.json:ro`
- Important operational behavior: realm import happens only on first boot of a fresh Keycloak container (documented in `v2/infra/compose/keycloak/README.md`).

### NextAuth redirect URIs + web origins (local/dev)
- NextAuth provider: `keycloak` (see `v2/apps/tribuence-mini/src/app/api/auth/[...nextauth]/route.ts`)
- Client ID: `tribuence-mini-v2` (defaults in `v2/scripts/vault/bootstrap-v2.sh`; realm import in `v2/infra/compose/keycloak/realm.json`)
- Redirect URIs (realm import):
  - `http://app.local/api/auth/callback/keycloak`
  - `http://app.local/api/auth/callback/*`
- Web origins (realm import):
  - `http://app.local`
- Issuer (local/dev):
  - `http://keycloak.local/realms/tribuence` (see `v2/infra/compose/keycloak/README.md`)

## Required Realm Settings (Checklist)
Fill in the exact UI paths + the realm-export JSON fragments when verified.

### Registration
- [x] User registration enabled (planned)
  - UI: `Realm settings → Login → User registration`
  - Realm JSON: `"registrationAllowed": true` (currently `false` in `v2/infra/compose/keycloak/realm.json`)
- [x] Email required + email verification posture selected (planned)
  - UI: `Realm settings → Login → Email as username`, `Realm settings → Login → Verify email`
  - Realm JSON:
    - `"loginWithEmailAllowed": true` (currently `true`)
    - `"duplicateEmailsAllowed": false` (currently `false`)
    - `"verifyEmail": false` (local/dev posture; currently `false`)
  - Notes:
    - Keep `verifyEmail=false` for local/dev (no SMTP configured in the realm import).
    - Enforcing “email required” is primarily a user-profile concern; treat this as a follow-up execution step to validate/adjust Keycloak’s user profile requirements in the admin UI and re-export.
- [x] Password policy defined (planned)
  - UI: `Authentication → Policies → Password policy`
  - Realm JSON: `"passwordPolicy": "<policy string>"`
  - Local/dev recommended baseline: `length(12)`
- [x] Brute force detection posture selected (planned)
  - UI: `Realm settings → Security defenses → Brute force detection`
  - Realm JSON: `"bruteForceProtected": false` (local/dev posture; currently `false`)

### Login
- [x] “Remember me” policy decided
  - UI: `Realm settings → Login → Remember me`
  - Realm JSON: `"rememberMe": true` (currently `true`)
- [x] Reset password flow decided (local/dev enabled)
  - UI: `Realm settings → Login → Forgot password`
  - Realm JSON: `"resetPasswordAllowed": true` (currently `true`)

### Required Actions
- [x] Required actions set for first login: none (local/dev posture)
  - UI: `Authentication → Required actions`
  - Notes:
    - Keep OTP off by default in local/dev; add it as an execution follow-up if required by launch gate posture.

### Clients (NextAuth)
- [x] Client exists for the v2 UI
  - UI: `Clients → tribuence-mini-v2`
  - Realm JSON: `.clients[] | select(.clientId=="tribuence-mini-v2")` (present in `v2/infra/compose/keycloak/realm.json`)
- [x] Redirect URIs match the v2 UI NextAuth callback routes
  - UI: `Clients → tribuence-mini-v2 → Settings → Valid redirect URIs`
  - Realm JSON: `"redirectUris": ["http://app.local/api/auth/callback/keycloak", "http://app.local/api/auth/callback/*"]`
- [x] Web origins are correct for `app.local`
  - UI: `Clients → tribuence-mini-v2 → Settings → Web origins`
  - Realm JSON: `"webOrigins": ["http://app.local"]`

## Bootstrap Automation Plan (Deterministic)
Pick one approach and document it precisely (commands + files + where it lives):

### Selected: Option A — Realm export/import (repo-tracked)
This is already the current wiring surface; the execution follow-up is to update the tracked realm export and document the
“apply changes” procedure so drift is detectable and remediable.

- Source-of-truth file: `v2/infra/compose/keycloak/realm.json`
- Import wiring: `v2/infra/compose/docker-compose.v2.yml` (`start-dev --import-realm` + mount to `/opt/keycloak/data/import/realm.json`)
- Apply realm changes (local/dev):
  - Keycloak imports the realm only on first boot of a fresh container. After editing `realm.json`, recreate Keycloak:
    - `docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml up -d --force-recreate --no-deps keycloak`
  - Then (if `NEXT_PUBLIC_REQUIRE_AUTH=true`), ensure the client secret exists in Vault:
    - Either set `KEYCLOAK_CLIENT_SECRET` explicitly, or run `V2_VAULT_FETCH_KEYCLOAK_CLIENT_SECRET=true bash v2/scripts/vault/bootstrap-v2.sh`
    - Note: `bootstrap-v2.sh` refuses `admin/admin` and requires non-default admin credentials.

### Option B: Scripted configuration via admin CLI/REST
- Script must be idempotent (safe to re-run).
- Script must emit a clear “already configured” vs “configured” output.

## Production Posture Pivot (When Option A Stops Being Enough)
Option A is a good fit for current v2 local/dev posture because it is simple, reviewable, and aligned with current wiring.
In a production-like posture, the realm becomes long-lived state (you cannot “recreate to re-import”), so config changes
must become safe, audited, and applied without resets.

### What “production posture” looks like
- Long-lived Keycloak backed by a durable database (no implicit resets).
- Managed secrets lifecycle:
  - confidential client secrets generated/rotated out-of-band and stored in a secrets manager (Vault is fine).
  - admin credentials are never defaults and are not used by automation except for break-glass.
- A deterministic, idempotent config apply mechanism (Option B-style), run by automation using a least-privilege account:
  - apply realm settings (registration, password policy, brute-force posture, required actions),
  - apply client settings (redirect URIs, web origins),
  - emit evidence/audit outputs on every run.
- Drift strategy:
  - detect + alert at minimum; detect + remediate once confidence is high.
- Security posture expectations:
  - SMTP configured and `verifyEmail=true` (or an explicit equivalent posture),
  - brute-force protection enabled with explicit thresholds,
  - password policy defined (min length + complexity),
  - required actions (e.g., OTP/MFA) explicitly enabled/disabled per environment.

### Trigger to pivot to production posture
Treat any of these as a “stop relying on re-import” signal:
- We cannot tolerate Keycloak container recreation (users/realm state must persist).
- Realm drift causes recurring onboarding/auth failures (e.g., more than once per sprint, or any P1 incident).
- We introduce staging/prod environments and require audited, repeatable realm changes (change control/compliance).
- We need to roll out realm/client changes without downtime and with rollback.

### Minimal pivot plan (future execution tasks)
- Add a read-only drift check script first (admin API query + evidence capture) and run it in the gate runner.
- Promote to a mutating, idempotent bootstrap only after the drift check is stable:
  - configure realm + client settings via `kcadm.sh`/REST,
  - keep secrets out of repo,
  - produce evidence artefacts for gates.

## Smoke Check (Fail Fast)
Define a deterministic smoke check that confirms:
- registration is enabled (UI or API observable signal),
- required NextAuth client exists and redirect URIs are correct,
- admin credentials are non-default (see `BUG-P1-20260105-083807`).

Record the exact command sequence and expected output under `project-handbook/status/evidence/TASK-004/`.

### Proposed smoke check sequence (for a future gate runner)
The gate runner should capture outputs into `project-handbook/status/evidence/TASK-004/`:

1) OIDC discovery responds (Keycloak is up)
   - Command: `curl -fsS http://keycloak.local/realms/tribuence/.well-known/openid-configuration`
   - Expected signals:
     - HTTP 200
     - JSON includes `"issuer": "http://keycloak.local/realms/tribuence"`
   - Evidence: `project-handbook/status/evidence/TASK-004/smoke-oidc-discovery.json`

2) Admin creds are non-default (fail-fast)
   - Command (shell guard in the gate runner):
     - fail if `KEYCLOAK_ADMIN=admin` and `KEYCLOAK_ADMIN_PASSWORD=admin`
   - Evidence: `project-handbook/status/evidence/TASK-004/smoke-admin-creds.txt` (should not include secrets)

3) Realm + client settings match expectations (drift detection)
   - Commands (example; run `kcadm.sh` inside the Keycloak container and parse locally):
     - `docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml exec -T keycloak /opt/keycloak/bin/kcadm.sh config credentials --server http://localhost:8080 --realm master --user \"$KEYCLOAK_ADMIN\" --password \"$KEYCLOAK_ADMIN_PASSWORD\"`
     - `docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml exec -T keycloak /opt/keycloak/bin/kcadm.sh get realms/tribuence > project-handbook/status/evidence/TASK-004/smoke-realm.json`
     - `docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml exec -T keycloak /opt/keycloak/bin/kcadm.sh get clients -r tribuence -q clientId=tribuence-mini-v2 > project-handbook/status/evidence/TASK-004/smoke-client.json`
   - Expected signals:
     - `smoke-realm.json` includes `"registrationAllowed": true`
     - `smoke-client.json` includes redirect URIs + web origins matching this doc
   - Evidence:
     - `project-handbook/status/evidence/TASK-004/smoke-realm.json`
     - `project-handbook/status/evidence/TASK-004/smoke-client.json`
