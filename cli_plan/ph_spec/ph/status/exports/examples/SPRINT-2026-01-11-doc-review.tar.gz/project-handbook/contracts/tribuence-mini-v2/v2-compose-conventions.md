---
title: Tribuence Mini v2 Compose Conventions (Local/Dev)
type: architecture
date: 2026-01-02
tags: [contracts, compose, docker, conventions, tribuence-mini-v2]
links:
  - ./service-topology.md
  - ./vault-secrets.md
  - ./vault-bootstrap.md
  - ./apollo-router-config.md
  - ./traefik-routing.md
  - ../../../v2/docs/README.md
  - ../../../v2/ARCHITECTURE.md
---

# Contract: v2 Compose Conventions (local/dev)

## Purpose
Define stable conventions for how v2 compose is structured so execution work doesn’t guess:
- where compose files live,
- network/project naming,
- how Vault Agent renders env files and where they mount,
- and which services bind to localhost vs stay internal.

## Compose File Location
The canonical v2 compose file is:
- `v2/infra/compose/docker-compose.v2.yml`

## Compose Project Name
Recommended compose project name:
- `tribuence-v2`

This is referenced in `v2/docs/README.md` for local operator commands.

## Network Convention
v2 uses a dedicated bridge network:
- name: `tribuence-v2-net`

All v2 services (Traefik, Router, Vault/Agent, subgraphs, DBs) must attach to this network so Router-to-subgraph routing URLs work.

## Vault + Env Rendering

### Vault dev (local/dev)
- Vault service runs in dev mode on the compose network.
- Vault API is bound to localhost on the host:
  - `http://127.0.0.1:${VAULT_PORT:-8200}`

### Vault Agent
Vault Agent must render env files into a shared secrets volume mounted at:
- `/secrets`

Rendered env filenames (contracted):
- `next.env`
- `router.env`
- `context.env`
- `anythingllm.env`

Source-of-truth key names and KV paths:
- `vault-secrets.md`

Bootstrap workflow expectations:
- `vault-bootstrap.md`

## Traefik Config Provider
Traefik uses the file provider and must mount dynamic config from:
- `v2/infra/compose/traefik/configs/`

The v2 dynamic config is expected at:
- `v2/infra/compose/traefik/configs/traefik.v2.yml` (see `traefik-routing.md`)

## Local Dev Bindings (Host vs Internal)

### Allowed host bindings
Only the following should be exposed on the host via Traefik ports 80/443:
- UI (`app.local`)
- Router (`router.local`)
- optional Keycloak (`keycloak.local`)

### Localhost-only bindings
Vault binds to `127.0.0.1` by default for operator convenience.

### Internal-only services
Twenty, AnythingLLM, Postgres, Context service, and wrapper subgraphs should remain internal-only (no Traefik routes).

