---
title: Task TASK-025 - Handbook: Plan v0.5.1 release + assign initial features
type: task
date: 2026-01-11
task_id: TASK-025
feature: handbook-hygiene
session: task-execution
tags: [task, handbook-hygiene]
links: [../../../../../features/handbook-hygiene/overview.md]
---

# Task TASK-025: Handbook: Plan v0.5.1 release + assign initial features

## Overview
- **Feature**: [handbook-hygiene](../../../../../features/handbook-hygiene/overview.md)
- **Decision**: [ADR-0012](../../../../../adr/0012-handbook-reporting-and-continuity-artifacts.md)
- **Story Points**: 2
- **Owner**: @spenser
- **Lane**: `handbook/release`
- **Session**: `task-execution`

## Goal
Create the next release plan (`v0.5.1`) and assign the initial feature set so discovery/execution work is scoped and reportable.

## Outputs (what must exist when done)
- `project-handbook/releases/v0.5.1/plan.md` created and set as `project-handbook/releases/current`.
- Initial features assigned to `v0.5.1` via `make release-add-feature`.
- Evidence captured under `project-handbook/status/evidence/TASK-025/` (release-plan output + release-status output).

## Non-goals
- Do not change product code under `v2/`.
- Do not create sprint tasks in this task (sprint tasks are already created in `SPRINT-2026-01-11`).

## Agent Navigation Rules
1. **Start work**: Update `task.yaml` status to "doing"
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: Set to "review" when ready for review

## Context & Background
This task implements the [ADR-0012](../../../../../adr/0012-handbook-reporting-and-continuity-artifacts.md) decision for the [handbook-hygiene] feature.

## Quick Start
```bash
pnpm -C project-handbook make -- task-status id=TASK-025 status=doing
cd project-handbook/sprints/current/tasks/TASK-025-*/
cat steps.md
cat commands.md
cat validation.md
```

## Dependencies
- Requires `TASK-024` to be `done` first (release close-out).

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.
