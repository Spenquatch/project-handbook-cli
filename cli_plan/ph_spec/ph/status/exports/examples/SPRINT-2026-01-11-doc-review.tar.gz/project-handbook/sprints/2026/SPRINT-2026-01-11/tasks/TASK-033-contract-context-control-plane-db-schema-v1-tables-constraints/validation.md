---
title: Contract: Context control-plane DB schema (v1 tables + constraints) - Validation Guide
type: validation
date: 2026-01-11
task_id: TASK-033
tags: [validation]
links: []
---

# Validation Guide: Contract: Context control-plane DB schema (v1 tables + constraints)

## Automated Validation
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Manual Validation (Task-Specific, No Ambiguity)
Create `project-handbook/status/evidence/TASK-033/` and capture:

### 1) Contract contains an explicit v1 section (additive)
Pass criteria:
- `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` contains an explicit v1 section that:
  - keeps v0 tables intact (`context_workspaces`, `context_references`)
  - defines v1 control-plane tables additively

### 2) Contract includes required tables + constraints (minimum set)
Pass criteria:
- The v1 section defines the following tables by name:
  - `capability_manifests`
  - `capability_status`
  - `integration_links`
  - `integration_jobs`
  - `integration_job_runs`
  - `setup_guidance`
  - `ui_module_manifests`
- Every table is tenant/workspace-scoped (explicit `tenant_id` + `workspace_id` columns; FK to `context_workspaces` where applicable).
- Idempotency uniqueness is explicitly defined:
  - `integration_jobs` includes `idempotency_key` and a uniqueness constraint that enforces idempotency.
- “No secrets” is explicit:
  - any credential/provider field is a reference ID only (no secret material).

### 3) Suggested SQL DDL exists (reference)
Pass criteria:
- Contract includes a “Suggested SQL DDL (v1 additions)” section with `CREATE TABLE IF NOT EXISTS` examples that align
  with the stated columns and constraints.

## Evidence (required)
- `project-handbook/status/evidence/TASK-033/index.md`
- `project-handbook/status/evidence/TASK-033/context-db-schema-before.txt`
- `project-handbook/status/evidence/TASK-033/context-db-schema-after.txt`
- `project-handbook/status/evidence/TASK-033/context-db-schema.diff`
- `project-handbook/status/evidence/TASK-033/validate.txt`
- `project-handbook/status/evidence/TASK-033/sprint-status.txt`

## Sign-off
- [ ] All validation steps completed
- [ ] Evidence documented above
- [ ] Ready to mark task as "done"
