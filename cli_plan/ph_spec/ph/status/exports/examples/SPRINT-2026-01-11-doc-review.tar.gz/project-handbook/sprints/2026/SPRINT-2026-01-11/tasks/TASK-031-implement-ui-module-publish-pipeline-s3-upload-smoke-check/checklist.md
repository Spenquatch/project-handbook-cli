---
title: Implement: UI module publish pipeline (S3 upload + smoke check) - Completion Checklist
type: checklist
date: 2026-01-11
task_id: TASK-031
tags: [checklist]
links: []
---

# Completion Checklist: Implement: UI module publish pipeline (S3 upload + smoke check)

## Pre-Work
- [ ] Confirm all `depends_on` tasks are `done`
- [ ] Review `README.md`, `steps.md`, `commands.md`
- [ ] Re-read `project-handbook/features/v2.1_ui-module-registry-discovery/fdr/0001-ui-module-artifact-origin-and-publish-pipeline.md`

## During Execution
- [ ] Implement `v2/scripts/ui-modules/publish-ui-module.sh` (sha256 + upload; append-only)
- [ ] Publish script output is stable: `moduleId=... version=... integritySha256=...` (stdout)
- [ ] Publish script refuses overwrites (detect existing object and exit non-zero)
- [ ] Implement `v2/scripts/ui-modules/smoke-ui-module-origin.sh` (S3 head/get + UI route hash match)
- [ ] Smoke script verifies both: (1) S3 object exists and (2) proxy route bytes hash-match
- [ ] Capture evidence under `project-handbook/status/evidence/TASK-031/`

## Before Review
- [ ] Run `pnpm -C project-handbook make -- validate`
- [ ] Run smoke script against local v2 stack (or CI runner) and save evidence outputs
- [ ] Update `validation.md` if evidence set changed
- [ ] Set status to `review` via `pnpm -C project-handbook make -- task-status ...`

## After Completion
- [ ] Peer review approved and merged
- [ ] Move status to `done` with `pnpm -C project-handbook make -- task-status ...`
