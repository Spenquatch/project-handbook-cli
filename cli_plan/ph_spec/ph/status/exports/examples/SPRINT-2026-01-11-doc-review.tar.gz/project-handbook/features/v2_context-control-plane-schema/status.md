---
title: v2 Context Control Plane Schema Status
type: status
feature: v2_context-control-plane-schema
date: 2026-01-12
tags: [status]
links:
  - ../../adr/0027-v2-context-control-plane-schema.md
---

# Status: v2 Context Control Plane Schema

Stage: approved

## Now
- Control-plane snapshot contract is accepted: [`FDR-v2_context-control-plane-schema-0001`](./fdr/0001-context-control-plane-snapshot-contract.md).
- Sprint `SPRINT-2026-01-11` execution tasks:
  - [TASK-032](../../sprints/current/tasks/TASK-032-contract-context-control-plane-snapshot-graphql-contract-v1/README.md) — contract: snapshot GraphQL contract (v1)
  - [TASK-033](../../sprints/current/tasks/TASK-033-contract-context-control-plane-db-schema-v1-tables-constraints/README.md) — contract: DB schema (v1)
  - [TASK-040](../../sprints/current/tasks/TASK-040-contract-v3-ready-ui-module-manifest-metadata-fields-v1/README.md) — contract: v3-ready UI module manifest metadata fields (v1)
  - [TASK-041](../../sprints/current/tasks/TASK-041-contract-v3-overlay-descriptors-precedence-in-context-snapshot-v1/README.md) — contract: v3 overlay descriptors + precedence (v1)
  - [TASK-034](../../sprints/current/tasks/TASK-034-implement-context-db-migrations-for-control-plane-tables-v1/README.md) — implement: additive DB migrations
  - [TASK-035](../../sprints/current/tasks/TASK-035-implement-context-snapshot-query-types-empty-safe/README.md) — implement: snapshot query + empty-safe types
  - [TASK-036](../../sprints/current/tasks/TASK-036-validate-v2-smoke-probe-for-control-plane-snapshot-query/README.md) — validate: v2 smoke probe gate

## Cross-Task Dependencies (SPRINT-2026-01-11)
- `TASK-029` is a prerequisite input to `TASK-028` (module registry v3 alignment constraints) because the v3 checklist must be grounded in a concrete Context snapshot/consumption contract.
- `TASK-035` (snapshot query) is a prerequisite for UI module panel integration (`TASK-038`) so module selection can be resolved from Context (no env/querystring guessing).
- `TASK-036` depends on `TASK-035` shipping both the query implementation and the runtime supergraph snapshot update used by `v2-smoke` (probe must fail fast if the field is missing).
- `TASK-040` and `TASK-041` must land after `TASK-032` + `TASK-033` and stay additive-only (empty-safe surfaces, deterministic ordering semantics, no secrets) so downstream v3 alignment work can consume them without breaking existing v1 consumers.

## Next
- Land the v1 contracts ([TASK-032](../../sprints/current/tasks/TASK-032-contract-context-control-plane-snapshot-graphql-contract-v1/README.md), [TASK-033](../../sprints/current/tasks/TASK-033-contract-context-control-plane-db-schema-v1-tables-constraints/README.md)) and keep them additive-only.
- Extend the v1 contracts additively for v3 alignment:
  - [TASK-040](../../sprints/current/tasks/TASK-040-contract-v3-ready-ui-module-manifest-metadata-fields-v1/README.md) (provenance + license posture metadata; empty-safe; no secrets)
  - [TASK-041](../../sprints/current/tasks/TASK-041-contract-v3-overlay-descriptors-precedence-in-context-snapshot-v1/README.md) (overlay descriptors + deterministic precedence semantics)
- Implement and validate:
  - [TASK-034](../../sprints/current/tasks/TASK-034-implement-context-db-migrations-for-control-plane-tables-v1/README.md) (idempotent migrations; preserves v0 tables),
  - [TASK-035](../../sprints/current/tasks/TASK-035-implement-context-snapshot-query-types-empty-safe/README.md) (empty-safe snapshot query + types; workspaceId fallback semantics),
  - [TASK-036](../../sprints/current/tasks/TASK-036-validate-v2-smoke-probe-for-control-plane-snapshot-query/README.md) (smoke probe gate).

## Risks
- Scope creep into knowledge graph ingestion (mitigated by keeping this feature control-plane focused).
- Leakage of non-authoritative gating signals (mitigated by a single snapshot query used everywhere).
- Non-idempotent DDL breaks Context startup (mitigated by strict `IF NOT EXISTS` migrations + restart evidence).

## Recent
- Feature created

## Active Work (auto-generated)
*Last updated: 2026-01-12*

### Current Sprint (SPRINT-2026-01-11)
- ✅ TASK-029: Investigate: Context control plane schema migration + wrapper consumption contract (3pts, @spenser)
- ⭕ TASK-032: Contract: Context control-plane snapshot GraphQL contract (v1) (2pts, @spenser)
- ⭕ TASK-033: Contract: Context control-plane DB schema (v1 tables + constraints) (2pts, @spenser)
- ⭕ TASK-034: Implement: Context DB migrations for control-plane tables (v1) (3pts, @spenser)
- ⭕ TASK-035: Implement: Context snapshot query + types (empty-safe) (3pts, @spenser)
- ⭕ TASK-036: Validate: v2 smoke probe for control-plane snapshot query (2pts, @spenser)
- ⭕ TASK-040: Contract: v3-ready UI module manifest metadata fields (v1) (2pts, @spenser)
- ⭕ TASK-041: Contract: v3 overlay descriptors + precedence in Context snapshot (v1) (2pts, @spenser)

### Metrics
- **Total Story Points**: 19 (planned)
- **Completed Points**: 3 (16%)
- **Remaining Points**: 16
- **Estimated Completion**: SPRINT-2026-W03
- **Average Velocity**: 21 points/sprint
