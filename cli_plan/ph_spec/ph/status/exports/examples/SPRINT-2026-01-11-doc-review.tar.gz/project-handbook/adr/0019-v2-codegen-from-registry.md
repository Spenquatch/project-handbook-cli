---
id: ADR-0019
title: v2 Code Generation Uses Cosmo Registry (No Local SDL Authority)
type: adr
status: accepted
date: 2026-01-06
tags: [tribuence-mini, v2, codegen, cosmo, schema, ci]
links:
  - ../features/v2_codegen-from-registry/overview.md
  - ../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
---

# Context

Type generation must match the composed schema that Apollo Router serves. Local snapshots drift quickly when subgraphs
change, producing broken UI builds and invalid assumptions.

# Decision

## 1) Codegen pulls schemas from Cosmo (registry source of truth)

All codegen inputs (supergraph/subgraphs) are fetched from Cosmo. Local copies are treated as mirrors for debugging only.

## 2) CI enforces publish → composition check → codegen → typecheck

Schema publishing and composition checks run before codegen. Codegen output must typecheck against the repository.

## 3) Local developer workflow uses the same source of truth

Local codegen uses Cosmo (running in the default v2 stack). Developers do not manually edit schema snapshots as a primary
workflow.

# Consequences

## Positive
- Codegen always reflects what is actually composed.
- Breakages are caught at publish/check time, not after UI changes land.

## Tradeoffs
- Requires Cosmo to be up for local codegen (aligned with ADR-0015 baseline requirement).

# Rollout / Acceptance

- A single command generates types from Cosmo-published schemas.
- CI fails if schemas cannot be composed or if codegen/types drift from registry.
