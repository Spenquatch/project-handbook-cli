---
title: Tribuence Mini V2 Testing
type: testing
feature: tribuence-mini-v2
date: 2025-12-22
tags: [testing]
links: []
---

# Testing: Tribuence Mini V2

## Test Strategy
- **Smoke first**: `make v2-smoke` is the primary acceptance gate during bring-up.
- **GraphQL contract checks**: validate schema composition and run a small set of “known good” queries/mutations.
- **Isolation checks**: confirm Traefik only exposes the intended public surfaces.

## Smoke Spec (Source of Truth)
- `../../contracts/tribuence-mini-v2/v2-smoke-spec.md`
Related:
- `../../contracts/tribuence-mini-v2/federation-composition.md` (how the supergraph snapshot is generated)
- `../../contracts/tribuence-mini-v2/ui-graphql-operations.md` (minimum UI operations aligned with smoke probes)

Smoke probes are allowed to be incremental: the spec includes optional sections that are only enforced once the corresponding subgraph/service is wired (e.g. AnythingLLM wrapper subgraph).
Incrementality is driven by detecting `join__Graph` values in the Router’s composed supergraph SDL; stricter gating can be enabled via `V2_SMOKE_REQUIRE_GRAPHS` (see the smoke spec).

## Test Cases
1. `make v2-up` boots the full stack and `router.local` responds.
2. Supergraph composes at least Twenty + Context (AnythingLLM can be staged next).
3. Basic GraphQL probes succeed (workspace create/list, Twenty entity CRUD, doc ingest path stubbed or implemented).
4. UI renders and can execute at least one end-to-end GraphQL flow.

## Acceptance Criteria
- [ ] `make v2-smoke` passes consistently.
- [ ] GraphQL composition failures are actionable (clear errors + where to look).
