---
title: Tribuence Mini v2 Federation Composition Workflow
type: process
date: 2026-01-02
tags: [contracts, graphql, federation, rover, apollo-router, tribuence-mini-v2]
links:
  - ./supergraph-router.md
  - ./twenty-subgraph.md
  - ./context-subgraph.md
  - ./anythingllm-subgraph.md
  - ./v2-smoke-spec.md
  - ../../../v2/ARCHITECTURE.md
---

# Contract: Federation Composition Workflow (v2)

## Purpose
Define a **repeatable** way to:
- maintain committed **subgraph SDL snapshots**, and
- generate the committed **supergraph snapshot** used by Apollo Router in local/dev.

This contract exists to remove guesswork from:
- `TASK-012` (federation assets + supergraph snapshot),
- `TASK-013` (Twenty SDL snapshot),
- and any later schema evolution work (Context/AnythingLLM wrapper changes).

## Required Artifacts (v2)

### 1) Subgraph SDL snapshots (inputs)
Each subgraph directory must contain a committed SDL snapshot at:
- `v2/infra/compose/graphql/subgraphs/twenty/schema.graphql`
- `v2/infra/compose/graphql/subgraphs/tribuence-context/schema.graphql`
- `v2/infra/compose/graphql/subgraphs/anythingllm/schema.graphql`

Source of truth for what these schemas should be:
- Twenty: generated via introspection (`twenty-subgraph.md`).
- Tribuence Context: starts as the minimum v0 schema in `context-subgraph.md`, then evolves.
- AnythingLLM wrapper: starts as the minimum v0 schema in `anythingllm-subgraph.md`, then evolves.

### 2) Subgraph composition config (recommended)
Create a local composition config at:
- `v2/infra/compose/graphql/subgraphs.yaml`

This file is required in the current v2 system because the schema publishing workflow uses it as the canonical
subgraph inventory input (and it also makes local composition deterministic and tool-friendly via Rover).

Required graph names (must match `supergraph-router.md`):
- `twenty` → `join__Graph` includes `TWENTY`
- `tribuence_context` → `join__Graph` includes `TRIBUENCE_CONTEXT`
- `anythingllm` → `join__Graph` includes `ANYTHINGLLM`

Example `subgraphs.yaml` shape (illustrative):
```yaml
subgraphs:
  twenty:
    routing_url: http://twenty-server:3150/graphql
    schema:
      file: ./subgraphs/twenty/schema.graphql
  tribuence_context:
    routing_url: http://context:4010/graphql
    schema:
      file: ./subgraphs/tribuence-context/schema.graphql
  anythingllm:
    routing_url: http://anythingllm-subgraph:4020/graphql
    schema:
      file: ./subgraphs/anythingllm/schema.graphql
```

Notes:
- `routing_url` is the Router→Subgraph internal URL; it must be reachable on the compose network.
- Directory naming (`tribuence-context`) can differ from graph name (`tribuence_context`); the graph name is what drives `join__Graph`.

### 3) Supergraph snapshot (output)
The composed supergraph SDL must be committed at:
- `v2/infra/compose/graphql/supergraph-local.graphql`

In the current v2 system, the committed supergraph snapshot is used for graph detection/debugging (not Router runtime
execution). Apollo Router consumes a Cosmo-synced runtime supergraph file:
- `APOLLO_ROUTER_SUPERGRAPH_PATH=/dist/graphql-runtime/supergraph.graphql`

## Composition Commands (Local/Dev)

### Preferred: Rover (host-installed)
```bash
rover supergraph compose \
  --config v2/infra/compose/graphql/subgraphs.yaml \
  > v2/infra/compose/graphql/supergraph-local.graphql
```

### Alternative: Rover via Docker (no host install)
```bash
docker run --rm \
  -v "$(pwd):/work" -w /work \
  ghcr.io/apollographql/rover:latest \
  supergraph compose --config v2/infra/compose/graphql/subgraphs.yaml \
  > v2/infra/compose/graphql/supergraph-local.graphql
```

## Validation Expectations

### 1) Supergraph contains the expected graphs
After composition, smoke probes may detect federated graphs by inspecting `enum join__Graph` in the committed supergraph snapshot:
- `v2/infra/compose/graphql/supergraph-local.graphql`

The expected `join__Graph` enum values are defined in:
- `supergraph-router.md`

### 2) Incremental bring-up is allowed
During early bring-up, composition may temporarily include a subset of graphs:
- first: `TWENTY`
- next: `TRIBUENCE_CONTEXT`
- later: `ANYTHINGLLM`

When `V2_SMOKE_REQUIRE_GRAPHS` is set (see `v2-smoke-spec.md`), missing required graphs must fail the smoke run.

## Change Policy
- Any change to a subgraph schema must update its `schema.graphql` snapshot **and** regenerate `supergraph-local.graphql`.
- If the graph names change, update:
  - `supergraph-router.md` (graph name contract),
  - `v2-smoke-spec.md` (join__Graph expectations),
  - and `v2/ARCHITECTURE.md` (canonical reference).
