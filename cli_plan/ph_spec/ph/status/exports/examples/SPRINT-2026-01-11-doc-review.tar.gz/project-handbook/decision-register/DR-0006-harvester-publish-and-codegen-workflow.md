---
title: DR-0006 — Harvester Publish Workflow + Codegen Wiring (SDL Sources, Mirrors, Reports)
type: decision-register
date: 2026-01-09
tags: [decision-register, cosmo, schema, codegen, ci]
links:
  - ../releases/current/plan.md
  - ../adr/0021-v2-schema-harvester-service.md
  - ../adr/0019-v2-codegen-from-registry.md
  - ../features/v2_schema-harvester-service/overview.md
  - ../features/v2_codegen-from-registry/overview.md
---

# Decision Register Entry

### DR-0006 — Harvester Publish Workflow + Codegen Wiring (SDL Sources, Mirrors, Reports)

**Decision owner(s):** @spenser  
**Date:** 2026-01-09  
**Status:** Accepted  
**Related docs:** `ADR-0021`, `ADR-0019`, `ADR-0032`, `v2_schema-harvester-service`, `v2_codegen-from-registry`, `TASK-004`

**Problem / Context**
- This DR ID was reserved during sprint planning to enable a `session=research-discovery` task; it is completed in `TASK-004` and requires operator/user approval before being marked `Accepted`.
- We need one canonical publish/check workflow that is safe (no secret leakage), deterministic (repeatable report shape + atomic mirror updates), and supports a CI gate ordering: publish/check → codegen → typecheck.
- v2 already has a committed subgraph inventory and mirror file locations (`v2/infra/compose/graphql/subgraphs.yaml`) and a local supergraph snapshot used by smoke probes; we need to decide how those relate to Cosmo (authoritative) and to the harvester/codegen workflow.
- Key unknowns that change scope/effort: SDL source-of-truth per subgraph (introspection vs repo contract SDL), mirror update rules and writepoints, publish report contract, and how codegen consumes Cosmo-backed schema inputs (local + CI) without drift.

**Evidence (repo inspection + docs; no secrets)**
- v2 subgraph inventory (routing URLs + mirror file paths): `project-handbook/status/evidence/TASK-004/subgraphs-yaml.txt`
- v2 mirror schema file locations: `project-handbook/status/evidence/TASK-004/subgraphs-schema-files.txt`
- v2 local supergraph snapshot stats only: `project-handbook/status/evidence/TASK-004/supergraph-local-stats.txt`
- v2 smoke script relies on the local supergraph snapshot for join__Graph/field presence checks: `project-handbook/status/evidence/TASK-004/v2-smoke-schema-hooks.txt`
- No current codegen wiring exists in v2 today (beyond handbook docs): `project-handbook/status/evidence/TASK-004/rg-codegen.txt`
- Cosmo CLI publish/check references:
  - `npx wgc subgraph publish` + `--routing-url` notes: `project-handbook/status/evidence/TASK-004/cosmo-cli-subgraph-publish-snippets.txt`
  - `npx wgc subgraph check` (breaking changes + composition errors): `project-handbook/status/evidence/TASK-004/cosmo-cli-subgraph-check-snippets.txt`
- Legacy reference (modular-oss-saas):
  - Harvester implements “Option A with fallback” today: `_service.sdl` introspection first, fallback to contract SDL, then local composition preflight: `project-handbook/status/evidence/TASK-004/legacy-schema-harvester-service-snippets.txt`
  - Harvester publishes to Cosmo via REST `POST /api/v1/schema/publish` with `x-api-key` and `graphRef` (no `wgc` CLI involved): `project-handbook/status/evidence/TASK-004/legacy-schema-harvester-publish-snippets.txt`
  - Legacy subgraph manifest + contracts exist (used as fallback, not authoritative): `project-handbook/status/evidence/TASK-004/legacy-federation-subgraphs-yaml.txt`

**Option A — Harvester introspects running subgraphs; codegen pulls schemas directly from Cosmo**
- **Pros:**
  - Matches `ADR-0021` intent: harvester runs inside the v2 network, reads live subgraphs via `routing_url`, and publishes what is actually served.
  - Keeps mirrors honest: after a successful publish/check, the SDL mirrors can be updated from the same “published” SDL (or a Cosmo-fetched equivalent), reducing drift between runtime and mirror.
  - Aligns with `ADR-0019`: codegen pulls schema inputs from Cosmo (not local SDL files), so generated types match what composes and what Router serves.
  - Encourages a single dependency model: local dev and CI both require a healthy Cosmo control plane (already a baseline requirement per `ADR-0015`).
  - Harvester output can be made deterministic without committing raw SDL to evidence: stable JSON shape, stable ordering, and atomic file updates.
- **Cons:**
  - Requires subgraphs to be running and reachable from the harvester at publish time (publish cannot run “in isolation” from the stack).
  - If a subgraph disables introspection intentionally, harvester must switch to a contract SDL fallback per subgraph (hybrid behavior adds complexity).
  - Debugging can involve two moving parts (subgraph runtime + Cosmo) unless a local “dump SDL” mode exists.
- **Cascading implications:**
  - Harvester needs a stable inventory source for subgraphs and schema mirror writepoints:
    - inventory: `v2/infra/compose/graphql/subgraphs.yaml` (evidence: `project-handbook/status/evidence/TASK-004/subgraphs-yaml.txt`)
    - mirror writepoints: `v2/infra/compose/graphql/subgraphs/*/schema.graphql` (evidence: `project-handbook/status/evidence/TASK-004/subgraphs-schema-files.txt`)
  - Publish sequencing becomes an explicit gate:
    - For each subgraph: gather SDL → `wgc subgraph publish ...` → `wgc subgraph check ...`
    - Only after all subgraphs pass: update mirrors atomically and (optionally) trigger supergraph sync (see `DR-0005`).
  - Codegen wiring must be Cosmo-backed and run after publish/check:
    - fetch schema from Cosmo (e.g., `wgc federated-graph fetch-schema`) → run GraphQL Codegen → run TypeScript typecheck.
  - Legacy alignment: the legacy schema harvester already follows this pattern (introspect → fallback contract → local composition preflight → publish). The main deltas for v2 are:
    - adopt the v2 inventory source (`v2/infra/compose/graphql/subgraphs.yaml` vs legacy `federation/subgraphs.yaml`),
    - add Cosmo-side check gating (`wgc subgraph check` or equivalent API) in addition to local composition preflight,
    - add mirror updates (atomic writes) after successful publish/check.
- **Risks:**
  - Publishing can become flaky if subgraphs are slow to start or intermittently unreachable; mitigate by adding a warmup/wait step (similar to `v2/scripts/v2-smoke.sh`) and by producing a report that clearly isolates which subgraph failed and why.
  - If mirrors are written non-atomically, consumers (humans, tooling, or future automation) may see partial writes; mitigate with temp file + atomic rename and “never delete last-known-good” behavior.
  - Introspection output can differ across environments if runtime config changes; mitigate by keeping publish to a single well-defined environment (e.g., `dev` namespace) and capturing `COSMO_VCS_*` metadata in the report when used in CI.
- **Unlocks:**
  - A single canonical publish entrypoint becomes the system of record for schema changes.
  - Unblocks deterministic CI ordering: publish/check → codegen → typecheck.
- **Quick wins / low-hanging fruit:**
  - Implement harvester as a CLI-first container that:
    - reads `subgraphs.yaml`,
    - introspects each routing URL,
    - publishes + checks via `wgc`,
    - writes a sanitized JSON report to a file,
    - and only then updates mirrors via atomic writes.

**Option B — Harvester uses repo contract SDL (or hybrid); codegen reads mirrors that are derived from Cosmo**
- **Pros:**
  - Publish can run without standing up all subgraphs (CI-friendly): schemas come from committed contract SDL (or generated SDL) rather than live introspection.
  - If mirrors are derived from Cosmo (written only after successful publish/check), codegen can use those mirrors as inputs while still tracing provenance back to Cosmo.
  - Encourages schema-as-contract: forces explicit schema evolution and review in repo.
- **Cons:**
  - Conflicts with the spirit of `ADR-0021` if taken “contract-first”: live services can drift from committed SDL and the harvester would publish something that the subgraph might not actually serve.
  - Increases process burden: every subgraph implementation must ensure contract SDL stays in sync with runtime behavior (otherwise publish/check success can mask runtime mismatches).
  - “Codegen reads mirrors” can drift if mirrors are stale or a developer skips publish/check; requires guardrails in CI (and potentially local preflight checks) to be safe.
- **Cascading implications:**
  - Requires a clear contract for who/what updates contract SDL:
    - manual edits (discouraged), or
    - a “generate SDL” job per subgraph (adds tooling), or
    - a hybrid of introspection (to generate SDL) + file-based publish (collapses toward Option A).
  - Requires strict CI guardrails:
    - publish/check must run in CI and be the only producer of mirror updates,
    - codegen must fail if mirrors are missing/stale (e.g., compare expected hash/metadata).
- **Risks:**
  - False confidence: composition can pass with a schema that does not reflect runtime.
  - Humans editing mirror SDL files as if they are authoritative, reintroducing drift.
  - Additional “staleness” failure modes for codegen (harder local ergonomics without a robust refresh mechanism).
- **Unlocks:**
  - Potentially lighter CI/automation if we later formalize contract-SDL generation and treat it as the source-of-truth for schema evolution.
- **Quick wins / low-hanging fruit:**
  - Keep the system aligned with current v2 structure by treating existing `v2/infra/compose/graphql/subgraphs/*/schema.graphql` as “contract SDL inputs”, and add a CI-only publish/check job; (but this requires a deliberate schema maintenance strategy for each subgraph).
  - Legacy alignment note: the legacy repo does keep contract SDL files (`federation/contracts/*.graphql`), but uses them as a fallback only when live SDL fetch fails (it does not treat them as authoritative).

**Recommendation**
- **Recommended:** Option A — Harvester introspects running subgraphs; codegen pulls schemas directly from Cosmo
- **Rationale:** This is the most consistent choice with existing accepted ADRs and with the legacy implementation: `ADR-0021` supports introspection as primary (contract SDL only as fallback), `ADR-0019` requires codegen to source schema inputs from Cosmo, and the legacy schema-harvester already implements “Option A with fallback” (plus a local composition preflight) before publishing to Cosmo. Option B is viable only if we invest in a strict contract-SDL maintenance workflow and add additional guardrails, which is unnecessary for v0.5.0’s goals.

**Follow-up tasks (explicit)**
- `TASK-004` (research-discovery): complete this DR and update execution-ready docs for harvester + codegen.
- After operator/user approval (keep this DR `Proposed` until then):
  - Create an execution task to implement the harvester entrypoint (CLI-first) with:
    - `subgraphs.yaml` inventory parsing,
    - SDL acquisition (introspection with per-subgraph fallback to file),
    - `wgc subgraph publish` + `wgc subgraph check` sequencing,
    - deterministic sanitized JSON report output,
    - atomic mirror updates under `v2/infra/compose/graphql/subgraphs/*/schema.graphql`.
  - Create an execution task to implement canonical codegen wiring with:
    - `wgc federated-graph fetch-schema` (Cosmo-backed schema fetch),
    - GraphQL Codegen config + generated output conventions,
    - CI ordering: publish/check → codegen → typecheck (and “no drift” enforcement).

**Operator/user approval request**
- Approved: **Option A** — Harvester introspects running subgraphs; codegen pulls schemas directly from Cosmo.
- Approved by: @spenser (2026-01-10)
