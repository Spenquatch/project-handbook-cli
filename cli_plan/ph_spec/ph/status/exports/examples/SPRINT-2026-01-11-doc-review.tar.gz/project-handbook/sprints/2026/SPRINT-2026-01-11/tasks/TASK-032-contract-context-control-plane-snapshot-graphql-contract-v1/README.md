---
title: Task TASK-032 - Contract: Context control-plane snapshot GraphQL contract (v1)
type: task
date: 2026-01-11
task_id: TASK-032
feature: v2_context-control-plane-schema
session: task-execution
tags: [task, v2_context-control-plane-schema]
links: [../../../../../features/v2_context-control-plane-schema/overview.md]
---

# Task TASK-032: Contract: Context control-plane snapshot GraphQL contract (v1)

## Overview
- **Feature**: [v2_context-control-plane-schema](../../../../../features/v2_context-control-plane-schema/overview.md)
- **Decision**: [FDR-v2_context-control-plane-schema-0001](../../../../../features/v2_context-control-plane-schema/fdr/0001-context-control-plane-snapshot-contract.md)
- **Story Points**: 2
- **Owner**: @spenser
- **Lane**: `context/control-plane`
- **Session**: `task-execution`

## Agent Navigation Rules
1. **Start work**: `pnpm -C project-handbook make -- task-status id=TASK-032 status=doing`
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: `pnpm -C project-handbook make -- task-status id=TASK-032 status=review`

## Context & Background
This task updates the **Project Handbook contract** for the Context subgraph to include the **v1 control-plane snapshot
query and types** defined in
[FDR-v2_context-control-plane-schema-0001](../../../../../features/v2_context-control-plane-schema/fdr/0001-context-control-plane-snapshot-contract.md).

This is an execution task for documentation/contracts only:
- In scope: `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md`
- Out of scope: any `v2/` product code changes

## Quick Start
```bash
pnpm -C project-handbook make -- task-status id=TASK-032 status=doing
cd project-handbook/sprints/current/tasks/TASK-032-contract-context-control-plane-snapshot-graphql-contract-v1/

# Follow implementation
cat steps.md              # Read implementation steps
cat commands.md           # Copy-paste commands
cat validation.md         # Validation approach
```

## Dependencies
Hard dependencies (must be `done` before execution):
- `TASK-029` — produced the accepted decision and migration posture that this contract must reflect.

Downstream tasks depend on this contract being explicit and stable:
- `TASK-035` (implements the snapshot query + types)
- `TASK-036` (adds a smoke probe for the snapshot query)
- `TASK-040` / `TASK-041` (extend the v1 snapshot contract additively)

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.

## Evidence
All evidence for this task must be captured under `project-handbook/status/evidence/TASK-032/` (see `validation.md`).
