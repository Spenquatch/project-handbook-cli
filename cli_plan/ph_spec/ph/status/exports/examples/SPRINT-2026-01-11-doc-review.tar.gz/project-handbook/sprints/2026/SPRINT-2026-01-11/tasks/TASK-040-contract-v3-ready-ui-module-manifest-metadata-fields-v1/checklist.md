---
title: Contract: v3-ready UI module manifest metadata fields (v1) - Completion Checklist
type: checklist
date: 2026-01-12
task_id: TASK-040
tags: [checklist]
links: []
---

# Completion Checklist: Contract: v3-ready UI module manifest metadata fields (v1)

## Pre-Work
- [ ] Confirm `TASK-032` and `TASK-033` are `done`
- [ ] Read `project-handbook/adr/0033-module-registry-alignment-with-v3-roadmap.md`
- [ ] Confirm v1 surfaces exist in contract docs (`ContextUiModuleManifest`, `ui_module_manifests`)

## During Execution
- [ ] Create `project-handbook/status/evidence/TASK-040/index.md`
- [ ] Update `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md` (additive v1 fields on `ContextUiModuleManifest`)
- [ ] Update `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` (nullable storage fields on `ui_module_manifests`; no secrets)
- [ ] Capture “before” and “after” excerpts + diffs (see `commands.md`)

## Before Review
- [ ] Run `pnpm -C project-handbook make -- validate`
- [ ] Ensure `validation.md` lists evidence files and pass/fail criteria
- [ ] Set status to `review` via `pnpm -C project-handbook make -- task-status id=TASK-040 status=review`

## After Completion
- [ ] Set status to `done` via `pnpm -C project-handbook make -- task-status id=TASK-040 status=done`
