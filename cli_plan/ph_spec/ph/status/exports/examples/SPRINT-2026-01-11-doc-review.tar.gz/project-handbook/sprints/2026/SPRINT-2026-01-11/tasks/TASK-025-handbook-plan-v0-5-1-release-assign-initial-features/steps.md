---
title: Handbook: Plan v0.5.1 release + assign initial features - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-025
tags: [implementation]
links: []
---

# Implementation Steps: Handbook: Plan v0.5.1 release + assign initial features

## Overview
This is a `session=task-execution` handbook task. The deliverable is a new release plan (`v0.5.1`) with initial feature assignments, plus evidence.

## Prerequisites
- `TASK-024` is `done`.

## Step 1 — Create the release plan (automation)
1. Create evidence directory `project-handbook/status/evidence/TASK-025/`.
2. Run `pnpm -C project-handbook make -- release-plan version=next bump=patch sprints=3 start=SPRINT-2026-01-16`.
3. Confirm the new release directory `project-handbook/releases/v0.5.1/` exists and `project-handbook/releases/current` points to it.

Evidence to capture:
- `project-handbook/status/evidence/TASK-025/release-plan.txt`

## Step 2 — Assign initial features
1. Add the initial feature set to the new release:
   - `v2.1_ui-module-registry-discovery` (`critical=true`)
   - `v2_context-control-plane-schema` (`critical=true`)
   - `v2.1_ui-module-registry-execution`
   - `v2_context-knowledge-network`
2. Capture `release-status` output.

Evidence to capture:
- `project-handbook/status/evidence/TASK-025/release-status.txt`

## Step 3 — Validate + move to review
1. Run `pnpm -C project-handbook make -- validate`.
2. Update `validation.md` and `checklist.md` with the evidence file list.
3. Set task status to `review`.

Notes:
- This task should not attempt to change feature scope; it only creates the release scaffold and assignments.
