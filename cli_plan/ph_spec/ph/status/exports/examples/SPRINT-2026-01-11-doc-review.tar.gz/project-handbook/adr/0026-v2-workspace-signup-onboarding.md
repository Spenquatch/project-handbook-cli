---
id: ADR-0026
title: v2 Workspace Signup Onboarding (Keycloak Registration + Post-Auth Workspace Create)
type: adr
status: accepted
date: 2026-01-07
tags: [tribuence-mini, v2, auth, keycloak, onboarding, workspace]
links:
  - ../features/v2_workspace-signup-onboarding/overview.md
  - ../features/v2_context-glue-integrations/overview.md
  - ../features/v2_capability-manifests-and-toggles/overview.md
  - ../features/v2_ui-dev-harness-and-module-boundaries/overview.md
---

# Context

Tribuence needs a deterministic “new user → new workspace” onboarding flow so developers and future operators can create
isolated workspaces without manual GraphQL calls. v2 already uses Keycloak and an auth-gated UI; onboarding must keep
that security posture and must trigger Context-owned capability provisioning.

# Decision

## 1) Signup uses Keycloak self-registration and v2 remains auth-gated

Users self-register in Keycloak and then authenticate into the v2 UI. Tribuence does not build a separate credentials
store and does not allow unauthenticated workspace creation.

## 2) Workspace creation happens via a required post-auth onboarding form

When a user is authenticated but has no selected workspace, the UI routes to a required onboarding form that:
- collects `workspace slug` and `workspace name`,
- calls Context `workspaceCreate`,
- selects the created workspace for the session,
- redirects to the existing landing harness.

## 3) Workspace creation triggers Context provisioning

On workspace creation, Context:
- persists the workspace record,
- applies capability manifests for the workspace,
- enqueues provisioning jobs for enabled capabilities (Twenty + AnythingLLM first),
- surfaces provisioning state via the Context capability surface.

# Consequences

## Positive
- Deterministic onboarding path that stays within the auth-gated posture.
- Workspace creation and provisioning are centralized in Context (single source of truth).
- Landing harness remains the canonical manual + E2E validation surface after onboarding.

## Tradeoffs
- Requires Keycloak realm bootstrap/configuration for self-registration to be deterministic across environments.

# Rollout / Acceptance

- Keycloak self-registration is enabled for the v2 realm and a new user can sign up and log in.
- If no workspace is selected, the UI forces onboarding and creates a Context workspace.
- Workspace creation triggers Context provisioning and capability state is visible via Context APIs.
- Playwright E2E validates the onboarding flow and ends in the landing harness.
