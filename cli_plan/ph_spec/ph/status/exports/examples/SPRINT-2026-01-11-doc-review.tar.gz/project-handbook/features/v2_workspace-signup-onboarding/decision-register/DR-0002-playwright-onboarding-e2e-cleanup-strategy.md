---
title: DR-0002 — Onboarding E2E Cleanup Strategy (Playwright)
type: decision-register
date: 2026-01-08
tags: [decision-register, playwright, onboarding, e2e]
links:
  - ../overview.md
  - ../../../../adr/0026-v2-workspace-signup-onboarding.md
  - ../../../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
---

# Decision Register Entry

### DR-0002 — Onboarding E2E Cleanup Strategy (Playwright)

**Decision owner(s):** @spenser  
**Date:** 2026-01-08  
**Status:** Accepted  
**Related docs:** `ADR-0026`, `ADR-0024`, `ADR-0028`, `FDR-v2_workspace-signup-onboarding-0002`, `project-handbook/features/v2_workspace-signup-onboarding/testing/PLAYWRIGHT_ONBOARDING_E2E.md`

**Problem / Context**
- This DR ID was reserved during sprint planning; `TASK-005` completes it and it requires explicit operator/user approval before being marked `Accepted`.
- Onboarding E2E creates state:
  - Keycloak user (auth identity),
  - Context workspace (tenant-scoped state; potentially triggers provisioning side-effects).
- A required launch gate (`ADR-0028`) needs a low-flake E2E strategy that is:
  - deterministic across re-runs,
  - safe (does not delete non-E2E resources),
  - fast enough to be run frequently (local + CI).

**Evidence (TASK-005)**
- `project-handbook/status/evidence/TASK-005/data-testid-scan.txt` (current stable selector surface in `v2/apps/tribuence-mini`)
- `project-handbook/status/evidence/TASK-005/playwright-surface.txt` (current Playwright config + existing `v2/apps/tribuence-mini/e2e/` baseline)

**Option A — API-driven teardown (delete user + workspace)**
- **Pros:**
  - Fast per-run cleanup (no docker restart loop) and compatible with `workers: 1` + serial gating.
  - Deterministic reruns: delete only resources created by the test (identified by test-owned IDs).
  - Scales to CI without requiring privileged “reset the world” permissions.
  - Keeps the “happy path” E2E close to real behavior (UI creates workspace; cleanup is post-test only).
- **Cons:**
  - Requires implementing deletion wiring that does not exist yet for Context workspaces (Context currently supports `workspaces` + `workspaceCreate`, but no delete mutation).
  - Requires careful auth posture to avoid introducing a dangerous delete surface.
  - If onboarding triggers external provisioning side-effects, deleting only Context state may leave provider artifacts (acceptable for local/dev; CI may require additional teardown later).
- **Cascading implications:**
  - Add Context deletion primitive (recommended minimal shape):
    - `workspaceDelete(id: ID!): ContextWorkspace!` in `v2/services/context/index.js` schema + resolver.
    - Update schema snapshots used for composition (`v2/infra/compose/graphql/subgraphs/tribuence-context/schema.graphql` and any generated supergraph snapshot workflow).
  - Add Playwright cleanup hooks:
    - Keycloak: extend `v2/apps/tribuence-mini/e2e/helpers/keycloak.ts` with `deleteUserByUsername(username)` using the same admin token mechanism already used for provisioning.
    - Context: add `v2/apps/tribuence-mini/e2e/helpers/context.ts` to delete the created workspace by `workspaceId` (read from the `tribuence-workspace-id` cookie) or by slug via `workspaces` query + match.
  - Gate runner integration (`ADR-0028`): add a launch gate step that runs the onboarding E2E and writes Playwright artifacts to `$EVIDENCE_DIR/` (see `project-handbook/features/v2_launch/implementation/GATES.md`).
- **Risks:**
  - **Accidental deletion:** mitigate by deleting only by test-owned identifiers:
    - workspaces whose slug starts with a reserved `e2e-` prefix and/or whose id matches the cookie set by the test,
    - Keycloak users with `username` prefix `e2e-`.
  - **Security surface:** mitigate by restricting delete mutations/endpoints (e.g., require an internal header or gate by env like `ALLOW_E2E_MUTATIONS=true` in local/CI only).
  - **Cleanup failure = cascading flake:** mitigate by making cleanup best-effort but loud (log a single-line warning with identifiers, do not mask test failures).
- **Unlocks:**
  - Makes onboarding E2E a credible required gate (`ADR-0028`) without turning “reset v2” into the default workflow.
  - Enables a future “sweep old e2e artifacts” job (prefix-based delete) without changing test semantics.
- **Quick wins / low-hanging fruit:**
  - Implement Keycloak user deletion in `v2/apps/tribuence-mini/e2e/helpers/keycloak.ts` (the admin token + create user path already exists).
  - Add Context `workspaceDelete` mutation in `v2/services/context/index.js` backed by `delete from context_workspaces where tenant_id = $1 and id = $2 returning ...`.

**Option B — Reset-by-recreate (wipe local state between runs)**
- **Pros:**
  - Lowest product-code surface area: no new deletion APIs required.
  - Fully resets state, including external system artifacts (Context DB, Keycloak, provider services) as long as volumes are wiped.
  - Simple mental model for local debugging when everything is broken.
- **Cons:**
  - Expensive and slow for CI; risks exceeding the explicit acceptance constraint (`<= 5 minutes`) for a single reset command.
  - Can be flaky: docker health timing, network/port reuse, and boot ordering become part of the test.
  - Encourages a workflow where E2E stability depends on global resets rather than deterministic cleanup.
- **Cascading implications:**
  - Requires a single deterministic operator command (e.g. `make -C v2 v2-reset`) that:
    - wipes volumes/state safely,
    - boots v2 back to healthy,
    - is measurable and consistently below the time budget.
  - Gate runner would need privileged access to run resets (often disallowed in CI runners).
- **Risks:**
  - **Time budget violation:** if resets exceed 5 minutes, Option B is disqualified by task acceptance criteria.
  - **False greens:** a reset can mask real cleanup bugs (test passes only after nuking state).
  - **Developer friction:** E2E becomes “too slow to run” and will rot.
- **Unlocks:**
  - Provides a fallback escape hatch when deletion primitives are missing or misbehaving.
- **Quick wins / low-hanging fruit:**
  - Measure the true reset runtime with `time -p` and capture evidence; only proceed if consistently under 5 minutes.

**Recommendation**
- **Recommended:** Option A — API-driven teardown (delete user + workspace)
- **Rationale:** Option A aligns with `ADR-0028` (fast, repeatable gates) and avoids making “reset the world” part of the default workflow. Option B remains a fallback for local debugging, but is too slow/fragile to rely on for a required launch gate unless proven under the 5-minute budget.

**Follow-up tasks (explicit)**
- After operator approval of Option A:
  - Create an ADR/FDR that commits to the teardown surface and its security posture (env gating / internal header).
  - Execution task: add Context `workspaceDelete` (and any guardrails) in `v2/services/context/index.js` + schema snapshot updates.
  - Execution task: extend `v2/apps/tribuence-mini/e2e/helpers/keycloak.ts` with `deleteUserByUsername` and add a shared e2e cleanup helper.
  - Execution task: implement onboarding E2E spec under `v2/apps/tribuence-mini/e2e/` per `project-handbook/features/v2_workspace-signup-onboarding/testing/PLAYWRIGHT_ONBOARDING_E2E.md`.
  - Integration task: wire the E2E into `make -C v2 v2-launch-gates` with evidence capture under `$EVIDENCE_DIR/` (see `project-handbook/features/v2_launch/implementation/GATES.md`).

**Operator approval**
- Approved: Option A (API-driven teardown) on 2026-01-09.
