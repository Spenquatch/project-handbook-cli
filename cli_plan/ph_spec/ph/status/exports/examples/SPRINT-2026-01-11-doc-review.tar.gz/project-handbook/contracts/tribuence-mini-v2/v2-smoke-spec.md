---
title: Tribuence Mini v2 Smoke Test Spec
type: testing
date: 2025-12-30
tags: [contracts, testing, smoke, tribuence-mini-v2]
links:
  - ../../features/tribuence-mini-v2/testing/TESTING.md
  - ./supergraph-router.md
  - ./context-subgraph.md
  - ../../../v2/ARCHITECTURE.md
---

# Spec: `make v2-smoke` (v2)

## Purpose
Define the concrete probes that `make v2-smoke` (or `v2/scripts/v2-smoke.sh`) must run to validate:
- compose bring-up is functional,
- Router responds and (when configured) federates Context,
- Traefik does not expose internal services.

## Preconditions
- `make v2-up` has been run and reports healthy services.

## Release Gate (v0.3.0)
For the `v0.3.0` release gate, smoke must pass **twice consecutively** without changing the running stack between runs.

Evidence guidance (handbook):
- Capture each `make v2-smoke` output to `project-handbook/status/evidence/TASK-002/` as timestamped logs (exact filenames are flexible).
- If a run fails, capture the failure output and file a backlog issue with a minimal repro (see `sprints/current/tasks/TASK-002-*/steps.md`).

## Configuration (optional)
`make v2-smoke` / `v2/scripts/v2-smoke.sh` may be parameterized by env vars so execution can tighten requirements over time without changing the spec:

- `V2_SMOKE_MODE` (default: `router`)
  - `infra`: only validates Traefik isolation posture and prints that Router probes are skipped.
  - `router`: validates Router liveness + join__Graph detection + isolation; graph-conditional probes run when graphs are present.
  - `full`: same as `router` but expects both `app.local` and `router.local` to be fully functional (UI reachable; Router reachable).
- `V2_SMOKE_TENANT_ID` (default: `tribuence`)
- `V2_SMOKE_REQUIRE_GRAPHS` (default: empty)
  - Comma-separated list of `join__Graph` enum values that must be present in the composed supergraph SDL (example: `TWENTY,TRIBUENCE_CONTEXT`).
  - If a required graph is missing, the smoke run must fail with a clear message.
- `V2_SMOKE_REQUIRE_ANYTHINGLLM_UPLOAD` (default: `false`)
  - When `true`, the AnythingLLM upload probe must run (and pass) once `ANYTHINGLLM` is present.
- `V2_SMOKE_REQUIRE_ANYTHINGLLM_CHAT` (default: `false`)
  - When `true`, the AnythingLLM chat probe must run (and pass) once `ANYTHINGLLM` is present.
- `V2_SMOKE_REQUIRE_TWENTY_AUTH` (default: `false`)
  - When `true`, the TWENTY auth probe must run (and pass) once `TWENTY` is present.
  - When `true` and `V2_SMOKE_AUTHORIZATION` is unset/empty, the smoke run must fail with a clear message (no token printing).

## Probes

### 0) Detect federated graphs (via committed supergraph snapshot)

To make probes incremental, smoke tests may detect which subgraphs are present by reading the committed supergraph snapshot and inspecting `enum join__Graph`.

In Apollo Router, the `join__*` types are **execution-only** details and are not exposed via normal GraphQL introspection. Instead, v2 local/dev treats the committed supergraph snapshot as the source of truth for “which graphs are present”.

Dependencies:
- The supergraph snapshot must be committed and current:
  - `v2/infra/compose/graphql/supergraph-local.graphql`
- Composition workflow:
  - `./federation-composition.md`

```bash
# Print the joined graphs present in the composed supergraph snapshot
rg -n '^\\s*[A-Z_]+\\s+@join__graph\\(' v2/infra/compose/graphql/supergraph-local.graphql
```

Graph names and expected `join__Graph` values are defined in `contracts/tribuence-mini-v2/supergraph-router.md`.

Error handling:
- If this probe fails and `V2_SMOKE_REQUIRE_GRAPHS` is set, the smoke run must fail with a clear message (“cannot detect graphs; supergraph-local.graphql missing/unreadable”).
- If this probe fails and `V2_SMOKE_REQUIRE_GRAPHS` is empty, smoke may continue but must print a warning and skip all graph-conditional sections.

### 1) Traefik surfaces

- UI host responds (only required in `V2_SMOKE_MODE=full`):
  - `http://app.local/` returns `200` (or `302` if auth enabled).
- Router host responds (required in `V2_SMOKE_MODE=router|full`):
  - `http://router.local/` returns `200` for a valid GraphQL POST.
- (Optional) Keycloak host responds (only when auth is enabled):
  - `http://keycloak.local/` returns `200`/`302`.

### 2) Router GraphQL liveness

Skip this section when `V2_SMOKE_MODE=infra`.

```bash
curl -sS --resolve "router.local:80:127.0.0.1" \
  -H 'content-type: application/json' \
  --data '{"query":"{ __typename }"}' \
  "http://router.local/" | jq -e '.data.__typename'
```

### 3) Federation presence (via supergraph snapshot)

If `V2_SMOKE_REQUIRE_GRAPHS` is set, verify the required `join__Graph` enum values are present in the composed SDL; otherwise, print the detected graphs for operator visibility.

Skip this section when `V2_SMOKE_MODE=infra`.

Minimum recommended checks over time:
- After `TASK-013`: `TWENTY` is present
- After `TASK-016`: `TRIBUENCE_CONTEXT` is present
- After AnythingLLM wrapper wiring: `ANYTHINGLLM` is present

### 4) Twenty auth probe (via Router, conditional)

Run this section only when the supergraph includes `TWENTY` (detected via `join__Graph`). If it is missing:
- skip with a clear message when `V2_SMOKE_REQUIRE_GRAPHS` does not include it, and
- fail when `V2_SMOKE_REQUIRE_GRAPHS` includes it.

This probe validates:
- Router → Twenty reachability (routing URL correctness), and
- authorization propagation posture (Router forwards `authorization`).

Behavior:
- If `V2_SMOKE_AUTHORIZATION` is unset/empty:
  - skip by default, and
  - fail when `V2_SMOKE_REQUIRE_TWENTY_AUTH=true`.

Skip this section when `V2_SMOKE_MODE=infra`.

Minimal probe (authorized):
```bash
curl -sS --resolve "router.local:80:127.0.0.1" \
  -H 'content-type: application/json' \
  -H 'x-tenant-id: tribuence' \
  -H "authorization: Bearer ${TWENTY_API_KEY}" \
  --data '{"query":"{ currentWorkspace { id } }"}' \
  "http://router.local/" | jq -e '.data.currentWorkspace.id'
```

### 5) Context subgraph CRUD (via Router)

Run this section only when the supergraph includes `TRIBUENCE_CONTEXT` (detected via `join__Graph`). If it is missing:
- skip with a clear message when `V2_SMOKE_REQUIRE_GRAPHS` does not include it, and
- fail when `V2_SMOKE_REQUIRE_GRAPHS` includes it.

Skip this section when `V2_SMOKE_MODE=infra`.

#### Create workspace
```bash
curl -sS --resolve "router.local:80:127.0.0.1" \
  -H 'content-type: application/json' \
  -H 'x-tenant-id: tribuence' \
  --data '{"query":"mutation($input: WorkspaceCreateInput!){ workspaceCreate(input:$input){ id slug name } }","variables":{"input":{"slug":"demo","name":"Demo"}}}' \
  "http://router.local/" | jq -e '.data.workspaceCreate.id'
```

#### List workspaces
```bash
curl -sS --resolve "router.local:80:127.0.0.1" \
  -H 'content-type: application/json' \
  -H 'x-tenant-id: tribuence' \
  --data '{"query":"{ workspaces { id slug name } }"}' \
  "http://router.local/" | jq -e '.data.workspaces | length >= 1'
```

#### Create reference (workspace-scoped)
Use the created workspace ID as `x-workspace-id`.
```bash
WORKSPACE_ID="<from create workspace>"
curl -sS --resolve "router.local:80:127.0.0.1" \
  -H 'content-type: application/json' \
  -H 'x-tenant-id: tribuence' \
  -H "x-workspace-id: ${WORKSPACE_ID}" \
  --data '{"query":"mutation($input: ReferenceCreateInput!){ referenceCreate(input:$input){ id workspaceId system entityType entityId } }","variables":{"input":{"system":"TWENTY","entityType":"Person","entityId":"example"}}}' \
  "http://router.local/" | jq -e '.data.referenceCreate.id'
```

### 6) Isolation checks (Traefik must not expose internals)

The following should return `404` from Traefik:
```bash
curl -sS -o /dev/null -w '%{http_code}\n' --resolve "twenty.local:80:127.0.0.1" "http://twenty.local/" | grep -qx '404'
curl -sS -o /dev/null -w '%{http_code}\n' --resolve "anythingllm.local:80:127.0.0.1" "http://anythingllm.local/" | grep -qx '404'
```

### 7) AnythingLLM probes (when subgraph is available)

If the v2 supergraph includes the AnythingLLM wrapper subgraph (`ANYTHINGLLM` present in `join__Graph`; see `anythingllm-subgraph.md`), `make v2-smoke` must run the following probes; otherwise it must **skip** them with a clear “subgraph not configured” message (unless required via `V2_SMOKE_REQUIRE_GRAPHS`).

Skip this section when `V2_SMOKE_MODE=infra`.

#### List AnythingLLM workspaces (via Router)
```bash
curl -sS --resolve "router.local:80:127.0.0.1" \
  -H 'content-type: application/json' \
  -H 'x-tenant-id: tribuence' \
  --data '{"query":"{ anythingWorkspaces { slug name } }"}' \
  "http://router.local/" | jq -e '.data.anythingWorkspaces'
```

#### Ensure AnythingLLM workspace (via Router)
Use a deterministic desired workspace slug for local/dev smoke runs, but treat the returned slug as canonical.
```bash
WS_SLUG_DESIRED="demo"
REQ=$(jq -n --arg ws "$WS_SLUG_DESIRED" '{query:"mutation($input: AnythingWorkspaceEnsureInput!){ anythingWorkspaceEnsure(input:$input){ slug name } }",variables:{input:{slug:$ws,name:"Demo"}}}')
WS_SLUG="$(curl -sS --resolve "router.local:80:127.0.0.1" \
  -H 'content-type: application/json' \
  -H 'x-tenant-id: tribuence' \
  --data "$REQ" \
  "http://router.local/" | jq -er '.data.anythingWorkspaceEnsure.slug')"
echo "AnythingLLM workspace slug: ${WS_SLUG}"
```

#### List AnythingLLM documents (via Router)
```bash
curl -sS --resolve "router.local:80:127.0.0.1" \
  -H 'content-type: application/json' \
  -H 'x-tenant-id: tribuence' \
  --data '{"query":"{ anythingDocuments { id title } }"}' \
  "http://router.local/" | jq -e '.data.anythingDocuments'
```

#### Upload a small document (via Router, optional)
Run this probe when `V2_SMOKE_REQUIRE_ANYTHINGLLM_UPLOAD=true` (and only when `ANYTHINGLLM` is present).

Contract reference:
- `anythingllm-subgraph.md` (base64 upload)

```bash
CONTENT_BASE64="$(printf 'v2-smoke upload\n' | base64 | tr -d '\n')"
REQ=$(jq -n --arg ws "$WS_SLUG" --arg b64 "$CONTENT_BASE64" '{
  query: "mutation($input: AnythingDocumentUploadInput!){ anythingDocumentUpload(input:$input){ ok } }",
  variables: { input: {
    workspaceSlug: $ws,
    filename: "v2-smoke.txt",
    mimeType: "text/plain",
    contentBase64: $b64,
    metadata: { source: "v2-smoke" }
  } }
}')
curl -sS --resolve "router.local:80:127.0.0.1" \
  -H 'content-type: application/json' \
  -H 'x-tenant-id: tribuence' \
  --data "$REQ" \
  "http://router.local/" | jq -e '.data.anythingDocumentUpload.ok == true'
```

#### Chat probe (via Router, optional)
Run this probe when `V2_SMOKE_REQUIRE_ANYTHINGLLM_CHAT=true` (and only when `ANYTHINGLLM` is present).

Note: this requires AnythingLLM to have a valid provider configuration (e.g. `OPENAI_API_KEY`) and may be staged later than “list” operations.

```bash
REQ=$(jq -n --arg ws "$WS_SLUG" '{query:"mutation($input: AnythingChatInput!){ anythingChat(input:$input){ textResponse error } }",variables:{input:{workspaceSlug:$ws,message:"hello",mode:"chat"}}}')
curl -sS --resolve "router.local:80:127.0.0.1" \
  -H 'content-type: application/json' \
  -H 'x-tenant-id: tribuence' \
  --data "$REQ" \
  "http://router.local/" | jq -e '.data.anythingChat.textResponse'
```

## Acceptance Gate Mapping
- **Compose bring-up**: validated by (1)
- **Federated GraphQL**: validated by (2) and (3)
- **Twenty via Router (optional/required)**: validated by (4) once auth is provided (or `V2_SMOKE_REQUIRE_TWENTY_AUTH=true`)
- **Context service**: validated by (5)
- **Isolation**: validated by (6)
- **AnythingLLM upload/chat (optional)**: validated by (7) when the corresponding `V2_SMOKE_REQUIRE_ANYTHINGLLM_*` flag is enabled
