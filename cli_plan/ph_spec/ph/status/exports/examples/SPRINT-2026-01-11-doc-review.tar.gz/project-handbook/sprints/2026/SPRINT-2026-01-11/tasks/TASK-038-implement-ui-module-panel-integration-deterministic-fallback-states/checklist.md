---
title: Implement: UI module panel integration + deterministic fallback states - Completion Checklist
type: checklist
date: 2026-01-11
task_id: TASK-038
tags: [checklist]
links: []
---

# Completion Checklist: Implement: UI module panel integration + deterministic fallback states

## Pre-Work
- [ ] Confirm all `depends_on` tasks are `done`
- [ ] Review `README.md`, `steps.md`, `commands.md`
- [ ] Re-read `project-handbook/features/v2.1_ui-module-registry-discovery/fdr/0002-nextjs-runtime-module-loading-strategy.md`

## During Execution
- [ ] Add a “UI Modules (registry harness)” section to `v2/apps/tribuence-mini/src/app/page.tsx`
- [ ] Fetch Context snapshot and use `uiModuleManifests` for module selection (no env/querystring selection)
- [ ] Render module-backed panels using the loader from `TASK-037`
- [ ] Render deterministic fallback states with stable reason codes (no secrets)
- [ ] Expose stable selectors for E2E:
  - [ ] `data-testid="ui-module-panel"`
  - [ ] `data-capability-id="<capabilityId>"`
  - [ ] `data-state="loaded|fallback"`
  - [ ] `data-reason-code="<REASON>"` (fallback only)

## Before Review
- [ ] Run `pnpm -C project-handbook make -- validate`
- [ ] Capture evidence under `project-handbook/status/evidence/TASK-038/` (per `validation.md`)
- [ ] Set status to `review` via `pnpm -C project-handbook make -- task-status id=TASK-038 status=review`

## After Completion
- [ ] Peer review approved and merged
- [ ] Move status to `done` via `pnpm -C project-handbook make -- task-status id=TASK-038 status=done`
