---
title: Implement: UI module origin proxy route (Option A) - Commands
type: commands
date: 2026-01-11
task_id: TASK-030
tags: [commands]
links: []
---

# Commands: Implement: UI module origin proxy route (Option A)

## Task Status Updates
```bash
pnpm -C project-handbook make -- task-status id=TASK-030 status=doing
pnpm -C project-handbook make -- task-status id=TASK-030 status=review
pnpm -C project-handbook make -- task-status id=TASK-030 status=done
```

## Required Environment (for `v2-ui` server-side S3 access)
These env vars must be present in the `v2-ui` process environment (Vault renders them into `/secrets/next.env`):
- `S3_ENDPOINT_URL`
- `S3_REGION`
- `S3_ACCESS_KEY_ID`
- `S3_SECRET_ACCESS_KEY`
- `S3_FORCE_PATH_STYLE`
- `COSMO_S3_BUCKET`

## Validation Commands
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Implementation Commands
```bash
# Add the API route + helper(s)
$EDITOR v2/apps/tribuence-mini/src/app/api/ui-modules/[moduleId]/[version]/[integritySha256]/route.ts
$EDITOR v2/apps/tribuence-mini/src/lib/ui-modules.ts
$EDITOR v2/apps/tribuence-mini/src/lib/s3.ts

# If needed: add AWS SDK client for server-side S3 fetch
pnpm -C v2/apps/tribuence-mini add @aws-sdk/client-s3

# Local checks
pnpm -C v2/apps/tribuence-mini lint
pnpm -C v2/apps/tribuence-mini typecheck
pnpm -C v2/apps/tribuence-mini test
```

## Seed a Known Module Artifact into Internal S3 (for smoke validation)
This is the minimal “publish” needed to validate the proxy route end-to-end.

```bash
EVID_DIR="project-handbook/status/evidence/TASK-030"
mkdir -p "$EVID_DIR"

# Minimal ESM payload
cat >"$EVID_DIR/index.mjs" <<'EOF'
export const hello = () => 'hello';
EOF

# Compute sha256 (hex digest)
INTEGRITY_SHA256="$(python3 - <<'PY'
import hashlib
path = "project-handbook/status/evidence/TASK-030/index.mjs"
with open(path, "rb") as f:
  print(hashlib.sha256(f.read()).hexdigest())
PY
)"
printf '%s\n' "$INTEGRITY_SHA256" | tee "$EVID_DIR/index.mjs.sha256.txt"

MODULE_ID="example"
VERSION="0.0.0"

docker compose -f v2/infra/compose/docker-compose.v2.yml run --rm \
  -e MODULE_ID="$MODULE_ID" \
  -e VERSION="$VERSION" \
  -e INTEGRITY_SHA256="$INTEGRITY_SHA256" \
  -v "$(pwd)/$EVID_DIR:/evid:ro" \
  --entrypoint /opt/healthcheck/with-env-file.sh \
  cosmo-artifact-probe \
  /secrets/artifacts.env sh -lc '
    KEY="ui-modules/${MODULE_ID}/${VERSION}/${INTEGRITY_SHA256}/index.mjs"
    echo "[INFO] uploading key=$KEY bucket=$COSMO_S3_BUCKET endpoint=$S3_ENDPOINT_URL" >&2
    aws --no-cli-pager --endpoint-url "$S3_ENDPOINT_URL" s3api put-object \
      --bucket "$COSMO_S3_BUCKET" \
      --key "$KEY" \
      --body /evid/index.mjs \
      --content-type "text/javascript; charset=utf-8" \
      >/dev/null
  '
```

## Git Integration
```bash
# Project Handbook repo: docs/task updates
git -C project-handbook status

# v2 repo: implementation work (run commits from inside the repo you change)
git -C v2 status
```

## Quick Copy-Paste
```bash
# Bring up v2 locally (if needed for manual curl validation)
make -C v2 v2-up
```
