---
id: ADR-0018
title: v2 Capability Detection Surface (Context Source of Truth)
type: adr
status: accepted
date: 2026-01-06
tags: [tribuence-mini, v2, ui, capabilities, context, gating]
links:
  - ../features/v2_capability-detection-surface/overview.md
  - ../features/v2_context-glue-integrations/overview.md
  - ../features/v2_capability-manifests-and-toggles/overview.md
---

# Context

The UI must render capability UX based on workspace-scoped configuration and integration state. Any approach that relies
on env inspection or URL banners produces false positives and makes local/dev unreliable.

# Decision

## 1) Context is the single source of truth for capabilities per workspace

Context exposes a GraphQL query that returns, for the current workspace:
- enabled capabilities,
- integration status per capability (ok/degraded/error/missing),
- setup guidance identifiers (no secrets).

## 2) The UI gates capabilities using Context data only

The UI does not infer capability readiness from:
- server env vars,
- querystring banners,
- upstream host reachability.

The UI reads Context capability state and renders deterministic gating UX.

## 3) `/api/healthz` remains a diagnostic surface, derived from the same sources

The v2 UI `/api/healthz` endpoint continues to exist for operator diagnostics, but it must reflect Context capability
state rather than acting as an ad-hoc source of truth.

# Consequences

## Positive
- One deterministic gating source for all capabilities.
- Prevents “it looks configured but isn’t” local/dev failures.
- Provides a stable surface for future Backstage/service-catalog integration.

## Tradeoffs
- Requires Context to expose a minimal “capabilities” API and keep it accurate.

# Rollout / Acceptance

- For a selected workspace, the UI shows capabilities based on Context-provided state only.
- Capability enable/disable and provisioning status are visible via Context GraphQL.
- `/api/healthz` reports capability readiness without contradicting Context.
