---
id: ADR-0012
title: Handbook Reporting + Continuity Artifacts (Date Sprints + Valid Index)
type: adr
status: draft
date: 2026-01-03
supersedes: null
superseded_by: null
tags: [handbook, reporting, continuity, sprints]
links:
  - ../backlog/bugs/BUG-P2-20260102-1806/README.md
  - ../backlog/wildcards/WILD-P2-20260101-2118/README.md
---

# Context

Two handbook automation gaps are blocking reliable planning/continuity in this repo:

1) **`make feature-summary` is effectively broken**
- It prints only the header in this repo.
- Root causes:
  - `process/automation/feature_status_updater.py` does not traverse `sprints/archive/<year>/SPRINT-*/tasks`.
  - “Current sprint” is derived as ISO-week (`SPRINT-YYYY-W##`), while this repo uses date-based sprint IDs (`SPRINT-YYYY-MM-DD`) with `sprints/current` as the canonical pointer.

2) **Session-end continuity artifacts are missing/stale**
- `process/sessions/session_end/session_end_index.json` contains records whose `summary_path` / `prompt_path` do not exist on disk.
- `process/sessions/logs/latest_summary.md` reports that no recaps have been generated for this repo yet.

# Decision

## Reporting (feature summary + feature status)

- The canonical “current sprint” in this repo is the directory pointed to by `project-handbook/sprints/current`.
- Feature reporting must collect tasks from:
  - active sprints: `project-handbook/sprints/<year>/SPRINT-*/tasks/`
  - archived sprints: `project-handbook/sprints/archive/<year>/SPRINT-*/tasks/`
- `make feature-summary` must emit actionable output (at minimum: per-feature progress and current sprint task list).

## Continuity (session-end recaps + index)

- Session-end recaps must be written under:
  - `process/sessions/session_end/<workstream>/`
- `process/sessions/session_end/session_end_index.json` must only reference files that exist on disk.
- Handbook validation must detect and flag stale/missing session-end paths early (before they block the “continuity checkpoint” workflow).

# Consequences

## Positive
- Planning and daily status can rely on accurate feature/sprint reporting.
- Continuity workflow can always load the newest recap and the associated Codex kickoff prompt.

## Tradeoffs
- Reporting must support date-based sprints (and avoid assuming ISO-week IDs).
- Validation becomes stricter (stale index records become a hard failure or prominent warning).

# Rollout

1. Fix `process/automation/feature_status_updater.py` to:
   - traverse archived tasks
   - derive the current sprint from `sprints/current`
2. Fix or regenerate session-end recap storage so:
   - recap files exist under `process/sessions/session_end/<workstream>/`
   - index is consistent with on-disk artifacts
3. Add validation coverage so future drift is caught automatically.

# Acceptance Criteria

- `pnpm make -- feature-summary` prints per-feature progress and includes current sprint tasks for date-based sprint IDs.
- `process/sessions/session_end/session_end_index.json` references only paths that exist.
- Handbook validation reports a clear error when session-end index entries are stale/missing.
