---
title: Task TASK-038 - Implement: UI module panel integration + deterministic fallback states
type: task
date: 2026-01-11
task_id: TASK-038
feature: v2.1_ui-module-registry-discovery
session: task-execution
tags: [task, v2.1_ui-module-registry-discovery]
links: [../../../features/v2.1_ui-module-registry-discovery/overview.md]
---

# Task TASK-038: Implement: UI module panel integration + deterministic fallback states

## Overview
**Feature**: [v2.1_ui-module-registry-discovery](../../../features/v2.1_ui-module-registry-discovery/overview.md)
**Decision**: [FDR-v2_1_ui-module-registry-discovery-0002](../../../../../features/v2.1_ui-module-registry-discovery/fdr/0002-nextjs-runtime-module-loading-strategy.md)
**Story Points**: 3
**Owner**: @spenser
**Lane**: module-registry/runtime
**Session**: `task-execution`

## Goal (what you’re building)
Add a **module-backed panel section** to the v2 landing harness (`ADR-0024`) that:
- reads the workspace-scoped module selection from Context (`ADR-0025`, snapshot contract per `TASK-035`),
- loads a module via the runtime loader (`TASK-037`, `FDR-...-0002`),
- renders deterministic fallback UI for loader failures (stable reason codes; no secrets),
- stays panel-scoped (the rest of the shell continues rendering).

## Agent Navigation Rules
1. **Start work**: Update `task.yaml` status to "doing"
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: Set to "review" when ready for review

## Context & Background
This task implements the [FDR-v2_1_ui-module-registry-discovery-0002](../../../../../features/v2.1_ui-module-registry-discovery/fdr/0002-nextjs-runtime-module-loading-strategy.md) decision for the [v2.1_ui-module-registry-discovery] feature.

## Quick Start
```bash
# Update status when starting
cd sprints/current/tasks/TASK-038-implement-ui-module-panel-integration-deterministic-fallback-states/
# Edit task.yaml: status: doing

# Follow implementation
cat steps.md              # Read implementation steps
cat commands.md           # Copy-paste commands
cat validation.md         # Validation approach
```

## Dependencies (explicit)
Must be `done` first (per `task.yaml`):
- `TASK-035` — Context snapshot query/types (includes `uiModuleManifests` surface).
- `TASK-037` — UI runtime loader (Option A browser verify + mode flag + reason codes).

Required for end-to-end validation (transitive/system dependencies):
- `TASK-030` — origin route exists: `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}`
- Internal S3/MinIO reachable by the origin route (artifact bytes exist)
- v2 stack running locally with `app.local` + `router.local`

External systems touched during execution/validation:
- Apollo Router (`router.local`) for Context snapshot queries
- Postgres (`postgres` in `v2/infra/compose/docker-compose.v2.yml`) if you seed `ui_module_manifests` for validation
- Internal S3/MinIO via the `cosmo-artifact-probe` helper container (preferred publish path comes from `TASK-031`)

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.
