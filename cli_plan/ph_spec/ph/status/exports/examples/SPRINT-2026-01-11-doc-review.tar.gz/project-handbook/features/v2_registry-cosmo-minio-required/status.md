---
title: v2 Registry Baseline (Cosmo + MinIO) Status
type: status
feature: v2_registry-cosmo-minio-required
date: 2026-01-09
tags: [status]
links:
  - ../../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
  - ../../adr/0030-v2-cosmo-artifact-store-minio-baseline-then-seaweedfs.md
  - ./fdr/0001-vault-secrets-contract-cosmo-minio.md
---

# Status: v2 Registry Baseline (Cosmo + MinIO)

Stage: approved

## Now
- DR-0003 topology accepted; ADR-0030 cutover plan accepted.
- Vault contract accepted and promoted to FDR-0001.
- Discovery tasks `TASK-001` and `TASK-002` are complete; execution work is unblocked.

## Next
- Execute the baseline:
  - [TASK-006](../../sprints/archive/2026/SPRINT-2026-01-09/tasks/TASK-006-implement-v2-cosmo-minio-baseline-from-legacy-reference/README.md): implement Cosmo + MinIO baseline + store-agnostic bucket init + reusable artifact probe
- Then cut over:
  - [TASK-007](../../sprints/archive/2026/SPRINT-2026-01-09/tasks/TASK-007-cutover-replace-minio-with-seaweedfs-s3-gateway/README.md): swap MinIO → SeaweedFS S3 gateway; keep probe green; remove MinIO from default stack

## Dependencies
- `TASK-006` depends on `TASK-002` (Vault contract).
- `TASK-007` depends on `TASK-006` and reuses its artifact probe.
- Execution invariant: `/secrets/artifacts.env` is the single source of truth for artifact-store config; cutover changes `S3_ENDPOINT_URL` only.
- Cross-feature: the Vault conventions from FDR-0001 are also used by downstream registry pipeline tasks (`DR-0005`, `DR-0006`).

## Risks
- Increased baseline infra complexity (mitigated by bootstrap automation + smoke probes).
- SeaweedFS S3 parity differences vs MinIO (mitigated by a deterministic probe + rollback path in `TASK-007`).

## Recent
- SPRINT-2026-01-09 discovery work completed for topology + secrets contract

## Active Work (auto-generated)
*Last updated: 2026-01-11*

### Current Sprint (SPRINT-2026-01-11)
- No active tasks in current sprint

### Recent Completed (last 5 tasks)
- ✅ TASK-002: Investigate: Vault seeding + secrets contract for Cosmo/MinIO (no leakage) (3pts) - SPRINT-2026-01-09
- ✅ TASK-006: Implement: v2 Cosmo+MinIO baseline (from legacy reference) (3pts) - SPRINT-2026-01-09
- ✅ TASK-005: Kickoff: v0.5.0 registry pipeline discovery (evidence dirs + next-up ordering) (1pts) - SPRINT-2026-01-09
- ✅ TASK-007: Cutover: Replace MinIO with SeaweedFS S3 gateway (3pts) - SPRINT-2026-01-09
- ✅ TASK-001: Investigate: Cosmo+MinIO baseline wiring strategy (topology, versions, posture) (3pts) - SPRINT-2026-01-09

### Metrics
- **Total Story Points**: 13 (planned)
- **Completed Points**: 13 (100%)
- **Remaining Points**: 0
- **Estimated Completion**: SPRINT-2026-W03
- **Average Velocity**: 21 points/sprint

