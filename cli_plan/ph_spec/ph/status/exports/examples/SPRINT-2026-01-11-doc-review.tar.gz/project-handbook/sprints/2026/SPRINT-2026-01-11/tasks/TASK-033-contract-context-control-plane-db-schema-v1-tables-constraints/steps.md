---
title: Contract: Context control-plane DB schema (v1 tables + constraints) - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-033
tags: [implementation]
links: []
---

# Implementation Steps: Contract: Context control-plane DB schema (v1 tables + constraints)

## Overview
Update the Context DB schema contract (`project-handbook/contracts/tribuence-mini-v2/context-db-schema.md`) from v0 to v1
so execution tasks can implement migrations without guesswork.

This task is contract/documentation work (no `v2/` code changes).

## Prerequisites
- `TASK-029` is `done`.
- Decision is accepted: `FDR-v2_context-control-plane-schema-0001`.

## Step 1 — Capture evidence index
1. Create `project-handbook/status/evidence/TASK-033/index.md`.
2. Capture “before” excerpts so review can see what changed:
   - `context-db-schema-before.txt` (grep output)
   - a short “before” excerpt in `index.md` (copy/paste 5–15 relevant lines from `context-db-schema-before.txt`)

## Step 2 — Update DB schema contract (v1)
Update `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` **additively**:

1. Keep existing v0 tables (`context_workspaces`, `context_references`) intact.
2. Add a new v1 section that defines the minimum control-plane tables and constraints required by
   `FDR-v2_context-control-plane-schema-0001`.

### 2.1 Non-negotiable invariants (must be stated in the contract)
- Every table is tenant/workspace scoped:
  - `tenant_id` on every row
  - `workspace_id` on every workspace-scoped row (FK to `context_workspaces.id`)
- Idempotency keys exist and are enforced by uniqueness constraints (jobs/operations must be safe to retry).
- No provider secrets stored:
  - credentials are stored as **reference IDs only** (never tokens/private keys/signed URLs).

### 2.2 v1 table set (minimum; do not rename later without an explicit breaking-change decision)
Define the following new tables (names are part of the contract):
- `capability_manifests` — desired enablement state per workspace/capability
- `capability_status` — observed state per workspace/capability
- `integration_links` — durable mapping to provider workspace + credential reference IDs
- `integration_jobs` — durable job records (idempotent by key)
- `integration_job_runs` — durable job run attempts (audit + retries)
- `setup_guidance` — deterministic guidance identifiers (no secrets)
- `ui_module_manifests` — v2.1 module selection (capability → module id + version + sha256)

### 2.3 Required columns + constraints (no ambiguity)
For each table, the contract must specify at least:
- columns (names + types),
- key uniqueness constraints,
- foreign keys (where applicable),
- “no secrets” posture for any credential/provider fields.

Minimum required shape (may be extended additively later):

1) `capability_manifests`
- Columns: `id`, `tenant_id`, `workspace_id`, `capability_id`, `enabled`, `created_at`, `updated_at`
- Constraints:
  - `unique (tenant_id, workspace_id, capability_id)`
  - `workspace_id` FK → `context_workspaces(id)` (cascade delete)

2) `capability_status`
- Columns: `id`, `tenant_id`, `workspace_id`, `capability_id`, `state`, `detail`, `created_at`, `updated_at`
- Constraints:
  - `unique (tenant_id, workspace_id, capability_id)`
  - `workspace_id` FK → `context_workspaces(id)` (cascade delete)

3) `integration_links`
- Columns: `id`, `tenant_id`, `workspace_id`, `capability_id`, `provider_type`, `provider_workspace_id`,
  `provider_workspace_slug`, `credential_ref_id`, `state`, `detail`, `created_at`, `updated_at`
- Constraints:
  - `unique (tenant_id, workspace_id, capability_id)`
  - `workspace_id` FK → `context_workspaces(id)` (cascade delete)
- No secrets rule: `credential_ref_id` is an identifier only (never secret material).

4) `integration_jobs`
- Columns: `id`, `tenant_id`, `workspace_id`, `capability_id`, `job_type`, `idempotency_key`, `state`, `detail`,
  `created_at`, `updated_at`
- Constraints:
  - `unique (tenant_id, workspace_id, capability_id, job_type, idempotency_key)`
  - `workspace_id` FK → `context_workspaces(id)` (cascade delete)

5) `integration_job_runs`
- Columns: `id`, `tenant_id`, `workspace_id`, `job_id`, `run_number`, `state`, `started_at`, `finished_at`,
  `error_code`, `error_detail`, `created_at`, `updated_at`
- Constraints:
  - `unique (tenant_id, job_id, run_number)`
  - `job_id` FK → `integration_jobs(id)` (cascade delete)

6) `setup_guidance`
- Columns: `id`, `tenant_id`, `workspace_id`, `capability_id`, `guidance_key`, `guidance_id`, `detail`,
  `created_at`, `updated_at`
- Constraints:
  - `unique (tenant_id, workspace_id, capability_id, guidance_key)`
  - `workspace_id` FK → `context_workspaces(id)` (cascade delete)

7) `ui_module_manifests`
- Columns: `id`, `tenant_id`, `workspace_id`, `capability_id`, `module_id`, `version`, `integrity_sha256`,
  `created_at`, `updated_at`
- Constraints:
  - `unique (tenant_id, workspace_id, capability_id)`
  - `workspace_id` FK → `context_workspaces(id)` (cascade delete)
  - `integrity_sha256` must be a 64-char lowercase hex digest (CHECK constraint recommended).

### 2.4 Suggested SQL DDL (reference)
Add a “Suggested SQL DDL (v1 additions)” section with `CREATE TABLE IF NOT EXISTS` examples that reflect the contract
(Postgres).

## Step 3 — Update validation docs
1. Update `validation.md` to match the finalized contract section (no placeholders).
2. Ensure the evidence file list is explicit and complete (see `validation.md`).
3. Run `pnpm -C project-handbook make -- validate`.

## Step 4 — Submit for review
1. Set status to `review` via `pnpm -C project-handbook make -- task-status id=TASK-033 status=review`.
