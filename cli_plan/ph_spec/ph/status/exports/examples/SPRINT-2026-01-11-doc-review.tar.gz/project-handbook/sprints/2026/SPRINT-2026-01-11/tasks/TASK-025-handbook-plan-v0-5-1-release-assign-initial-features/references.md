---
title: Handbook: Plan v0.5.1 release + assign initial features - References
type: references
date: 2026-01-11
task_id: TASK-025
tags: [references]
links: []
---

# References: Handbook: Plan v0.5.1 release + assign initial features

## Internal References

### Decision Context
- **Decision**: [ADR-0012](../../../../../adr/0012-handbook-reporting-and-continuity-artifacts.md)
- **Feature**: [Feature overview](../../../../../features/handbook-hygiene/overview.md)
- **Architecture**: [Feature architecture](../../../../../features/handbook-hygiene/architecture/ARCHITECTURE.md)

### Canonical Process
- **Agent workflow**: [AI Agent Start Here](../../../../../process/AI_AGENT_START_HERE.md)
- **Session template**: [task-execution](../../../../../process/sessions/templates/task-execution.md)

### Sprint Context
- **Sprint Plan**: [Current sprint](../../plan.md)
- **Sprint Tasks**: [All sprint tasks](../)
- **Daily Progress**: [Daily status](../../daily/)

### Release Context
- **Release Manager Commands**: [Makefile targets](../../../../../Makefile)
- **Current Release Plan**: [releases/current](../../../../../releases/current/plan.md)

## Notes
Add concrete links here only when you discover resources during the task (no placeholders).
