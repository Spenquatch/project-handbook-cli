---
title: Task TASK-031 - Implement: UI module publish pipeline (S3 upload + smoke check)
type: task
date: 2026-01-11
task_id: TASK-031
feature: v2.1_ui-module-registry-discovery
session: task-execution
tags: [task, v2.1_ui-module-registry-discovery]
links: [../../../../../features/v2.1_ui-module-registry-discovery/overview.md]
---

# Task TASK-031: Implement: UI module publish pipeline (S3 upload + smoke check)

## Overview
- **Feature**: [v2.1_ui-module-registry-discovery](../../../../../features/v2.1_ui-module-registry-discovery/overview.md)
- **Decision**: [FDR-v2_1_ui-module-registry-discovery-0001](../../../../../features/v2.1_ui-module-registry-discovery/fdr/0001-ui-module-artifact-origin-and-publish-pipeline.md)
- **Story Points**: 3
- **Owner**: @spenser
- **Lane**: `module-registry/origin`
- **Session**: `task-execution`

## Agent Navigation Rules
1. **Start work**: `pnpm -C project-handbook make -- task-status id=TASK-031 status=doing`
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: `pnpm -C project-handbook make -- task-status id=TASK-031 status=review`

## Context & Background
This task implements the [FDR-v2_1_ui-module-registry-discovery-0001](../../../../../features/v2.1_ui-module-registry-discovery/fdr/0001-ui-module-artifact-origin-and-publish-pipeline.md) decision for the [v2.1_ui-module-registry-discovery] feature.

## What You Are Building (contract summary)
- A repeatable publish script that:
  - computes `integritySha256` over `index.mjs` bytes
  - uploads append-only to `s3://COSMO_S3_BUCKET/ui-modules/{moduleId}/{version}/{integritySha256}/index.mjs`
  - prints a copy/paste-friendly tuple `{moduleId, version, integritySha256}` for manifest wiring
- A smoke script that validates:
  - object exists in internal S3
  - UI proxy route serves bytes that hash to `integritySha256`

## Quick Start
```bash
pnpm -C project-handbook make -- task-status id=TASK-031 status=doing
cd project-handbook/sprints/current/tasks/TASK-031-implement-ui-module-publish-pipeline-s3-upload-smoke-check/

# Follow implementation
cat steps.md              # Read implementation steps
cat commands.md           # Copy-paste commands
cat validation.md         # Validation approach
```

## Dependencies
Hard dependencies (must be `done` before execution):
- `TASK-030` — provides the `GET /api/ui-modules/...` proxy route required for the smoke check.

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.

## Evidence
All evidence for this task must be captured under `project-handbook/status/evidence/TASK-031/` (see `validation.md`).
