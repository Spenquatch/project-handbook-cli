---
title: Implement: Context DB migrations for control-plane tables (v1) - Completion Checklist
type: checklist
date: 2026-01-11
task_id: TASK-034
tags: [checklist]
links: []
---

# Completion Checklist: Implement: Context DB migrations for control-plane tables (v1)

## Preconditions (must be true before coding)
- [ ] `TASK-033` is `done`
- [ ] `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` contains a v1 control-plane schema section
- [ ] You understand Context’s migration model: `v2/services/context/index.js` applies all `.sql` migrations every boot

## Schema Implementation (binary)
- [ ] New migration file(s) added under `v2/services/context/db/migrations/` (do not modify `001_init.sql`)
- [ ] Migration filenames are ordered correctly (leading numeric prefix; lexicographic sort matches intended order)
- [ ] Every statement is idempotent (`IF NOT EXISTS` / duplicate-safe guards); Context can restart repeatedly with no errors
- [ ] v0 tables preserved and still present: `context_workspaces`, `context_references`
- [ ] v1 control-plane tables exist (minimum set; exact names per contract):
  - [ ] `capability_manifests`
  - [ ] `capability_status`
  - [ ] `integration_links`
  - [ ] `integration_jobs`
  - [ ] `integration_job_runs`
  - [ ] `setup_guidance`
  - [ ] `ui_module_manifests`

## Validation + Evidence (required)
- [ ] Evidence directory exists: `project-handbook/status/evidence/TASK-034/`
- [ ] Evidence captured:
  - [ ] `project-handbook/status/evidence/TASK-034/index.md`
  - [ ] `project-handbook/status/evidence/TASK-034/migrations-ls.txt`
  - [ ] `project-handbook/status/evidence/TASK-034/context-startup-logs.txt`
  - [ ] `project-handbook/status/evidence/TASK-034/psql-schema.txt`
  - [ ] `project-handbook/status/evidence/TASK-034/handbook-validate.txt`
- [ ] `pnpm -C project-handbook make -- validate` passes

## Status Updates
- [ ] Set status to `review`: `pnpm -C project-handbook make -- task-status id=TASK-034 status=review`
