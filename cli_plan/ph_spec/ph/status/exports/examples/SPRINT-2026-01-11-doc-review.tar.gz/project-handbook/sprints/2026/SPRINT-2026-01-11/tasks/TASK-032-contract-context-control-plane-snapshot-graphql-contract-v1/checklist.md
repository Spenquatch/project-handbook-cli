---
title: Contract: Context control-plane snapshot GraphQL contract (v1) - Completion Checklist
type: checklist
date: 2026-01-11
task_id: TASK-032
tags: [checklist]
links: []
---

# Completion Checklist: Contract: Context control-plane snapshot GraphQL contract (v1)

## Pre-Work
- [ ] Confirm all `depends_on` tasks are `done` (must include `TASK-029`)
- [ ] Re-read `project-handbook/features/v2_context-control-plane-schema/fdr/0001-context-control-plane-snapshot-contract.md`
- [ ] Re-read `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md` (current v0 contract)

## During Execution
- [ ] Create evidence directory: `project-handbook/status/evidence/TASK-032/`
- [ ] Capture “before” excerpt evidence (`context-subgraph-before.txt`)
- [ ] Update `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md` additively:
- [ ] Add `contextControlPlaneSnapshot(workspaceId: ID): ContextControlPlaneSnapshot!`
- [ ] Document input semantics (`workspaceId` may be omitted; fallback to `x-workspace-id`; error `BAD_USER_INPUT` if neither)
- [ ] Define `ContextControlPlaneSnapshot` with required empty-safe arrays and `generatedAt`
- [ ] Define minimal types for manifests/statuses/links/jobs/guidance/ui module manifests (additive-only later)
- [ ] Document consumer contract: headers, strict timeout + deterministic fallback, and “wrappers must not call Router”
- [ ] Capture “after” excerpt evidence (`context-subgraph-after.txt`) + `context-subgraph.diff`

## Before Review
- [ ] Run `pnpm -C project-handbook make -- validate`
- [ ] Ensure `validation.md` lists all required evidence files (no placeholders)
- [ ] Set status to `review` via `pnpm -C project-handbook make -- task-status id=TASK-032 status=review`

## After Completion
- [ ] Peer review approved
- [ ] Move status to `done` with `pnpm -C project-handbook make -- task-status id=TASK-032 status=done`
