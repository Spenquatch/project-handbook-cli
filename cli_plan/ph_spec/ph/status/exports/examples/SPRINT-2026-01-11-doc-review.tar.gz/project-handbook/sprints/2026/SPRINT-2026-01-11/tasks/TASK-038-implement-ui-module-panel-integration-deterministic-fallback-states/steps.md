---
title: Implement: UI module panel integration + deterministic fallback states - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-038
tags: [implementation]
links: []
---

# Implementation Steps: Implement: UI module panel integration + deterministic fallback states

## Overview
Integrate the runtime loader (Option A) into the v2 landing harness in a way that preserves the module-ready panel
boundary (`ADR-0024`):
- consume Context-provided module selection (no env/querystring guessing),
- render module-backed panels when present,
- render deterministic fallback panel states on load failures,
- keep the shell running even if one module fails.

Implementation posture for this sprint:
- Add a dedicated **“UI Modules (registry harness)”** section to the landing page.
- Render a small fixed set of module panel “slots” keyed by `capabilityId` so Playwright can validate success + failure
  modes deterministically in `TASK-039`.

## Prerequisites
- [ ] `TASK-037` is `done` (loader abstraction exists)
- [ ] `TASK-035` is `done` (Context snapshot query/types exist for module selection)

## Step 1 — Add a “UI Modules (registry harness)” section to the landing page
1. Confirm the harness entrypoint:
   - `v2/apps/tribuence-mini/src/app/page.tsx`
2. Add a new section (peer to “Twenty” / “AnythingLLM”) titled **UI Modules**.
3. In that section, render one reusable panel component multiple times (same component; different `capabilityId`):
   - `ui-module-demo-happy`
   - `ui-module-demo-not-allowlisted`
   - `ui-module-demo-missing`
   - `ui-module-demo-hash-mismatch`
   - `ui-module-demo-eval-error`
   - `ui-module-demo-export-invalid`

Hard requirement (for `TASK-039` selectors):
- Each slot must render a stable wrapper element with:
  - `data-testid="ui-module-panel"`
  - `data-capability-id="<capabilityId>"`

## Step 2 — Wire Context module selection to the UI (no guessing)
1. Fetch the control-plane snapshot via Apollo Router using the contract from `TASK-035`:
   - Query: `contextControlPlaneSnapshot(workspaceId: ID): ContextControlPlaneSnapshot!`
   - Field: `uiModuleManifests: [ContextUiModuleManifest!]!`
2. Query payload must include the fields needed to resolve the loader tuple:
   - `uiModuleManifests { capabilityId moduleId version integritySha256 updatedAt }`
3. Resolve selection per slot:
   - for each `capabilityId` listed in Step 1, find the matching `ContextUiModuleManifest`
   - if missing: render a deterministic **“no selection”** state (panel-scoped, no crash)
4. Pass the resolved tuple into the loader abstraction from `TASK-037` (client-only execution boundary).

Hard requirement:
- The panel must not read `process.env` or querystring values to select modules (ADR-0024 / ADR-0025).

## Step 3 — Deterministic fallback states
Implement a deterministic fallback panel state that:
- shows a stable reason code (not secret data),
- includes operator-friendly guidance identifiers (if applicable),
- does not block rendering of other panels.

Required reason codes (stable identifiers):
- `NOT_ALLOWLISTED`
- `FETCH_404`
- `FETCH_FAILED`
- `HASH_MISMATCH`
- `EVAL_ERROR`
- `EXPORT_INVALID`

Hard requirements (for E2E assertions + evidence):
- On success: the wrapper element must include `data-state="loaded"`.
- On failure: the wrapper element must include `data-state="fallback"` and `data-reason-code="<REASON>"`.
- The fallback UI must render the reason code as visible text somewhere within the panel (no “icons only”).

## Step 4 — Evidence capture
Capture evidence under `project-handbook/status/evidence/TASK-038/`:
- screenshot(s) showing a module panel rendered and a fallback panel rendered,
- test output (if applicable) confirming deterministic reason codes.

## Notes
- Keep the implementation bounded: the “registry harness” section is the only place that needs to be module-backed in this task.
