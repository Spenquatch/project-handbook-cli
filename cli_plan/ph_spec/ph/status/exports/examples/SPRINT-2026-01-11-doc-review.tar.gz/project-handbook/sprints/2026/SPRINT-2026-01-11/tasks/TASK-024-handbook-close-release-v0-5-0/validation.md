---
title: Handbook: Close release v0.5.0 - Validation Guide
type: validation
date: 2026-01-11
task_id: TASK-024
tags: [validation]
links: []
---

# Validation Guide: Handbook: Close release v0.5.0

## Automated Validation
```bash
pnpm -C project-handbook make -- release-status
pnpm -C project-handbook make -- dashboard
pnpm -C project-handbook make -- status
pnpm -C project-handbook make -- validate
```

## Pass/Fail Criteria
- `project-handbook/releases/v0.5.0/plan.md` reflects the close-out (status updated by `release-close`).
- `project-handbook/releases/current` is a valid symlink (no “No current release found” errors).
- `project-handbook/status/current_summary.md` references `SPRINT-2026-01-11` and lists the sprint tasks.

## Evidence (required)
- `project-handbook/status/evidence/TASK-024/release-status.before.txt`
- `project-handbook/status/evidence/TASK-024/release-close.txt`
- `project-handbook/status/evidence/TASK-024/release-status.after.txt`
- `project-handbook/status/evidence/TASK-024/status.txt`
- `project-handbook/status/evidence/TASK-024/dashboard.txt`

## Sign-off
- Completed: 2026-01-11
- [x] All validation steps completed
- [x] Evidence documented above
- [x] Ready to mark task as "done"
