---
title: Tribuence Mini V2 Implementation
type: implementation
feature: tribuence-mini-v2
date: 2025-12-22
tags: [implementation]
links: []
---

# Implementation: Tribuence Mini V2

## Development Plan
### Phase 0 — Compose skeleton (bring-up)
- Create `v2/` directory skeleton.
- Build `v2/infra/compose/docker-compose.v2.yml` starting from baseline infra compose.
- Add `make v2-up`, `make v2-down`, `make v2-smoke` entrypoints.

### Phase 1 — Secrets bootstrap (Vault)
- Copy/adapt Vault agent templates into `v2/infra/vault/templates/*`.
- Add `v2/scripts/vault/bootstrap-v2.sh` to seed required KV entries.

### Phase 2 — Federation baseline (Apollo Router)
- Add `v2/infra/compose/graphql/router.v2.yaml`.
- Federate Twenty first; then add Context and AnythingLLM subgraphs.
- Establish SDL/codegen workflow under `v2/infra/compose/graphql/subgraphs/*`.

### Phase 3 — Context service
- Implement `v2/services/context/` with DB schema + resolvers for workspaces/reference IDs and metadata.

### Phase 4 — UI migration
- Copy `apps/tribuence-mini` → `v2/apps/tribuence-mini`.
- Replace all REST/proxy calls with GraphQL queries/mutations; add workspace/reference UX.

### Phase 5 — Smoke + docs
- Add `v2/scripts/v2-smoke.sh` and quickstart docs under `v2/docs/README.md`.

## Technical Decisions
- `ADR-0007`: federated GraphQL supergraph + Context service baseline.
- `ADR-0010`: local/dev auth + header strategy for early bring-up.
- Keep `oss-forks/*` unchanged; consume upstream images/config.

## Contracts (Implement Exactly These Interfaces)
- Router exposure + header propagation: `../../contracts/tribuence-mini-v2/supergraph-router.md`
- Federation composition workflow: `../../contracts/tribuence-mini-v2/federation-composition.md`
- Twenty subgraph endpoint/auth: `../../contracts/tribuence-mini-v2/twenty-subgraph.md`
- Context subgraph schema/semantics: `../../contracts/tribuence-mini-v2/context-subgraph.md`
- Context DB schema (v0): `../../contracts/tribuence-mini-v2/context-db-schema.md`
- AnythingLLM wrapper subgraph: `../../contracts/tribuence-mini-v2/anythingllm-subgraph.md`
- Vault KV layout + rendered env files: `../../contracts/tribuence-mini-v2/vault-secrets.md`
- Smoke probes (what must pass): `../../contracts/tribuence-mini-v2/v2-smoke-spec.md`
- UI operations (what the first UI slice implements): `../../contracts/tribuence-mini-v2/ui-graphql-operations.md`

## Implementation Notes
- Track source-of-truth architecture details in `v2/ARCHITECTURE.md`; keep this doc aligned as the stack evolves.

## Reuse Inventory (Copious Infra Exists)

To move quickly, pull forward existing infra patterns from the reference trees and adapt them in `v2/`:

### Compose + routing (start here)
- Use as the baseline to copy/copy-edit into `v2/infra/compose/docker-compose.v2.yml`:
  - `modular-oss-saas/infra/compose/docker-compose.yml`
  - `modular-oss-saas/infra/compose/docker-compose.override.yml`
  - `modular-oss-saas/infra/compose/docker-compose.observability.yml`

### Vault templates + bootstrap
- Copy/adapt templates into `v2/infra/vault/templates/*`:
  - `modular-oss-saas/infra/vault/templates/agent.hcl`
  - `modular-oss-saas/infra/vault/templates/next.env.tpl`
- Copy/adapt bootstrap into `v2/scripts/vault/bootstrap-v2.sh`:
  - `modular-oss-saas/scripts/vault/bootstrap-mini.sh`

### Upstream systems (read-only sources)
- Twenty CRM fork reference and wiring details:
  - `oss-forks/twenty-crm/`

## Planning Output Expectations

Each sprint task should explicitly state:
- which reference files it expects to copy/copy-edit from `modular-oss-saas/` and/or `oss-forks/`,
- what the minimal runnable slice is (what should boot/respond),
- how to validate it (smoke probes + handbook validation).
