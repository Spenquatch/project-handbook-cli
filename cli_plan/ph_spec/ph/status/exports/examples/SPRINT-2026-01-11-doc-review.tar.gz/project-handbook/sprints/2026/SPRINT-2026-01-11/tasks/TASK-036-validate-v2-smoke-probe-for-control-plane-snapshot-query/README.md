---
title: Task TASK-036 - Validate: v2 smoke probe for control-plane snapshot query
type: task
date: 2026-01-11
task_id: TASK-036
feature: v2_context-control-plane-schema
session: task-execution
tags: [task, v2_context-control-plane-schema]
links: [../../../../features/v2_context-control-plane-schema/overview.md]
---

# Task TASK-036: Validate: v2 smoke probe for control-plane snapshot query

## Overview
- **Feature**: [v2_context-control-plane-schema](../../../../features/v2_context-control-plane-schema/overview.md)
- **Decision**: [FDR-v2_context-control-plane-schema-0001](../../../../features/v2_context-control-plane-schema/fdr/0001-context-control-plane-snapshot-contract.md)
- **Story Points**: 2
- **Owner**: @spenser
- **Lane**: `context/control-plane`
- **Session**: `task-execution`

## Agent Navigation Rules
1. **Start work**: `pnpm -C project-handbook make -- task-status id=TASK-036 status=doing`
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: `pnpm -C project-handbook make -- task-status id=TASK-036 status=review`

## Context & Background
This task hardens the control-plane snapshot contract by adding an end-to-end probe to the v2 smoke harness.

The snapshot query is a cross-cutting dependency: the UI shell and wrapper subgraphs rely on a single canonical
`contextControlPlaneSnapshot` response shape being stable and empty-safe. This task makes that stability measurable
in CI/local runs via `make -C v2 v2-smoke`.

Decision reference: [FDR-v2_context-control-plane-schema-0001](../../../../features/v2_context-control-plane-schema/fdr/0001-context-control-plane-snapshot-contract.md).

## What You Are Changing
- Add a `contextControlPlaneSnapshot` probe to `v2/scripts/v2-smoke.sh` (repo root) with:
  - shape assertions (workspace id + empty-safe arrays + `generatedAt`),
  - a failure-mode assertion for missing workspace scope (`BAD_USER_INPUT` when neither `workspaceId` nor `x-workspace-id` is provided).
- Capture evidence under `project-handbook/status/evidence/TASK-036/` and reference it from `validation.md`.

## Quick Start
```bash
# From repo root
pnpm -C project-handbook make -- task-status id=TASK-036 status=doing
cd project-handbook/sprints/current/tasks/TASK-036-validate-v2-smoke-probe-for-control-plane-snapshot-query/

# Follow implementation
cat steps.md              # Read implementation steps
cat commands.md           # Copy-paste commands
cat validation.md         # Validation approach
```

## Dependencies
Hard dependency (must be `done` before execution):
- `TASK-035` — implements the `contextControlPlaneSnapshot` query and updates the SDL snapshot.

Operational/system dependencies (must exist for validation):
- v2 stack running locally (Traefik + Apollo Router + Context subgraph).
- Local prerequisites: `docker`, `docker compose`, `curl`, `jq`.

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.

## Evidence
All evidence for this task must be captured under `project-handbook/status/evidence/TASK-036/` (see `validation.md`).
