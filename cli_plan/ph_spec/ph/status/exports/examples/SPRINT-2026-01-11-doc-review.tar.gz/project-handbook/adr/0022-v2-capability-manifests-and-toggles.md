---
id: ADR-0022
title: v2 Capability Manifests + Workspace Toggles (Context-Controlled)
type: adr
status: accepted
date: 2026-01-06
tags: [tribuence-mini, v2, capabilities, manifests, context]
links:
  - ../features/v2_capability-manifests-and-toggles/overview.md
  - ../features/v2_context-glue-integrations/overview.md
  - ../features/v2_capability-detection-surface/overview.md
---

# Context

Tribuence needs a deterministic way to define “which capabilities are enabled for which workspace” that drives:
- provisioning workflows,
- Router/UI behavior (via stub gating),
- future service-catalog automation.

# Decision

## 1) Capability enablement is stored and enforced in Context

Context stores a per-workspace capability manifest that includes:
- capability type (`TWENTY`, `ANYTHINGLLM`, etc.),
- desired state (`enabled` or `disabled`),
- provisioning policy (run-once provisioning for enabled capabilities).

## 2) Enable/disable triggers provisioning and updates gating surfaces

When a capability is enabled for a workspace, Context enqueues provisioning jobs (ADR-0016). When disabled, Context:
- retains the mapping record (for auditability),
- marks the capability as disabled in the capability detection surface (ADR-0018),
- causes the wrapper subgraph to operate in stub mode for that workspace (ADR-0017).

# Consequences

## Positive
- One authoritative toggle plane for all capabilities.
- Predictable behavior when capabilities are toggled.

## Tradeoffs
- Requires careful migration/versioning of capability manifest schema as capabilities grow.

# Rollout / Acceptance

- Context exposes a GraphQL API to enable/disable a capability per workspace.
- Enabling triggers provisioning; disabling triggers stub gating without changing composed schema.
- The UI reflects enablement state via the Context capability detection surface.
