---
title: Tribuence Mini V2
type: overview
feature: tribuence-mini-v2
date: 2025-12-22
tags: [feature]
links:
  - ./architecture/ARCHITECTURE.md
  - ./implementation/IMPLEMENTATION.md
  - ./testing/TESTING.md
  - ../../contracts/tribuence-mini-v2/README.md
  - ../../../../v2/ARCHITECTURE.md
  - ../../adr/0007-tribuence-mini-v2-supergraph-context.md
  - ../../adr/0008-tribuence-mini-v2-anythingllm-subgraph-wrapper.md
  - ../../adr/0010-tribuence-mini-v2-local-dev-auth-and-headers.md
dependencies: []
backlog_items:
  - WILD-P1-20251229-2134
  - WILD-P2-20251222-1203
  - WILD-P2-20251222-1204
  - WILD-P2-20251230-2050
  - WILD-P2-20251231-1000
  - WILD-P2-20260103-2109
  - WILD-P3-20251222-1203
  - WILD-P3-20251229-2134
parking_lot_origin: null  # Original parking lot ID if promoted
capacity_impact: planned  # planned (80%) or reactive (20%)
epic: false
---

# Tribuence Mini V2

## Purpose
Deliver the `v2/` stack defined in `v2/ARCHITECTURE.md`: a single local/dev bring-up that boots core infra + Twenty CRM + AnythingLLM behind a federated GraphQL supergraph, with a Tribuence Context service providing workspaces/reference IDs and metadata.

## Outcomes
- `make v2-up` boots Traefik, Vault, Postgres, Keycloak, Apollo Router, Twenty, AnythingLLM, Context service, and the v2 UI.
- The v2 UI uses GraphQL-only (no ad-hoc REST proxies) and supports workspace + reference workflows.
- `make v2-smoke` validates federation, CRUD probes, doc upload, and chat runtime, plus isolation checks.

## State
- Stage: developing
- Owner: @spenser

## Backlog Integration
- Related Issues:
  - `WILD-P2-20251222-1203` (UI GraphQL-only migration)
  - `WILD-P2-20251222-1204` (AnythingLLM subgraph wrapper)
  - `WILD-P3-20251222-1203` (v2 smoke + docs quickstart)
  - `WILD-P2-20260103-2109` (AnythingLLM upstream response shape verification)
- Capacity Type: planned  # Uses 80% allocation
- Parking Lot Origin: null  # Set if promoted from parking lot

## Key Links
- [Architecture](./architecture/ARCHITECTURE.md)
- [Implementation](./implementation/IMPLEMENTATION.md)
- [Testing](./testing/TESTING.md)
- [Contracts](../../contracts/tribuence-mini-v2/README.md)
- [Status](./status.md)
- [Changelog](./changelog.md)
- [Canonical v2 Architecture](../../../v2/ARCHITECTURE.md)
