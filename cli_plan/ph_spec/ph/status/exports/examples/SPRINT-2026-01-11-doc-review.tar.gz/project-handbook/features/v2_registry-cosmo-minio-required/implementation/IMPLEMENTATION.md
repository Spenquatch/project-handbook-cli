---
title: v2 Registry Baseline (Cosmo + MinIO) Implementation
type: implementation
feature: v2_registry-cosmo-minio-required
date: 2026-01-06
tags: [implementation]
links:
  - ../../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
---

# Implementation: v2 Registry Baseline (Cosmo + MinIO)

**Pending operator approval:** Implement the baseline topology selected in `project-handbook/decision-register/DR-0003-cosmo-minio-baseline-topology.md` only after operator approval (keep DR status `Proposed` until approved).

## Build Steps (required)
1. Add Cosmo services (and required dependencies) plus an S3-compatible artifact store (MinIO baseline; SeaweedFS migration target) to the default v2 compose wiring.
2. Extend Vault templates and `v2/scripts/vault/bootstrap-v2.sh` to seed and render:
   - `/secrets/cosmo.env`
   - `/secrets/minio.env` (baseline)
   - `/secrets/artifacts.env` (migration-friendly single source of truth for endpoint + creds + bucket)
3. Add an idempotent bucket initializer for Cosmo artifacts.
4. Add smoke probes that fail fast when Cosmo/artifact-store dependencies are unhealthy.

## Required Posture
- No Traefik routers for Cosmo or the artifact store (MinIO/SeaweedFS).
- Default stack (DR-0003 Option B recommended): **no host port bindings** for Cosmo/artifact-store services (strict internal-only).
- If an operator overlay is later added, bind operator ports to `127.0.0.1` only.
- No secrets printed to stdout/stderr; no env dumps in logs.

## Implementation Notes
- Mirror the reference Cosmo stack dependency inventory described in ADR-0015.
- Keep v2 Postgres as the shared database; create dedicated Cosmo databases/roles via bootstrap job.
- Cosmo images are `linux/amd64` only; on Apple Silicon, the v2 compose pins `platform: linux/amd64` for Cosmo services.

## Execution-ready wiring plan (pending approval)

### 1) v2 wiring points (files to edit)
- Compose wiring:
  - `v2/infra/compose/docker-compose.v2.yml`
    - Add services: `minio` (baseline), `cosmo-clickhouse`, `cosmo-redis`, `cosmo-nats`, `cosmo-keycloak`, `cosmo-cdn`, `cosmo-controlplane`, `cosmo-studio`
    - If migrating to SeaweedFS later: add `seaweedfs` (S3 via `weed server -s3`, endpoint `:8333`) and update the artifact endpoint env.
    - Add one-shot services: `cosmo-postgres-bootstrap`, `cosmo-db-migration`, `cosmo-clickhouse-migration`, `artifact-bucket-init`
    - Add volumes for MinIO/ClickHouse/Redis and any Cosmo-specific config mounts (Keycloak realm import, ClickHouse init).
    - Enforce posture:
      - no Traefik labels/routers for Cosmo/artifact-store
      - no `ports:` for Cosmo/artifact-store in the default stack (Option B)
- Vault Agent templates:
  - `v2/infra/vault/templates/agent.hcl` (add template stanzas)
  - Add new templates:
    - `v2/infra/vault/templates/cosmo.env.tpl`
    - `v2/infra/vault/templates/minio.env.tpl`
    - (migration-friendly) `v2/infra/vault/templates/artifacts.env.tpl` (endpoint + creds + bucket) used by bucket init and referenced by Cosmo.
- Vault bootstrap:
  - `v2/scripts/vault/bootstrap-v2.sh`
    - Seed KV paths for Cosmo/MinIO (paths + key names only; values generated; must not print).
    - Follow the secrets contract from `project-handbook/decision-register/DR-0004-vault-secrets-contract-cosmo-minio.md` once approved.
- Optional config assets to vendor (reference-only until implementation task):
  - Keycloak realm import JSON (Cosmo realm + clients), plus any theme/template needs.
  - ClickHouse init SQL for Cosmo OTEL schemas (reference: `modular-oss-saas/infra/compose/cosmo/clickhouse/init/*`).

### 2) Required env/secrets (high-level)
Detailed contract belongs in `project-handbook/decision-register/DR-0004-vault-secrets-contract-cosmo-minio.md` (pending operator approval). The current recommended contract (Option A) is:

- `kv/data/tribuence/v2/minio` (artifact-store baseline; secrets)
  - `MINIO_ACCESS_KEY`
  - `MINIO_SECRET_KEY`
  - `COSMO_S3_BUCKET`
- `kv/data/tribuence/v2/cosmo` (Cosmo controlplane/cdn/seed; mixed config + secrets)
  - Postgres (secrets)
    - `COSMO_POSTGRES_USER`
    - `COSMO_POSTGRES_PASSWORD`
    - `COSMO_POSTGRES_DB`
  - ClickHouse (secrets)
    - `COSMO_CLICKHOUSE_DB`
    - `COSMO_CLICKHOUSE_USER`
    - `COSMO_CLICKHOUSE_PASSWORD`
  - Cosmo auth (secrets)
    - `COSMO_AUTH_JWT_SECRET`
    - `COSMO_AUTH_ADMISSION_SECRET`
  - Cosmo Keycloak (secrets)
    - `COSMO_KEYCLOAK_ADMIN`
    - `COSMO_KEYCLOAK_ADMIN_PASSWORD`
  - Cosmo seed (secrets)
    - `COSMO_SEED_API_KEY`
    - `COSMO_SEED_USER_EMAIL`
    - `COSMO_SEED_USER_PASSWORD`
    - `COSMO_SEED_ORG`
  - Optional centralized config (non-secrets; keep out of `.env` drift)
    - `S3_REGION` (default `auto`)
    - `S3_FORCE_PATH_STYLE` (default `true`)
    - `COSMO_CONTROLPLANE_ALLOWED_ORIGINS`
    - `COSMO_WEB_BASE_URL`

Rendered env files (by Vault Agent):
- `/secrets/minio.env`
- `/secrets/cosmo.env`
- `/secrets/artifacts.env`

See the durable execution contract: `project-handbook/features/v2_registry-cosmo-minio-required/fdr/0001-vault-secrets-contract-cosmo-minio.md`.

#### Template outputs (execution-ready)
- `/secrets/minio.env` (used by `minio`)
  - `MINIO_ROOT_USER` (from `MINIO_ACCESS_KEY`)
  - `MINIO_ROOT_PASSWORD` (from `MINIO_SECRET_KEY`)
- `/secrets/cosmo.env` (used by `cosmo-controlplane`, `cosmo-cdn`, `cosmo-seed`)
  - Derived DSNs/URLs (do not store duplicated values in Vault)
    - `DB_URL` (from Cosmo Postgres fields)
    - `CLICKHOUSE_DSN`, `CLICKHOUSE_MIGRATION_DSN` (from Cosmo ClickHouse fields)
    - `S3_STORAGE_URL` (from MinIO creds + bucket)
  - Required Cosmo env vars referenced in the legacy stack (names only; see `project-handbook/status/evidence/TASK-002/modular-compose-cosmo-minio-env-snippets.txt`)

#### “No secrets printed” posture checklist (implementation agents)
- Never print secrets to stdout/stderr:
  - Do not `cat /secrets/*.env`, `env`, or log full command lines that include DSNs or `S3_STORAGE_URL`.
  - Avoid `set -x` (or disable it) around any secret-handling code paths.
- Evidence hygiene:
  - Evidence files may include KV paths + key names only (never values).
  - Prefer inventories/snippets/stats; redact if a value could appear.
- Bootstrap hygiene (`v2/scripts/vault/bootstrap-v2.sh`):
  - Emit “value not printed” style messages when generating/fetching secrets.
  - Treat known placeholders as “unset” and refuse to persist placeholder secrets.
  - Ensure Vault reads never dump values (no `vault kv get` output in logs).

#### If/when to transition to Option B (split contract)
Transition from Option A to the split model (per-service KV paths + per-service env templates) when signals appear such as:
- controlplane/cdn must not see seed user credentials,
- new jobs (harvester/router/publisher) need narrow subsets of secrets,
- rotation cadence diverges (tokens rotate frequently; DB creds do not),
- operator drift/overwrites occur in a large combined KV payload,
- exposure posture increases (even localhost-bound operator overlays).

### 3) Artifact-store bucket init approach (idempotent; no leakage)
Use a short-lived initializer on the v2 Docker network that:
1) waits for the artifact-store readiness,
2) creates the bucket if missing (ignore-existing), and
3) exits successfully without printing secrets.

Reference patterns (to adapt for v2):
- Legacy known-good: `modular-oss-saas/scripts/infra/bootstrap-cosmo.sh` (bucket init uses `minio/mc mb --ignore-existing` on the Docker network).
- Preferred (store-agnostic): use `aws s3api create-bucket --endpoint-url ...` from a pinned `amazon/aws-cli` helper container (works for MinIO and SeaweedFS S3).

### 4) Smoke probes (minimum)
Add probes that fail fast and enforce posture:
- Health:
  - Cosmo controlplane `GET /health` (container-local)
  - Artifact store health (container-local):
    - MinIO: `GET /minio/health/live`
    - SeaweedFS: probe S3 endpoint `:8333` and perform a minimal list/create call via an S3 client
  - ClickHouse `SELECT 1` (container-local)
  - Redis `PING` (container-local)
  - NATS readiness (container-local)
  - Cosmo Keycloak readiness (container-local)
- Posture:
  - No Traefik exposure: prove Traefik has no Cosmo/artifact-store routers (config inventory + negative curl checks).
  - No host binds (Option B): host `curl http://127.0.0.1:<cosmo/artifact-store ports>` should fail.
