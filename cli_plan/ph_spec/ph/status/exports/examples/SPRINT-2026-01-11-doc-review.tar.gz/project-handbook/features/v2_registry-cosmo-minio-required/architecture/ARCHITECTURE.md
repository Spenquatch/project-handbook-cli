---
title: v2 Registry Baseline (Cosmo + MinIO) Architecture
type: architecture
feature: v2_registry-cosmo-minio-required
date: 2026-01-06
tags: [architecture]
links:
  - ../../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
---

# Architecture: v2 Registry Baseline (Cosmo + MinIO)

## Overview
Cosmo is the required schema registry and composition gate for v2. The default stack includes an S3-compatible artifact store for Cosmo artifacts.
Everything runs internal-only by default (no Traefik exposure) with secrets seeded via Vault.

**Pending operator approval:** The baseline topology + version pins are defined in `project-handbook/decision-register/DR-0003-cosmo-minio-baseline-topology.md` and must be approved before implementation tasks mark it `Accepted`.

## Baseline inventory (pending approval; DR-0003 Recommendation = Option B)
All Cosmo services and the artifact store run on the v2 Docker network (`tribuence-v2-net`) and are **not exposed via Traefik**.

### Service + image pins
- **Cosmo services (pinned multi-arch digests; avoids Apple Silicon emulation):**
  - `ghcr.io/wundergraph/cosmo/controlplane@sha256:f31a50a2230c182673272983c8ccb89dc7d060c3094d8b929b4366d4617d741d`
  - `ghcr.io/wundergraph/cosmo/cdn@sha256:0d8fcbc3784206511ddcd27ede4eb6585ed89520c466521a9ada2f6b22af8d3b`
  - `ghcr.io/wundergraph/cosmo/studio@sha256:4d9aa4d6633ea535b1a50a77fd3b6dc41df7a70c5aabb9479ce903e099b77a18`
  - `ghcr.io/wundergraph/cosmo/keycloak@sha256:660b4b95810751cf052ac90273c9ccfe2d2d7e61275377e3ac6176ef87010f58`
- **Cosmo dependencies (pinned):**
  - ClickHouse: `clickhouse/clickhouse-server:24.12`
  - Redis (dedicated for Cosmo): `redis:7.2.4-alpine`
  - NATS: `nats:2.10.6`
- **Artifact storage (baseline now; pinned):**
  - MinIO: `bitnamilegacy/minio:2024.7.16-debian-12-r0`
  - Bucket init helper (one-shot): prefer `amazon/aws-cli` to create `COSMO_S3_BUCKET` via S3 API (avoid coupling to `minio/mc`).
- **Artifact storage (migration target; pending new decision/ADR):**
  - SeaweedFS: `chrislusf/seaweedfs:4.05` (S3 gateway via `weed server -s3`, endpoint `:8333`)
- **Shared v2 dependencies (already present):**
  - Postgres (shared v2 DB): `pgvector/pgvector:pg15`
  - Vault + Vault Agent: `hashicorp/vault:1.16.1`

### Datastores + persistence
- **Postgres**: stores Cosmo controlplane state (in dedicated DBs/roles inside the shared v2 Postgres).
- **ClickHouse**: stores Cosmo OpenTelemetry traces/metrics tables (Cosmo migrations create/maintain schema).
- **Artifact store (MinIO now)**: stores Cosmo artifacts in `COSMO_S3_BUCKET` (default `cosmo`).
- **Volumes (proposed):** `postgres-data-v2` (existing), plus dedicated Cosmo volumes for ClickHouse/Redis and artifact store data.

### Exposure posture (internal-only)
- **No Traefik exposure**: no Traefik routers/labels for Cosmo or the artifact store.
- **Host binds (default)**: none (strict internal-only; no `ports:` for Cosmo or the artifact store in the default stack).
- If operator host access becomes required later, introduce an explicit operator-only overlay (separate decision) that binds ports to `127.0.0.1` only.

## Components
- **Artifact store (S3-compatible)**: MinIO now; SeaweedFS is the preferred migration target (pending decision/ADR).
- **Cosmo controlplane**: schema registry + composition checks API.
- **Cosmo CDN**: artifact serving surface used by Cosmo.
- **Cosmo Keycloak**: auth for Cosmo services.
- **Cosmo dependencies**: ClickHouse (telemetry), Redis (runtime state), NATS (events).
- **Vault + Vault Agent**: seeds and renders `/secrets/minio.env` (or a future `/secrets/artifacts.env`) and `/secrets/cosmo.env`.
- **Vault + Vault Agent**: seeds and renders `/secrets/minio.env`, `/secrets/cosmo.env`, and `/secrets/artifacts.env` (single source of truth for the artifact store; reused for MinIO baseline and SeaweedFS cutover).

## Data Flow
1) Vault bootstrap seeds Cosmo/MinIO secrets into v2 KV paths.
2) Vault Agent renders `/secrets/minio.env` and `/secrets/cosmo.env`.
3) Bucket initializer ensures required bucket(s) exist for Cosmo artifacts.
4) Cosmo services start and become healthy on the v2 network.

## Dependencies
- Vault KV v2 (`kv/data/tribuence/v2/{cosmo,minio}`).
- Postgres for Cosmo controlplane DB (shared v2 Postgres).
