---
title: Tribuence Mini V2 Risks
type: risks
feature: tribuence-mini-v2
date: 2026-01-02
tags: [risks]
links:
  - ./overview.md
  - ./status.md
  - ../../sprints/current/plan.md
  - ../../contracts/tribuence-mini-v2/vault-secrets.md
  - ../../adr/0014-tribuence-mini-v2-auth-gated-ui-bff-and-security-posture.md
---

# Risk Register: Tribuence Mini V2

## High Priority Risks
- **Federation complexity (composition and schema drift)**
  - Impact: High
  - Probability: Medium
  - Mitigation: incremental subgraph bring-up (Twenty → Context → AnythingLLM), lock SDL snapshots, add smoke queries.
- **AnythingLLM GraphQL surface**
  - Impact: High
  - Probability: Medium
  - Mitigation: start with a minimal wrapper subgraph that covers workspace lifecycle + ingestion + chat runtime; expand iteratively.

## Medium Priority Risks
- **Secrets/bootstrap drift**
  - Impact: Medium
  - Probability: Medium
  - Mitigation: keep Vault bootstrap + templates in v2 and treat them as part of acceptance criteria.
- **Token leakage via service/UI logging**
  - Impact: Medium
  - Probability: Medium
  - Mitigation: configure log redaction for `authorization`/cookies and sanitize browser-visible errors (`BUG-P1-20260105-0837`, `BUG-P1-20260105-083811`).
- **Keycloak admin console exposed with default credentials (local/dev)**
  - Impact: Medium
  - Probability: Low
  - Mitigation: require non-default admin password (or seed from Vault) before exposing `keycloak.local` (`BUG-P1-20260105-083807`).
- **Keycloak ↔ NextAuth client secret drift**
  - Impact: Medium
  - Probability: Medium
  - Mitigation: ensure the Keycloak client secret is set deterministically (scripted) and not committed into `v2/infra/compose/keycloak/realm.json`; capture evidence and operator notes in `TASK-003`/`TASK-004`.
- **AnythingLLM API key provisioning (local/dev determinism)**
  - Impact: Medium
  - Probability: Medium
  - Mitigation: make `ANYLLM_API_KEY` strategy explicit (operator-provided vs minted-in-container) and ensure bootstrap does not rely on placeholders.
- **AnythingLLM workspace scoping + ingestion ambiguity (upload/docs/chat)**
  - Impact: Medium
  - Probability: Medium
  - Mitigation: enforce truthful workspace slug semantics and verifiable UI state; add E2E coverage for ensure/upload/query flows (`TASK-014`–`TASK-016`).
- **Twenty token provisioning + misleading “submit that fails” UX**
  - Impact: Medium
  - Probability: Medium
  - Mitigation: gate the Twenty UI based on `/api/healthz` dependency status and provide deterministic “how to seed TWENTY_API_KEY” guidance; add E2E coverage for missing-token + configured-token flows (`TASK-017`).
- **Local DNS / host routing drift (`*.local`)**
  - Impact: Medium
  - Probability: Medium
  - Mitigation: standardize on `curl --resolve ...` probes in smoke/validation docs; document any required `/etc/hosts` entries in `v2/docs/README.md` once UI work lands.
- **Tooling availability (Rover / schema composition)**
  - Impact: Medium
  - Probability: Medium
  - Mitigation: prefer `docker run ... ghcr.io/apollographql/rover` on the compose network so composition/introspection does not depend on host-installed tools.
- **Cosmo infra footprint (ClickHouse/NATS/MinIO)**
  - Impact: Medium
  - Probability: Medium
  - Mitigation: keep Cosmo behind an explicit compose overlay/profile; default internal-only posture; add deterministic Vault bootstrap + minimal smoke probes before enabling by default.

## Risk Mitigation Strategies
- Keep `v2/ARCHITECTURE.md` canonical and update as decisions change.
- Prefer small, runnable slices that land a working `make v2-up` + `make v2-smoke` early.
