---
title: Investigate: UI module artifact origin + publish pipeline (S3 + integrity) - Commands
type: commands
date: 2026-01-11
task_id: TASK-026
tags: [commands]
links: []
---

# Commands: Investigate: UI module artifact origin + publish pipeline (S3 + integrity)

## Task Status
```bash
pnpm -C project-handbook make -- task-status id=TASK-026 status=doing
pnpm -C project-handbook make -- task-status id=TASK-026 status=review
pnpm -C project-handbook make -- task-status id=TASK-026 status=done
```

## Evidence Directory (required)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-026"
mkdir -p "$EVID_DIR"
${EDITOR:-vi} "$EVID_DIR/index.md"
```

## Read Context (capture as evidence)
```bash
set -euo pipefail

sed -n '1,240p' project-handbook/adr/0025-v2-1-ui-module-registry.md | tee "$EVID_DIR/adr-0025.txt"
DR_PATH="project-handbook/features/v2.1_ui-module-registry-discovery/decision-register/DR-0001-ui-module-artifact-origin-and-publish-pipeline.md"
${EDITOR:-vi} "$DR_PATH"
```

## Inventory v2 Artifact Store + Vault Patterns (repo inspection only)
```bash
rg -n "seaweed|minio|artifact|s3" v2/infra/compose/docker-compose.v2.yml -S | tee "$EVID_DIR/v2-artifact-store-inventory.txt" || true
find v2/infra/vault/templates -maxdepth 1 -type f -print | tee "$EVID_DIR/v2-vault-template-inventory.txt"
sed -n '1,220p' project-handbook/features/v2_registry-cosmo-minio-required/fdr/0001-vault-secrets-contract-cosmo-minio.md | tee "$EVID_DIR/fdr-0001.txt"
```

## Handbook Validation
```bash
pnpm -C project-handbook make -- validate
```
