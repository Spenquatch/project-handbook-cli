---
title: Project Changelog
type: changelog
date: 2025-09-12
tags: [changelog]
links: []
---

## [Unreleased]

### Added
- Initial handbook scaffolding (refs: ADR-0001)

## [0.1.0] - 2025-09-12
### Added
- Seeds for ADR, FDR, feature template, execution phase, and validation stubs

