---
id: ADR-0009
title: Task Review + Approval Workflow
type: adr
status: draft
date: 2026-01-02
tags: [adr, process, review]
links:
  - ../process/sessions/templates/task-review.md
---

# ADR-0009: Task Review + Approval Workflow

## Context
Sprint tasks currently move to `review` after execution, but the handbook does not yet provide a standardized session template for reviewers to:
- select tasks that are in `review`,
- confirm task deliverables and acceptance criteria,
- rerun validations where feasible, and
- verify that the codebase matches claims recorded in the task’s `validation.md` / `checklist.md`.

This leads to inconsistent review depth and increases the chance of “approved” tasks drifting from their documented evidence.

## Decision
Add a dedicated session template (`process/sessions/templates/task-review.md`) that guides a reviewer through:
- finding tasks in `review`,
- reviewing full task scope (docs + deliverables + risks),
- verifying codebase state against recorded claims (spot checks + rerun validations),
- recording review evidence, and
- approving (move to `done`) or rejecting (move back to `doing` + create follow-ups).

## Consequences
- Reviews become consistent and repeatable.
- Tasks in `review` include stronger evidence and fewer “assumed” validations.
- Reviewers have a single place to document the decision and next steps.

