---
title: v2 Workspace Signup Onboarding Testing
type: testing
feature: v2_workspace-signup-onboarding
date: 2026-01-07
tags: [testing]
links:
  - ../../adr/0026-v2-workspace-signup-onboarding.md
  - ../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
---

# Testing: v2 Workspace Signup Onboarding

## Test Strategy
- **Integration**: workspace onboarding flow creates a Context workspace and selects it for the session.
- **Integration**: workspace creation triggers provisioning jobs and updates Context capability state.
- **E2E**: Playwright validates register/login → onboarding → landing harness render.

## Test Cases
1) New user registers in Keycloak and logs into the v2 UI; onboarding form renders (no workspace selected).
2) User submits onboarding form; workspace is created and selected; UI redirects to landing harness.
3) Context capability surface reports provisioning status for the new workspace.
4) User can log out/in and the workspace selection persists via the supported mechanism.

## Acceptance Criteria
- [ ] Keycloak self-registration + login works end-to-end into the v2 UI.
- [ ] On first login without a workspace, the UI forces workspace onboarding and creates a Context workspace.
- [ ] Workspace creation triggers Context provisioning and capability status updates.
- [ ] Playwright E2E covers the onboarding path using the landing harness as the post-onboarding surface.
