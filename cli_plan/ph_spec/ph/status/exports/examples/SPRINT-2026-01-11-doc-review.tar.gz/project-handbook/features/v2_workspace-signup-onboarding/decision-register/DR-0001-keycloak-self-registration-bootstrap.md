---
title: DR-0001 — Keycloak Self-Registration Bootstrap (Realm Config Automation)
type: decision-register
date: 2026-01-08
tags: [decision-register, keycloak, onboarding]
links:
  - ../overview.md
  - ../fdr/0001-keycloak-self-registration-bootstrap.md
  - ../../../../adr/0026-v2-workspace-signup-onboarding.md
---

# Decision Register Entry

### DR-0001 — Keycloak Self-Registration Bootstrap (Realm Config Automation)

**Decision owner(s):** @spenser  
**Date:** 2026-01-08  
**Status:** Accepted  
**Related docs:** `ADR-0026`, `FDR-v2_workspace-signup-onboarding-0001`, `project-handbook/features/v2_workspace-signup-onboarding/implementation/KEYCLOAK_SELF_REGISTRATION.md`

**Problem / Context**
- This DR ID was reserved during sprint planning to enable a `session=research-discovery` task; it must be completed in `TASK-004` and requires operator/user approval before being marked `Accepted`.
- v2 onboarding depends on Keycloak self-registration being enabled and stable in local/dev.
- Realm settings drift is a recurring failure mode; we need deterministic bootstrap + a drift-detecting smoke check.

**Option A — Versioned realm export/import (repo-tracked)**
- **Pros:**
  - Matches the current v2 wiring: Keycloak starts with `--import-realm` and mounts a repo-tracked `realm.json`.
  - Easy to review: a single tracked JSON export is the “config contract”.
  - Keeps the bootstrap surface inside infra-as-code (compose + realm JSON), not runtime mutation.
  - Secrets stay out of git: the realm import intentionally excludes the confidential client secret.
- **Cons:**
  - Keycloak realm import only happens on the first boot of a fresh container; realm changes require recreating Keycloak.
  - Drift is not automatically remediated: if an operator changes realm settings in the UI, those changes persist until Keycloak is recreated.
  - Realm export JSON can be incomplete (e.g., password policy / user profile) unless explicitly maintained and re-exported.
- **Cascading implications:**
  - Local/dev “apply changes” becomes: edit `v2/infra/compose/keycloak/realm.json` then recreate Keycloak (documented in `v2/infra/compose/keycloak/README.md`).
  - CI/gate runners can drift-detect by querying Keycloak state and comparing to expected values from the tracked realm export.
  - Vault remains the source of truth for the Keycloak confidential client secret (not committed).
- **Risks:**
  - Drift slips in unnoticed if smoke checks are not run (mitigation: add a launch gate smoke check that queries realm + client config).
  - Recreate-on-change can be disruptive if local/dev relies on persisted users (mitigation: keep it local/dev-only; provide a clear “this resets auth users” warning).
  - Keycloak export/import compatibility can change across versions (mitigation: pin Keycloak image tag in compose and include drift smoke checks in the gate runner).
- **Unlocks:**
  - Deterministic local bring-up for v2 onboarding (`ADR-0026`) with a single source-of-truth realm config.
  - A gate runner can prove auth posture (redirect URIs + registration enabled) without manual UI checks.
- **Quick wins / low-hanging fruit:**
  - Enable self-registration by updating `"registrationAllowed": true` in `v2/infra/compose/keycloak/realm.json` (currently `false`) and documenting the re-import procedure.
  - Add a smoke check (admin API query) that fails fast if `registrationAllowed` is false or NextAuth client redirect URIs drift.
  - Evidence-backed plan doc: `project-handbook/features/v2_workspace-signup-onboarding/implementation/KEYCLOAK_SELF_REGISTRATION.md`

**Option B — Idempotent admin CLI/REST configuration script**
- **Pros:**
  - Can enforce settings on every run (drift remediation), not just detect drift.
  - Can apply changes without resetting the Keycloak container (no “recreate to re-import” requirement).
  - A single script can configure realm settings, client redirect URIs, and any missing policy/user-profile settings.
- **Cons:**
  - Requires admin credentials at runtime; increases the blast radius of “who can run bootstrap”.
  - More moving parts: idempotency logic, Keycloak API stability, error handling, and output contracts.
  - Higher risk of accidentally logging secret values if not carefully implemented.
- **Cascading implications:**
  - Adds a new automation surface (e.g., `v2/scripts/keycloak/bootstrap-realm.sh`) that must be called by `make v2-up` or a gate runner after Keycloak is healthy.
  - Must define an audit trail (where does the script write evidence? what does it consider “desired state”?).
  - Needs a stable mechanism to find/update the NextAuth client (query by `clientId=tribuence-mini-v2` then patch).
- **Risks:**
  - Script breaks when Keycloak API/CLI output changes (mitigation: pin Keycloak version; keep the script small; validate against `kcadm.sh` JSON outputs).
  - Admin creds handling becomes a frequent source of failure (mitigation: fail-fast on default creds; document required env; avoid printing secrets).
  - Partial configuration can leave the realm in an inconsistent state (mitigation: explicit step ordering + “all-or-nothing” checks).
- **Unlocks:**
  - Drift remediation can be fully automated and run continuously (CI, local bring-up, or launch gates).
  - Password policy / user profile / required actions can be enforced even if they’re awkward to maintain in a static realm export.
- **Quick wins / low-hanging fruit:**
  - Start with a read-only “smoke check” script using `kcadm.sh` (drift detection only) and graduate it to a mutating bootstrap after confidence.

**Recommendation**
- **Recommended:** Option A — Versioned realm export/import (repo-tracked)
- **Rationale:**
  - Option A matches the current v2 implementation surfaces (compose + realm import) and keeps the “desired state” reviewable and repo-tracked.
  - Drift risk is real, but can be handled with a deterministic smoke check in a launch gate runner (fail fast + capture evidence) without introducing a new mutating script surface yet.
  - Option B remains viable if drift remediation becomes mandatory, but it is more operationally complex and raises the stakes of admin-credential usage.

**Follow-up tasks (explicit)**
- Evidence referenced:
  - `project-handbook/status/evidence/TASK-004/v2-infra-keycloak-wiring.txt`
  - `project-handbook/status/evidence/TASK-004/compose-keycloak-snippet.txt`
  - `project-handbook/status/evidence/TASK-004/compose-keycloak-realm-mentions.txt`
- `TASK-004` (research-discovery): complete this DR and the execution-ready plan doc:
  - `project-handbook/features/v2_workspace-signup-onboarding/implementation/KEYCLOAK_SELF_REGISTRATION.md`
- After operator/user approval (do not start until approved):
  - Create an execution task to update `v2/infra/compose/keycloak/realm.json` for local/dev posture:
    - set `"registrationAllowed": true`
    - add a baseline `"passwordPolicy"` (start with `length(12)` unless overridden)
    - confirm/adjust user-profile “email required” in UI and re-export to JSON
  - Create an execution task to add a drift-detecting smoke check (likely via `kcadm.sh`) and capture evidence files:
    - OIDC discovery probe output
    - realm JSON output (via admin API)
    - client JSON output (via admin API)
  - Integrate the smoke check into the gate runner (see `TASK-006` / `ADR-0028`).

**Operator/user approval request**
- Please reply with approval for **Option A (realm export/import)** or request switching to **Option B (idempotent admin script)**. Keep this DR as `Proposed` until approval is confirmed.
