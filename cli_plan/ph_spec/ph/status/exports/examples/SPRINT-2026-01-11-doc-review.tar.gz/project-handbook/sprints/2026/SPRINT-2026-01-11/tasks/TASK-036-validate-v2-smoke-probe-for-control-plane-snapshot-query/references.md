---
title: Validate: v2 smoke probe for control-plane snapshot query - References
type: references
date: 2026-01-11
task_id: TASK-036
tags: [references]
links: []
---

# References: Validate: v2 smoke probe for control-plane snapshot query

## Internal References

### Decision Context
- **Decision**: [FDR-v2_context-control-plane-schema-0001](../../../../features/v2_context-control-plane-schema/fdr/0001-context-control-plane-snapshot-contract.md)
- **Feature**: [Feature overview](../../../../features/v2_context-control-plane-schema/overview.md)
- **Architecture**: [Feature architecture](../../../../features/v2_context-control-plane-schema/architecture/ARCHITECTURE.md)

### Code References (repo root)
- **Smoke harness**: [v2/scripts/v2-smoke.sh](../../../../../v2/scripts/v2-smoke.sh)
- **Smoke target**: [v2/Makefile](../../../../../v2/Makefile)
- **Runtime supergraph snapshot used by smoke**: `v2/infra/compose/graphql/supergraph-local.graphql`

### Related Tasks
- `TASK-035` (dependency): adds/updates `contextControlPlaneSnapshot` and ensures schema snapshot is updated.

### Sprint Context
- **Sprint Plan**: [Current sprint](../../plan.md)
- **Sprint Tasks**: [All sprint tasks](../)
- **Daily Progress**: [Daily status](../../daily/)

## Notes
- If the new probe fails with “field missing”, re-check that the runtime supergraph snapshot file contains
  `contextControlPlaneSnapshot` and that `TASK-035` is actually `done` in the sprint.
