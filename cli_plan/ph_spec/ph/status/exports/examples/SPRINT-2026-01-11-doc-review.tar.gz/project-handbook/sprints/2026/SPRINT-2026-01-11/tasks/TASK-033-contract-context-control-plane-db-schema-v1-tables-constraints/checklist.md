---
title: Contract: Context control-plane DB schema (v1 tables + constraints) - Completion Checklist
type: checklist
date: 2026-01-11
task_id: TASK-033
tags: [checklist]
links: []
---

# Completion Checklist: Contract: Context control-plane DB schema (v1 tables + constraints)

## Pre-Work
- [ ] Confirm all `depends_on` tasks are `done` (must include `TASK-029`)
- [ ] Re-read `project-handbook/features/v2_context-control-plane-schema/fdr/0001-context-control-plane-snapshot-contract.md`
- [ ] Re-read `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` (current v0 contract)

## During Execution
- [ ] Create evidence directory: `project-handbook/status/evidence/TASK-033/`
- [ ] Capture “before” excerpt evidence (`context-db-schema-before.txt`)
- [ ] Update `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` additively:
- [ ] Keep v0 tables (`context_workspaces`, `context_references`) intact
- [ ] Add a v1 section defining new tables + constraints (no placeholders):
- [ ] `capability_manifests` (desired state) with `unique (tenant_id, workspace_id, capability_id)`
- [ ] `capability_status` (observed state) with `unique (tenant_id, workspace_id, capability_id)`
- [ ] `integration_links` (provider mapping) with `unique (tenant_id, workspace_id, capability_id)` and “no secrets” posture
- [ ] `integration_jobs` with idempotency uniqueness including `idempotency_key`
- [ ] `integration_job_runs` with `unique (tenant_id, job_id, run_number)` and FK → `integration_jobs`
- [ ] `setup_guidance` with deterministic identifiers and `unique (tenant_id, workspace_id, capability_id, guidance_key)`
- [ ] `ui_module_manifests` with deterministic module pointer (`module_id`, `version`, `integrity_sha256`) and sha format constraint
- [ ] Add a “Suggested SQL DDL (v1 additions)” section with `CREATE TABLE IF NOT EXISTS` examples
- [ ] Capture “after” excerpt evidence (`context-db-schema-after.txt`) + `context-db-schema.diff`

## Before Review
- [ ] Run `pnpm -C project-handbook make -- validate`
- [ ] Ensure `validation.md` lists all required evidence files (no placeholders)
- [ ] Set status to `review` via `pnpm -C project-handbook make -- task-status id=TASK-033 status=review`

## After Completion
- [ ] Peer review approved
- [ ] Move status to `done` with `pnpm -C project-handbook make -- task-status id=TASK-033 status=done`
