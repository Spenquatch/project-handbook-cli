---
title: Implement: UI module runtime loader (Option A browser verify + mode flag) - Completion Checklist
type: checklist
date: 2026-01-11
task_id: TASK-037
tags: [checklist]
links: []
---

# Completion Checklist: Implement: UI module runtime loader (Option A browser verify + mode flag)

## Pre-Work
- [ ] Confirm all `depends_on` tasks are `done`
- [ ] Review `README.md`, `steps.md`, `commands.md`
- [ ] Re-read `project-handbook/features/v2.1_ui-module-registry-discovery/fdr/0002-nextjs-runtime-module-loading-strategy.md`

## During Execution
- [ ] Implement `loadUiModule()` (single abstraction) with `moduleLoaderMode` flag
- [ ] Implement Option A behavior (`browser-verify`): sha256 verify-before-execute + Blob URL ESM import
- [ ] Implement deterministic reason codes + export validation + telemetry event emission
- [ ] Add Vitest coverage for the above

## Before Review
- [ ] Run `pnpm -C project-handbook make -- validate`
- [ ] Capture evidence under `project-handbook/status/evidence/TASK-037/` (per `validation.md`)
  - [ ] `project-handbook/status/evidence/TASK-037/index.md` exists (API + mode flag + reason codes summary)
  - [ ] `project-handbook/status/evidence/TASK-037/lint.txt` exists
  - [ ] `project-handbook/status/evidence/TASK-037/typecheck.txt` exists
  - [ ] `project-handbook/status/evidence/TASK-037/test.txt` exists
- [ ] Set status to `review` via `pnpm -C project-handbook make -- task-status id=TASK-037 status=review`

## After Completion
- [ ] Peer review approved and merged
- [ ] Move status to `done` via `pnpm -C project-handbook make -- task-status id=TASK-037 status=done`
