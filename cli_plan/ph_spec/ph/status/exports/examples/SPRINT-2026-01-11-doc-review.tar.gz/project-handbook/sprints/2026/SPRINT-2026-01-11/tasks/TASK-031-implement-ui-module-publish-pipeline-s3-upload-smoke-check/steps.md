---
title: Implement: UI module publish pipeline (S3 upload + smoke check) - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-031
tags: [implementation]
links: []
---

# Implementation Steps: Implement: UI module publish pipeline (S3 upload + smoke check)

## Overview
Implement a repeatable publish + smoke validation workflow for UI module artifacts per
`FDR-v2_1_ui-module-registry-discovery-0001`.

## Prerequisites
- [ ] `TASK-030` is `done` (the proxy route exists so the smoke check can validate end-to-end)
- [ ] Internal S3 access is available (v2 uses `seaweedfs`; S3 env keys are available server-side)
- [ ] `app.local` resolves locally OR validation will use `curl --resolve "app.local:80:127.0.0.1"`

## Step 1 — Define the publish inputs/outputs (contract)
Inputs:
- `moduleId`
- `version`
- path to built `index.mjs`

Outputs:
- computed `integritySha256` (64-char lowercase hex digest over file bytes)
- uploaded object at `s3://COSMO_S3_BUCKET/ui-modules/{moduleId}/{version}/{integritySha256}/index.mjs`

## Step 2 — Implement publish command/script
Implement a small shell script (preferred for parity with existing v2 helper scripts):
- `v2/scripts/ui-modules/publish-ui-module.sh`

Hard requirements:
- computes sha256 from file bytes,
- performs `put-object` to the exact key scheme,
- refuses to overwrite an existing object (append-only posture),
- never prints secret values.

Required interface (stable, copy/paste-friendly):
- Flags: `--moduleId`, `--version`, `--file`
- Stdout: exactly one line `moduleId=<...> version=<...> integritySha256=<...>`
- Stderr: operational logs ok (no secrets)
- Exit codes:
  - `0` success
  - `2` usage error / missing inputs
  - `3` object already exists (append-only refusal)
  - `4` upload failed

Implementation approach (explicit; avoid requiring host access to internal S3):
- Use `docker compose -f v2/infra/compose/docker-compose.v2.yml run --rm cosmo-artifact-probe ...` to execute `aws s3api` inside the v2 network with `/secrets/artifacts.env` loaded.
- Mount the module file into the helper container read-only.

## Step 3 — Implement smoke check (S3 + proxy route)
Implement a smoke check that:
1. Verifies the object exists in S3 (HEAD or GET).
2. Fetches bytes through the UI proxy route and verifies sha256 matches.

Suggested location:
- `v2/scripts/ui-modules/smoke-ui-module-origin.sh`

Required interface (stable):
- Flags: `--moduleId`, `--version`, `--integritySha256`
- Flags: `--origin` (default `http://app.local`) and `--resolve` (default `app.local:80:127.0.0.1`)
- Stdout: human-friendly pass/fail lines (no secrets)
- Exit codes: `0` pass, non-`0` fail

## Step 4 — Evidence capture
Capture evidence under `project-handbook/status/evidence/TASK-031/` per `validation.md`.

## Notes
- Keep the script output stable and copy/paste-friendly; it should produce the tuple `{moduleId, version, integritySha256}` for manifest wiring.
