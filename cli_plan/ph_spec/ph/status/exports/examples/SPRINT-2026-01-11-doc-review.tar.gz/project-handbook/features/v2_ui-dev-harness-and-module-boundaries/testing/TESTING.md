---
title: v2 UI Dev Harness + Module-Ready Boundaries Testing
type: testing
feature: v2_ui-dev-harness-and-module-boundaries
date: 2026-01-07
tags: [testing]
links:
  - ../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
  - ../../adr/0018-v2-capability-detection-surface.md
---

# Testing: v2 UI Dev Harness + Module-Ready Boundaries

## Test Strategy
- **E2E**: landing harness is the canonical entrypoint for capability tests.
- **Integration**: capability panels render deterministic gated states based on Context capability data.
- **Security**: no secrets are rendered in HTML, logs, or error banners.

## Test Cases
1) Login → select workspace → assert harness renders panels based on Context capabilities.
2) Disable a capability → assert panel renders gated state and interactive controls are disabled/absent.
3) Enable a capability → assert panel interactive UI is available and actions succeed.
4) Assert no panel reads env-based readiness by changing only Context capability state and observing UI behavior.

## Acceptance Criteria
- [ ] Landing page is the canonical dev harness used by Playwright E2E flows.
- [ ] Capability panels are gated exclusively by Context capability state.
- [ ] Capability panels enforce module-ready boundaries (no env reads, no querystring readiness, no secrets in UI).
