---
title: v2.1 UI Module Registry (Discovery)
type: overview
feature: v2.1_ui-module-registry-discovery
date: 2026-01-07
tags: [feature]
links: [./architecture/ARCHITECTURE.md, ./implementation/IMPLEMENTATION.md, ./testing/TESTING.md]
dependencies: ["ADR-0025", "ADR-0024", "ADR-0018", "ADR-0022", "ADR-0015", "v2_ui-dev-harness-and-module-boundaries", "v2_context-control-plane-schema", "v2_registry-cosmo-minio-required"]
backlog_items:
  - WORK-P2-20260107-104645
  - WORK-P2-20260107-104653
  - WORK-P2-20260107-161505
parking_lot_origin: null  # Original parking lot ID if promoted
capacity_impact: planned  # planned (80%) or reactive (20%)
epic: false
---

# v2.1 UI Module Registry (Discovery)

## Purpose
Discovery work to validate the module registry runtime approach (Next.js runtime loading + internal MinIO-backed artifact
origin + integrity checks) and produce an execution-ready implementation plan.

## Outcomes
- Validate runtime loading of a remote capability panel in the UI shell with allowlist + version pin + sha256 integrity.
- Validate MinIO-backed module artifact origin and publish pipeline posture.
- Produce the concrete execution plan for `v2.1_ui-module-registry-execution`.

## State
- Stage: approved
- Owner: @spenser

## Scope
- This feature does not deliver the production runtime module registry; it delivers validated discovery outputs only.
- v2 panels remain in-repo; discovery validates extraction and loading feasibility without retrofits.

## Backlog Integration
- Related Issues: ["WORK-P2-20260107-104645", "WORK-P2-20260107-104653", "WORK-P2-20260107-161505"]
- Capacity Type: planned  # Uses 80% allocation
- Parking Lot Origin: null  # Set if promoted from parking lot

## Key Links
- [Architecture](./architecture/ARCHITECTURE.md)
- [Implementation](./implementation/IMPLEMENTATION.md)
- [Testing](./testing/TESTING.md)
- [Status](./status.md)
- [Changelog](./changelog.md)
