---
id: FDR-v2_1_ui-module-registry-discovery-0002
title: Next.js runtime module loading strategy (Option A browser verify + Blob URL)
type: fdr
status: accepted
date: 2026-01-12
tags: [v2.1, ui, modules, registry, nextjs, integrity, allowlist, fdr]
links:
  - ../overview.md
  - ../decision-register/DR-0002-nextjs-runtime-module-loading-strategy.md
  - ../fdr/0001-ui-module-artifact-origin-and-publish-pipeline.md
  - ../../../adr/0025-v2-1-ui-module-registry.md
  - ../../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
  - ../../../status/evidence/TASK-027/index.md
---

# Decision

Adopt **Option A** from `DR-0002`: the browser verifies sha256 **before execute** and imports module code via **Blob URL ESM**.

# Scope

In scope:
- v2.1 runtime loader behavior (allowlist, integrity verification posture, execution mechanism).
- Module format + export contract used by the UI shell.
- Deterministic failure semantics and telemetry for module load outcomes.
- A deliberate “low-lift” transition path from Option A → Option B.

Out of scope:
- Artifact origin and publish pipeline (see `FDR-v2_1_ui-module-registry-discovery-0001`).
- Context schema and snapshot query contracts (owned by control-plane schema FDRs).

# Implementation Contract (Execution Work References This)

## Stable contracts (must not change between Option A and Option B)
- **Manifest fields**: `{ moduleId, version, integritySha256 }` (Context-owned per `ADR-0025`).
- **Fetch URL**: `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}` (same-origin; `FDR-...-0001`).
- **Artifact format**: single-file ESM `index.mjs`.
- **Module contract**:
  - required exports: `default` (React component), `capabilityId` (string),
  - optional exports: `panelTitle`, `panelVersion`,
  - deterministic failure reason codes + a stable telemetry event shape.
- **Loader API**: implement a single abstraction (example: `loadUiModule()`), with:
  - `moduleLoaderMode = "browser-verify" | "server-verify"`.

## Option A (accepted): browser-verify + Blob URL ESM import
- **Client-only execution**: the loader runs in the browser only (do not SSR-execute module code).
- **Verify-before-execute**:
  - fetch bytes from `/api/ui-modules/...`,
  - compute sha256 in the browser and compare to `integritySha256`,
  - only after a match: `Blob` → `URL.createObjectURL()` → `import(blobUrl)`.
- **Caching posture**:
  - route returns `Cache-Control: public, max-age=31536000, immutable`,
  - loader caches the loaded module in-memory keyed by `{moduleId, version, integritySha256}`.

## Deterministic failure semantics (required)
The UI must render a deterministic panel-scoped fallback state (shell continues rendering).

Failure reason codes (stable identifiers):
- `NOT_ALLOWLISTED`
- `FETCH_404`
- `FETCH_FAILED`
- `HASH_MISMATCH`
- `EVAL_ERROR`
- `EXPORT_INVALID`

## Telemetry (required, no secrets)
Emit `ui_module_load_result` with:
- `{ moduleId, version, integritySha256, outcome, reasonCode, durationMs }`
- optional `correlationId` if the server route returns one on error responses.

# When to transition to Option B (server verify + import by URL) — explicit triggers

Transition when one or more of these become true:
- **CSP hardening blocks `blob:`**: security posture requires a CSP that does not allow `script-src blob:`.
- **Client CPU is measurable**: hashing/import overhead increases p95/p99 time-to-interactive on supported devices.
- **Browser compatibility issues**: Blob URL ESM import has unacceptable edge-case failures in supported browsers.
- **Operational simplicity**: prefer minimal client logic and standard `import(url)` caching semantics.

# Transition plan: Option A → Option B (expected lift)

Expected lift is **low-ish** if the “stable contracts” above are followed.

Mechanical steps:
1) Update the server route to enforce “verify-before-serve” (it must not return bytes unless verified for the requested `{integritySha256}`).
2) Flip `moduleLoaderMode` to `"server-verify"` and change the loader to `import(/* webpackIgnore: true */ url)`.
3) Re-run the same E2E suite; expected user-visible behavior (panel states + reason codes) remains unchanged.

# Status

Accepted (operator approved Option A in `DR-0002` on 2026-01-12).
