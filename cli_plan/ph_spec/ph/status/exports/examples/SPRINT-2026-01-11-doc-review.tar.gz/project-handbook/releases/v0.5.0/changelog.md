---
title: Release v0.5.0 Changelog
type: changelog
version: v0.5.0
date: 2026-01-11
tags: [changelog, release]
links: []
---

# Changelog: v0.5.0

## Release Summary
Released on January 11, 2026

## Features Delivered
- **v2_registry-cosmo-minio-required**: Feature description
- **v2_schema-publishing-and-composition**: Feature description
- **v2_schema-harvester-service**: Feature description
- **v2_codegen-from-registry**: Feature description


## Tasks Completed
*Auto-generated from sprint tasks*

## Breaking Changes
- None

## Migration Guide
- No migration required

## Known Issues
- None

## Contributors
- Team members who contributed
