---
title: Contract: Context control-plane snapshot GraphQL contract (v1) - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-032
tags: [implementation]
links: []
---

# Implementation Steps: Contract: Context control-plane snapshot GraphQL contract (v1)

## Overview
Update the Context subgraph contract (`project-handbook/contracts/tribuence-mini-v2/context-subgraph.md`) to define the
**v1 control-plane snapshot query** and the **consumer contract** required by the UI and wrapper subgraphs.

This task is contract/documentation work (no `v2/` code changes).

## Prerequisites
- `TASK-029` is `done`.
- Decision is accepted: `FDR-v2_context-control-plane-schema-0001`.

## Step 1 — Capture evidence index
1. Create `project-handbook/status/evidence/TASK-032/index.md`.
2. Capture “before” excerpts so review can see what changed:
   - `context-subgraph-before.txt` (grep output)
   - a short “before” excerpt in `index.md` (copy/paste 5–15 relevant lines from `context-subgraph-before.txt`)

## Step 2 — Update the Context subgraph contract (v1 snapshot)
Update `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md` **additively**:

1. Keep the existing v0 contract intact (workspaces + references).
2. Add a new section for the v1 control-plane snapshot contract that includes:
   - query name + input semantics,
   - SDL (types + fields),
   - consumer contract (headers, wrapper transport, timeout/fallback).

### 2.1 Canonical query + input semantics (no ambiguity)
- Query name: `contextControlPlaneSnapshot`
- Signature: `contextControlPlaneSnapshot(workspaceId: ID): ContextControlPlaneSnapshot!`
- Semantics:
  - `workspaceId` argument may be omitted.
  - If omitted, Context must use `x-workspace-id` (parity with existing v0 reference APIs).
  - If both are missing, the query must fail with `BAD_USER_INPUT`.

### 2.2 Minimal v1 SDL (additive; extend later)
Add an SDL block that defines the minimal v1 snapshot surface. Use `extend type Query` to avoid rewriting the v0
contract block.

Required snapshot fields (all arrays must be empty-safe, never `null`):
- `workspace: ContextWorkspace!`
- `manifests: [ContextCapabilityManifest!]!`
- `statuses: [ContextCapabilityStatus!]!`
- `integrationLinks: [ContextIntegrationLinkSummary!]!`
- `jobs: [ContextIntegrationJobSummary!]!`
- `setupGuidance: [ContextSetupGuidance!]!`
- `uiModuleManifests: [ContextUiModuleManifest!]!`
- `generatedAt: DateTime!`

Minimum type contracts (fields may be extended additively later; do not remove/rename):
- `ContextCapabilityManifest { capabilityId, enabled, updatedAt }`
- `ContextCapabilityStatus { capabilityId, state, detail, updatedAt }`
- `ContextIntegrationLinkSummary { capabilityId, providerType, providerWorkspaceId, providerWorkspaceSlug, credentialRefId, state, detail, updatedAt }`
- `ContextIntegrationJobSummary { jobId, capabilityId, jobType, state, detail, updatedAt }`
- `ContextSetupGuidance { capabilityId, guidanceKey, guidanceId, detail, updatedAt }`
- `ContextUiModuleManifest { capabilityId, moduleId, version, integritySha256, updatedAt }`

### 2.3 Consumer contract (UI + wrappers)
Document this **explicitly in the contract** (not just in the FDR):
- **Headers**:
  - `x-tenant-id` required (production contract; local/dev may default as already documented for v0).
  - `x-workspace-id` required unless `workspaceId` is provided.
- **UI transport**: UI queries via Apollo Router (normal GraphQL traffic).
- **Wrapper transport**:
  - wrapper subgraphs call Context directly (service-to-service),
  - forward `x-tenant-id`, `x-workspace-id`, and `authorization` (if present),
  - wrappers must not call Apollo Router for gating (avoid recursion/composition ambiguity).
- **Timeout + fallback**:
  - consumer timeout must be strict (recommended default 1500ms),
  - on error/timeout, consumers default to deterministic “stub / gated” behavior,
  - caching posture defaults to `no-store` (do not allow stale “enabled” state).

## Step 3 — Update validation docs
1. Update `validation.md` to match the finalized contract sections (no placeholders).
2. Ensure the evidence file list is explicit and complete (see `validation.md`).
3. Run `pnpm -C project-handbook make -- validate`.

## Step 4 — Submit for review
1. Set status to `review` via `pnpm -C project-handbook make -- task-status id=TASK-032 status=review`.
