---
title: Implement: UI module publish pipeline (S3 upload + smoke check) - Validation Guide
type: validation
date: 2026-01-11
task_id: TASK-031
tags: [validation]
links: []
---

# Validation Guide: Implement: UI module publish pipeline (S3 upload + smoke check)

## Automated Validation
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Manual Validation (Must Be Task-Specific)
Create `project-handbook/status/evidence/TASK-031/` and capture:

### 1) Publish a module artifact
```bash
EVID_DIR="project-handbook/status/evidence/TASK-031"
mkdir -p "$EVID_DIR"

MODULE_ID="example"
VERSION="0.0.0"

cat >"$EVID_DIR/index.mjs" <<'EOF'
export const hello = () => 'hello';
EOF

INTEGRITY_SHA256="$(python3 - <<'PY'
import hashlib
path = "project-handbook/status/evidence/TASK-031/index.mjs"
with open(path, "rb") as f:
  print(hashlib.sha256(f.read()).hexdigest())
PY
)"
printf '%s\n' "$INTEGRITY_SHA256" | tee "$EVID_DIR/index.mjs.sha256.txt"

# Expected: script prints integritySha256 and uploads to COSMO_S3_BUCKET under ui-modules/
bash v2/scripts/ui-modules/publish-ui-module.sh \
  --moduleId "$MODULE_ID" \
  --version "$VERSION" \
  --file "$EVID_DIR/index.mjs" \
  | tee "$EVID_DIR/publish-output.txt"
```

**Pass criteria**
- Output includes the computed `integritySha256`.
- Publish is append-only (script refuses to overwrite an existing object).

### 2) Smoke check end-to-end (S3 + proxy route)
```bash
bash v2/scripts/ui-modules/smoke-ui-module-origin.sh \
  --moduleId "$MODULE_ID" \
  --version "$VERSION" \
  --integritySha256 "$INTEGRITY_SHA256" \
  --origin "http://app.local" \
  --resolve "app.local:80:127.0.0.1" \
  | tee "$EVID_DIR/smoke-output.txt"
```

**Pass criteria**
- Script verifies object exists in S3.
- Script fetches bytes via `http://app.local/api/ui-modules/...` and sha256 matches `integritySha256`.

## Evidence (required)
- `project-handbook/status/evidence/TASK-031/index.mjs`
- `project-handbook/status/evidence/TASK-031/index.mjs.sha256.txt`
- `project-handbook/status/evidence/TASK-031/publish-output.txt`
- `project-handbook/status/evidence/TASK-031/smoke-output.txt`

## Sign-off
- [ ] All validation steps completed
- [ ] Evidence documented above
- [ ] Ready to mark task as "done"
