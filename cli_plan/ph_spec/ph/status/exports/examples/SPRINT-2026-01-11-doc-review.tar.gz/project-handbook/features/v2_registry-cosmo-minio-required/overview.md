---
title: v2 Registry Baseline (Cosmo + MinIO)
type: overview
feature: v2_registry-cosmo-minio-required
date: 2026-01-06
tags: [feature]
links: [./architecture/ARCHITECTURE.md, ./implementation/IMPLEMENTATION.md, ./testing/TESTING.md]
dependencies: ["ADR-0015"]
backlog_items: []  # Related P0-P4 issues from backlog
parking_lot_origin: null  # Original parking lot ID if promoted
capacity_impact: planned  # planned (80%) or reactive (20%)
epic: false
---

# v2 Registry Baseline (Cosmo + MinIO)

## Purpose
Make Cosmo + MinIO (and required Cosmo dependencies) a required part of the default v2 stack so schema publishing,
composition checks, and artifact storage are deterministic across all capabilities.

## Outcomes
- `make v2-up` brings up Cosmo + MinIO in the default stack (internal-only posture).
- Vault seeds and renders Cosmo/MinIO secrets without printing them.
- MinIO bucket initialization is automated and idempotent.
- Smoke probes enforce baseline health (Cosmo, MinIO, ClickHouse, Redis, NATS, Cosmo Keycloak).

## State
- Stage: approved
- Owner: @spenser

## Scope
- Required Cosmo + MinIO services are present in the default v2 compose wiring.
- No Traefik routers for Cosmo/MinIO; any operator ports bind to `127.0.0.1` only.

## Backlog Integration
- Related Issues: []  # List any P0-P4 items this addresses
- Capacity Type: planned  # Uses 80% allocation
- Parking Lot Origin: null  # Set if promoted from parking lot

## Acceptance
See `project-handbook/features/v2_registry-cosmo-minio-required/testing/TESTING.md`.

## Key Links
- [Architecture](./architecture/ARCHITECTURE.md)
- [Implementation](./implementation/IMPLEMENTATION.md)
- [Testing](./testing/TESTING.md)
- [Status](./status.md)
- [Changelog](./changelog.md)
