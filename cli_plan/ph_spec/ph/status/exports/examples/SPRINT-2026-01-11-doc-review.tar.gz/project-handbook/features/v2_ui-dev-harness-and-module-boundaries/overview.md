---
title: v2 UI Dev Harness + Module-Ready Boundaries
type: overview
feature: v2_ui-dev-harness-and-module-boundaries
date: 2026-01-07
tags: [feature]
links: [./architecture/ARCHITECTURE.md, ./implementation/IMPLEMENTATION.md, ./testing/TESTING.md]
dependencies: ["ADR-0024", "ADR-0018", "ADR-0022", "v2_capability-detection-surface"]
backlog_items:
  - BUG-P1-20260105-083811
parking_lot_origin: null  # Original parking lot ID if promoted
capacity_impact: planned  # planned (80%) or reactive (20%)
epic: false
---

# v2 UI Dev Harness + Module-Ready Boundaries

## Purpose
Use the existing auth-gated v2 landing page as the required dev harness for validating capabilities via UI and
Playwright, while enforcing module-ready UI boundaries so v2.1 module registry work does not require a retrofit.

## Outcomes
- The landing page is the single supported UI harness for capability development and E2E testing.
- Each capability UI is implemented behind a stable “capability panel” boundary with a deterministic interface.
- Capability visibility/gating is driven only by Context capability state (no env/url guessing).
- Capability UI panels can be moved into a future module registry without changing their internal contracts.

## State
- Stage: approved
- Owner: @spenser

## Scope
- v2 uses the existing landing page as the harness and keeps capability panels in-repo.
- v2 enforces module-ready boundaries (stable panel interface + routing/data access rules).
- v2 does not implement a module registry or module federation runtime; it enforces compatibility constraints only.

## Backlog Integration
- Related Issues: ["BUG-P1-20260105-083811"]
- Capacity Type: planned  # Uses 80% allocation
- Parking Lot Origin: null  # Set if promoted from parking lot

## Acceptance
See `project-handbook/features/v2_ui-dev-harness-and-module-boundaries/testing/TESTING.md`.

## Key Links
- [Architecture](./architecture/ARCHITECTURE.md)
- [Implementation](./implementation/IMPLEMENTATION.md)
- [Testing](./testing/TESTING.md)
- [Status](./status.md)
- [Changelog](./changelog.md)
