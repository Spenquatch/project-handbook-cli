---
title: Implement: UI module runtime loader (Option A browser verify + mode flag) - Validation Guide
type: validation
date: 2026-01-11
task_id: TASK-037
tags: [validation]
links: []
---

# Validation Guide: Implement: UI module runtime loader (Option A browser verify + mode flag)

## Automated Validation
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Manual Validation (Must Be Task-Specific)
Run v2 unit checks and capture evidence files.

```bash
set -euo pipefail
EVID_DIR="project-handbook/status/evidence/TASK-037"
mkdir -p "$EVID_DIR"

pnpm -C v2/apps/tribuence-mini lint 2>&1 | tee "$EVID_DIR/lint.txt"
pnpm -C v2/apps/tribuence-mini typecheck 2>&1 | tee "$EVID_DIR/typecheck.txt"
pnpm -C v2/apps/tribuence-mini test 2>&1 | tee "$EVID_DIR/test.txt"
```

**Pass criteria**
- `lint`, `typecheck`, and `test` all exit `0`.
- Loader behavior matches `FDR-v2_1_ui-module-registry-discovery-0002`:
  - Option A (`browser-verify`) verifies sha256 before execute and imports via Blob URL ESM.
  - Loader exposes a mode flag with a clear A → B switch point (`"browser-verify" | "server-verify"`).
  - Failures map to deterministic reason codes (no secrets).

## Evidence (required)
- `project-handbook/status/evidence/TASK-037/index.md`
- `project-handbook/status/evidence/TASK-037/lint.txt`
- `project-handbook/status/evidence/TASK-037/typecheck.txt`
- `project-handbook/status/evidence/TASK-037/test.txt`

## Sign-off
- [ ] All validation steps completed
- [ ] Evidence documented above
- [ ] Ready to mark task as "done"
