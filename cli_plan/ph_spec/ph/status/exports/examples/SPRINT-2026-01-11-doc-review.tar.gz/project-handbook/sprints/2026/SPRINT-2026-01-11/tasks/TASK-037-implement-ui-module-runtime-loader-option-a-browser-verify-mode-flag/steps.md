---
title: Implement: UI module runtime loader (Option A browser verify + mode flag) - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-037
tags: [implementation]
links: []
---

# Implementation Steps: Implement: UI module runtime loader (Option A browser verify + mode flag)

## Overview
Implement the runtime loader contract from `FDR-v2_1_ui-module-registry-discovery-0002`:
- a single loader abstraction with a mode flag (`browser-verify` now; `server-verify` later),
- verify sha256 **before execute** in the browser (Option A),
- deterministic failure reason codes and non-secret telemetry.

## Prerequisites
- [ ] `TASK-030` is `done` (the byte origin route exists: `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}`)
- [ ] v2 app dev/test tooling works locally:
  - `pnpm -C v2/apps/tribuence-mini test`

## Step 0 — Create evidence directory + index (before touching code)
1. Create `project-handbook/status/evidence/TASK-037/index.md`.
2. Record the intended loader API shape + mode flag and link the governing decision:
   - `project-handbook/features/v2.1_ui-module-registry-discovery/fdr/0002-nextjs-runtime-module-loading-strategy.md`

## Step 1 — Lock the contracts (no drift)
1. Re-read:
   - `project-handbook/features/v2.1_ui-module-registry-discovery/fdr/0002-nextjs-runtime-module-loading-strategy.md`
   - `project-handbook/features/v2.1_ui-module-registry-discovery/fdr/0001-ui-module-artifact-origin-and-publish-pipeline.md`
2. Confirm what must be treated as stable:
   - manifest fields: `{ moduleId, version, integritySha256 }`
   - fetch URL: `/api/ui-modules/{moduleId}/{version}/{integritySha256}`
   - reason codes + telemetry schema

## Step 2 — Implement the loader abstraction (Option A now, Option B switch later)
1. Add a single loader entrypoint at:
   - `v2/apps/tribuence-mini/src/lib/ui-module-loader.ts` (must export `loadUiModule()`)
2. Hard requirements:
   - Expose `moduleLoaderMode: "browser-verify" | "server-verify"` (mode flag exists even if only one is implemented now).
   - Option A behavior for `"browser-verify"`:
     - fetch bytes from the same-origin route,
     - compute sha256 in the browser (WebCrypto) and compare to `{integritySha256}` (hex),
     - only after match: Blob URL ESM `import()`,
     - validate exports: `default` (React component) + `capabilityId` (string).
   - Deterministic failure reason mapping (`NOT_ALLOWLISTED`, `FETCH_404`, `FETCH_FAILED`, `HASH_MISMATCH`, `EVAL_ERROR`, `EXPORT_INVALID`).
   - Emit a telemetry event (names + fields per FDR; no secrets).
3. Keep module-id allowlist logic in:
   - `v2/apps/tribuence-mini/src/lib/ui-modules.ts` (create if missing)

### Step 2a — Keep the implementation unit-testable (Vitest runs in Node)
Vitest uses `environment: "node"` in `v2/apps/tribuence-mini/vitest.config.ts`, so structure the loader with small units:
- a pure-ish `validateUiModuleExports(ns)` that returns `EXPORT_INVALID` deterministically
- a `sha256Hex(bytes)` helper that uses `globalThis.crypto.subtle.digest` (Node 20 provides WebCrypto)
- an import shim that can be mocked in tests (e.g. a function that takes bytes → returns module namespace)

This lets you cover the security posture without needing `URL.createObjectURL` to exist in Node.

## Step 3 — Tests (minimum bar)
Add Vitest coverage to lock security posture and future refactors:
- allowlist enforcement (unknown moduleId ⇒ `NOT_ALLOWLISTED`)
- sha256 format validation and mismatch ⇒ `HASH_MISMATCH`
- export validation ⇒ `EXPORT_INVALID`
- evaluation failure (module throws) ⇒ `EVAL_ERROR`

## Step 4 — Evidence capture
Capture evidence under `project-handbook/status/evidence/TASK-037/`:
- `index.md` describing the loader API + mode flag + reason codes
- `lint.txt`, `typecheck.txt`, `test.txt` command outputs (per `validation.md`)

## Notes
- Do not log secrets or dump `/secrets/*.env`.
