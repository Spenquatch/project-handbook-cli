---
title: Implement: UI module origin proxy route (Option A) - Validation Guide
type: validation
date: 2026-01-11
task_id: TASK-030
tags: [validation]
links: []
---

# Validation Guide: Implement: UI module origin proxy route (Option A)

## Automated Validation
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Manual Validation (Must Be Task-Specific)
Create `project-handbook/status/evidence/TASK-030/` and capture:

### 1) Seed one known module artifact into internal S3
```bash
EVID_DIR="project-handbook/status/evidence/TASK-030"
mkdir -p "$EVID_DIR"

cat >"$EVID_DIR/index.mjs" <<'EOF'
export const hello = () => 'hello';
EOF

INTEGRITY_SHA256="$(python3 - <<'PY'
import hashlib
path = "project-handbook/status/evidence/TASK-030/index.mjs"
with open(path, "rb") as f:
  print(hashlib.sha256(f.read()).hexdigest())
PY
)"
printf '%s\n' "$INTEGRITY_SHA256" | tee "$EVID_DIR/index.mjs.sha256.txt"

MODULE_ID="example"
VERSION="0.0.0"

docker compose -f v2/infra/compose/docker-compose.v2.yml run --rm \
  -e MODULE_ID="$MODULE_ID" \
  -e VERSION="$VERSION" \
  -e INTEGRITY_SHA256="$INTEGRITY_SHA256" \
  -v "$(pwd)/$EVID_DIR:/evid:ro" \
  --entrypoint /opt/healthcheck/with-env-file.sh \
  cosmo-artifact-probe \
  /secrets/artifacts.env sh -lc '
    KEY="ui-modules/${MODULE_ID}/${VERSION}/${INTEGRITY_SHA256}/index.mjs"
    aws --no-cli-pager --endpoint-url "$S3_ENDPOINT_URL" s3api put-object \
      --bucket "$COSMO_S3_BUCKET" \
      --key "$KEY" \
      --body /evid/index.mjs \
      --content-type "text/javascript; charset=utf-8" \
      >/dev/null
  '
```

### 2) Route behavior (curl)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-030"
mkdir -p "$EVID_DIR"

MODULE_ID="example"
VERSION="0.0.0"
INTEGRITY_SHA256="$(cat "$EVID_DIR/index.mjs.sha256.txt")"

curl -sS --resolve "app.local:80:127.0.0.1" \
  -D "$EVID_DIR/headers.txt" \
  -o "$EVID_DIR/body.mjs" \
  "http://app.local/api/ui-modules/${MODULE_ID}/${VERSION}/${INTEGRITY_SHA256}"

python3 - <<'PY' "$EVID_DIR/body.mjs" | tee "$EVID_DIR/body.sha256.txt"
import hashlib,sys
path=sys.argv[1]
with open(path,"rb") as f:
  print(hashlib.sha256(f.read()).hexdigest())
PY
```

**Pass criteria**
- Response status is `200`.
- `Cache-Control` includes `immutable` (content-addressed artifact).
- `sha256(body.mjs)` matches `INTEGRITY_SHA256`.

### 3) Allowlist + input validation enforcement
```bash
curl -sS -D "$EVID_DIR/headers-unknown-module.txt" -o /dev/null \
  --resolve "app.local:80:127.0.0.1" \
  "http://app.local/api/ui-modules/not-allowlisted/${VERSION}/${INTEGRITY_SHA256}" || true

curl -sS -D "$EVID_DIR/headers-invalid-sha.txt" -o /dev/null \
  --resolve "app.local:80:127.0.0.1" \
  "http://app.local/api/ui-modules/${MODULE_ID}/${VERSION}/not-a-sha256" || true
```

**Pass criteria**
- Response is `404` (or `403`) and does not proxy arbitrary S3 keys.
- Invalid sha is rejected (non-`200`) without attempting to proxy arbitrary keys.

## Evidence (required)
- `project-handbook/status/evidence/TASK-030/index.mjs`
- `project-handbook/status/evidence/TASK-030/index.mjs.sha256.txt`
- `project-handbook/status/evidence/TASK-030/headers.txt`
- `project-handbook/status/evidence/TASK-030/body.mjs`
- `project-handbook/status/evidence/TASK-030/body.sha256.txt`
- `project-handbook/status/evidence/TASK-030/headers-unknown-module.txt`
- `project-handbook/status/evidence/TASK-030/headers-invalid-sha.txt`

## Sign-off
- [ ] All validation steps completed
- [ ] Evidence documented above
- [ ] Ready to mark task as "done"
