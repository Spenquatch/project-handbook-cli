---
title: Task TASK-030 - Implement: UI module origin proxy route (Option A)
type: task
date: 2026-01-11
task_id: TASK-030
feature: v2.1_ui-module-registry-discovery
session: task-execution
tags: [task, v2.1_ui-module-registry-discovery]
links: [../../../../../features/v2.1_ui-module-registry-discovery/overview.md]
---

# Task TASK-030: Implement: UI module origin proxy route (Option A)

## Overview
- **Feature**: [v2.1_ui-module-registry-discovery](../../../../../features/v2.1_ui-module-registry-discovery/overview.md)
- **Decision**: [FDR-v2_1_ui-module-registry-discovery-0001](../../../../../features/v2.1_ui-module-registry-discovery/fdr/0001-ui-module-artifact-origin-and-publish-pipeline.md)
- **Story Points**: 3
- **Owner**: @spenser
- **Lane**: `module-registry/origin`
- **Session**: `task-execution`

## Agent Navigation Rules
1. **Start work**: `pnpm -C project-handbook make -- task-status id=TASK-030 status=doing`
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: `pnpm -C project-handbook make -- task-status id=TASK-030 status=review`

## Context & Background
This task implements the [FDR-v2_1_ui-module-registry-discovery-0001](../../../../../features/v2.1_ui-module-registry-discovery/fdr/0001-ui-module-artifact-origin-and-publish-pipeline.md) decision for the [v2.1_ui-module-registry-discovery] feature.

## What You Are Building (contract summary)
- A same-origin Next.js route: `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}`
- It maps to the internal object key: `ui-modules/{moduleId}/{version}/{integritySha256}/index.mjs` in `COSMO_S3_BUCKET`
- It must be **strictly allowlisted** by `moduleId` and must never proxy arbitrary bucket/keys
- It must set immutable caching headers for content-addressed artifacts

## Quick Start
```bash
pnpm -C project-handbook make -- task-status id=TASK-030 status=doing
cd project-handbook/sprints/current/tasks/TASK-030-implement-ui-module-origin-proxy-route-option-a/

# Follow implementation
cat steps.md              # Read implementation steps
cat commands.md           # Copy-paste commands
cat validation.md         # Validation approach
```

## Dependencies
Hard dependencies (must be `done` before execution):
- `TASK-027` — defines the runtime allowlist + integrity behavior this route must enforce.

Operational/system dependencies (must exist for validation):
- v2 stack uses internal S3-compatible storage (`seaweedfs`) and `COSMO_S3_BUCKET` exists.
- `v2-ui` container has server-side access to the S3 env vars listed in `steps.md` (via Vault-rendered env file).

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.

## Evidence
All evidence for this task must be captured under `project-handbook/status/evidence/TASK-030/` (see `validation.md`).
