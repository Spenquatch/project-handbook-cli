---
title: Implement: UI module origin proxy route (Option A) - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-030
tags: [implementation]
links: []
---

# Implementation Steps: Implement: UI module origin proxy route (Option A)

## Overview
Implement the approved Option A origin model from `FDR-v2_1_ui-module-registry-discovery-0001`:
- The browser fetches module bytes from a **same-origin** Next.js route.
- The Next.js server fetches module bytes from the internal S3-compatible store (`seaweedfs`) using server-side credentials.

## Prerequisites
- [ ] `TASK-027` is `done` (runtime allowlist/integrity behavior is defined so this route can enforce the same allowlist)
- [ ] Local v2 stack can reach S3 internally (v2 uses `seaweedfs`)
- [ ] Vault renders S3 env for the v2 UI (this task’s implementation assumes `v2-ui` receives the S3 env via `/secrets/next.env`)
- [ ] `app.local` resolves locally (preferred) OR you will use `curl --resolve "app.local:80:127.0.0.1"` in validation

## Step 1 — Confirm the contract you must implement
1. Re-read:
   - `project-handbook/features/v2.1_ui-module-registry-discovery/fdr/0001-ui-module-artifact-origin-and-publish-pipeline.md`
2. Record the exact contract (you will implement it verbatim):
   - Route: `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}`
   - Storage key: `ui-modules/{moduleId}/{version}/{integritySha256}/index.mjs`
   - Bucket: `COSMO_S3_BUCKET`

## Step 2 — Ensure `v2-ui` has server-side S3 env
This route runs server-side in Next.js, so it needs the same S3 env used elsewhere in v2.

1. Confirm the current S3 env canonical source:
   - `v2/infra/vault/templates/artifacts.env.tpl` (authoritative list of S3 env keys for v2)
2. Confirm how `v2-ui` receives env:
   - `v2/infra/compose/docker-compose.v2.yml` (`v2-ui` entrypoint reads `/secrets/next.env`)
3. Implementation requirement (make it true before coding the route):
   - Update `v2/infra/vault/templates/next.env.tpl` to include these keys (populated from the same Vault secret sources as `artifacts.env.tpl`):
     - `S3_ENDPOINT_URL`
     - `S3_REGION`
     - `S3_ACCESS_KEY_ID`
     - `S3_SECRET_ACCESS_KEY`
     - `S3_FORCE_PATH_STYLE`
     - `COSMO_S3_BUCKET`

## Step 3 — Implement the proxy route (allowlist + stream)
1. Add the route handler:
   - `v2/apps/tribuence-mini/src/app/api/ui-modules/[moduleId]/[version]/[integritySha256]/route.ts`
2. Hard requirements:
   - **Allowlist** `moduleId` (exactly match the runtime allowlist defined by `TASK-027` outputs).
   - Validate `integritySha256` is a 64-char lowercase hex digest; reject invalid input before any S3 call.
   - Construct key exactly: `ui-modules/{moduleId}/{version}/{integritySha256}/index.mjs`.
   - Fetch from internal S3 and stream bytes (no unbounded buffering).
   - Always set:
     - `Content-Type: text/javascript; charset=utf-8`
     - `Cache-Control: public, max-age=31536000, immutable`
   - Error semantics:
     - unknown moduleId → `404` (preferred)
     - missing object → `404`
     - upstream S3 error → `502` with a terse body (no endpoints, no secrets)
3. Extract helpers (recommended for testability):
   - `v2/apps/tribuence-mini/src/lib/ui-modules.ts`:
     - `isAllowlistedModuleId(moduleId): boolean`
     - `buildUiModuleS3Key({ moduleId, version, integritySha256 }): string`
   - `v2/apps/tribuence-mini/src/lib/s3.ts`:
     - reads `S3_*` + `COSMO_S3_BUCKET`
     - configures path-style if `S3_FORCE_PATH_STYLE=true`

## Step 4 — Tests (minimum bar)
Add at least one unit test (Vitest) to lock the security posture:
- key construction is deterministic and exact
- allowlist rejects unknown values
- `integritySha256` validation rejects non-hex / wrong length

## Step 5 — Smoke validation (publish → serve → verify)
Follow `validation.md` to:
1. Seed one known `index.mjs` object into internal S3 at the exact key.
2. Fetch via the proxy route and verify:
   - status `200`
   - `Cache-Control` contains `immutable`
   - response bytes hash to `integritySha256`
3. Verify allowlist enforcement returns `404` for an unknown module.

## Notes
- This route must never expose S3 credentials or allow the caller to influence S3 bucket/key beyond the strict contract.
