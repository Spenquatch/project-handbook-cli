---
title: Tribuence Mini V2 Status
type: status
feature: tribuence-mini-v2
date: 2026-01-05
tags: [status]
links:
  - ./overview.md
  - ./risks.md
  - ../../sprints/current/plan.md
  - ../../releases/v0.4.0/plan.md
  - ../../adr/0014-tribuence-mini-v2-auth-gated-ui-bff-and-security-posture.md
  - ../../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
---

# Status: Tribuence Mini V2

Stage: developing

## Now
- Release focus is now `v0.4.0`: security posture + auth-gated UI + reliability (health endpoints) while preserving the Traefik public allowlist.
- Sprint planning remains anchored to `v2/ARCHITECTURE.md` and the v2 contracts under `project-handbook/contracts/tribuence-mini-v2/`.
- New decisions:
  - `ADR-0014` (auth-gated UI + minimal BFF endpoints + security posture)
  - `ADR-0015` (Cosmo/MinIO discovery path)

## Next
- Stabilize a minimal “workspace landing” UX that can be used daily: login → workspace select → AnythingLLM chat/upload → Twenty create.
- Decide the “next increment” for cross-plane services (Cosmo/MinIO) based on `TASK-012` discovery results (recommended: optional internal-only overlay; no Traefik exposure by default).
- Expand Twenty UI operations with a stable contract + codegen once the minimal create flow is proven.

## Current Sprint Tasks (SPRINT-2026-01-04-19)
- [`TASK-001` v0.4.0 security audit + threat model](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-001-v0-4-0-security-audit-threat-model/README.md)
- [`TASK-002` Traefik: expose keycloak.local (allowlist only)](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-002-traefik-expose-keycloak-local-allowlist-only/README.md)
- [`TASK-003` Keycloak: NextAuth client + redirect URI wiring](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-003-keycloak-nextauth-client-redirect-uri-wiring/README.md)
- [`TASK-004` Vault: seed NextAuth/Keycloak secrets + auth toggle](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-004-vault-seed-nextauth-keycloak-secrets-auth-toggle/README.md)
- [`TASK-005` v2 UI: NextAuth + middleware auth gate + login page](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-005-v2-ui-nextauth-middleware-auth-gate-login-page/README.md)
- [`TASK-006` v2 UI: landing flow (workspace select only)](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-006-v2-ui-landing-flow-workspace-select-only/README.md)
- [`TASK-007` v2 UI: AnythingLLM chat (+ optional upload) on landing](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-007-v2-ui-anythingllm-chat-optional-upload-on-landing/README.md)
- [`TASK-008` Twenty create flow: operation discovery + contract update](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-008-twenty-create-flow-operation-discovery-contract-update/README.md)
- [`TASK-009` v2 UI: Twenty create tool (server-side, no token leak)](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-009-v2-ui-twenty-create-tool-server-side-no-token-leak/README.md)
- [`TASK-010` v2 UI: GET /api/healthz aggregate](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-010-v2-ui-get-api-healthz-aggregate/README.md)
- [`TASK-011` v2 services: normalize health endpoints + checks](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-011-v2-services-normalize-health-endpoints-checks/README.md)
- [`TASK-012` Cosmo+MinIO discovery plan (docs + threats + wiring)](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-012-cosmo-minio-discovery-plan-docs-threats-wiring/README.md)
- [`TASK-013` Integration gate: validate auth + smoke + evidence](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-013-integration-gate-validate-auth-smoke-evidence/README.md)
- [`TASK-014` BUG-P2-20260105-182826: AnythingLLM ensure-workspace verifiable feedback + E2E](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-014-bug-p2-20260105-182826-anythingllm-ensure-workspace-verifiable-feedback-e2e/README.md)
- [`TASK-015` BUG-P2-20260105-184734: AnythingLLM upload workspace slug semantics + E2E](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-015-bug-p2-20260105-184734-anythingllm-upload-workspace-slug-semantics-e2e/README.md)
- [`TASK-016` BUG-P2-20260105-185349: AnythingLLM chat sees uploaded docs + E2E](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-016-bug-p2-20260105-185349-anythingllm-chat-sees-uploaded-docs-e2e/README.md)
- [`TASK-017` BUG-P2-20260105-183831: Twenty create-person token gating + E2E](../../sprints/archive/2026/SPRINT-2026-01-04-19/tasks/TASK-017-bug-p2-20260105-183831-twenty-create-person-token-gating-e2e/README.md)

## Cross-Task Dependencies (SPRINT-2026-01-04-19)
- `TASK-001` (`depends_on: [FIRST_TASK]`) → `TASK-002` → `TASK-003` → `TASK-004` → `TASK-005` → `TASK-006` → `TASK-007`
- `TASK-008` (depends on `TASK-001`) → `TASK-009` (also depends on `TASK-004` + `TASK-006`)
- `TASK-010` + `TASK-011` + `TASK-012` depend on `TASK-001`
- Integration gate: `TASK-013` depends on `TASK-005` + `TASK-009` + `TASK-010`
- AnythingLLM UX stabilization: `TASK-007` → `TASK-014` + `TASK-015` → `TASK-016`
- Twenty gating: `TASK-009` → `TASK-017`

## Planned Sprints (Draft)
- `../../sprints/current/plan.md` — current sprint tasks and sequencing
- `../../releases/v0.4.0/plan.md` — release scope and goals

## Completed Sprint Tasks (SPRINT-2026-01-12)
- [`TASK-003` v2 UI: ingestion workflow polish (upload + error shaping)](../../sprints/archive/2026/SPRINT-2026-01-12/tasks/TASK-003-v2-ui:-ingestion-workflow-polish-(upload-+-error-shaping)/README.md)
- [`TASK-004` v2 UI: chat workflow polish (sessions + sources UX)](../../sprints/archive/2026/SPRINT-2026-01-12/tasks/TASK-004-v2-ui:-chat-workflow-polish-(sessions-+-sources-ux)/README.md)

## Cross-Task Dependencies (SPRINT-2026-01-12)
- Cross-feature gate: `TASK-001` (feature: `handbook-hygiene`) → `TASK-003`
- `TASK-003` → `TASK-004`

## Completed (Archive)
- Sprint plan: `../../sprints/archive/2025/SPRINT-2025-12-22/plan.md`
- Sprint plan: `../../sprints/archive/2026/SPRINT-2026-01-02/plan.md`
- Task entrypoints:
  - `../../sprints/archive/2025/SPRINT-2025-12-22/tasks/TASK-005-v2-scaffold:-create-v2-skeleton/README.md`
  - `../../sprints/archive/2025/SPRINT-2025-12-22/tasks/TASK-006-v2-compose:-baseline-infra-stack/README.md`
  - `../../sprints/archive/2025/SPRINT-2025-12-22/tasks/TASK-007-v2-traefik:-app.local-+-router.local-routes/README.md`
  - `../../sprints/archive/2025/SPRINT-2025-12-22/tasks/TASK-008-v2-make:-v2-up-v2-down-entrypoints/README.md`
  - `../../sprints/archive/2025/SPRINT-2025-12-22/tasks/TASK-009-v2-vault:-agent-+-env-templates/README.md`
  - `../../sprints/archive/2025/SPRINT-2025-12-22/tasks/TASK-010-v2-vault:-bootstrap-v2-kv-seeds/README.md`
  - `../../sprints/archive/2025/SPRINT-2025-12-22/tasks/TASK-011-v2-router:-service-+-router.local-liveness/README.md`
  - `../../sprints/archive/2025/SPRINT-2025-12-22/tasks/TASK-012-v2-federation-assets:-subgraph-dirs-+-supergraph-snapshot/README.md`
  - `../../sprints/archive/2025/SPRINT-2025-12-22/tasks/TASK-013-v2-twenty-subgraph:-endpoint-auth-+-schema-snapshot/README.md`
  - `../../sprints/archive/2025/SPRINT-2025-12-22/tasks/TASK-014-v2-context:-service-skeleton-+-health-graphql/README.md`
  - `../../sprints/archive/2025/SPRINT-2025-12-22/tasks/TASK-015-v2-context:-db-schema-workspace-reference/README.md`
  - `../../sprints/archive/2025/SPRINT-2025-12-22/tasks/TASK-016-v2-context-subgraph:-resolvers-+-router-wiring/README.md`
  - `../../sprints/archive/2025/SPRINT-2025-12-22/tasks/TASK-017-handbook-task-review-approve-reject-session-template/README.md`
  - `../../sprints/archive/2026/SPRINT-2026-01-02/tasks/TASK-018-v2-smoke-harness/README.md`
  - `../../sprints/archive/2026/SPRINT-2026-01-02/tasks/TASK-019-v2-ui-graphql-only-bootstrap/README.md`
  - `../../sprints/archive/2026/SPRINT-2026-01-02/tasks/TASK-020-v2-anythingllm-api-key-bootstrap-strategy/README.md`
  - `../../sprints/archive/2026/SPRINT-2026-01-02/tasks/TASK-021-v2-compose:-add-anythingllm-service-(internal-only)/README.md`
  - `../../sprints/archive/2026/SPRINT-2026-01-02/tasks/TASK-022-v2-vault-bootstrap-twenty-api-key-provisioning-no-placeholder-overwrite/README.md`
  - `../../sprints/archive/2026/SPRINT-2026-01-02/tasks/TASK-023-twenty-smoke-probe-via-router/README.md`

## Risks
- Federation/schema composition complexity → mitigate with incremental subgraph bring-up and smoke queries.
- Upstream service integration (AnythingLLM surface) may require a wrapper → mitigate by scoping a minimal first subgraph and iterating.
- Chat runtime may require provider configuration → keep chat probes optional until stable.

## Recent
- Feature created
- `ADR-0007` drafted to formalize the v2 architecture decision.
- Added v2 contract docs under `project-handbook/contracts/tribuence-mini-v2/`.
- Handbook note: feature reporting now uses `sprints/current` for the current sprint id (resolved via `TASK-001` in `SPRINT-2026-01-12`).

## Reporting Note
- "Active Work (auto-generated)" is regenerated via `pnpm make -- feature-update-status` and derives the current sprint id from `sprints/current`.

## Active Work (auto-generated)
*Last updated: 2026-01-11*

### Current Sprint (SPRINT-2026-01-11)
- No active tasks in current sprint

### Recent Completed (last 5 tasks)
- ✅ TASK-023: Twenty smoke probe via Router (2pts) - SPRINT-2026-01-02
- ✅ TASK-019: v2 UI: GraphQL-only bootstrap (workspace/reference) (5pts) - SPRINT-2026-01-02
- ✅ TASK-020: v2 Vault bootstrap: deterministic AnythingLLM API key strategy (3pts) - SPRINT-2026-01-02
- ✅ TASK-018: v2 smoke harness (script + make target + docs) (3pts) - SPRINT-2026-01-02
- ✅ TASK-022: v2 vault bootstrap: TWENTY_API_KEY provisioning / no placeholder overwrite (3pts) - SPRINT-2026-01-02

### Metrics
- **Total Story Points**: 134 (planned)
- **Completed Points**: 134 (100%)
- **Remaining Points**: 0
- **Estimated Completion**: SPRINT-2026-W03
- **Average Velocity**: 21 points/sprint

