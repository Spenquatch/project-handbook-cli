---
title: Release v0.3.0 Plan
type: release-plan
version: v0.3.0
start_sprint: SPRINT-2026-01-12
end_sprint: SPRINT-2026-01-19
planned_sprints: 2
sprint_ids: [SPRINT-2026-01-12, SPRINT-2026-01-19]
status: delivered
date: 2026-01-03
delivered_sprint: SPRINT-2026-01-19
delivered_date: 2026-01-04
tags: [release, planning]
links: []
---

# Release v0.3.0

> Release status: **delivered** (completed in `SPRINT-2026-01-19`, archived on 2026-01-04).

## Release Summary
Deliver the first shippable `v2/` bring-up of Tribuence Mini: a local/dev stack that boots core infra + Twenty CRM + AnythingLLM behind a federated GraphQL supergraph, with a Context service for workspaces/reference IDs — and a GraphQL-only UI validated by `make v2-smoke`.

## Release Goals
1. **Primary Goal**: A stable `make v2-up` + `make v2-smoke` that validates the end-to-end v2 supergraph (Twenty + Context + AnythingLLM wrapper) and a GraphQL-only UI slice (workspace → ingest → chat).
2. **Secondary Goal**: A documented, repeatable local/dev workflow (Vault bootstrap, routing/DNS expectations, and troubleshooting) aligned to the v2 contracts under `project-handbook/contracts/tribuence-mini-v2/`.
3. **Stretch Goal**: Tighten smoke gates by enabling optional AnythingLLM upload/chat probes once provider + API key flows are deterministic.

## Release Type & Scope
- **Type**: minor (2 sprints)
- **In scope (must-have)**:
  - `make v2-up` boots the full v2 stack defined in `project-handbook/features/tribuence-mini-v2/overview.md`.
  - Supergraph composes and routes at least: Twenty + Context + AnythingLLM wrapper subgraphs.
  - v2 UI remains GraphQL-only and supports: workspace/reference selection, ingestion (upload + error shaping), chat (sessions + sources UX).
  - `make v2-smoke` passes consistently for required graphs and required probes (federation + core CRUD + UI-aligned operations).
  - v2 quickstart and troubleshooting docs updated (Vault/bootstrap + local routing + known gotchas).
- **Out of scope (explicitly not in this release)**:
  - Production deployment, hosting, CI/CD, and multi-env promotion.
  - Auth hardening beyond local/dev posture; SSO/role modeling.
  - Performance tuning, load testing, and observability/monitoring work.
  - Non-GraphQL API surfaces (no new REST proxies).
- **Scope flexibility**:
  - Locked:
    - GraphQL-only UI integration.
    - v2 contracts under `project-handbook/contracts/tribuence-mini-v2/` (interfaces and smoke spec).
    - Minimum runnable slice: Twenty → Context → AnythingLLM wrapper sequencing.
  - Flexible:
    - UI polish depth beyond the stated workflows (nice-to-haves defer).
    - Optional smoke probes (enabled only when provider config is stable).

## Sprint Timeline
- **SPRINT-2026-01-12** (Sprint 1 of 2): Close remaining v2 UI workflows (ingestion + chat), stabilize AnythingLLM wrapper integration, and align smoke probes to the minimum UI operations.
- **SPRINT-2026-01-19** (Sprint 2 of 2): Hardening + documentation pass: tighten smoke requirements where safe, fix edge-case failures, and prepare release notes + demo-ready checklist.


## Feature Assignments
- `tribuence-mini-v2` (critical path)

## Scope Control
- **Scope lock date**: End of Sprint 1 planning window (SPRINT-2026-01-12)
- **Change control**:
  - Default: new requests go to the next release
  - Exceptions: @spenser may swap in/out only scope-neutral fixes required for `make v2-smoke` reliability (document in this plan under “Risk Management”).

## Communication Plan
### Internal
- Announcement: Post release kickoff note linking `project-handbook/releases/v0.3.0/plan.md`.
- Progress cadence: weekly release health check
- Escalation path: escalate blockers via backlog issue + note in `status/daily/*` (owner: @spenser).

### Stakeholders
- Update cadence: end of each sprint (release-status summary).
- Demo date(s): End of Sprint 2 (SPRINT-2026-01-19).
- Release notes owner: @spenser

## Success Criteria
- [x] `make v2-up` boots without manual intervention beyond documented prerequisites.
- [x] Supergraph composes and exposes Twenty + Context + AnythingLLM wrapper subgraphs.
- [x] `make v2-smoke` passes 2× consecutively on a clean bring-up.
- [x] v2 UI completes the core workflows using GraphQL only: workspace/reference → ingestion → chat.
- [x] v2 quickstart/troubleshooting docs cover Vault/bootstrap + routing expectations (`*.local`) and smoke validation.

## Risk Management
- Critical path:
  - `tribuence-mini-v2` end-to-end federation + GraphQL-only UI flows.
  - Smoke reliability (tests are the release gate).
- Dependencies:
  - AnythingLLM API/provider behavior + deterministic API key provisioning (local/dev).
  - Federation composition stability (schema drift between subgraphs).
- Capacity:
  - Plan assumes 80/20 allocation; unexpected P0/P1 work may consume the reactive budget.
- Top risks (from feature risk register):
  - Federation complexity (composition + schema drift) → mitigate via incremental bring-up and locked SDL snapshots.
  - AnythingLLM GraphQL surface gaps → mitigate via minimal wrapper subgraph and iterative expansion.
  - Secrets/bootstrap drift → treat Vault templates + bootstrap as acceptance criteria.

## Release Notes Draft
*Auto-generated from completed tasks and features*

### How to run (validated)
Validated via:
- `project-handbook/status/evidence/TASK-002/` (gate)
- `project-handbook/status/evidence/TASK-003/` (stabilization)

```bash
# From repo root
make v2-down
make v2-up

# Run smoke gate (2× on same running stack)
make v2-smoke
make v2-smoke
```

**Smoke defaults used (no overrides required):**
- `V2_SMOKE_ROUTER_URL`: unset (default `http://router.local/`)
- `V2_SMOKE_MODE`: unset (default `router`)
- `V2_SMOKE_REQUIRE_GRAPHS`: unset (smoke asserts detected graphs from `v2/infra/compose/graphql/supergraph-local.graphql`)
- `V2_SMOKE_AUTHORIZATION`: unset (Twenty auth probe is skipped)

**Optional overrides (no secrets):**
- `TRAEFIK_ENTRYPOINT_HTTP` / `TRAEFIK_ENTRYPOINT_HTTPS`: override Traefik ports for the stack (defaults `80`/`443`)
- `V2_SMOKE_ROUTER_URL`: set if Traefik ports are overridden (example: `http://router.local:<port>/`)
- `V2_SMOKE_REQUIRE_GRAPHS`: require specific subgraphs (example: `ANYTHINGLLM,TWENTY,TRIBUENCE_CONTEXT`)
- `V2_SMOKE_AUTHORIZATION`: enable Twenty auth probe
- `V2_SMOKE_REQUIRE_ANYTHINGLLM_UPLOAD=true`: enforce upload probe
- `V2_SMOKE_REQUIRE_ANYTHINGLLM_CHAT=true`: enforce chat probe

### Known issues (if any)
Populated by `SPRINT-2026-01-19/TASK-004` from `TASK-003` deferrals.

- None (as of 2026-01-03; see `TASK-003` validation)

### Evidence
- `project-handbook/status/evidence/TASK-002/` (gate)
- `project-handbook/status/evidence/TASK-003/` (stabilization)

### Validated on
- OS: macOS 15.6.1 (Darwin 24.6.0)
- Docker: Docker Desktop 28.0.4 (Compose v2.34.0-desktop.1)
- CPU arch: arm64
