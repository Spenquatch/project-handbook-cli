---
title: v2 UI Dev Harness + Module-Ready Boundaries Risks
type: risks
feature: v2_ui-dev-harness-and-module-boundaries
date: 2026-01-07
tags: [risks]
links:
  - ../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
  - ../../adr/0018-v2-capability-detection-surface.md
---

# Risk Register: v2 UI Dev Harness + Module-Ready Boundaries

## High Priority Risks
- **UI gating relies on non-authoritative readiness signals**  
  - Impact: High  
  - Probability: Medium  
  - Mitigation: enforce Context-only capability gating and fail tests when env/querystring gating is detected.
- **Secret leakage through UI props or debug banners**  
  - Impact: High  
  - Probability: Low  
  - Mitigation: server-only actions; never render provider tokens; sanitize errors and ban env dumps (`TASK-003` enforces “no raw upstream bodies” + correlation IDs).

## Medium Priority Risks
- **Panel contract drift prevents future ModuleRegistry extraction**  
  - Impact: Medium  
  - Probability: Medium  
  - Mitigation: standardize the panel interface and validate composition via shared harness tests.

## Risk Mitigation Strategies
- Treat the landing harness as the single supported E2E entrypoint and keep it stable.
- Keep capability panels isolated and contract-first so future module loading is a packaging change only.
