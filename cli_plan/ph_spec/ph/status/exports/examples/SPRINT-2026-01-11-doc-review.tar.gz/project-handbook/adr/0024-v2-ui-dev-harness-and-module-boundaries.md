---
id: ADR-0024
title: v2 UI Dev Harness + Module-Ready Boundaries (Landing Page Harness)
type: adr
status: accepted
date: 2026-01-07
tags: [tribuence-mini, v2, ui, harness, e2e, capabilities]
links:
  - ../features/v2_ui-dev-harness-and-module-boundaries/overview.md
  - ../features/v2_capability-detection-surface/overview.md
  - ../features/v2_capability-manifests-and-toggles/overview.md
---

# Context

Tribuence needs a deterministic, auth-gated UI surface that developers and Playwright can use to validate capabilities
end-to-end. A future v2.1 UI module registry (ModuleRegistry/module federation/dynamic routing) must not require a v2
retrofit. v2 therefore enforces module-ready boundaries now, while using the existing landing page as the harness.

# Decision

## 1) The v2 landing page is the canonical dev harness

The v2 landing page is the single supported UI harness for:
- manual validation of capabilities,
- Playwright E2E test entrypoint for capability flows.

The harness is auth-gated and requires explicit Context workspace selection.

## 2) Capability panels are contract-first and module-ready

Each capability UI is implemented behind a stable “capability panel” boundary with these invariants:
- capability gating is driven exclusively by Context capability state,
- panels never read `process.env` for readiness and never use querystring banners as readiness signals,
- panels perform provider operations server-side only and never accept/emit provider secrets.

This boundary is the compatibility layer that allows v2.1 module registry work to become a packaging/loading change
without changing panel contracts.

## 3) Capability absence is deterministic and testable

When a capability is disabled or unprovisioned, the harness renders:
- a clearly gated panel state,
- deterministic setup guidance identifiers (no secrets),
- no interactive controls that appear usable.

# Consequences

## Positive
- One stable UI harness for capability development and E2E validation.
- Eliminates “UI guessed readiness” failures in local/dev.
- Avoids a retrofit when module registry work starts (panels already follow a stable contract).

## Tradeoffs
- The landing page harness must remain stable and comprehensive as new capabilities are added.

# Rollout / Acceptance

- The landing page is the canonical E2E entrypoint for capability tests.
- Capability panel gating is driven only by Context capability state.
- Capability panels do not read env/querystring readiness signals and do not render provider secrets.
