---
title: Implement: Context DB migrations for control-plane tables (v1) - Validation Guide
type: validation
date: 2026-01-11
task_id: TASK-034
tags: [validation]
links: []
---

# Validation Guide: Implement: Context DB migrations for control-plane tables (v1)

## Automated Validation
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Manual Validation (task-specific, no ambiguity)
Create `project-handbook/status/evidence/TASK-034/` and capture:

### 1) Context applies migrations with no errors (including after restart)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-034"
mkdir -p "$EVID_DIR"

KEYCLOAK_ADMIN=admin KEYCLOAK_ADMIN_PASSWORD=dev-not-admin make -C v2 v2-up
V2_VAULT_MINT_ANYLLM_API_KEY=true bash v2/scripts/vault/bootstrap-v2.sh

docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml logs --tail=200 context \
  | tee "$EVID_DIR/context-startup-logs.txt"

# Prove idempotency: restart Context (migrations run again)
docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml restart context
docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml logs --tail=200 context \
  | tee -a "$EVID_DIR/context-startup-logs.txt"
```

**Pass criteria**
- Context service is running and logs contain no SQL/migration errors on initial start or after restart.

### 2) Tables + indexes exist (and v0 tables preserved)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-034"

ls -1 v2/services/context/db/migrations/*.sql | tee "$EVID_DIR/migrations-ls.txt"

{
  echo "== tables ==";
  docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml exec -T postgres \
    psql -U postgres -d tribuence_v2 -c "\\dt" ;
  echo "";
  echo "== context_* indexes ==";
  docker compose -p tribuence-v2 -f v2/infra/compose/docker-compose.v2.yml exec -T postgres \
    psql -U postgres -d tribuence_v2 -c "select tablename, indexname from pg_indexes where schemaname='public' and tablename like 'context_%' order by tablename, indexname;" ;
} | tee "$EVID_DIR/psql-schema.txt"
```

**Pass criteria**
- `context_workspaces` and `context_references` still exist.
- All v1 control-plane tables required by the DB contract exist.

## Evidence (required)
- `project-handbook/status/evidence/TASK-034/index.md`
- `project-handbook/status/evidence/TASK-034/migrations-ls.txt`
- `project-handbook/status/evidence/TASK-034/context-startup-logs.txt`
- `project-handbook/status/evidence/TASK-034/psql-schema.txt`
- `project-handbook/status/evidence/TASK-034/handbook-validate.txt`

## Sign-off
- [ ] All validation steps completed
- [ ] Evidence documented above
- [ ] Ready to mark task as "done"
