---
title: Handbook: Close release v0.5.0 - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-024
tags: [implementation]
links: []
---

# Implementation Steps: Handbook: Close release v0.5.0

## Overview
This is a `session=task-execution` handbook task. The deliverable is a closed release record for `v0.5.0` plus updated status/reporting surfaces. No product code changes.

## Prerequisites
- `TASK-024` is the sprint’s `FIRST_TASK`.

## Step 1 — Capture current release status (evidence)
1. Create evidence directory `project-handbook/status/evidence/TASK-024/`.
2. Capture `release-status` output (before close).

Evidence to capture:
- `project-handbook/status/evidence/TASK-024/release-status.before.txt`

## Step 2 — Close the release
1. Run `pnpm -C project-handbook make -- release-close version=v0.5.0`.
2. Capture the command output.

Evidence to capture:
- `project-handbook/status/evidence/TASK-024/release-close.txt`

## Step 3 — Confirm release close + update status surfaces
1. Re-run `pnpm -C project-handbook make -- release-status` and capture output.
2. Run `pnpm -C project-handbook make -- status` and confirm `project-handbook/status/current_summary.md` references `SPRINT-2026-01-11` and lists the sprint tasks.
3. Run `pnpm -C project-handbook make -- dashboard` and confirm sprint reporting is coherent.

Evidence to capture:
- `project-handbook/status/evidence/TASK-024/release-status.after.txt`
- `project-handbook/status/evidence/TASK-024/status.txt`
- `project-handbook/status/evidence/TASK-024/dashboard.txt`

## Step 4 — Validate handbook + move to review
1. Run `pnpm -C project-handbook make -- validate`.
2. Update `validation.md` and `checklist.md` with the evidence file list.
3. Set task status to `review`.
