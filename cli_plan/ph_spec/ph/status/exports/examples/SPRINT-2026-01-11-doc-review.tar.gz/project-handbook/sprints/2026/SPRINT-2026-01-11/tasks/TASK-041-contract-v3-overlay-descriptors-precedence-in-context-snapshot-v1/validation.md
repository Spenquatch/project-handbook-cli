---
title: Contract: v3 overlay descriptors + precedence in Context snapshot (v1) - Validation Guide
type: validation
date: 2026-01-12
task_id: TASK-041
tags: [validation]
links: []
---

# Validation Guide: Contract: v3 overlay descriptors + precedence in Context snapshot (v1)

## Automated Validation
```bash
EVID_DIR="project-handbook/status/evidence/TASK-041"
mkdir -p "$EVID_DIR"

pnpm -C project-handbook make -- validate | tee "$EVID_DIR/validate.txt"
pnpm -C project-handbook make -- sprint-status | tee "$EVID_DIR/sprint-status.txt"
```

## Manual Validation (Pass/Fail; no ambiguity)
- `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md` includes, additively:
  - `ContextControlPlaneSnapshot.overlays: [ContextOverlayDescriptor!]!` (empty-safe)
  - `ContextOverlayDescriptor` type with fields:
    - `overlayId: String!`, `version: String!`, `integritySha256: String!`
    - `scope: ContextOverlayScope!` (TENANT | WORKSPACE | CAPABILITY)
    - `capabilityId: String` (nullable)
    - `priority: Int!`
  - Explicit deterministic precedence rules:
    - apply overlays ascending by `priority`,
    - tie-break deterministically by `overlayId`,
    - overlays cannot bypass capability gating.
- `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` v1 includes an explicit `overlay_bindings` binding/storage contract that:
  - is tenant-scoped,
  - is optionally workspace-scoped / capability-scoped,
  - preserves deterministic precedence via `priority` + deterministic tie-breaker (`overlay_id`),
  - does not store secrets.
- Evidence captures show “before” and “after” excerpts and diffs for both contract files.

## Evidence (required)
- `project-handbook/status/evidence/TASK-041/index.md`
- `project-handbook/status/evidence/TASK-041/adr-0033.txt`
- `project-handbook/status/evidence/TASK-041/v3-overlays-overview.txt`
- `project-handbook/status/evidence/TASK-041/v3-overlays-arch.txt`
- `project-handbook/status/evidence/TASK-041/context-subgraph-before.txt`
- `project-handbook/status/evidence/TASK-041/context-subgraph-after.txt`
- `project-handbook/status/evidence/TASK-041/context-subgraph.diff`
- `project-handbook/status/evidence/TASK-041/context-db-before.txt`
- `project-handbook/status/evidence/TASK-041/context-db-after.txt`
- `project-handbook/status/evidence/TASK-041/context-db.diff`
- `project-handbook/status/evidence/TASK-041/validate.txt`
- `project-handbook/status/evidence/TASK-041/sprint-status.txt`

## Sign-off
- [ ] All validation steps completed
- [ ] Evidence documented above
- [ ] Ready to mark task as "done"
