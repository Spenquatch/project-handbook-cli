---
title: Task TASK-035 - Implement: Context snapshot query + types (empty-safe)
type: task
date: 2026-01-11
task_id: TASK-035
feature: v2_context-control-plane-schema
session: task-execution
tags: [task, v2_context-control-plane-schema]
links: [../../../../../features/v2_context-control-plane-schema/overview.md]
---

# Task TASK-035: Implement: Context snapshot query + types (empty-safe)

## Overview
**Feature**: [v2_context-control-plane-schema](../../../../../features/v2_context-control-plane-schema/overview.md)
**Decision**: [FDR-v2_context-control-plane-schema-0001](../../../../../features/v2_context-control-plane-schema/fdr/0001-context-control-plane-snapshot-contract.md)
**Story Points**: 3
**Owner**: @spenser
**Lane**: context/control-plane
**Session**: `task-execution`

## Agent Navigation Rules
1. **Start work**: Update `task.yaml` status to "doing"
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: Set to "review" when ready for review

## Context & Background
This task adds the **canonical control-plane snapshot read surface** to the existing v2 Context subgraph:

- Query: `contextControlPlaneSnapshot(workspaceId: ID): ContextControlPlaneSnapshot!`
- Input semantics:
  - `workspaceId` may be omitted
  - when omitted, the resolver must fall back to `x-workspace-id`
  - when both are missing, return a `BAD_USER_INPUT` GraphQL error

Empty-safe posture (required for incremental rollout):
- For new control-plane surfaces that do not yet have write paths, return **empty arrays** (never `null`).
- Always include `generatedAt`.

## Quick Start
```bash
# Update status when starting
cd sprints/current/tasks/TASK-035-implement-context-snapshot-query-types-empty-safe/
# Edit task.yaml: status: doing

# Follow implementation
cat steps.md              # Read implementation steps
cat commands.md           # Copy-paste commands
cat validation.md         # Validation approach
```

## Dependencies
Task dependencies (must be `done` first):
- `TASK-032` (GraphQL contract: snapshot query + v1 types)
- `TASK-034` (DB migrations applied cleanly)

External/system dependencies used during execution + validation:
- v2 local stack (Docker Compose) including Router endpoint `http://router.local/`
- Vault bootstrap renders `/secrets/*.env` for Router/Context
- `jq` installed locally (used to extract workspace id from JSON responses)

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.

## Evidence Expectations (required)
Capture evidence under `project-handbook/status/evidence/TASK-035/`:
- `index.md` (inputs, decisions, changed files)
- `schema-grep.txt` (proves committed SDL snapshot updated)
- `workspace-create.json` (workspace id used for validation)
- `snapshot-by-arg.json` (query with explicit `workspaceId`)
- `snapshot-by-header.json` (query using `x-workspace-id` fallback)
- `snapshot-missing-workspace.json` (error when neither provided)
- `snapshot-tenant-mismatch.json` (tenant scoping)
- `handbook-validate.txt` (`pnpm -C project-handbook make -- validate` output)
