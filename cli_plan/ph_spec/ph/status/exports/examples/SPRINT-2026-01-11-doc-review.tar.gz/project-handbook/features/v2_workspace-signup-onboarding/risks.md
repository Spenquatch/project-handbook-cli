---
title: v2 Workspace Signup Onboarding Risks
type: risks
feature: v2_workspace-signup-onboarding
date: 2026-01-07
tags: [risks]
links:
  - ../../adr/0026-v2-workspace-signup-onboarding.md
  - ../../adr/0016-v2-context-glue-integrations.md
---

# Risk Register: v2 Workspace Signup Onboarding

## High Priority Risks
- **Unauthenticated or cross-tenant workspace creation**  
  - Impact: High  
  - Probability: Low  
  - Mitigation: onboarding is post-auth only, enforce `x-tenant-id` scoping, and validate in E2E.
- **Provider secret capture during onboarding**  
  - Impact: High  
  - Probability: Low  
  - Mitigation: onboarding never requests provider secrets; provisioning uses server-side creds only.

## Medium Priority Risks
- **Keycloak realm config drift breaks self-registration**  
  - Impact: Medium  
  - Probability: Medium  
  - Mitigation: realm bootstrap is automated and validated via smoke checks:
    - `TASK-004` defines the contract/plan (decision + expected values),
    - `TASK-009` updates the repo-tracked realm import for local/dev,
    - `TASK-010` provides a deterministic drift check suitable for launch gating.
- **Onboarding E2E becomes flaky or non-deterministic (cleanup failures)**  
  - Impact: Medium  
  - Probability: Medium  
  - Mitigation: pick a deterministic teardown/reset strategy with evidence and operator approval (`DR-0002` via `TASK-005`) before implementation.
- **Provisioning latency causes confusing first-run UX**  
  - Impact: Medium  
  - Probability: Medium  
  - Mitigation: show explicit provisioning states from Context capability surface and keep UI deterministic.

## Risk Mitigation Strategies
- Enforce strict post-auth onboarding and tenant/workspace isolation in every layer.
- Validate onboarding and provisioning with Playwright E2E using the landing harness (`TASK-005` defines the strategy; follow-up tasks implement it).
- Treat Keycloak admin defaults as a hard fail-fast requirement (`TASK-001`) so drift/bring-up issues are caught immediately.
