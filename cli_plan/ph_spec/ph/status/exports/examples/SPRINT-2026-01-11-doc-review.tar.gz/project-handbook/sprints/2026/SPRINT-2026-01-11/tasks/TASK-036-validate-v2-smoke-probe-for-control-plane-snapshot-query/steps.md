---
title: Validate: v2 smoke probe for control-plane snapshot query - Implementation Steps
type: implementation
date: 2026-01-11
task_id: TASK-036
tags: [implementation]
links: []
---

# Implementation Steps: Validate: v2 smoke probe for control-plane snapshot query

## Overview
Add an end-to-end v2 smoke probe that:
- asserts the `contextControlPlaneSnapshot` query exists in the runtime supergraph,
- asserts the response shape is stable and empty-safe (arrays are present even when empty),
- asserts the missing-scope failure mode is enforced (`BAD_USER_INPUT` when neither `workspaceId` nor `x-workspace-id` is provided).

## Prerequisites
- `TASK-035` is `done` (snapshot query exists in Context and the SDL snapshot used by the smoke harness is updated).
- You can run the v2 smoke harness locally:
  - v2 stack is up (Traefik + Router + Context)
  - local prereqs: `docker`, `docker compose`, `curl`, `jq`

## Step 1 — Create evidence directory + index (before touching code)
1. Create the evidence directory and index file:
   - `project-handbook/status/evidence/TASK-036/index.md`
2. In `index.md`, record:
   - the exact commands you run (including any `V2_SMOKE_*` env vars),
   - a short summary of the new probe(s) being added,
   - any deviations from defaults (router URL, tenant id, auth).

## Step 2 — Add the `contextControlPlaneSnapshot` probe to `v2/scripts/v2-smoke.sh`
Place the probe in the existing **Context probes** block, after `ws_id` has been resolved (created or discovered).

### 2.1 Gate on schema presence (fail fast, no silent skips)
Add a supergraph snapshot check consistent with the existing smoke harness style:
- If `TRIBUENCE_CONTEXT` is present and ready, but the runtime supergraph snapshot lacks `contextControlPlaneSnapshot`,
  the harness must `fail` with a clear remediation hint (this should never be a skip for this task).

### 2.2 Add the happy-path shape assertion (empty-safe)
Query selection set (keep it minimal but contract-covering):
- `workspace { id }`
- list fields:
  - `manifests`
  - `statuses`
  - `integrationLinks`
  - `jobs`
  - `setupGuidance`
  - `uiModuleManifests`
- `generatedAt`

Expected jq assertions (example):
- `.data.contextControlPlaneSnapshot.workspace.id | type=="string"`
- `.data.contextControlPlaneSnapshot.manifests | type=="array"`
- `.data.contextControlPlaneSnapshot.statuses | type=="array"`
- `.data.contextControlPlaneSnapshot.integrationLinks | type=="array"`
- `.data.contextControlPlaneSnapshot.jobs | type=="array"`
- `.data.contextControlPlaneSnapshot.setupGuidance | type=="array"`
- `.data.contextControlPlaneSnapshot.uiModuleManifests | type=="array"`
- `.data.contextControlPlaneSnapshot.generatedAt | type=="string"`

Run the happy-path query using **header scoping** (omit `workspaceId`, provide `-H "x-workspace-id: ${ws_id}"`) so the
probe locks the “header parity” contract from `FDR-v2_context-control-plane-schema-0001`.

### 2.3 Add the failure-mode assertion (missing workspace scope)
Add a second probe that calls `contextControlPlaneSnapshot` with:
- no `workspaceId` argument, and
- no `x-workspace-id` header

The probe must assert:
- `.errors | type=="array" and length >= 1`
- `.errors[0].extensions.code == "BAD_USER_INPUT"`

Implementation guidance (to keep diffs small):
- Use the existing `graphql_post` helper to capture the raw response JSON.
- Use `jq -e` to assert the error conditions, and call `pass`/`fail` accordingly.

### 2.4 Determinism constraints (must hold)
- Do not require any provider credentials (no AnythingLLM/Twenty-specific behaviors).
- Do not require external network access beyond the local v2 stack.

## Step 3 — Run the smoke harness
1. Run the smoke harness in Router mode and require Context to be present:
   - `V2_SMOKE_REQUIRE_GRAPHS=TRIBUENCE_CONTEXT make -C v2 v2-smoke`
2. If the v2 stack is not running, bring it up and re-run (see `commands.md` for explicit `make -C v2 v2-up` + required env vars).
3. Capture the full output to `project-handbook/status/evidence/TASK-036/v2-smoke.txt`.

## Step 4 — Update validation notes + submit for review
1. Update `validation.md`:
   - link to the evidence files created under `project-handbook/status/evidence/TASK-036/`,
   - include the exact env vars used for the smoke run (especially `V2_SMOKE_*`).
2. Set status to `review`:
   - `pnpm -C project-handbook make -- task-status id=TASK-036 status=review`
