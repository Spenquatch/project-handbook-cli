---
title: Task TASK-034 - Implement: Context DB migrations for control-plane tables (v1)
type: task
date: 2026-01-11
task_id: TASK-034
feature: v2_context-control-plane-schema
session: task-execution
tags: [task, v2_context-control-plane-schema]
links: [../../../../../features/v2_context-control-plane-schema/overview.md]
---

# Task TASK-034: Implement: Context DB migrations for control-plane tables (v1)

## Overview
**Feature**: [v2_context-control-plane-schema](../../../../../features/v2_context-control-plane-schema/overview.md)
**Decision**: [FDR-v2_context-control-plane-schema-0001](../../../../../features/v2_context-control-plane-schema/fdr/0001-context-control-plane-snapshot-contract.md)
**Story Points**: 3
**Owner**: @spenser
**Lane**: context/control-plane
**Session**: `task-execution`

## Agent Navigation Rules
1. **Start work**: Update `task.yaml` status to "doing"
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: Set to "review" when ready for review

## Context & Background
This task adds **idempotent, additive SQL migrations** to the v2 Context service so it can safely evolve from the v0
`context_workspaces` / `context_references` schema into the **control-plane** schema required by
`FDR-v2_context-control-plane-schema-0001`.

Important implementation constraint:
- `v2/services/context/index.js` runs **every `.sql` file in** `v2/services/context/db/migrations/` **on every boot**
  (sorted lexicographically). There is no migration ledger table. Every statement must therefore be safe to re-run.

Source of truth for what to implement:
- `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` (v1 section produced by `TASK-033`).

Minimum expected control-plane table set (v1, per decision + feature plan; exact columns/constraints come from the DB contract):
- `capability_manifests`
- `capability_status`
- `integration_links`
- `integration_jobs`
- `integration_job_runs`
- `setup_guidance`
- `ui_module_manifests`

## Quick Start
```bash
# Update status when starting
cd sprints/current/tasks/TASK-034-implement-context-db-migrations-for-control-plane-tables-v1/
# Edit task.yaml: status: doing

# Follow implementation
cat steps.md              # Read implementation steps
cat commands.md           # Copy-paste commands
cat validation.md         # Validation approach
```

## Dependencies
Task dependencies (must be `done` first):
- `TASK-033` (DB contract: v1 control-plane tables + constraints)

External/system dependencies used during execution + validation:
- v2 local stack (Docker Compose) including Postgres (`v2/infra/compose/docker-compose.v2.yml`)
- Vault bootstrap renders `/secrets/context.env` (Context `DATABASE_URL`)

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.

## Evidence Expectations (required)
Capture evidence under `project-handbook/status/evidence/TASK-034/`:
- `index.md` (inputs, decisions, migration filenames)
- `migrations-ls.txt` (post-change migration file list)
- `context-startup-logs.txt` (shows migrations apply with no errors)
- `psql-schema.txt` (tables + indexes exist; v0 tables still present)
- `handbook-validate.txt` (`pnpm -C project-handbook make -- validate` output)
