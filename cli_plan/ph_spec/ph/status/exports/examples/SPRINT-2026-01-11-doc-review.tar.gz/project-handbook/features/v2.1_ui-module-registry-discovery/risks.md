---
title: v2.1 UI Module Registry (Discovery) Risks
type: risks
feature: v2.1_ui-module-registry-discovery
date: 2026-01-07
tags: [risks]
links:
  - ../../adr/0025-v2-1-ui-module-registry.md
---

# Risk Register: v2.1 UI Module Registry (Discovery)

## High Priority Risks
- **Remote code execution via untrusted modules**  
  - Impact: High  
  - Probability: Low  
  - Mitigation: internal-only origin, module allowlist, version pinning, sha256 integrity checks, and CI policy gates.
- **Supply chain compromise of module build artifacts**  
  - Impact: High  
  - Probability: Low  
  - Mitigation: build in CI, upload to MinIO with immutable keys, verify integrity at runtime, and restrict publish credentials.
- **v3 governance requires trusted publisher/provenance gates**  
  - Impact: High  
  - Probability: Medium  
  - Mitigation: keep module artifacts content-addressed; reserve additive metadata extension points (provenance + license posture) and promote `DR-0007` to an ADR before execution depends on it.

## Medium Priority Risks
- **Module runtime incompatibilities (React/Next runtime mismatch)**  
  - Impact: Medium  
  - Probability: Medium  
  - Mitigation: strict module interface contract and a CI runtime smoke that loads the module in the shell.
- **Manifest drift causes broken UI selection**  
  - Impact: Medium  
  - Probability: Medium  
  - Mitigation: Context enforces schema validation for manifests and rejects unknown module ids/versions.
- **Client overlay precedence becomes nondeterministic**  
  - Impact: Medium  
  - Probability: Medium  
  - Mitigation: enforce explicit, deterministic overlay precedence rules and keep overlays as additive control-plane state (no mutation of module bytes).
- **E2E harness drift or brittle seeding**  
  - Impact: Medium  
  - Probability: Medium  
  - Mitigation: keep `TASK-038` selectors stable (`data-testid` + `data-capability-id`), seed artifacts via `TASK-031` publish script, and document an explicit hash-mismatch fallback seed (no secrets).

## Risk Mitigation Strategies
- Treat module loading as a hardened internal capability (not a public plugin system).
- Require E2E coverage for successful module load and deterministic fallback behavior.
