---
title: Implement: Context snapshot query + types (empty-safe) - Completion Checklist
type: checklist
date: 2026-01-11
task_id: TASK-035
tags: [checklist]
links: []
---

# Completion Checklist: Implement: Context snapshot query + types (empty-safe)

## Preconditions (must be true before coding)
- [ ] `TASK-032` is `done` (contract exists)
- [ ] `TASK-034` is `done` (migrations exist)
- [ ] You can point to the canonical contract in `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md`

## Implementation (binary)
- [ ] `v2/services/context/index.js` SDL includes:
  - [ ] `contextControlPlaneSnapshot(workspaceId: ID): ContextControlPlaneSnapshot!`
  - [ ] `ContextControlPlaneSnapshot` and required child types (per contract)
- [ ] Resolver behavior matches the contract:
  - [ ] `workspaceId` falls back to `x-workspace-id`
  - [ ] missing both returns `BAD_USER_INPUT`
  - [ ] workspace is loaded for current tenant/workspace; tenant mismatch does not leak data
  - [ ] `generatedAt` is always present
  - [ ] all list fields are empty-safe arrays (never `null`)
- [ ] Committed SDL snapshot updated:
  - [ ] `v2/infra/compose/graphql/subgraphs/tribuence-context/schema.graphql` includes the new query + types

## Validation + Evidence (required)
- [ ] Evidence directory exists: `project-handbook/status/evidence/TASK-035/`
- [ ] Evidence captured:
  - [ ] `project-handbook/status/evidence/TASK-035/index.md`
  - [ ] `project-handbook/status/evidence/TASK-035/schema-grep.txt`
  - [ ] `project-handbook/status/evidence/TASK-035/workspace-create.json`
  - [ ] `project-handbook/status/evidence/TASK-035/snapshot-by-arg.json`
  - [ ] `project-handbook/status/evidence/TASK-035/snapshot-by-header.json`
  - [ ] `project-handbook/status/evidence/TASK-035/snapshot-missing-workspace.json`
  - [ ] `project-handbook/status/evidence/TASK-035/snapshot-tenant-mismatch.json`
  - [ ] `project-handbook/status/evidence/TASK-035/handbook-validate.txt`
- [ ] `pnpm -C project-handbook make -- validate` passes

## Status Updates
- [ ] Set status to `review`: `pnpm -C project-handbook make -- task-status id=TASK-035 status=review`
