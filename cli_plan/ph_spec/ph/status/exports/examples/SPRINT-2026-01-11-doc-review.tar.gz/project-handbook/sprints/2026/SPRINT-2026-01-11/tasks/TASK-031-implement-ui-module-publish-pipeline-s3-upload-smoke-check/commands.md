---
title: Implement: UI module publish pipeline (S3 upload + smoke check) - Commands
type: commands
date: 2026-01-11
task_id: TASK-031
tags: [commands]
links: []
---

# Commands: Implement: UI module publish pipeline (S3 upload + smoke check)

## Task Status Updates
```bash
pnpm -C project-handbook make -- task-status id=TASK-031 status=doing
pnpm -C project-handbook make -- task-status id=TASK-031 status=review
pnpm -C project-handbook make -- task-status id=TASK-031 status=done
```

## Required Environment
The scripts should rely on the Vault-rendered S3 env in `/secrets/artifacts.env` (loaded via `with-env-file.sh` inside the `cosmo-artifact-probe` helper container):
- `S3_ENDPOINT_URL`
- `S3_REGION`
- `S3_ACCESS_KEY_ID`
- `S3_SECRET_ACCESS_KEY`
- `S3_FORCE_PATH_STYLE`
- `COSMO_S3_BUCKET`

## Validation Commands
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Implementation Commands
```bash
# Add publish + smoke scripts
mkdir -p v2/scripts/ui-modules
$EDITOR v2/scripts/ui-modules/publish-ui-module.sh
$EDITOR v2/scripts/ui-modules/smoke-ui-module-origin.sh
```

## Example: Publish + Smoke (local)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-031"
mkdir -p "$EVID_DIR"

cat >"$EVID_DIR/index.mjs" <<'EOF'
export const hello = () => 'hello';
EOF

MODULE_ID="example"
VERSION="0.0.0"

bash v2/scripts/ui-modules/publish-ui-module.sh \
  --moduleId "$MODULE_ID" \
  --version "$VERSION" \
  --file "$EVID_DIR/index.mjs" \
  | tee "$EVID_DIR/publish-output.txt"

# Use the locally computed sha to avoid brittle parsing of stdout
INTEGRITY_SHA256="$(python3 - <<'PY'
import hashlib
path = "project-handbook/status/evidence/TASK-031/index.mjs"
with open(path, "rb") as f:
  print(hashlib.sha256(f.read()).hexdigest())
PY
)"
printf '%s\n' "$INTEGRITY_SHA256" | tee "$EVID_DIR/index.mjs.sha256.txt"

bash v2/scripts/ui-modules/smoke-ui-module-origin.sh \
  --moduleId "$MODULE_ID" \
  --version "$VERSION" \
  --integritySha256 "$INTEGRITY_SHA256" \
  --origin "http://app.local" \
  --resolve "app.local:80:127.0.0.1" \
  | tee "$EVID_DIR/smoke-output.txt"
```

## Git Integration
```bash
# Project Handbook repo: docs/task updates
git -C project-handbook status

# v2 repo: implementation work (run commits from inside the repo you change)
git -C v2 status
```

## Quick Copy-Paste
```bash
# Bring up v2 locally (if needed for manual smoke validation)
make -C v2 v2-up
```
