---
id: ADR-0013
title: Bounded Sprints + Lanes (Non-Timeboxed Planning)
type: adr
status: accepted
date: 2026-01-04
supersedes: null
superseded_by: null
tags: [handbook, sprints, planning, lanes, concurrency]
links:
  - ../parking-lot/archive/technical-debt/DEBT-20260102-standardize-task-directory-slu/README.md
  - ../parking-lot/archive/research/RES-20251230-process-fix-session-end-index-/README.md
  - ../backlog/archive/wildcards/WILD-P3-20260101-1721/README.md
  - ../backlog/archive/wildcards/WILD-P3-20260104-1016/README.md
---

# Context

The handbook sprint system currently assumes:

- **Weekly timeboxes** (Monday → Friday; day-of-sprint; burndown by weekday)
- **Capacity-limited scoping** (80/20 planned vs reactive; sprint “fits” capacity)

This is a poor fit for an AI-heavy workflow where:

- Work can run **concurrently** across many independent concerns/services.
- The limiting factor is usually **dependency structure**, not calendar time or human capacity.
- We still want **story points**, but primarily as *telemetry* (throughput, cycle-time trends), not a scoping constraint.

# Decision

## Sprint model

Default sprint planning is **bounded**, not timeboxed:

- A sprint is a **work package** defined by *work boundaries* (a deliberate partition of concerns) plus an explicit integration plan.
- Sprints can still use date-based sprint IDs, but IDs do **not** imply a 5-day window.
- Sprints are closed when **exit criteria** are met, not because a date elapsed.

Timeboxed/weekly sprints remain supported as an optional configuration for human teams.

## Lanes

Each sprint plan uses **lanes** to express parallel work:

- A **lane** is a coherent concern/service/workstream that can be executed largely independently.
- Cross-lane work is represented as explicit **integration tasks** with dependencies on lane deliverables.

Tasks may optionally include a `lane` field to allow automation to group and report work in lane form.

## Points

Story points remain required and tracked, but:

- **Do not cap** sprints by points.
- Use points for **velocity and throughput telemetry** (e.g., points completed per day/week/session) and for comparing changes over time.

# Heuristics (Planning Guidance)

Use these heuristics to define sprint boundaries and lanes:

1. **Prefer separation by concern/service**, not by “who does it”.
2. **Minimize cross-lane dependencies**; when unavoidable, make them explicit and front-load integration tasks.
3. **Keep dependency depth shallow**: long linear chains reduce parallelism and increase coordination overhead.
4. **Create at least one “integration checkpoint”** when multiple lanes feed a shared interface.
5. **Avoid “grab bag” lanes**; if a lane has no cohesive output, split it or move it to another sprint.

Suggested simple lane taxonomy:

- `service/<name>` (router, context, crm, anythingllm, etc.)
- `infra/<name>` (deploy, ci, db, observability)
- `handbook/<area>` (automation, docs, process)
- `integration/<scope>` (cross-service wiring, e2e validation)

# Consequences

## Positive

- Sprint plans become explicitly parallelizable and dependency-aware.
- Sprint scope is defined by *structure* (boundaries/lanes/integration), not the calendar.
- Points become higher-signal telemetry over time.

## Tradeoffs

- Timeboxed expectations (weekday burndown, “day 3” health checks) must become optional.
- Automation must report sprint health without assuming a 5-day window.

# Acceptance Criteria

- Sprint planning templates emphasize lanes + integration instead of 5-day capacity.
- `make sprint-status` can report progress grouped by lane when `lane` is present.
- Timeboxed mode remains available via configuration.
