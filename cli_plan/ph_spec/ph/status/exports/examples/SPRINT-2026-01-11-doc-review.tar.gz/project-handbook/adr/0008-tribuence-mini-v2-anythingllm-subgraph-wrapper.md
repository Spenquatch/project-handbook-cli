---
id: ADR-0008
title: Tribuence Mini v2 AnythingLLM Subgraph Wrapper
type: adr
status: draft
date: 2025-12-31
supersedes: null
superseded_by: null
tags: [tribuence-mini, v2, anythingllm, graphql, federation, apollo-router]
links:
  - ../../v2/ARCHITECTURE.md
  - ../features/tribuence-mini-v2/overview.md
  - ../contracts/tribuence-mini-v2/anythingllm-subgraph.md
  - ../contracts/tribuence-mini-v2/supergraph-router.md
  - ../backlog/wildcards/WILD-P2-20251222-1204/README.md
---

# Context

AnythingLLM is an upstream service that provides its primary integration surface via REST. Tribuence Mini v2 requires a GraphQL-only UI and a federated supergraph entrypoint (Apollo Router). Therefore, “AnythingLLM subgraph” must be defined explicitly:

- how the Router federates AnythingLLM behavior, and
- how we keep the GraphQL surface stable as upstream REST evolves.

# Decision

Implement AnythingLLM integration as a **dedicated GraphQL wrapper subgraph service**:

1. Create a new internal service under `v2/services/anythingllm-subgraph/` (implementation task will follow) that exposes:
   - `GET /health`
   - `POST /graphql` (federation-ready)
2. The wrapper calls AnythingLLM REST internally using Vault-provisioned secrets:
   - `ANYLLM_BASE_URL`
   - `ANYLLM_API_KEY`
3. The minimal schema/operations are defined by the contract `project-handbook/contracts/tribuence-mini-v2/anythingllm-subgraph.md`.

# Consequences

## Positive
- UI stays GraphQL-only while AnythingLLM remains REST-first.
- The wrapper is the right place to normalize AnythingLLM quirks (uploads, polling, error shaping).
- Federation remains consistent: Router always talks GraphQL to subgraphs.

## Tradeoffs / Risks
- Wrapper must be maintained as upstream AnythingLLM REST changes.
- Some operations (e.g., uploads) may require non-trivial translation; the contract starts with a base64 upload to keep early smoke probes simple.

# Rollout

1. Add wrapper service skeleton + `/health`.
2. Implement minimal GraphQL schema and resolvers calling the REST endpoints in the contract.
3. Federate wrapper as the AnythingLLM subgraph in Apollo Router.
4. Expand smoke probes and UI migration to use the wrapper operations.

# Acceptance Criteria

- `anythingllm-subgraph` can be composed into the v2 supergraph as a subgraph.
- The minimal operations in `contracts/tribuence-mini-v2/anythingllm-subgraph.md` function against a running AnythingLLM container.
- The v2 smoke spec can include AnythingLLM probes without relying on Next API routes.

