---
title: Implement: UI module origin proxy route (Option A) - Completion Checklist
type: checklist
date: 2026-01-11
task_id: TASK-030
tags: [checklist]
links: []
---

# Completion Checklist: Implement: UI module origin proxy route (Option A)

## Pre-Work
- [ ] Confirm all `depends_on` tasks are `done`
- [ ] Review `README.md`, `steps.md`, `commands.md`
- [ ] Re-read `project-handbook/features/v2.1_ui-module-registry-discovery/fdr/0001-ui-module-artifact-origin-and-publish-pipeline.md`

## During Execution
- [ ] Ensure `v2-ui` has server-side S3 env (`S3_*` + `COSMO_S3_BUCKET`) via `/secrets/next.env`
- [ ] Add the Next.js route: `v2/apps/tribuence-mini/src/app/api/ui-modules/[moduleId]/[version]/[integritySha256]/route.ts`
- [ ] Ensure strict `moduleId` allowlist enforcement (no arbitrary S3 key proxying)
- [ ] Validate `integritySha256` shape (64-char lowercase hex) before any S3 call
- [ ] Ensure immutable cache headers for content-addressed artifacts
- [ ] Stream from S3 (avoid unbounded buffering)
- [ ] Capture evidence under `project-handbook/status/evidence/TASK-030/`

## Before Review
- [ ] Run `pnpm -C project-handbook make -- validate`
- [ ] Run `pnpm -C v2/apps/tribuence-mini lint && pnpm -C v2/apps/tribuence-mini typecheck && pnpm -C v2/apps/tribuence-mini test`
- [ ] Update `validation.md` with exact commands + evidence list (if it changed)
- [ ] Set status to `review` via `pnpm -C project-handbook make -- task-status ...`

## After Completion
- [ ] Peer review approved and merged
- [ ] Move status to `done` with `pnpm -C project-handbook make -- task-status ...`
