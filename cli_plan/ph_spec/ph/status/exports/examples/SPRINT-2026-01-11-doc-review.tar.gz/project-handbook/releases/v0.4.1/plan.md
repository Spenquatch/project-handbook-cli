---
title: Release v0.4.1 Plan
type: release-plan
version: v0.4.1
start_sprint: SPRINT-2026-01-07
end_sprint: SPRINT-2026-01-07
planned_sprints: 1
sprint_ids: [SPRINT-2026-01-07]
status: planned
date: 2026-01-07
tags: [release, planning]
links: []
---

# Release v0.4.1

## Release Summary
Post-`v0.4.0` hardening and launch-readiness: close three P1 security posture issues (redaction + auth posture), produce
deterministic onboarding discovery outputs, and standardize a single “launch gate runner” entrypoint with evidence.

## Release Goals
1. **Primary Goal**: Eliminate obvious secret leakage vectors (UI error bodies, service logs, Keycloak default admin creds).
2. **Secondary Goal**: Add a single v2 launch gate runner and complete the integration/evidence gate for the sprint.
3. **Stretch Goal**: Ship execution-ready onboarding discovery outputs (Keycloak self-registration + Playwright E2E plan).

## Release Type & Scope
- **Type**: patch/hardening (1 bounded sprint)
- **In scope (must-have)**:
  - P1 fixes:
    - `BUG-P1-20260105-083811` UI sanitizes upstream/router errors (no raw bodies rendered to browser).
    - `BUG-P1-20260105-0837` Fastify logs redact `Authorization` / `Cookie` / `Set-Cookie`.
    - `BUG-P1-20260105-083807` Keycloak admin creds are non-default (Vault-seeded or fail-fast).
  - A single “launch gate runner” entrypoint (`v2_launch`) and a sprint integration gate with evidence.
  - Onboarding discovery outputs (Keycloak self-registration settings + Playwright strategy).
- **Out of scope (explicitly not in this release)**:
  - Module registry discovery/execution (`v2.1_ui-module-registry-*`).
  - Context control-plane schema discovery/execution (`v2_context-control-plane-schema`).
  - Full onboarding implementation (beyond discovery outputs + validation plan).
  - Full observability stack bring-up (beyond log redaction rules).
- **Scope flexibility**:
  - Locked: P1 security posture fixes + evidence-backed validation gate.
  - Flexible: depth of onboarding discovery outputs (as long as the output is execution-ready).

## Sprint Timeline
- **SPRINT-2026-01-07** (Sprint 1 of 1): Sprint theme/focus
  - Theme: hardening + onboarding discovery + launch gates.


## Feature Assignments
*Use `make release-add-feature` to assign features to this release*
Assigned in `releases/v0.4.1/features.yaml`:
- `v2_launch` (critical path)
- `v2_ui-dev-harness-and-module-boundaries` (critical path)
- `v2_workspace-signup-onboarding`
- `v2_observability-and-runbooks`

## Scope Control
- **Scope lock date**: TBD
- **Change control**:
  - Default: new requests go to the next release
  - Exceptions: TBD (who decides, criteria, and how to document)

## Communication Plan
### Internal
- Announcement: TBD
- Progress cadence: weekly release health check
- Escalation path: TBD

### Stakeholders
- Update cadence: TBD
- Demo date(s): TBD
- Release notes owner: TBD

## Success Criteria
- [ ] All assigned features complete (or explicitly de-scoped with an updated plan)
- [ ] P1 fixes validated (no raw upstream bodies rendered; logs redacted; Keycloak defaults eliminated)
- [ ] Launch gate runner exists as a single entrypoint and is used by the integration gate
- [ ] Evidence captured for the sprint integration gate
- [ ] Feature docs and task docs updated for execution

## Risk Management
- Critical path: (Identify critical features)
- Dependencies: (External dependencies)
- Capacity: (Team availability considerations)

## Release Notes Draft
*Auto-generated from completed tasks and features*
