---
title: Handbook: Plan v0.5.1 release + assign initial features - Commands
type: commands
date: 2026-01-11
task_id: TASK-025
tags: [commands]
links: []
---

# Commands: Handbook: Plan v0.5.1 release + assign initial features

## Task Status
```bash
pnpm -C project-handbook make -- task-status id=TASK-025 status=doing
pnpm -C project-handbook make -- task-status id=TASK-025 status=review
pnpm -C project-handbook make -- task-status id=TASK-025 status=done
```

## Evidence Directory (required)
```bash
EVID_DIR="project-handbook/status/evidence/TASK-025"
mkdir -p "$EVID_DIR"
${EDITOR:-vi} "$EVID_DIR/index.md"
```

## Release Plan + Feature Assignment
```bash
set -euo pipefail

pnpm -C project-handbook make -- release-plan version=next bump=patch sprints=3 start=SPRINT-2026-01-16 | tee "$EVID_DIR/release-plan.txt"

pnpm -C project-handbook make -- release-add-feature release=v0.5.1 feature=v2.1_ui-module-registry-discovery critical=true
pnpm -C project-handbook make -- release-add-feature release=v0.5.1 feature=v2_context-control-plane-schema critical=true
pnpm -C project-handbook make -- release-add-feature release=v0.5.1 feature=v2.1_ui-module-registry-execution
pnpm -C project-handbook make -- release-add-feature release=v0.5.1 feature=v2_context-knowledge-network

pnpm -C project-handbook make -- release-status | tee "$EVID_DIR/release-status.txt"
```

## Handbook Validation
```bash
pnpm -C project-handbook make -- validate
```
