---
id: FDR-v2_workspace-signup-onboarding-0001
title: Keycloak Self-Registration Bootstrap (Realm Import + Drift Smoke Check)
type: fdr
status: accepted
date: 2026-01-09
tags: [v2, onboarding, keycloak, auth, fdr]
links:
  - ../overview.md
  - ../decision-register/DR-0001-keycloak-self-registration-bootstrap.md
  - ../implementation/KEYCLOAK_SELF_REGISTRATION.md
  - ../../../adr/0026-v2-workspace-signup-onboarding.md
---

# Decision

Use a **repo-tracked realm export/import** as the deterministic source of truth for v2 local/dev Keycloak realm
configuration, and add a drift-detecting **smoke check** suitable for launch gating.

# Scope

In scope:
- Local/dev realm bootstrap for v2 onboarding (`ADR-0026`).
- Enabling Keycloak self-registration for the v2 realm.
- Deterministic drift detection for critical auth settings (registration posture + NextAuth redirect URIs/origins).

Out of scope:
- Production IdP hardening rollout (SMTP-backed verify email, MFA enforcement, etc). See
  `project-handbook/features/v2_workspace-signup-onboarding/implementation/KEYCLOAK_SELF_REGISTRATION.md`.

# Implementation Contract (Execution Work References This)

## Source of truth
- Realm import file: `v2/infra/compose/keycloak/realm.json`
- Import wiring: `v2/infra/compose/docker-compose.v2.yml` (`start-dev --import-realm` + mount to `/opt/keycloak/data/import/realm.json`)
- Confidential client secret is not committed and must stay in Vault:
  - KV path: `kv/data/tribuence/v2/next`
  - Key: `KEYCLOAK_CLIENT_SECRET`

## Must-have realm/client settings (local/dev)
- Realm `tribuence`:
  - `registrationAllowed=true`
  - baseline password policy defined (start with `length(12)` unless superseded)
- Client `tribuence-mini-v2`:
  - redirect URIs include `http://app.local/api/auth/callback/keycloak` and `http://app.local/api/auth/callback/*`
  - web origins include `http://app.local`

## Drift smoke check (fail fast)
Implement a smoke check that:
- verifies OIDC discovery is reachable for `http://keycloak.local/realms/tribuence`,
- queries realm + client settings via admin API and fails if expectations drift,
- refuses default `admin/admin` usage for any admin auth path and never prints secrets,
- captures evidence outputs for gates.

# Status

Accepted (based on operator approval in DR-0001).

