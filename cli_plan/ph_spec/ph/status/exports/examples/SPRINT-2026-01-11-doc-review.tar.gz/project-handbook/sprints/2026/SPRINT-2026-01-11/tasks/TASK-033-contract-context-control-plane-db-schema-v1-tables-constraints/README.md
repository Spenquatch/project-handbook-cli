---
title: Task TASK-033 - Contract: Context control-plane DB schema (v1 tables + constraints)
type: task
date: 2026-01-11
task_id: TASK-033
feature: v2_context-control-plane-schema
session: task-execution
tags: [task, v2_context-control-plane-schema]
links: [../../../../../features/v2_context-control-plane-schema/overview.md]
---

# Task TASK-033: Contract: Context control-plane DB schema (v1 tables + constraints)

## Overview
- **Feature**: [v2_context-control-plane-schema](../../../../../features/v2_context-control-plane-schema/overview.md)
- **Decision**: [FDR-v2_context-control-plane-schema-0001](../../../../../features/v2_context-control-plane-schema/fdr/0001-context-control-plane-snapshot-contract.md)
- **Story Points**: 2
- **Owner**: @spenser
- **Lane**: `context/control-plane`
- **Session**: `task-execution`

## Agent Navigation Rules
1. **Start work**: `pnpm -C project-handbook make -- task-status id=TASK-033 status=doing`
2. **Read first**: `steps.md` for implementation sequence
3. **Use commands**: Copy-paste from `commands.md`
4. **Validate progress**: Follow `validation.md` guidelines
5. **Check completion**: Use `checklist.md` before marking done
6. **Update status**: `pnpm -C project-handbook make -- task-status id=TASK-033 status=review`

## Context & Background
This task updates the **Project Handbook DB contract** for Context so execution tasks can implement v1 migrations without
guesswork:
- In scope: `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md`
- Out of scope: any `v2/` product code changes

## Quick Start
```bash
pnpm -C project-handbook make -- task-status id=TASK-033 status=doing
cd project-handbook/sprints/current/tasks/TASK-033-contract-context-control-plane-db-schema-v1-tables-constraints/

# Follow implementation
cat steps.md              # Read implementation steps
cat commands.md           # Copy-paste commands
cat validation.md         # Validation approach
```

## Dependencies
Hard dependencies (must be `done` before execution):
- `TASK-029` — produced the accepted decision and migration posture that this DB contract must reflect.

Downstream tasks depend on this DB contract being explicit and stable:
- `TASK-034` (implements SQL migrations for the v1 tables/indices)
- `TASK-040` / `TASK-041` (extend v1 tables additively; do not rename v1 columns)

## Acceptance Criteria
See `task.yaml` acceptance section and `checklist.md` for completion requirements.

## Evidence
All evidence for this task must be captured under `project-handbook/status/evidence/TASK-033/` (see `validation.md`).
