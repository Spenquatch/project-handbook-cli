---
title: Implement: UI module origin proxy route (Option A) - References
type: references
date: 2026-01-11
task_id: TASK-030
tags: [references]
links: []
---

# References: Implement: UI module origin proxy route (Option A)

## Internal References

### Decision Context
- **Decision**: [FDR-v2_1_ui-module-registry-discovery-0001](../../../../../features/v2.1_ui-module-registry-discovery/fdr/0001-ui-module-artifact-origin-and-publish-pipeline.md)
- **Feature**: [Feature overview](../../../../../features/v2.1_ui-module-registry-discovery/overview.md)
- **Architecture**: [Feature architecture](../../../../../features/v2.1_ui-module-registry-discovery/architecture/ARCHITECTURE.md)
- **Implementation**: [Feature implementation](../../../../../features/v2.1_ui-module-registry-discovery/implementation/IMPLEMENTATION.md)

### v2 Wiring (S3 + Traefik)
- `v2/infra/vault/templates/artifacts.env.tpl` (authoritative S3 env list)
- `v2/infra/vault/templates/next.env.tpl` (v2-ui Vault-rendered env)
- `v2/infra/compose/docker-compose.v2.yml` (v2-ui consumes `/secrets/next.env`)
- `v2/infra/compose/traefik/configs/traefik.v2.yml` (routes `Host(app.local)` → v2-ui)
- `v2/docs/README.md` (local `/etc/hosts` notes)

### Sprint Context
- **Sprint Plan**: [Current sprint](../../plan.md)
- **Sprint Tasks**: [All sprint tasks](../)
- **Daily Progress**: [Daily status](../../../../../status/daily/)

## Notes
Add concrete links here only when you discover resources during the task (no placeholders).
