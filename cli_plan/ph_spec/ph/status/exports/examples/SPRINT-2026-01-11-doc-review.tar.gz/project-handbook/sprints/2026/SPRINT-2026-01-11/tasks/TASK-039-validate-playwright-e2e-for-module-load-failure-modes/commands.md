---
title: Validate: Playwright E2E for module load + failure modes - Commands
type: commands
date: 2026-01-11
task_id: TASK-039
tags: [commands]
links: []
---

# Commands: Validate: Playwright E2E for module load + failure modes

## Task Status Updates
```bash
pnpm -C project-handbook make -- task-status id=TASK-039 status=doing
pnpm -C project-handbook make -- task-status id=TASK-039 status=review
pnpm -C project-handbook make -- task-status id=TASK-039 status=done
```

## Required Environment (for E2E)
- v2 stack up and reachable:
  - `http://app.local/` (UI)
  - `http://router.local/` (GraphQL)
  - `http://keycloak.local/` (auth)
- Keycloak auth mode (pick exactly one):
  - Provisioned user (preferred): set admin creds and ensure `E2E_KEYCLOAK_USERNAME`/`E2E_KEYCLOAK_PASSWORD` are unset:
    - `E2E_KEYCLOAK_ADMIN_USERNAME` + `E2E_KEYCLOAK_ADMIN_PASSWORD`
    - or `KEYCLOAK_ADMIN` + `KEYCLOAK_ADMIN_PASSWORD`
  - Existing user: set user creds; provisioning/teardown is skipped:
    - `E2E_KEYCLOAK_USERNAME` + `E2E_KEYCLOAK_PASSWORD`

## Validation Commands
```bash
pnpm -C project-handbook make -- validate
pnpm -C project-handbook make -- sprint-status
```

## Implementation Commands
```bash
# Evidence folder
EVID_DIR="project-handbook/status/evidence/TASK-039"
mkdir -p "$EVID_DIR"

# 1) Publish test modules via the pipeline from TASK-031
MODULE_VERSION="0.0.0"

cat >"$EVID_DIR/example.index.mjs" <<'EOF'
export const capabilityId = 'ui-module-demo-happy';
export const panelTitle = 'Example module';
export default function ExamplePanel() {
  return 'Example module rendered.';
}
EOF

bash v2/scripts/ui-modules/publish-ui-module.sh \
  --moduleId "example" \
  --version "$MODULE_VERSION" \
  --file "$EVID_DIR/example.index.mjs" \
  | tee "$EVID_DIR/publish-example.txt"

cat >"$EVID_DIR/example-eval-error.index.mjs" <<'EOF'
export const capabilityId = 'ui-module-demo-eval-error';
throw new Error('eval error fixture');
export default function Broken() {
  return 'unreachable';
}
EOF

bash v2/scripts/ui-modules/publish-ui-module.sh \
  --moduleId "example-eval-error" \
  --version "$MODULE_VERSION" \
  --file "$EVID_DIR/example-eval-error.index.mjs" \
  | tee "$EVID_DIR/publish-example-eval-error.txt"

cat >"$EVID_DIR/example-export-invalid.index.mjs" <<'EOF'
export const capabilityId = 'ui-module-demo-export-invalid';
export const panelTitle = 'Missing default export fixture';
EOF

bash v2/scripts/ui-modules/publish-ui-module.sh \
  --moduleId "example-export-invalid" \
  --version "$MODULE_VERSION" \
  --file "$EVID_DIR/example-export-invalid.index.mjs" \
  | tee "$EVID_DIR/publish-example-export-invalid.txt"

# 2) Hash mismatch seed (documented fallback; publish script cannot create mismatched bytes)
# Upload tampered bytes under a key that includes the sha256 of the *expected* bytes.
cat >"$EVID_DIR/example-hash-mismatch.expected.index.mjs" <<'EOF'
export const capabilityId = 'ui-module-demo-hash-mismatch';
export default function Expected() {
  return 'Expected module bytes.';
}
EOF

cat >"$EVID_DIR/example-hash-mismatch.tampered.index.mjs" <<'EOF'
export const capabilityId = 'ui-module-demo-hash-mismatch';
export default function Tampered() {
  return 'Tampered module bytes.';
}
EOF

EXPECTED_SHA256="$(python3 - <<'PY'
import hashlib
path = "project-handbook/status/evidence/TASK-039/example-hash-mismatch.expected.index.mjs"
with open(path, "rb") as f:
  print(hashlib.sha256(f.read()).hexdigest())
PY
)"
printf '%s\n' "$EXPECTED_SHA256" | tee "$EVID_DIR/example-hash-mismatch.expected.sha256.txt"

docker compose -f v2/infra/compose/docker-compose.v2.yml run --rm \
  -e MODULE_ID="example-hash-mismatch" \
  -e VERSION="$MODULE_VERSION" \
  -e INTEGRITY_SHA256="$EXPECTED_SHA256" \
  -v "$(pwd)/$EVID_DIR:/evid:ro" \
  --entrypoint /opt/healthcheck/with-env-file.sh \
  cosmo-artifact-probe \
  /secrets/artifacts.env sh -lc '
    KEY="ui-modules/${MODULE_ID}/${VERSION}/${INTEGRITY_SHA256}/index.mjs"
    aws --no-cli-pager --endpoint-url "$S3_ENDPOINT_URL" s3api put-object \
      --bucket "$COSMO_S3_BUCKET" \
      --key "$KEY" \
      --body /evid/example-hash-mismatch.tampered.index.mjs \
      --content-type "text/javascript; charset=utf-8" \
      >/dev/null
    printf "%s\n" "uploaded key=${KEY}"
  ' | tee "$EVID_DIR/publish-example-hash-mismatch.txt"

# 3) Compute sha256 digests for DB seeding (use the same bytes that were uploaded)
EXAMPLE_SHA256="$(python3 - <<'PY'
import hashlib
path = "project-handbook/status/evidence/TASK-039/example.index.mjs"
with open(path, "rb") as f:
  print(hashlib.sha256(f.read()).hexdigest())
PY
)"
printf '%s\n' "$EXAMPLE_SHA256" | tee "$EVID_DIR/example.sha256.txt"

EVAL_ERROR_SHA256="$(python3 - <<'PY'
import hashlib
path = "project-handbook/status/evidence/TASK-039/example-eval-error.index.mjs"
with open(path, "rb") as f:
  print(hashlib.sha256(f.read()).hexdigest())
PY
)"
printf '%s\n' "$EVAL_ERROR_SHA256" | tee "$EVID_DIR/example-eval-error.sha256.txt"

EXPORT_INVALID_SHA256="$(python3 - <<'PY'
import hashlib
path = "project-handbook/status/evidence/TASK-039/example-export-invalid.index.mjs"
with open(path, "rb") as f:
  print(hashlib.sha256(f.read()).hexdigest())
PY
)"
printf '%s\n' "$EXPORT_INVALID_SHA256" | tee "$EVID_DIR/example-export-invalid.sha256.txt"

# 4) Seed Context module selection for the registry harness (DB-level seed)
# Pick a workspace id to seed (example: query workspaces via Router):
# curl -sS --resolve "router.local:80:127.0.0.1" -H 'content-type: application/json' -H 'x-tenant-id: tribuence' \
#   --data '{"query":"query { workspaces { id slug } }"}' "http://router.local/" | jq

WORKSPACE_ID="PUT-WORKSPACE-ID-HERE"
TENANT_ID="tribuence"

MISSING_SHA256="1111111111111111111111111111111111111111111111111111111111111111"
NOT_ALLOWLISTED_SHA256="0000000000000000000000000000000000000000000000000000000000000000"

docker compose -f v2/infra/compose/docker-compose.v2.yml exec -T postgres \
  psql -v ON_ERROR_STOP=1 -U "${POSTGRES_USER:-postgres}" -d "${POSTGRES_DB:-tribuence_v2}" <<SQL
insert into ui_module_manifests (
  id, tenant_id, workspace_id, capability_id,
  module_id, version, integrity_sha256,
  created_at, updated_at
) values
  ('seed-' || md5(random()::text || clock_timestamp()::text), '${TENANT_ID}', '${WORKSPACE_ID}', 'ui-module-demo-happy', 'example', '${MODULE_VERSION}', '${EXAMPLE_SHA256}', now(), now()),
  ('seed-' || md5(random()::text || clock_timestamp()::text), '${TENANT_ID}', '${WORKSPACE_ID}', 'ui-module-demo-not-allowlisted', 'not-allowlisted', '${MODULE_VERSION}', '${NOT_ALLOWLISTED_SHA256}', now(), now()),
  ('seed-' || md5(random()::text || clock_timestamp()::text), '${TENANT_ID}', '${WORKSPACE_ID}', 'ui-module-demo-missing', 'example-missing', '${MODULE_VERSION}', '${MISSING_SHA256}', now(), now()),
  ('seed-' || md5(random()::text || clock_timestamp()::text), '${TENANT_ID}', '${WORKSPACE_ID}', 'ui-module-demo-hash-mismatch', 'example-hash-mismatch', '${MODULE_VERSION}', '${EXPECTED_SHA256}', now(), now()),
  ('seed-' || md5(random()::text || clock_timestamp()::text), '${TENANT_ID}', '${WORKSPACE_ID}', 'ui-module-demo-eval-error', 'example-eval-error', '${MODULE_VERSION}', '${EVAL_ERROR_SHA256}', now(), now()),
  ('seed-' || md5(random()::text || clock_timestamp()::text), '${TENANT_ID}', '${WORKSPACE_ID}', 'ui-module-demo-export-invalid', 'example-export-invalid', '${MODULE_VERSION}', '${EXPORT_INVALID_SHA256}', now(), now())
on conflict (tenant_id, workspace_id, capability_id)
do update set
  module_id = excluded.module_id,
  version = excluded.version,
  integrity_sha256 = excluded.integrity_sha256,
  updated_at = now();
SQL

# 5) Run Playwright
pnpm -C v2/apps/tribuence-mini exec playwright test 2>&1 | tee "$EVID_DIR/playwright.txt"
```

## Git Integration
```bash
git -C project-handbook status
git -C v2 status
```

## Quick Copy-Paste
```bash
pnpm -C project-handbook make -- validate
pnpm -C v2/apps/tribuence-mini exec playwright test
```
