---
title: v2.1 UI Module Registry (Discovery) Architecture
type: architecture
feature: v2.1_ui-module-registry-discovery
date: 2026-01-07
tags: [architecture]
links:
  - ../../adr/0025-v2-1-ui-module-registry.md
  - ../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md
  - ../../adr/0018-v2-capability-detection-surface.md
  - ../../adr/0022-v2-capability-manifests-and-toggles.md
  - ../../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
---

# Architecture: v2.1 UI Module Registry (Discovery)

## Overview
The UI module registry provides runtime loading of capability UI panels per workspace. Context owns the module manifest
that selects which modules are enabled for a workspace. The UI shell loads only allowlisted modules from an internal
artifact origin with pinned versions and integrity checks.

## DR-0002 — Runtime loader strategy (approved)
The runtime loader strategy is defined in:
- `project-handbook/features/v2.1_ui-module-registry-discovery/decision-register/DR-0002-nextjs-runtime-module-loading-strategy.md`

Approved: **Option A — browser verifies sha256 and imports via Blob URL ESM**.

## Components
- **Context `uiModuleManifest`**: per-workspace mapping from `capabilityId` → `{ moduleId, version, integritySha256 }`.
- **UI shell (Next.js)**: reads capability + module manifest state and loads modules at runtime.
- **Module artifact origin (internal-only)**: serves versioned module artifacts (backed by MinIO).
- **Module allowlist + integrity**: rejects unknown module ids and invalid hashes at runtime.

## Origin Model (selected)
Selected in `DR-0001`: **Option A — proxy module bytes via the UI shell**.

- **Storage**: internal S3-compatible artifact store (`seaweedfs`) accessed server-side using Vault-rendered `/secrets/artifacts.env`.
- **Browser access**: browser never fetches from S3 endpoints; it fetches from a same-origin UI route and verifies sha256 integrity before executing code.

### When to migrate to a dedicated origin (Option B)
Use the “signals to transition Option A → Option B” guidance in `DR-0001` when:
- module byte serving becomes a measurable UI shell bottleneck,
- module artifacts evolve into multi-file bundles/assets,
- or operational/security posture calls for a dedicated “serve bytes” service.

## Data Flow
1) User authenticates and selects a Context workspace.
2) UI queries Context for:
   - capability enablement/status,
   - `uiModuleManifest` for that workspace.
3) For each enabled capability panel, UI resolves `{ moduleId, version, integritySha256 }`.
4) UI resolves `{ moduleId, version, integritySha256 }` into a same-origin fetch:
   - `GET /api/ui-modules/{moduleId}/{version}/{integritySha256}`
5) UI verifies sha256 integrity and then executes the module code:
   - Option A: fetch bytes → sha256 verify → Blob URL → `import(blobUrl)` (verify-before-execute in the browser).
   - Option B: server verifies sha256 → UI `import(url)` (verify-before-execute enforced server-side).
6) If a module is unavailable or fails integrity, the shell renders a deterministic fallback panel state.

## Failure modes (deterministic)
Failure semantics must be deterministic and panel-scoped (the shell continues rendering other panels).

Required failure reasons (codes are stable identifiers, not user-facing copy):
- `NOT_ALLOWLISTED`: module id not in the shell allowlist.
- `FETCH_404`: module bytes not present at the expected `{moduleId, version, integritySha256}` key.
- `FETCH_FAILED`: network error or non-200 response.
- `HASH_MISMATCH`: bytes hash does not match `integritySha256` (Option A browser verification or Option B server verification).
- `EVAL_ERROR`: module evaluation throws.
- `EXPORT_INVALID`: module exports do not match the required contract.

## Dependencies
- Landing page harness and module-ready panel boundaries (ADR-0024).
- Context capability surface and manifests (ADR-0018, ADR-0022).
- Required artifact storage baseline (MinIO required, ADR-0015).
