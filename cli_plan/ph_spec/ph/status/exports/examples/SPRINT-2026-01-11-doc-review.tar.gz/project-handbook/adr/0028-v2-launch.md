---
id: ADR-0028
title: v2 Launch Readiness (Required Baseline Gates)
type: adr
status: accepted
date: 2026-01-07
tags: [tribuence-mini, v2, launch, gates, validation]
links:
  - ../features/v2_launch/overview.md
  - ../features/v2_ui-dev-harness-and-module-boundaries/overview.md
  - ../features/v2_workspace-signup-onboarding/overview.md
  - ../features/v2_context-control-plane-schema/overview.md
  - ../features/v2_registry-cosmo-minio-required/overview.md
  - ../features/v2_schema-publishing-and-composition/overview.md
  - ../features/v2_codegen-from-registry/overview.md
---

# Context

v2 requires a deterministic, validated baseline that can be used as the platform foundation for expanded OSS support.
“Launch” means the v2 stack, schema lifecycle, workspace onboarding, and capability gating are stable and verified by
automated validation gates.

# Decision

## 1) v2 launch is defined by required gates, not feature aspirations

v2 launch readiness is satisfied only when the required gates pass:
- infra baseline is up and healthy (Cosmo + MinIO required),
- observability baseline is up and healthy (Prometheus + Grafana + Loki + Alertmanager),
- schema publishing + composition checks pass and Router runs the expected supergraph,
- codegen runs from registry schemas and typecheck passes,
- auth-gated UI harness is the canonical E2E entrypoint,
- post-auth workspace onboarding creates a Context workspace and triggers provisioning state,
- UI gating uses Context capability state only.

## 2) v2.1 runtime module registry work depends on v2 launch readiness

Runtime module loading is deferred to v2.1 and cannot proceed to execution until v2 launch gates are met.

# Consequences

## Positive
- Clear definition of “done” for v2 launch readiness.
- Prevents moving on to v2.1 runtime module loading while v2 foundations are unstable.

## Tradeoffs
- Some features may be deferred if they are not required by the launch gates.

# Rollout / Acceptance

- `pnpm -C project-handbook make -- validate` passes.
- v2 stack boots and health gates pass for required baseline services.
- Schema publish + composition checks pass and the Router serves the composed supergraph.
- Codegen runs from registry schemas and the v2 UI typechecks.
- Playwright E2E validates login → workspace onboarding → landing harness gating based on Context state.
