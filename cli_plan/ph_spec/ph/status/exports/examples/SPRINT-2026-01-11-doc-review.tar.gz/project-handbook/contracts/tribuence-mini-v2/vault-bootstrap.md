---
title: Tribuence Mini v2 Vault Bootstrap Workflow (Local/Dev)
type: process
date: 2026-01-02
tags: [contracts, vault, bootstrap, secrets, tribuence-mini-v2]
links:
  - ./vault-secrets.md
  - ./twenty-subgraph.md
  - ./anythingllm-subgraph.md
  - ./service-topology.md
  - ../../../v2/ARCHITECTURE.md
---

# Contract: Vault Bootstrap Workflow (v2)

## Purpose
Define a repeatable, low-friction workflow for seeding Vault KV entries required by the v2 stack, including the cases where some secrets can only be minted **after containers are running**.

This contract supports:
- `TASK-010` (bootstrap-v2 KV seeds)
- downstream smoke and schema snapshot tasks (`TASK-013`, `WILD-P3-20251222-1203`)

## Two-Phase Model

### Phase A — Seed “boot-safe” keys (no running containers required)
These can be generated/seeded deterministically without calling any service:
- Random secrets:
  - `NEXTAUTH_SECRET`, `JWT_SECRET`, `CONTEXT_JWT_SECRET`
- Local/dev defaults:
  - `NEXT_PUBLIC_APP_URL=http://app.local`
  - `V2_GRAPHQL_URL=http://router.local/`
  - `TENANT_DEFAULT=tribuence`

Expected behavior:
- Bootstrap should be able to run Phase A even if the compose stack is not up yet.
- If a required key cannot be seeded, fail fast with the KV path + missing key.

### Phase B — Mint “service-derived” keys (requires running containers)
Some keys are easiest (or only possible) to mint from a running service/database:

#### 1) `TWENTY_API_KEY` (Twenty API key token)
Dependency: Twenty database is reachable (local/dev).

Reference implementation (read-only source):
- `modular-oss-saas/scripts/vault/bootstrap-mini.sh` (`generate_twenty_api_key`)

High-level approach:
- Query Twenty DB for:
  - a known `workspace_id`
  - a known `api_key_id`
- Derive a long-lived token using `TWENTY_APP_SECRET`, `workspace_id`, `api_key_id`.

Contract expectation:
- v2 bootstrap either mints `TWENTY_API_KEY` (preferred), or requires an operator-provided `TWENTY_API_KEY` and prints clear instructions.

#### 2) `ANYLLM_API_KEY` (AnythingLLM REST API key)
Dependency: AnythingLLM container is running and can mint an API key.

Reference implementation (read-only source):
- `modular-oss-saas/scripts/vault/bootstrap-mini.sh` (`generate_anythingllm_api_key`)

High-level approach:
- Execute inside the AnythingLLM container and call its server-side API key minting logic to produce a new API key secret.

Contract expectation:
- v2 bootstrap either mints `ANYLLM_API_KEY` (preferred for local/dev), or requires an operator-provided value and prints clear instructions.
- Minting must be **explicit and operator-controlled** (no surprise key rotation):
  - `V2_VAULT_MINT_ANYLLM_API_KEY=true bash v2/scripts/vault/bootstrap-v2.sh`
  - When enabled, mint only if Vault does not already contain a non-placeholder key.

#### 3) `KEYCLOAK_CLIENT_SECRET` (Keycloak confidential client secret)
Dependency: Keycloak container is running and the realm import created the confidential client.

Contract expectation:
- v2 bootstrap can fetch the generated client secret and persist it to `kv/data/tribuence/v2/next` without printing it.
- Fetching must be explicit and operator-controlled:
  - `NEXT_PUBLIC_REQUIRE_AUTH=true V2_VAULT_FETCH_KEYCLOAK_CLIENT_SECRET=true bash v2/scripts/vault/bootstrap-v2.sh`
  - When enabled, fetch only if Vault does not already contain a non-placeholder secret.

## Script UX Requirements
Whether implemented as a single script or multiple subcommands, the bootstrap UX must:
- print which phase(s) ran,
- list which KV paths were written,
- clearly call out any keys that could not be minted (and why),
- exit non-zero when required keys are missing (unless explicitly run in a “Phase A only” mode).

Additionally:
- The bootstrap workflow must not silently seed known-unusable placeholders for service-auth tokens (e.g. AnythingLLM API keys).
- Any minting step must not print secrets to stdout/stderr; log only masked/boolean confirmation.

## Linkage
- The required KV paths and key names are defined in `vault-secrets.md`.
- Subgraph auth requirements are defined in:
  - `twenty-subgraph.md`
  - `anythingllm-subgraph.md`
