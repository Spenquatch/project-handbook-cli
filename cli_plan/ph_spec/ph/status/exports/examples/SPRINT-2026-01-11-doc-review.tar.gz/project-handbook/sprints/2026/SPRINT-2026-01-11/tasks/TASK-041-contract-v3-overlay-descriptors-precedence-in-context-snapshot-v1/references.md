---
title: Contract: v3 overlay descriptors + precedence in Context snapshot (v1) - References
type: references
date: 2026-01-11
task_id: TASK-041
tags: [references]
links: []
---

# References: Contract: v3 overlay descriptors + precedence in Context snapshot (v1)

## Internal References

### Decision Context
- **Decision**: [ADR-0033](../../../../adr/0033-module-registry-alignment-with-v3-roadmap.md)
- **Decision register**: [DR-0007](../../../../decision-register/DR-0007-module-registry-alignment-with-v3-roadmap.md)
- **Feature (Context control-plane)**: [Overview](../../../../features/v2_context-control-plane-schema/overview.md)
- **Feature (v3 overlays)**: [Overview](../../../../features/v3_client-customization-overlays/overview.md)

### Sprint Context
- **Sprint Plan**: [Current sprint](../../plan.md)
- **Sprint Tasks**: [All sprint tasks](../)
- **Daily Progress**: [Daily status](../../../../status/daily/)

### Contracts (targets to edit)
- `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md`
- `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md`

### Upstream Tasks (must be done first)
- [TASK-032](../TASK-032-contract-context-control-plane-snapshot-graphql-contract-v1/README.md)
- [TASK-033](../TASK-033-contract-context-control-plane-db-schema-v1-tables-constraints/README.md)

## Notes
Add concrete links here only when you discover resources during the task (no placeholders).
