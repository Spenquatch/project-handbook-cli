---
title: Investigate: Next.js runtime module loading (allowlist + sha256) - References
type: references
date: 2026-01-11
task_id: TASK-027
tags: [references]
links: []
---

# References: Investigate: Next.js runtime module loading (allowlist + sha256)

## Internal References

### Decision Context
- **Decision**: `DR-0002` (create during this task)
- **Feature**: [Feature overview](../../../../../features/v2.1_ui-module-registry-discovery/overview.md)
- **Architecture**: [Feature architecture](../../../../../features/v2.1_ui-module-registry-discovery/architecture/ARCHITECTURE.md)

### Canonical Process
- **Agent workflow**: [AI Agent Start Here](../../../../../process/AI_AGENT_START_HERE.md)
- **Session template**: [research-discovery](../../../../../process/sessions/templates/research-discovery.md)
- **Playbook**: [research-discovery](../../../../../process/playbooks/research-discovery.md)
- **Decision Register**: [DR rules + exact template](../../../../../decision-register/README.md)

### Related Decisions / Contracts
- **ADR-0025**: [UI module registry](../../../../../adr/0025-v2-1-ui-module-registry.md)
- **ADR-0024**: [UI module-ready boundaries](../../../../../adr/0024-v2-ui-dev-harness-and-module-boundaries.md)

### Sprint Context
- **Sprint Plan**: [Current sprint](../../plan.md)
- **Sprint Tasks**: [All sprint tasks](../)
- **Daily Progress**: [Daily status](../../daily/)

## Notes
Add concrete links here only when you discover resources during the task (no placeholders).
