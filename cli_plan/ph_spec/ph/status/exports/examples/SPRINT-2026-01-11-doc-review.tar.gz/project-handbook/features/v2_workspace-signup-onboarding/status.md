---
title: v2 Workspace Signup Onboarding Status
type: status
feature: v2_workspace-signup-onboarding
date: 2026-01-07
tags: [status]
links:
  - ../../adr/0026-v2-workspace-signup-onboarding.md
---

# Status: v2 Workspace Signup Onboarding

Stage: approved

## Now
- Locked post-auth onboarding posture: Keycloak self-registration + first-login workspace creation into the landing harness.

## Next
- Enable Keycloak self-registration in the v2 realm and add deterministic drift detection for realm/client settings.
- Wire workspace creation to Context provisioning and add Playwright coverage.

## Cross-Task Dependencies (SPRINT-2026-01-07)
- `TASK-011` provides Context teardown (`workspaceDelete`) and is required before onboarding E2E can be a deterministic gate.
- `TASK-012` provides Keycloak teardown (`deleteUserByUsername`) and is required before onboarding E2E can be a deterministic gate.
- `TASK-013` provides `/onboarding` UX + stable selectors and is required before the spec can be low-flake.
- `TASK-014` is blocked on `TASK-006` (gate runner) plus `TASK-011`..`TASK-013` and turns the onboarding flow into a launch gate with evidence output.

## Risks
- Cross-workspace leakage (mitigated by strict scoping and E2E isolation tests).
- Onboarding becomes brittle due to IdP configuration drift (mitigated by automated realm bootstrap and smoke checks).

## Recent
- Feature created

## Sprint Links (manual)
### SPRINT-2026-01-07
- [`TASK-001` Keycloak admin creds non-default (Vault or fail-fast)](../../sprints/archive/2026/SPRINT-2026-01-07/tasks/TASK-001-bug-p1-20260105-083807-keycloak-admin-creds-non-default-vault-or-fail-fast/README.md)
- [`TASK-004` Keycloak self-registration realm bootstrap (discovery)](../../sprints/archive/2026/SPRINT-2026-01-07/tasks/TASK-004-work-p2-20260107-110638-keycloak-self-registration-realm-bootstrap-discovery/README.md)
  - Decision: [`DR-0001`](decision-register/DR-0001-keycloak-self-registration-bootstrap.md)
  - Target output: [`implementation/KEYCLOAK_SELF_REGISTRATION.md`](implementation/KEYCLOAK_SELF_REGISTRATION.md)
- [`TASK-009` Enable Keycloak self-registration realm import (local/dev)](../../sprints/archive/2026/SPRINT-2026-01-07/tasks/TASK-009-work-p2-enable-keycloak-self-registration-realm-import-local-dev/README.md)
- [`TASK-010` Add Keycloak realm drift smoke check (kcadm + evidence)](../../sprints/archive/2026/SPRINT-2026-01-07/tasks/TASK-010-work-p2-add-keycloak-realm-drift-smoke-check-kcadm-evidence/README.md)
- [`TASK-005` Playwright onboarding harness E2E (discovery)](../../sprints/archive/2026/SPRINT-2026-01-07/tasks/TASK-005-work-p2-20260107-110646-playwright-signup-workspace-create-landing-harness-e2e-d/README.md)
  - Decision: [`DR-0002`](decision-register/DR-0002-playwright-onboarding-e2e-cleanup-strategy.md)
  - Target output: [`testing/PLAYWRIGHT_ONBOARDING_E2E.md`](testing/PLAYWRIGHT_ONBOARDING_E2E.md)
- Execution follow-ups (after `FDR-v2_workspace-signup-onboarding-0002` acceptance):
  - [`TASK-011` Context workspaceDelete mutation (E2E teardown)](../../sprints/archive/2026/SPRINT-2026-01-07/tasks/TASK-011-work-p2-context-workspacedelete-mutation-e2e-teardown/README.md)
  - [`TASK-012` Keycloak E2E deleteUser helper + teardown hook](../../sprints/archive/2026/SPRINT-2026-01-07/tasks/TASK-012-work-p2-keycloak-e2e-deleteuser-helper-teardown-hook/README.md)
  - [`TASK-013` UI onboarding route + data-testid for Playwright](../../sprints/archive/2026/SPRINT-2026-01-07/tasks/TASK-013-work-p2-ui-onboarding-route-data-testid-for-playwright/README.md)
  - [`TASK-014` Playwright onboarding E2E spec + gate runner wiring](../../sprints/archive/2026/SPRINT-2026-01-07/tasks/TASK-014-work-p2-playwright-onboarding-e2e-spec-gate-runner-wiring/README.md)

## Active Work (auto-generated)
*Last updated: 2026-01-11*

### Current Sprint (SPRINT-2026-01-11)
- No active tasks in current sprint

### Recent Completed (last 5 tasks)
- ✅ TASK-009: WORK-P2: Enable Keycloak self-registration realm import (local/dev) (2pts) - SPRINT-2026-01-07
- ✅ TASK-010: WORK-P2: Add Keycloak realm drift smoke check (kcadm + evidence) (2pts) - SPRINT-2026-01-07
- ✅ TASK-005: WORK-P2-20260107-110646: Playwright signup→workspace create→landing harness E2E (discovery) (3pts) - SPRINT-2026-01-07
- ✅ TASK-011: WORK-P2: Context workspaceDelete mutation (E2E teardown) (2pts) - SPRINT-2026-01-07
- ✅ TASK-014: WORK-P2: Playwright onboarding E2E spec + gate runner wiring (3pts) - SPRINT-2026-01-07

### Metrics
- **Total Story Points**: 22 (planned)
- **Completed Points**: 22 (100%)
- **Remaining Points**: 0
- **Estimated Completion**: SPRINT-2026-W03
- **Average Velocity**: 21 points/sprint

