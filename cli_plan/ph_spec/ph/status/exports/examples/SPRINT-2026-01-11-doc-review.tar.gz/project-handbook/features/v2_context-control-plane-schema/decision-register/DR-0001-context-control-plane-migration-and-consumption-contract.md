---
title: DR-0001 — Context control-plane migration + wrapper/UI consumption contract
type: decision-register
date: 2026-01-11
tags: [decision-register, v2, context, control-plane, schema, migration, wrappers, contract]
links:
  - ../../../adr/0027-v2-context-control-plane-schema.md
  - ../../../adr/0018-v2-capability-detection-surface.md
  - ../../../contracts/tribuence-mini-v2/context-subgraph.md
  - ../../../contracts/tribuence-mini-v2/context-db-schema.md
  - ../../../status/evidence/TASK-029/index.md
---

# Decision Register Entry

### DR-0001 — Context control-plane migration + wrapper/UI consumption contract

**Decision owner(s):** v2 platform (@spenser)  
**Date:** 2026-01-11  
**Status:** Accepted  
**Related docs:**  
- `project-handbook/adr/0027-v2-context-control-plane-schema.md`  
- `project-handbook/features/v2_context-control-plane-schema/fdr/0001-context-control-plane-snapshot-contract.md`  
- `project-handbook/status/evidence/TASK-029/index.md`  
- `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md`  
- `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md`  

**Problem / Context**
- `ADR-0027` requires Context to expose a single, stable workspace-scoped control-plane snapshot query used for *all* UI and wrapper gating (manifests, status, links, jobs/runs summary, setup guidance, and future UI module selection).
- Today, `v2/services/context/` only implements `ContextWorkspace` + `ContextReference` (v0 schema + resolvers). We need an additive migration plan that grows this service into the control plane without breaking existing callers.
- We need a wrapper/UI consumption contract: headers, determinism guarantees, caching/timeout/fallback semantics, and invariants (tenant/workspace scoping; idempotency keys; no provider secrets stored/returned).

**Option A — Additive expansion in existing Context service (single canonical snapshot query)**
- **Pros:** Lowest operational complexity; directly satisfies `ADR-0027`; keeps a single system-of-record; simplest for local/dev and smoke tests.
- **Cons:** Context becomes a “wide” foundational service; requires discipline to keep schema additive and avoid provider-specific leakage.
- **Cascading implications:**
  - Context subgraph adds a canonical snapshot query owned by Context; consumers do not invent alternative gating surfaces.
  - Wrapper subgraphs **do not call the Apollo Router** for gating (avoid recursion). They call Context directly (service-to-service) and forward the relevant headers.
- **Risks:**
  - Schema churn risks breaking gating; mitigated by additive-only rules + contract docs + smoke probes.
  - Slow snapshot queries could degrade UX; mitigated by indexing + summaries (job history summary, not full logs) + strict timeouts and deterministic fallback.
- **Unlocks:**
  - Consistent gating UX across UI + wrappers.
  - Durable provisioning audit trail and deterministic remediation guidance.
  - v2.1 UI module selection can be wired without changing the gating contract shape.
- **Quick wins / low-hanging fruit:**
  - Ship the snapshot query early returning empty lists for new surfaces while write paths land incrementally.
  - Reuse the existing header contract (`x-tenant-id`, `x-workspace-id`) already used by Context v0.

  **Canonical snapshot query (proposed contract)**
  ```graphql
  type Query {
    # workspaceId is optional; falls back to `x-workspace-id`
    contextControlPlaneSnapshot(workspaceId: ID): ContextControlPlaneSnapshot!
  }

  type ContextControlPlaneSnapshot {
    workspace: ContextWorkspace!
    manifests: [ContextCapabilityManifest!]!
    statuses: [ContextCapabilityStatus!]!
    integrationLinks: [ContextIntegrationLinkSummary!]!
    jobs: [ContextIntegrationJobSummary!]!
    setupGuidance: [ContextSetupGuidance!]!
    uiModuleManifests: [ContextUiModuleManifest!]!
    generatedAt: DateTime!
  }

  type ContextCapabilityManifest {
    capabilityId: String!
    enabled: Boolean!
    updatedAt: DateTime!
  }

  enum ContextCapabilityStatusState {
    DISABLED
    PROVISIONING
    READY
    DEGRADED
    ERROR
  }

  type ContextCapabilityStatus {
    capabilityId: String!
    state: ContextCapabilityStatusState!
    detail: String
    updatedAt: DateTime!
  }
  ```

  **Wrapper/UI consumption contract (proposed)**
  - **Headers:** `x-tenant-id` required; `x-workspace-id` required unless using `workspaceId` argument.
  - **UI transport:** UI calls the snapshot query via Router (same as other v2 UI GraphQL calls).
  - **Wrapper transport:** wrapper subgraphs call Context directly (service-to-service) using the internal Context URL (avoid Router recursion), forwarding `x-tenant-id`, `x-workspace-id`, and `authorization` (if present).
  - **Timeouts:** consumers must set strict timeouts (suggested default: 1500ms) and treat timeout as a deterministic gating failure.
  - **Fallback:** if snapshot fetch fails, default to “stub / gated” behavior (no side effects, no provisioning actions).
  - **Caching:** no-store by default; any caching must be short-lived and must not allow stale “enabled” state to persist after disable.
  - **Invariants:** snapshot must never return provider secrets; DB must store only provider identifiers and credential *reference IDs* (never secret material).

  **Rollout sequencing (proposed)**
  1. Add additive, idempotent SQL migrations for new tables and indices (keep v0 intact).
  2. Add the snapshot query returning empty-safe arrays (schema-first).
  3. Add writes/mutations + worker/job wiring incrementally (manifests → links → jobs/runs → status).
  4. Add smoke probes asserting snapshot shape stability and basic invariants.

**Option B — Dedicated control-plane subgraph (Context writes; consumers read from a separate control-plane graph)**
- **Pros:** Separates “write-y” Context concerns from a stable read contract; can scale reads independently; isolates schema evolution from other Context surfaces.
- **Cons:** Introduces another service (deployment, routing, health, ops); requires duplication (read model or direct DB reads) and introduces consistency concerns.
- **Cascading implications:**
  - New subgraph/service owns the canonical snapshot query; Context either emits events or shares DB access patterns for the read model.
  - Wrappers/UI must be updated to point gating to the new graph, and federation composition becomes stricter.
- **Risks:**
  - Eventual consistency can produce confusing gating (manifest says enabled, but read-model says disabled).
  - More moving parts for local/dev bring-up, increasing time-to-debug.
- **Unlocks:**
  - Clear boundary for future “operator control plane” tooling and potential v3 alignment.
- **Quick wins / low-hanging fruit:** none (the overhead is front-loaded before product value lands).

**Recommendation**
- **Recommended:** Option A — Additive expansion in existing Context service (single canonical snapshot query)
- **Rationale:** The current Context service is small and already the intended system-of-record (`ADR-0027`). Option A delivers the contract with the fewest moving parts and the clearest migration path; we can still split into a dedicated read subgraph later if scaling or ownership boundaries demand it.

**Follow-up tasks (explicit)**
- Update `project-handbook/contracts/tribuence-mini-v2/context-subgraph.md` to include the snapshot query + types (v1).
- Update `project-handbook/contracts/tribuence-mini-v2/context-db-schema.md` with control-plane tables + constraints (v1).
- Implement additive SQL migrations under `v2/services/context/db/migrations/` (idempotent `CREATE TABLE IF NOT EXISTS`, indices, uniqueness for idempotency keys).
- Extend `v2/services/context/index.js` schema + resolvers:
  - `contextControlPlaneSnapshot(workspaceId: ID): ContextControlPlaneSnapshot!` (workspaceId optional; falls back to `x-workspace-id` like existing reference APIs).
  - Enforce “no provider secrets stored/returned”; store only provider identifiers and credential reference IDs.
- Add a v2 smoke probe that calls the snapshot query and asserts shape stability (empty-safe, deterministic).
- Update v2 UI to call the snapshot query once per workspace selection and pass the snapshot to capability panels for deterministic gating.
- Update wrapper subgraphs to:
  - fetch snapshot with strict timeouts,
  - default to safe “stub mode” on missing/errored snapshot.

**Operator approval request**
- Approved on 2026-01-12: Option A (“additive expansion in existing Context service”).
