---
id: ADR-0029
title: v2 Observability + Runbooks (Prometheus/Loki/Grafana Baseline)
type: adr
status: accepted
date: 2026-01-07
tags: [tribuence-mini, v2, observability, monitoring, logs, runbooks]
links:
  - ../features/v2_observability-and-runbooks/overview.md
  - ../features/v2_launch/overview.md
---

# Context

v2 requires deterministic operational visibility to be considered launch-ready. Health endpoints alone are insufficient;
operators and developers need a consistent metrics/logs surface and runbook entrypoints for diagnosing failures in the
stack, schema lifecycle, and capability provisioning.

# Decision

## 1) v2 includes a required local observability baseline

The v2 stack includes an observability baseline that is part of the default bring-up and validated by smoke gates:
- Prometheus for metrics collection,
- Grafana for dashboards,
- Loki (and log shipping) for centralized logs,
- Alertmanager for deterministic alert routing stubs.

## 2) v2 defines required dashboards and runbook entrypoints

v2 includes deterministic dashboards for:
- Apollo Router,
- Context service,
- AnythingLLM subgraph,
- v2 UI shell,
- Keycloak and Vault (auth + secrets dependencies).

Runbook entrypoints are documented in the Project Handbook and linked from the feature documentation.

## 3) v1 infra assets are the reference implementation

v1 already contains infra-level observability wiring; v2 reuses the same patterns and configuration layout as reference:
- `modular-oss-saas/infra/observability/*`
- `modular-oss-saas/infra/*`
- `modular-oss-saas/scripts/*`

# Consequences

## Positive
- Deterministic operational visibility for v2 launch readiness.
- Clear, repeatable troubleshooting posture for development and CI.

## Tradeoffs
- Additional always-on containers in the default v2 stack.

# Rollout / Acceptance

- v2 bring-up includes the observability stack and smoke validation fails if it is unhealthy.
- Grafana dashboards exist for the required services and show live metrics/logs.
- Runbook entrypoints exist in `project-handbook` and are linked from the v2 feature docs.
