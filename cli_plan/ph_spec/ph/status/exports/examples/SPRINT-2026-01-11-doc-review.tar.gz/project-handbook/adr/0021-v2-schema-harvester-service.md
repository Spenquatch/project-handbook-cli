---
id: ADR-0021
title: v2 Schema Harvester Service (Publish + Mirror)
type: adr
status: accepted
date: 2026-01-06
tags: [tribuence-mini, v2, schema, harvester, cosmo, federation]
links:
  - ../features/v2_schema-harvester-service/overview.md
  - ../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
---

# Context

As capability count grows, schema publishing must be automated, repeatable, and traceable. Manual introspection and hand
edited snapshots drift and break composition.

# Decision

## 1) Add a dedicated schema harvester service

The harvester runs inside the v2 network and is responsible for:
- introspecting subgraphs (or reading their committed contract SDL where introspection is intentionally disabled),
- publishing subgraph schemas to Cosmo,
- producing a deterministic publish report.

## 2) Harvester maintains an in-repo mirror of published schemas

After successful publish, the harvester writes updated SDL snapshots into the repository under `v2/infra/compose/graphql/subgraphs/*/schema.graphql`
as a mirror for diffing and debugging. These mirrors are not authoritative; Cosmo is authoritative.

## 3) Publishing is a required gate for composition

The harvester triggers composition checks in Cosmo; publish fails fast when checks fail.

# Consequences

## Positive
- Deterministic schema pipeline across many capabilities.
- Easy diffs for developers and reviewers via the in-repo mirror.

## Tradeoffs
- Requires harvester credentials/tokens and careful secret handling.

# Rollout / Acceptance

- A single command runs the harvester to publish all v2 subgraphs to Cosmo.
- Harvester writes mirror SDL snapshots into the repo after publish.
- Composition checks run as part of publish and block invalid schema changes.
