---
title: DR-0004 — Vault Seeding + Secrets Contract for Cosmo/MinIO (No Leakage)
type: decision-register
date: 2026-01-09
tags: [decision-register, vault, cosmo, minio, security]
links:
  - ../releases/current/plan.md
  - ../adr/0015-tribuence-mini-v2-cosmo-minio-and-schema-publishing.md
  - ../features/v2_registry-cosmo-minio-required/overview.md
---

# Decision Register Entry

### DR-0004 — Vault Seeding + Secrets Contract for Cosmo/MinIO (No Leakage)

**Decision owner(s):** @spenser  
**Date:** 2026-01-09  
**Status:** Accepted  
**Related docs:** `ADR-0015`, `ADR-0030`, `FDR-v2_registry-cosmo-minio-required-0001`, `v2_registry-cosmo-minio-required`, `TASK-002`

**Problem / Context**
- This DR ID was reserved during sprint planning to enable a `session=research-discovery` task; it must be completed in `TASK-002` and requires operator/user approval before being marked `Accepted`.
- The Cosmo/MinIO baseline introduces new credentials and tokens (DB creds, MinIO keys, Cosmo API tokens). The default v2 posture requires: Vault-seeded, Vault Agent-rendered, and never printed to stdout/stderr or evidence artefacts.
- This decision defines:
  - the Vault KV paths + required field names (no values),
  - the rendered `/secrets/*.env` contract (which env files exist and who consumes them),
  - bootstrap behavior (idempotent, no secret printing),
  - and a posture checklist for evidence/log hygiene.

**Evidence (repo inspection; no values)**
- `project-handbook/status/evidence/TASK-002/index.md`

**Option A — Single v2 KV layout + rendered env files (`/secrets/cosmo.env`, `/secrets/minio.env`)**
- **Contract shape**
  - **KV paths (Vault KV v2)**
    - `kv/data/tribuence/v2/minio`
      - `MINIO_ACCESS_KEY`
      - `MINIO_SECRET_KEY`
      - `COSMO_S3_BUCKET`
    - `kv/data/tribuence/v2/cosmo`
      - `COSMO_POSTGRES_USER`
      - `COSMO_POSTGRES_PASSWORD`
      - `COSMO_POSTGRES_DB`
      - `COSMO_CLICKHOUSE_DB`
      - `COSMO_CLICKHOUSE_USER`
      - `COSMO_CLICKHOUSE_PASSWORD`
      - `COSMO_AUTH_JWT_SECRET`
      - `COSMO_AUTH_ADMISSION_SECRET`
      - `COSMO_KEYCLOAK_ADMIN`
      - `COSMO_KEYCLOAK_ADMIN_PASSWORD`
      - `COSMO_SEED_API_KEY`
      - `COSMO_SEED_USER_EMAIL`
      - `COSMO_SEED_USER_PASSWORD`
      - `COSMO_SEED_ORG`
      - Optional config (non-secret but centralized): `S3_REGION`, `S3_FORCE_PATH_STYLE`, `COSMO_CONTROLPLANE_ALLOWED_ORIGINS`, `COSMO_WEB_BASE_URL`
  - **Rendered env files**
    - `/secrets/minio.env` (consumed by: `minio`, and optionally any bucket-init helper)
      - `MINIO_ROOT_USER` (from `MINIO_ACCESS_KEY`)
      - `MINIO_ROOT_PASSWORD` (from `MINIO_SECRET_KEY`)
    - `/secrets/cosmo.env` (consumed by: `cosmo-controlplane`, `cosmo-cdn`, `cosmo-seed`)
      - Uses Cosmo + MinIO fields to derive:
        - `DB_URL` (Postgres DSN for Cosmo)
        - `CLICKHOUSE_DSN`, `CLICKHOUSE_MIGRATION_DSN`
        - `S3_STORAGE_URL`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY`, `S3_REGION`, `S3_FORCE_PATH_STYLE`
      - Contains required Cosmo auth/Keycloak/seed fields above (names only in contract).
  - **v2 template files to exist**
    - `v2/infra/vault/templates/minio.env.tpl` → `/secrets/minio.env`
    - `v2/infra/vault/templates/cosmo.env.tpl` → `/secrets/cosmo.env`
    - `v2/infra/vault/templates/agent.hcl` updated to render both (like existing `next.env.tpl`, `router.env.tpl`, etc.)

**Addendum — Cosmo CLI auth env (`/secrets/cosmo-cli.env`)**
- Context: some non-Cosmo helpers (e.g. Router-lane `supergraph-sync`, Harvester publish/check jobs) need Cosmo control-plane API access via Cosmo CLI (`wgc`) without expanding secret blast radius to Router or unrelated services.
- **KV path (Vault KV v2)**
  - `kv/data/tribuence/v2/cosmo-cli`
    - `COSMO_API_KEY` (secret)
    - `COSMO_API_URL` (non-secret; internal control plane URL, e.g. `http://cosmo-controlplane:3001`)
    - `COSMO_FEDERATED_GRAPH_NAME` (non-secret; e.g. `tribuence`)
    - `COSMO_FEDERATED_GRAPH_NAMESPACE` (non-secret; e.g. `dev`)
- **Rendered env file**
  - `/secrets/cosmo-cli.env` (consumed by: `supergraph-sync` and Harvester jobs; never by `apollo-router`)
    - renders the exact keys above (names/values; never printed to logs/evidence)
- **v2 template files to exist**
  - `v2/infra/vault/templates/cosmo-cli.env.tpl` → `/secrets/cosmo-cli.env`
  - `v2/infra/vault/templates/agent.hcl` updated to render it
- **Pros:**
  - Matches the existing v2 pattern: one KV path + one env template per domain/service (`next`, `router`, `context`, `anythingllm`) and a small number of `/secrets/*.env` outputs.
  - Keeps bootstrap changes localized: extend `v2/scripts/vault/bootstrap-v2.sh` with two new payload blocks (MinIO + Cosmo) using the same “sanitize + placeholder” approach already present.
  - Minimizes template/file churn for the first baseline implementation task.
- **Cons:**
  - Coarser-grained: `cosmo.env` includes env needed by multiple Cosmo containers (controlplane/cdn/seed), so those containers see more env vars than strictly required.
  - If/when additional Cosmo components are added, the single KV entry can grow.
- **Cascading implications:**
  - Implementation work will mount `/secrets/cosmo.env` into the subset of Cosmo services that need it; avoid mounting it broadly.
  - SeaweedFS cutover can keep the same S3-shaped vars in `cosmo.env` (only the endpoint + creds change).
- **Risks:**
  - Over-privileged env file mount could expand the blast radius if a container is compromised (still internal-only in dev, but worth minimizing).
  - Secret hygiene regressions if bootstrap or evidence collection captures values (mitigated by checklist and existing “value not printed” patterns).
- **Unlocks:**
  - Unblocks `TASK-006` by providing an explicit KV/template contract and safe bootstrap behavior.
  - Provides a single, stable contract for bucket-init + Cosmo services to consume.
- **Quick wins / low-hanging fruit:**
  - Reuse existing v2 bootstrap helper patterns (sanitize, placeholder detection, “value not printed” messaging).
  - Reuse existing Vault Agent plumbing (`agent.hcl` template stanzas) with minimal additions.

**Option B — Per-service KV keys + per-service templates (more granular)**
- **Contract shape**
  - **KV paths (Vault KV v2)**
    - `kv/data/tribuence/v2/minio`
      - `MINIO_ACCESS_KEY`, `MINIO_SECRET_KEY`, `COSMO_S3_BUCKET`
    - `kv/data/tribuence/v2/cosmo-controlplane`
      - `COSMO_POSTGRES_USER`, `COSMO_POSTGRES_PASSWORD`, `COSMO_POSTGRES_DB`
      - `COSMO_CLICKHOUSE_DB`, `COSMO_CLICKHOUSE_USER`, `COSMO_CLICKHOUSE_PASSWORD`
      - `COSMO_AUTH_JWT_SECRET`, `COSMO_AUTH_ADMISSION_SECRET`
      - `COSMO_KEYCLOAK_ADMIN`, `COSMO_KEYCLOAK_ADMIN_PASSWORD`
      - Optional config: `S3_REGION`, `S3_FORCE_PATH_STYLE`, `COSMO_CONTROLPLANE_ALLOWED_ORIGINS`, `COSMO_WEB_BASE_URL`
    - `kv/data/tribuence/v2/cosmo-cdn`
      - `COSMO_AUTH_JWT_SECRET`, `COSMO_AUTH_ADMISSION_SECRET` (or reference from `cosmo-controlplane`)
    - `kv/data/tribuence/v2/cosmo-seed`
      - `COSMO_SEED_API_KEY`, `COSMO_SEED_USER_EMAIL`, `COSMO_SEED_USER_PASSWORD`, `COSMO_SEED_ORG`
  - **Rendered env files**
    - `/secrets/minio.env` (minio)
    - `/secrets/cosmo-controlplane.env` (controlplane)
    - `/secrets/cosmo-cdn.env` (cdn)
    - `/secrets/cosmo-seed.env` (seed)
  - **v2 template files to exist**
    - `v2/infra/vault/templates/minio.env.tpl`
    - `v2/infra/vault/templates/cosmo-controlplane.env.tpl`
    - `v2/infra/vault/templates/cosmo-cdn.env.tpl`
    - `v2/infra/vault/templates/cosmo-seed.env.tpl`
    - `v2/infra/vault/templates/agent.hcl` updated to render all of the above.
- **Pros:**
  - Follows least-privilege: seed user credentials don’t need to be visible to the controlplane/cdn containers.
  - Scales better as Cosmo services expand (each service owns its own env contract).
- **Cons:**
  - More KV entries, templates, and compose wiring to implement and keep in sync.
  - Slightly higher bootstrapping complexity (multiple payloads and more “required field” checks).
- **Cascading implications:**
  - Bucket init and any future harvester/publisher jobs will need to pick the correct env file (or a shared “artifacts” env) to access S3 creds.
  - If other services need Cosmo tokens later (router refresh, harvester publish), additional env templates may be required.
- **Risks:**
  - More moving parts increases the chance of drift (a required env var missing in one of the per-service templates).
  - More files means more places to accidentally log/capture env values during debugging.
- **Unlocks:**
  - Clean separation of responsibilities and a safer-by-default posture for seed credentials.
- **Quick wins / low-hanging fruit:**
  - Still reuses the same v2 mechanisms (Vault Agent template stanzas + bootstrap sanitize/placeholder patterns); it’s additive, just broader.

**Recommendation**
- **Recommended:** Option A — Single v2 KV layout + rendered env files (`/secrets/cosmo.env`, `/secrets/minio.env`)
- **Rationale:** It is the smallest contract that cleanly extends the existing v2 Vault pattern and keeps the first Cosmo/MinIO baseline implementation focused on wiring + posture, not template sprawl. If we later find seed creds or Cosmo token separation is required, we can evolve to Option B with a follow-up DR and mechanical KV/template splits.

**Guidance: signals to transition from Option A → Option B (examples)**
- **Least-privilege requirements emerge:** A security review (or upcoming prod-like workflow) requires that `cosmo-controlplane` and/or `cosmo-cdn` must not have access to seed user credentials (`COSMO_SEED_USER_PASSWORD`) or other one-shot bootstrap secrets.
- **New consumers need subsets:** Harvester/router/publisher jobs need a Cosmo token or S3 creds, but should not inherit the full `cosmo.env` surface (e.g., only need publish token + S3, not DB admin secrets).
- **Rotation cadence diverges:** Some secrets need frequent/independent rotation (e.g., Cosmo API token vs DB password) and bundling them in one env contract increases blast radius or downtime.
- **Operational drift becomes painful:** Operators are regularly editing a large `kv/data/tribuence/v2/cosmo` entry and mistakes/overwrites are happening; splitting into per-service KV paths reduces accidental coupling.
- **Hardening posture upgrades:** Introducing host port bindings (even to `127.0.0.1`) or any external exposure increases the value of tighter secret scoping, making Option B a safer default.

**Follow-up tasks (explicit)**
- After operator/user approval of Option A:
  - Implement Vault contract in v2 (likely `TASK-006`):
    - Add KV payload seeding to `v2/scripts/vault/bootstrap-v2.sh` for `kv/data/tribuence/v2/minio` and `kv/data/tribuence/v2/cosmo` (idempotent; never prints values).
    - Add templates: `v2/infra/vault/templates/minio.env.tpl`, `v2/infra/vault/templates/cosmo.env.tpl`.
    - Update `v2/infra/vault/templates/agent.hcl` to render `/secrets/minio.env` and `/secrets/cosmo.env`.
  - Wire compose to consume the rendered env files:
    - `v2/infra/compose/docker-compose.v2.yml`: add Cosmo + MinIO services and mount `secrets` volume; use `env_file: /secrets/*.env` and avoid printing env.
  - Add a “no secrets printed” validation gate:
    - Confirm scripts never run with `set -x` around secret handling.
    - Add a grep-based check in probes/CI (if present) that disallows `cat /secrets/` usage.

**Operator/user approval**
- Approved: **Option A** (operator/user approval received 2026-01-10).
